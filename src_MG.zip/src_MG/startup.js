var mygalleriesGA = {};
$(document).ready(function(){
	
	mygalleriesGA = new com.art.core.tracking.GoogleAnalytics("My Galleries");
    mygalleriesGA.init();
   
       
//    html {
//    	  filter: expression(document.execCommand("BackgroundImageCache", false, true));
//    	}

    var viewMode = "";
    var loc = window.location.href;
    if (loc.indexOf('item/') > -1) {
        viewMode = MyGalleriesCore.constants.DETAIL_VIEW;
    }
    else {
    	var regex = /gallery\/.+/;
        
        if (loc.match(regex) == undefined || com.art.core.utils.BrowserUtil.getQueryString("logout"))
            viewMode = MyGalleriesCore.constants.GALLERY_HOME;
        else
            viewMode = MyGalleriesCore.constants.GRID_VIEW;
    }
	MyGalleriesCore.init(MyGalleriesEnvironmentVariables, viewMode);
		
	MyGalleriesCore.addToEnvironment('isMyGalleryPage',(location.href.indexOf("/me/") > -1 || location.href.indexOf("mygalleries.asp") ) > -1);
	//MyGalleriesCore.addToEnvironment('isMyGalleryPage',location.href.indexOf("me") > -1? true: false);
	MyGalleriesCore.addToEnvironment('isExternalPage',location.href.indexOf("/me/") == -1);

	if(typeof _galleryPageOptionJson != 'undefined')
		_galleryPageOptionJson = (_galleryPageOptionJson == "True") ? true : false;
	else
		_galleryPageOptionJson = false;
	MyGalleriesCore.addToEnvironment('isDetailView',_galleryPageOptionJson);
		
	MyGalleriesCore.addToEnvironment('selectedGalleryItemId','');
	
	if($('.MyGalleriesSelected').length > 0)
	{
		var getId = $('.MyGalleriesSelected').attr('id');
		getId = getId.split("_");
		MyGalleriesEnvironmentVariables.selectedGalleryID = getId[1];
	}	
	
	if(MyGalleriesEnvironmentVariables.isMyGalleryPage)
	{
		// inherting the header 
	    $('.headerMnuLink:last-child').live('mouseover', function() {
	        $(this).addClass('headerMnuLinkLastChild');
	    });
	    $('.headerMnuLink:last-child').live('mouseout', function() {
	        $(this).removeClass('headerMnuLinkLastChild');
	    });
	    $('.popup').live('mouseover', function() {
	        var sel = "#" + $(this).attr('id') + "Link";
	        $(sel).addClass('overridemenu');
	    });
	    $('.popup').live('mouseout', function() {
	        var sel = "#" + $(this).attr('id') + "Link";
	        $(sel).removeClass('overridemenu');
	    });
			
		//build shell
		if(typeof _galleryDataJson != 'undefined')
			MyGalleriesCore.getModel().setGalleries(_galleryDataJson);
		//if(typeof mygalitemsortby != 'undefined')
			//MyGalleriesEnvironmentVariables.galleryItemSort = mygalitemsortby;
		
		var cookieobject = new com.art.core.cookie.Cookie();        
		var mygalitemprivacy=cookieobject.getCookieDictionary('arts','mygalitemprivacy');
		
		if(mygalitemprivacy!="")
			{
				MyGalleriesEnvironmentVariables.galleryItemPrivacy = mygalitemprivacy;
			}
	
		
		//need to set page number first
		MyGalleriesCore.getModel().setInitialPageNumber(com.art.core.utils.BrowserUtil.getQueryString('page', location.href));
	
	    //now set galleryItems on initial load
		if(typeof _galleryItemDataJson != 'undefined')
			MyGalleriesCore.getModel().setGalleryItems(_galleryItemDataJson,true);

		if($('#thumbNailImageMyGalleries').length > 0)
		{
			if( MyGalleriesEnvironmentVariables.selectedGalleryID != "" && MyGalleriesEnvironmentVariables.selectedGalleryID != undefined)
			{
				var selectedGallery=MyGalleriesEnvironmentVariables.selectedGalleryID;
				$('#thumbNailImageMyGalleries').attr('href',MyGalleriesCore.getModel().cacheByGalleryList[selectedGallery].IconUrl);
				$('#titleMyGalleries').attr('content',MyGalleriesCore.getModel().cacheByGalleryList[selectedGallery].Name);
				$('#descriptionMyGalleries').attr('content',MyGalleriesCore.getModel().cacheByGalleryList[selectedGallery].ShortDescription);
			}	

		}
		//Register Common Modules
		MyGalleriesCore.registerModule(new com.art.myGalleries.modules.TitleBarModule({}, MyGalleriesCore));
		MyGalleriesCore.registerModule(new com.art.myGalleries.modules.ControlBarModule({target:"#controlBar"},MyGalleriesCore));
		MyGalleriesCore.registerModule(new com.art.myGalleries.modules.GridDisplayModule({ target: "#itemsDisplay" }, MyGalleriesCore));	
		MyGalleriesCore.registerModule(new com.art.myGalleries.modules.RoomView({targets:{grid:"#items",details:"#itemsDisplay"}},MyGalleriesCore));
		MyGalleriesCore.registerModule(new com.art.myGalleries.modules.VerticalNavigationModule({target:""},MyGalleriesCore));
		MyGalleriesCore.registerModule(new com.art.myGalleries.modules.ShareModule({target:""},MyGalleriesCore));
		
		//Register Common Command
		MyGalleriesCore.registerSubscriber(new com.art.myGalleries.commands.ApplicationCommand({target:''},MyGalleriesCore));	
		
		//get hash id for view mode; for sharing
		var href = location.href;
		var viewmode = MyGalleriesCore.constants.DEFAULT;
		var hashtagIndex = href.indexOf("#");
		if(hashtagIndex > -1)
			viewmode = href.substring(hashtagIndex+1);
		
		//determine which module to register on startup
		if(viewmode == MyGalleriesCore.constants.GRID_VIEW)
			MyGalleriesCore.registerModule(new com.art.myGalleries.modules.GridDisplayModule({},MyGalleriesCore));
		if(viewmode == MyGalleriesCore.constants.ROOM_VIEW)
			MyGalleriesCore.registerModule(new com.art.myGalleries.modules.RoomView({},MyGalleriesCore));
		if(viewmode == MyGalleriesCore.constants.DEFAULT || viewmode == MyGalleriesCore.constants.GALLERY_HOME)
			MyGalleriesCore.registerModule(new com.art.myGalleries.modules.GalleryHome({},MyGalleriesCore));
			
		//default
		MyGalleriesCore.startAllByViewMode(viewmode);
		trace(MyGalleriesEnvironmentVariables.galleryItemSort);
		trace("id="+MyGalleriesEnvironmentVariables.selectedGalleryID);
		if(MyGalleriesEnvironmentVariables.galleryKey != "")
		{
			var cookieobject = new com.art.core.cookie.Cookie();			
			cookieobject.setCookieDictionary('arts','mygalitemsortby',MyGalleriesEnvironmentVariables.galleryItemSort,'/', cookieobject.getCookieDomain('art'));
		}
		if(MyGalleriesEnvironmentVariables.galleryItemPrivacy!="")
		{
			var cookieobject = new com.art.core.cookie.Cookie();			
			cookieobject.setCookieDictionary('arts','mygalitemprivacy',MyGalleriesEnvironmentVariables.galleryItemPrivacy,'/', cookieobject.getCookieDomain('art'));
		}
		
		//fix art.com layout for project
		$("#HM_Footer").css("height","1px");
		$(".GlobalFooter").css("padding-top","0px");
		$(".GlobalFooter").css("clear","both");
		$("div.clear").css("height","0px");
		$(".GlobalFooter").siblings("br").remove();
		$("#HM_Footer").siblings("div.clear").remove();
		$("#dCustomerZoneID").remove();
		$("#FooterTopBar").css('margin-top','-1px');
	}
	if(MyGalleriesEnvironmentVariables.isExternalPage)
	{
		trace("isProductPage");
		MyGalleriesCore.registerModule(new com.art.myGalleries.modules.ExternalModule({},MyGalleriesCore));
		
		//Register Common Command
		MyGalleriesCore.registerSubscriber(new com.art.myGalleries.commands.ApplicationCommand({target:''},MyGalleriesCore));	
		
		MyGalleriesCore.startModule(com.art.myGalleries.modules.ExternalModule.NAME);					
		
	}	
	if(MyGalleriesEnvironmentVariables.isDetailView)
	{
		$("#background").hide();
		$("#sortby").hide();
		$("#privacy").hide();
		$("#share").hide();
		MyGalleriesCore.registerModule(new com.art.myGalleries.modules.DetailView({},MyGalleriesCore));
		MyGalleriesCore.startModule(com.art.myGalleries.modules.DetailView.NAME);
	}
	
});


