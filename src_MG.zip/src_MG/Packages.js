com.art.myGalleries = {};
com.art.myGalleries.modules = {};
com.art.myGalleries.proxies = {};
com.art.myGalleries.components = {};
com.art.myGalleries.commands = {};
com.art.myGalleries.vos = {};