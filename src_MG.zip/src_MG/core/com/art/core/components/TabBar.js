com.art.core.components.TabBar = function(id)
{
	this.init();
	this.RIGHT = "right";
	this.id = id;
	//this is required so we can append before this item
	//if contol tab is ALIGN right
	this.firstControlTabID;
	this.guids = {};
	this.tabsById = {};
	this.tabs = [];
	this.controlTabs = [];
	this.gradients = {"webkit":"-webkit-gradient(linear, left top, left bottom, from(white), to(#F0F0F0))","mozilla":"-moz-linear-gradient(center top , #FFFFFF, #F0F0F0) repeat scroll 0 0 transparent","default":"#DDDDDD"};
	this.browser = $.browser;
	this.gradient = this.browser.webkit?"webkit":this.browser.mozilla?"mozilla":"default";
	this.tabStyleActive = {
			"display":"inline-block",
			"background":this.gradients[this.gradient],
			"filter":"progid:DXImageTransform.Microsoft.gradient(startColorstr='#FFFFFF', endColorstr='#F0F0F0')",
			"borderRight":"1px solid #DCDDDE",
    		"borderTop":"1px solid #DCDDDE",
    		"borderLeft":"1px solid #DCDDDE",
			"display":"inline-block",
			"fontFamily":"Arial, Helvetica, sans-serif",
			"fontSize":"14px",
			"fontStyle":"normal",
			"padding":"9px 3px 8px",
			"text-shadow": "0 1px #FFFFFF",
			"marginRight":"1px",
			"cursor":"pointer",
			"color":"#3A261E",
			"float":"left",
			"list-style-type":"none"
	};
	this.tabStyleSelected = {
			"display":"inline-block",
			"background":"",
			"backgroundColor":"#757D8D",
			"borderRight":"1px solid #D4D4D4",
    		"borderTop":"1px solid #D4D4D4",
    		"borderLeft":"1px solid #D4D4D4",
			"display":"inline-block",
			"fontFamily":"Arial, Helvetica, sans-serif",
			"fontSize":"14px",
			"fontStyle":"normal",
			"padding":"9px 3px 8px",
			"marginRight":"1px",
			"textShadow":"",
			"textDecoration":"none",
			"color":"#FFFFFF",
			"cursor":"default",
			"filter":"",
			"float":"left",
			"list-style-type":"none"
	};
};
com.art.core.components.TabBar.prototype.hasTabById = function(id)
{
	return this.tabsById[id] != undefined;
};
com.art.core.components.TabBar.prototype.render = function(){
	
	return this.template.replace(/\$ID/g,this.id).replace("$W", this.width);
};
com.art.core.components.TabBar.prototype.template = "<ul id='$ID' style='padding:0px;margin:0px;border-bottom:0px solid; width:$Wpx;height:34px;'><li id='$ID_end' style='list-style-type:none;clear:all;'/></ul>";
com.art.core.components.TabBar.prototype.addTab = function(id,label,callback,isControlTab)
{
	var isControlTab = isControlTab != undefined;
	var _this = this;
	var key = 'str_' + com.art.core.utils.StringUtil.generateUID();
	this.guids[key] = {id:id,label:label,callback:callback,isActive:true,isControlTab:isControlTab,key:key};
	this.tabsById[id] = {id:id,label:label,callback:callback,isActive:true,isControlTab:isControlTab,key:key};
	
	if(isControlTab)
	{
		
		$("#"+this.id+"_end").before("<li id='"+key+"'>"+label+"</li>");
		$("#"+key).css({"display":"inline-block","padding":"10px 10px 5px","cursor":"pointer","list-style-type":"none","float":"left"});
		
		if(this.firstControlTabID == null)
			this.firstControlTabID = key;
		
		this.controlTabs.push(key);
	}
	else
	{
		if(this.firstControlTabID != null)
			$("#"+this.firstControlTabID).before("<li id='"+key+"'>"+label+"</li>");
		else
			$("#"+this.id+"_end").before("<li id='"+key+"'>"+label+"</li>");
		$("#"+key).css(this.tabStyleActive);
		
		//stack of tabs
		this.tabs.push(key);
		
	}
	$("#" + key).click(function(){
		var k = $(this).attr("id");
		var obj = _this.guids[k];
		if(!obj.isControlTab)
		{
			_this.resetAllTabs();
			$(this).css(_this.tabStyleSelected);
			_this.guids[k].isActive = false;
		}
		
		if(_this.guids[k].callback != null)
			_this.guids[k].callback(obj);
	});
	$("#"+key).mouseover(function(){
		var k = $(this).attr("id");
		if(_this.guids[k].isActive)
			$(this).css("text-decoration","underline");
	});
	$("#"+key).mouseout(function(){
		var k = $(this).attr("id");
		if(_this.guids[k].isActive)
			$(this).css("text-decoration","none");
	});
};
//clear all instantiated tabs
//start from scratch
com.art.core.components.TabBar.prototype.clearAllTabs = function()
{
	$("#"+this.id).html("");
	this.tabs 			= [];
	this.controlTabs 	= [];
	this.tabsById		= {};
	this.guids 			= {};
	this.firstControlTabID = null;
};
com.art.core.components.TabBar.prototype.resetAllTabs = function()
{
	trace("resetAllTabs:");
	for(var i=0; i < this.tabs.length; i++)
	{
		$("#"+this.tabs[i]).css(this.tabStyleActive);
		this.guids[this.tabs[i]].isActive = true;
	}
};

/**
 * Remove a tab by its ID, we also clean up all data associated with that tab
 * @param id
 */
com.art.core.components.TabBar.prototype.removeTabById = function(id)
{
	var tmp = [];
	for(var _id in this.tabsById)
	{
		if(_id == id)
		{
			var key = this.tabsById[id].key;
			delete this.tabsById[id];
			delete this.guids[key];
			for(var i=0; i < this.tabs.length; i++)
			{
				if(this.tabs[i] != key)
				{
					tmp.push(this.tabs[i]);
				}
			}
			$("#"+key).unbind("click");
			$("#"+key).unbind("mouseover");
			$("#"+key).unbind("mouseout");
			$("#"+key).remove();
			$("#"+key).empty();
		}
	}
	this.tabs = tmp;
	delete tmp;
};
com.art.core.components.TabBar.prototype.removeTab = function()
{
	if(this.hasTabs())
	{
		var p = this.tabs.pop();
		$("#"+p).remove();
	}
};
com.art.core.components.TabBar.prototype.getControlTabByIndex = function(index)
{
	if(this.controlTabs[index] == undefined)
		throw new Error("com.art.core.components.TabBar failed! ControlTab index is undefined.");
	return this.controlTabs[index];
};
com.art.core.components.TabBar.prototype.selectTabByIndex = function(index)
{
	trace("selectTabByIndex: "+index);
	if(this.tabs[index] == undefined)
		throw new Error("com.art.core.components.TabBar.selectTabByIndex failed! No index given tabs["+index+"].");
	var id = this.tabs[index];
	trace("id: "+id);
	$("#"+id).css(this.tabStyleSelected);
	this.guids[id].isActive = false;
};
com.art.core.components.TabBar.prototype.isInitialized = function()
{
	return this.tabs.length > 0 && this.controlTabs.length > 0;
};
com.art.core.components.TabBar.prototype.isRendered = function()
{
	var w = $("#" + this.id).width();
	return w > 0;
};

com.art.core.components.TabBar.prototype.show = function()
{
	trace("tabBar.show");
	$("#"+this.id).css("display","block");
};

com.art.core.components.TabBar.prototype.hide = function()
{
	$("#"+this.id).css("display","none");
};


com.art.core.components.TabBar.prototype.hasTabs = function()
{
	return this.tabs.length > 0;
};
com.art.core.components.BaseComponent.extend(com.art.core.components.TabBar.prototype);