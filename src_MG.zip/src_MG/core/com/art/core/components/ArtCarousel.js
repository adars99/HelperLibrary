com.art.core.components.ArtCarousel = function(id,width,height,customHashKeyLabel)
{
	this.init();
    this.id = id;
    this.width = width;
    this.itemWidths = 0;
    this.height	= height;
    this.totalItems = 0;
    this.currentlySelectedIndex = 0;
    this.currentlySelectedObject = {};
    this.currentHoverObject = {};
    this.itemCollection = [];
    this.customHashKeyLabel = customHashKeyLabel ? customHashKeyLabel : "";
    this.itemHash = {}; //optional
    this.SCROLL_INTERVAL = 150; //ms
    this.SCROLL_RATE = .5; //per ms
    this.SCROLL_AREA_WIDTH = 150;
    this.SCROLL_MIN = this.SCROLL_AREA_WIDTH;
    this.SCROLL_MAX = this.width - (this.SCROLL_AREA_WIDTH + 35 ); //35 is ~width of righthand button
    this.scrollDirection;
    this.scrollTimerID;
    this.scrollMouseXPosition = 0; 
    this.NAME = com.art.core.components.ArtCarousel.NAME;
    this.LEFT = "scrollLeft";
    this.RIGHT = "scrollRight";
    this.currentlySelectedItemRendererIndex = -1;
    this.MOUSE_OVER = com.art.core.components.ArtCarousel.MOUSE_OVER;
    this.MOUSE_OUT 	= com.art.core.components.ArtCarousel.MOUSE_OUT;
    this.CLICK		= com.art.core.components.ArtCarousel.CLICK;
};
com.art.core.components.ArtCarousel.NAME = "ArtCarousel.NAME";
com.art.core.components.ArtCarousel.MOUSE_OVER = "ArtCarousel_mouseover";
com.art.core.components.ArtCarousel.MOUSE_OUT = "ArtCarousel_mouseout";
com.art.core.components.ArtCarousel.CLICK = "ArtCarousel_click";
 

com.art.core.components.ArtCarousel.prototype.setCustomHashKey = function(key)
{
	this.customHashKeyLabel = key;
	this.itemHash = new Object();
};
    
/**
 * Outputs markup for component
 * @method render
 * @returns {String}
 */

com.art.core.components.ArtCarousel.prototype.isRendered = function()
{
	var w = parseInt($("#"+this.id).width());
	return  (w > 0);
};

com.art.core.components.ArtCarousel.prototype.stopIntervals = function()
{
	window.clearInterval(this.scrollTimerID);
};

com.art.core.components.ArtCarousel.prototype.render = function () {
    return this.getTemplate();
};


com.art.core.components.ArtCarousel.prototype.clearCallbacks = function () {
	trace("artCarousel.clearCallbacks");
    this.callbacks = {};
};


com.art.core.components.ArtCarousel.prototype.getItemsCount = function()
{
	return this.totalItems;
};


com.art.core.components.ArtCarousel.prototype.getCarousel = function()
{
	return $("#"+this.id+"_jcarousel");
};
/**
 * Adding itmes to carousel; entire collection at once
 * @param arr
 */
com.art.core.components.ArtCarousel.prototype.addItems = function(arr)
{
	this.removeEvents();
	
	this.totalItems 	= arr.length;
	this.itemCollection = arr;
	this.selectedIndex 	= 0;
	this.itemWidths		= 0;
	this.selectedObject = arr[0];
	
	this.clearEvents();
	this.removeEvents();
	this.clearCallbacks();
	
	//clear first
	if(this.getCarousel().data("jcarousel") != undefined)
		this.getCarousel().data("jcarousel").reset();
	
	this.getCarousel().jcarousel({
		size: arr.length,
		scroll:1,
		itemFallbackDimension: this.width
	});
	
	
	for(var i = 0; i < arr.length; i++)
	{
		this.indexItemByCustomKey(arr[i]);
		
		if(arr[i].itemRenderer.render() == undefined || arr[i].itemRenderer.render() == "")
			throw new Error("ArtCarousel failed! Item does not have markup property.");
		try
		{
			var str = arr[i].itemRenderer.render();
			this.getCarousel().jcarousel('add', i + 1,str); //<div id="someKey_i" index="i">..</div>
		}
		catch(e)
		{
			throw new Error('ArtCarousel failed! Unable to add item[error:'+e.message+'].');
		}
		
		$("#"+arr[i].itemRenderer.id).addClass(this.getCommonClassName());
		
		this.itemWidths += $("#"+arr[i].itemRenderer.id).width();
	}
	trace("itemWidths: "+this.itemWidths);
	var _this = this;
	$("."+this.getCommonClassName()).mouseover(function(e){
		var id = $(this).attr("id");
		
		trace("MOUSEOVER: "+id);
		trace($(this));
		
		var _index = parseInt($(this).attr("index"));
		if(_this.currentHoverObject.NAME == undefined)
		{
			trace("currentHoverObject init");
			_this.currentHoverObject = _this.itemCollection[_index];
		}
		else
		{
			trace("mouseover _index: "+_index);
			trace(" mouseover _this.currentHoverObject.itemRenderer.index: " +_this.currentHoverObject.itemRenderer.index);
		}
		
		
		trace("MOUSEOVER TRIGGERED");
		
		if(_this.callbacks[_this.MOUSE_OVER] != null)
		{
			var obj = _this.itemCollection[_index];
			_this.callbacks[_this.MOUSE_OVER](obj);
		}
		_this.startScroll();
	});
	$("."+this.getCommonClassName()).mouseout(function(e){
		var id = $(this).attr("id");
		
		var _index = parseInt($(this).attr("index"));

		trace(_this.currentHoverObject.itemRenderer.index);

		
		if(_this.callbacks[_this.MOUSE_OUT] != null)
		{
			
			var obj = _this.itemCollection[_index];
			_this.callbacks[_this.MOUSE_OUT](obj);
		}
		_this.stopScroll();
	});
	$("."+this.getCommonClassName()).bind("click",function(){
		_this.currentlySelectedObject = _this.itemCollection[parseInt($(this).attr("index"))];
		if(_this.callbacks[_this.CLICK] != null)
			_this.callbacks[_this.CLICK](_this.itemCollection[parseInt($(this).attr("index"))]);
	});

	$("."+this.getCommonClassName()).bind("mousemove",function(e)
	{
		_this.scrollMouseXPosition = e.pageX;
	});
	this.getCarousel().css("width","0px"); //reset first
	this.getCarousel().css("width",(this.itemWidths + 2)+"px");
	
};
com.art.core.components.ArtCarousel.prototype.clearEvents = function()
{
	trace("clear mouse movements");
	this.getCarousel().unbind("mouseover");
	this.getCarousel().unbind("mouseout");
	this.getCarousel().unbind("mousemove");
	this.getCarousel().unbind("click");
};
com.art.core.components.ArtCarousel.prototype.indexItemByCustomKey = function(obj)
{
	if(this.customHashKeyLabel != "")
	{
		
		if(obj[this.customHashKeyLabel] == undefined)
			throw new Error("ArtCarousel.addItems failed! customHashKeyLabel is undefined.");
		var key = obj[this.customHashKeyLabel];
		this.itemHash[key]= obj;
		
		
	}
};


com.art.core.components.ArtCarousel.prototype.getItemByCustomKey = function(key)
{	
	//not yet added to ArtCarousel
	if(this.itemHash[key] == undefined)
		return;
	
	return this.itemHash[key];
};
com.art.core.components.ArtCarousel.prototype.removeEvents = function()
{
	trace("removeEvents");
	$("."+this.getCommonClassName()).unbind("mouseover");
	$("."+this.getCommonClassName()).unbind("mouseout");
	$("."+this.getCommonClassName()).unbind("click");
};


com.art.core.components.ArtCarousel.prototype.startScroll = function()
{
	trace("startScroll");
	var _this = this;
	this.scrollTimerID = window.setInterval(function(){
		trace("interval running");
		
		var ul 				= $("#"+_this.id+"_jcarousel"); //<ul> is at the root of JCarousel; this is the element that scrolls left/right
		var ulLeft		 	= ul.position().left;
		var ulWidth	 		= ul.width();
		var offsetLeft 		= ul.parent().offset().left;
		var containerWidth 	= ul.parent().width();
		var mousePosition 	= _this.scrollMouseXPosition - offsetLeft;
		var inc 			= _this.SCROLL_INTERVAL * _this.SCROLL_RATE;
		var newLeft;
		if( ((mousePosition < _this.SCROLL_MIN) || (mousePosition > _this.SCROLL_MAX)) && (ulWidth > containerWidth) )
		{
			var scrollRight = (mousePosition < _this.SCROLL_MIN);
			
			trace("scrollRight:"+scrollRight);
			trace("ulLeft:"+ulLeft);
			
			//safeguards
			if(ulLeft > 0) ul.css("left","0px");
			if(ulLeft < (containerWidth - ulWidth)) ul.css("left",(containerWidth - ulWidth)+"px");
			
			
			
			//scroll direction logic
			if(scrollRight)
			{
				ul.jcarousel("prev"); //",1,true);
			}
			else
			{
				ul.jcarousel("next");
			}
		}
		
	},this.SCROLL_INTERVAL);
};
com.art.core.components.ArtCarousel.prototype.stopScroll = function(obj)
{
	window.clearInterval(this.scrollTimerID);
};
com.art.core.components.ArtCarousel.prototype.doScroll = function(obj)
{
};



com.art.core.components.ArtCarousel.prototype.getCommonClassName = function()
{
	return this.id+"_klass";
};


/**
 * Select item in carousel by index, ItemRenderer will determine selected state
 * @param index
 */
com.art.core.components.ArtCarousel.prototype.selectItemByIndex = function(index,scrollToFlag)
{
	if(scrollToFlag)
	{
		var ul 					= $("#"+this.id+"_jcarousel");
		var ulWidth				= ul.width();
		var itemWidth			= Math.round(this.itemWidths/this.itemCollection.length);
		var containerWidth		= ul.parent().width();
		var numberOfItemsInView	= Math.floor(containerWidth/itemWidth);
		var scrollToIndex = index > (this.itemCollection.length-numberOfItemsInView) ? this.itemCollection.length-numberOfItemsInView : index;
		
		this.getCarousel().jcarousel("scroll",scrollToIndex);
	}
	
	this.deSelectItemByIndex();
	this.currentlySelectedItemRendererIndex = index;
	this.itemCollection[this.currentlySelectedItemRendererIndex].itemRenderer.select();
	this.currentlySelectedObject = this.itemCollection[this.currentlySelectedItemRendererIndex];
	
};
com.art.core.components.ArtCarousel.prototype.deSelectItemByIndex = function()
{
	if(this.currentlySelectedItemRendererIndex == -1 || this.currentlySelectedItemRendererIndex > (this.itemCollection.length-1) )
		return; //ignore of first use
	
	this.itemCollection[this.currentlySelectedItemRendererIndex].itemRenderer.deselect();
};


com.art.core.components.ArtCarousel.prototype.show = function()
{
	$("#"+this.id).css("display","block");
};


com.art.core.components.ArtCarousel.prototype.hide = function()
{
	$("#" + this.id).css("display","none");
};
    
    
com.art.core.components.ArtCarousel.prototype.getTemplate = function () {
	var _this = this;
	setTimeout(function(){
		_this.update();
	},250);
    return this.template.replace(/\$ID/g,this.id).replace("$W",this.width).replace("$H", this.height);
    
};
com.art.core.components.ArtCarousel.prototype.update = function()
{
	$(".jcarousel-skin-jc2 jcarousel-clip jcarousel-clip-horizontal").css("width",this.width - 50 + "px");
};

com.art.core.components.ArtCarousel.prototype.template = '<div id="$ID" style="border:1px solid #DCDDDE; padding:3px;display:inline-block;background-color:#ffffff;">'
	+ '<div id="$ID_jcarousel_container"  style="display:block; width:$Wpx; height:$Hpx;">'
	+ '<ul id="$ID_jcarousel" class="jcarousel-skin-jc2"></ul>'
    + '</div></div>';

com.art.core.components.BaseComponent.extend(com.art.core.components.ArtCarousel.prototype);