/**
 * Lightbox component will dim the contents of target element, useful for displaying modal content on top of target parameter
 * @class LightBox
 * @namespace com.art.core.components
 * @constructor
 * @param id
 * @param target
 * @param opacity
 */
com.art.core.components.LightBox = function (id,target,opacity) {
	this.init();
    this.id = id;
    this.target = target;
    this.opacity = opacity;
    this.CLICK = com.art.core.components.LightBox.CLICK;
    this.zindex = -1;
};
com.art.core.components.LightBox.CLICK = "LightBoxClicked";
com.art.core.components.LightBox.NAME = "LightBox";
/**
 * Default opacity
 * @property opacity
 */
com.art.core.components.LightBox.prototype.opacity = 0.4;

/**
 * Standard function for all components
 * @method getTemplate
 * 
 */
com.art.core.components.LightBox.prototype.getTemplate = function()
{
	return this.template.replace('$ID',this.id).replace("$CONTENTS","").replace(/\$IMAGE_HOST/g, this.getImageHost());
};
/**
 * Closes the lightbox component
 * @method close
 */
com.art.core.components.LightBox.prototype.close = function () {
		
    $("#" + this.id).die("click");
    $("#" + this.id).unbind("click");
    $("#" + this.id).remove();
    $("#" + this.id).empty();
};

/**
 * Used to get document height
 * @method getDocHeight
 * @returns {Number}
 */
com.art.core.components.LightBox.prototype.getDocHeight = function () {
    var calc = Math.max($(document).height(), $(window).height(), /* For opera: */document.documentElement.clientHeight);
    if ($.browser.msie && parseInt($.browser.version) == 7 && (calc > 3000)) 
    {
	    calc = 3000;
    }
    return calc;
};

/**
 * Used to get document width
 * @method getDocWidth
 * @returns {Number}
 */
com.art.core.components.LightBox.prototype.getDocWidth = function () {
    return Math.max($(document).width(), $(window).width(), /* For opera: */document.documentElement.clientWidth);
};
/**
 * Outputs markup for component
 * @method render
 * @returns {String}
 */
com.art.core.components.LightBox.prototype.render = function () {
    this.show();
};
/**
 * Trigger display of LightBox component on top of target element
 * @method show
 */
com.art.core.components.LightBox.prototype.show = function ()
{
	var theTarget = this.target == 'body' ? this.target : '#' + this.target;
	if($("#"+this.id).width() == null)
		$(theTarget).append(this.getTemplate()); //don't append if already there!
	
	var _this = this;
	var nw = (this.target == "body") ? this.getDocWidth() : parseInt($(this.target).width())+"px";
	var nh = (this.target == "body") ? this.getDocHeight() : parseInt($(this.target).height())+"px";
    
    $("#" + this.id).css({
        "position": "absolute",
        "top": "0px",
        "left": "0px",
        "background-color": "#000000",
        "z-index": _this.getLightBoxZIndex(),
        "height": nh,
        "width": nw,
        "filter": "alpha (opacity=" + this.opacity + ")",
        "filter": "progid:DXImageTransform.Microsoft.Alpha(style=0, opacity=" + (this.opacity * 100) + ")",
        "-moz-opacity": this.opacity,
        "opacity": this.opacity,
        "-khtml-opacity": this.opacity
    });
    var _this = this;
    
    if(this.target == 'body')
    {
    	$(window).resize(function () {
            $("#" + _this.id).css({
                "height": _this.getDocHeight(),
                "width": _this.getDocWidth()
            });
        });
    }
};

com.art.core.components.LightBox.prototype.changeOpacity = function (opacity)
{
    this.opacity = opacity;
    
    $("#" + this.id).css({
        "filter": "alpha (opacity=" + this.opacity + ")",
        "filter": "progid:DXImageTransform.Microsoft.Alpha(style=0, opacity=" + (this.opacity * 100) + ")",
        "-moz-opacity": this.opacity,
        "opacity": this.opacity,
        "-khtml-opacity": this.opacity
    });
};

/**
 * Set Lightbox z-index; read all direct child of target and increment by 1
 * @method setLightBoxZIndex
 * @param value optional, if no value is passed in lb will find next highest depth
 */
com.art.core.components.LightBox.prototype.setLightBoxZIndex = function(value)
{
	if(value != undefined)
	{
		this.zindex = value;
	}
	else
	{
		var _this = this;
		var count = 0;
		$("*").each(function(){
			if($(this).attr('id') != _this.id)
			{
				var zindex = parseInt($(this).css("z-index"));
				if(zindex >= _this.zindex && zindex != Number.NaN)
				{
					_this.zindex = zindex + 1;
				}
			}
			count++;
		});
		if(this.zindex == -1)
			this.zindex = 1;
	}
	
};
/**
 * Return LightBox z-index style property
 * @method getLightBoxZIndex
 * @return {Number}
 */
com.art.core.components.LightBox.prototype.getLightBoxZIndex = function()
{
	if(this.zindex == -1)
		this.setLightBoxZIndex();
	
	return this.zindex;
};

com.art.core.components.LightBox.prototype.registerEvents = function()
{
	var _this = this;
	$("#"+this.id).unbind("click");
	$("#"+this.id).click(function(){
		trace("LB clicked");
		_this.close();
		if(_this.callbacks[_this.CLICK] != undefined)
			_this.callbacks[_this.CLICK]();
	});
};
com.art.core.components.LightBox.prototype.template = '<div id="$ID" class="core_lightbox"></div>';
com.art.core.components.BaseComponent.extend(com.art.core.components.LightBox.prototype);