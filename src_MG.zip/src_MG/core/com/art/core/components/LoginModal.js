/**
 * 
 * Login modal dialog box. This modal is used to login-in/log-out in entire website.
 * @class LoginModal
 * @constructor
 * @param id
 * @param brand
 * 
 */
com.art.core.components.LoginModal = function (id, loginTitle, registerTitle, brand, loginOption) {
    this.init();
     this.id = id;
    this.loginTitle = loginTitle;
    this.registerTitle = registerTitle;
    this.brand = brand;
    this.loginOption=loginOption;
    this.base = new com.art.core.components.BaseModal("myModalLogin", 300, "#f7f7ed", true);
    this.CLOSE_CLICKED = com.art.core.components.LoginModal.CLOSE_CLICKED;
    this.REGISTER_CLICKED = com.art.core.components.LoginModal.REGISTER_CLICKED;
    this.LOGIN_CLICKED = com.art.core.components.LoginModal.LOGIN_CLICKED;
    this.ON_FACEBOOK_LOGIN_SUCCESS = com.art.core.components.LoginModal.ON_FACEBOOK_LOGIN_SUCCESS;
    this.registerStatus = false;
    
};
com.art.core.components.LoginModal.CLOSE_CLICKED = "LoginModalCloseClicked";
com.art.core.components.LoginModal.REGISTER_CLICKED = "RegisterButtonClicked";
com.art.core.components.LoginModal.LOGIN_CLICKED = "LoginButtonClicked";
com.art.core.components.LoginModal.ON_FACEBOOK_LOGIN_SUCCESS = "onFaceBookLoginSuccess";
/*
* This method is used to render the HTML template
* @method render()
*/

com.art.core.components.LoginModal.prototype.render = function (zindex) {
    //return this.getTemplate();
    this.base.setContents(this.getTemplate(zindex));
    return this.base.render(zindex + 1);
};


com.art.core.components.LoginModal.prototype.initSubmitButtons = function()
{
	var _this = this;
	 
	this.base.registerButton("mygallerylogin", com.art.core.components.ArtButton.ART_ORANGE, "Login", function () {
        trace("login button clicked");
        var emailAddressVal = $("#" + _this.id + "_txtUsername").val();
        var passwordVal = $("#" + _this.id + "_txtPassword").val();
       
        if (_this.loginValidation(emailAddressVal, passwordVal, 'undefined')) {
            if (_this.callbacks[_this.LOGIN_CLICKED] != undefined)
                _this.callbacks[_this.LOGIN_CLICKED]();
        }        
    });
	       
    this.base.registerButton("mygalleryregister", com.art.core.components.ArtButton.ART_ORANGE, "Register", function () {
        trace("login button clicked");
        
        var emailAddressVal = $("#" + _this.id + "_txtRegUsername").val();
        var passwordVal = $("#" + _this.id + "_txtRegPassword").val();
        var confirmPasswordVal = $("#" + _this.id + "_txtRegConfirmPassword").val();        
       
        if (_this.loginValidation(emailAddressVal, passwordVal, confirmPasswordVal)) {
            if (_this.callbacks[_this.REGISTER_CLICKED] != undefined)
                _this.callbacks[_this.REGISTER_CLICKED]();
        }
    });
   
};
/**
* Used this method to send register username and password
* @method geRegisterUserData
*/
com.art.core.components.LoginModal.prototype.getRegisterAccountData = function () {    
    //Encrypt the username and password before sending
    return { username: $("#" + this.id + "_txtRegUsername").val(), password: $("#" + this.id + "_txtRegPassword").val() };
};

/**
* Used this method to login mygallery by using username and password
* @method getLoginAccountData
*/
com.art.core.components.LoginModal.prototype.getLoginAccountData = function () {
    //Encrypt the username and password before sending
    return { username: $("#" + this.id + "_txtUsername").val(), password: $("#" + this.id + "_txtPassword").val() };
};
/*
* This method is used to handle the events e.g. click
* @method registerEvents()
*/
com.art.core.components.LoginModal.prototype.registerEvents = function () {

    var _this = this;
   
    
    //Register the login button and handle login error message
    $("#" + _this.id + "_ErrorMsg").hide();
    if($.browser.msie && parseInt($.browser.version)==8)
    	{  
    	if(this.id=="myGalleryLogin")    	
		   {	
    		$("#myGalleryLogin_loginTabs").css("height","36px");
    		$("#myGalleryLogin_registerTabs").css("height","36px");
    		$('.logintab_content').css('margin-top','5px');
		   }
    	else
    		{
    	
	   		$('#baseExtend').css('width','100%');		    
	  		$(".loginModalErrorMsg").css("width","250px");		    
			$("#myGalleryLogin_loginTabs").css("height","36px");
			$("#myGalleryLogin_registerTabs").css("height","36px");
		    $("#mygallerylogin").css("height","32px");
			$("#mygallerylogin").css("left","80px");
			$("#mygallerylogin_label").css("height","32px");
			$("#mygallerylogin_rightcap").css("height","32px");
			$("#mygalleryregister_label").css("height","32px");
			$("#mygalleryregister_rightcap").css("height","32px");
			$("#mygalleryregister_label").css("height","32px");
			$("#mygalleryregister").css("left","70px");
			$("#mySaveToGalleryLogin_viewTerm").css("position","relative");
			$("#mySaveToGalleryLogin_viewTerm").css("bottom","-110px");
			$("#mySaveToGalleryLogin_viewTerm").css("left","-150px");
    		}
    	}
    if($.browser.msie && parseInt($.browser.version)==7)
    		{
	   if(this.id=="myGalleryLogin")
			   {
		   		$('#baseExtend').css('width','90%');
		   		$(".loginModalTxt").css("width","230px");
		  		$(".loginModalPass").css("width","230px");
		  		$('.loginModalPassword').css("width","230px");
		  		$(".loginModalErrorMsg").css("width","250px");
			    $(".registerModalPass").css("width","230px");
			    $('.registerModalPassword').css("width","230px");
			    $(".loginModalConfPass").css("width","230px");
			    $('.loginModalConfPassword').css("width","230px");
			    $('.loginModalConfPassword').css("width","230px");
				$("#myGalleryLogin_loginTabs").css("height","36px");
				$("#myGalleryLogin_registerTabs").css("height","36px");
				$('.logintab_content').css('margin-top','5px');
		   }
	   else
		   {
		   		$('#baseExtend').css('width','100%');
		  		$(".loginModalErrorMsg").css("width","250px");
				$("#myGalleryLogin_loginTabs").css("height","36px");
				$("#myGalleryLogin_registerTabs").css("height","36px");
			    $("#mygallerylogin").css("height","32px");
				$("#mygallerylogin").css("left","80px");
				$("#mygallerylogin_label").css("height","32px");
				$("#mygallerylogin_rightcap").css("height","32px");
				$("#mygalleryregister_label").css("height","32px");
				$("#mygalleryregister_rightcap").css("height","32px");
				$("#mygalleryregister_label").css("height","32px");
				$("#mygalleryregister").css("left","70px");
				$("#mySaveToGalleryLogin_viewTerm").css("position","relative");
				$("#mySaveToGalleryLogin_viewTerm").css("bottom","-110px");
				$("#mySaveToGalleryLogin_viewTerm").css("left","-150px");
		   }
    }
   
    //Register the register button and handle register error message


    trace("LoginModal registerEvents");
    var _this = this;    
    
    if(this.loginOption=="SignUp")
	{
    	$("ul.tabs li:nth-child(2)").addClass("active").show(); //Activate second tab
    	$(".logintab_content").hide(); //Show first tab content
        $("#mygalleryregister").show();
        $("#mygallerylogin").hide(); //show the login button
        $(".registertab_content").show(); //Hide all content
        $(".loginModalErrorMsg").hide(); //Hide the login/register error message
        if($.browser.msie)
        	{
        		$('.registertab_content').css('margin-top','5px');
        	}
        		
	}
    else
	{
    	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
    	$(".logintab_content").show(); //Show first tab content
    	$(".registertab_content").hide(); //Hide all content
        $("#mygalleryregister").hide();
	}
    

    //    // Reset the password value on page loading
    $('.loginModalPass').val('');
    $('.loginModalConfPass').val('');
    // Reset the email address value on page loading
    $('.loginModalTxt').val('Email Address');
    $('.loginModalPassword').val('Password');
    $('.loginModalConfPassword').val('Confirm Password');
    
    $('.loginModalPass').hide();
    $('.loginModalConfPass').hide();
    $('.registerModalPass').hide();
    
    $('.loginModalTxt').focusin(function () {
        $(this).css("color", "#333333");
        if ($(this).val() == "Email Address") {
            $(this).val('');
        }
    });

    $('.loginModalTxt').focusout(function () {
        $(this).css("color", "#999999");
        if ($(this).val() == "") {
            $(this).val('Email Address');
        }
    });
    
    
        $('.loginModalPassword').live('click',function () {        	
	        $(this).css("color", "#333333");
	        if ($(this).val() == "Password") {
	        	$('.loginModalPassword').hide();        
	            $('.loginModalPass').show();
	            $('.loginModalPass').focus();
	         }
        });
        
        $('.loginModalPassword').live('keyup', function(e) {
        	$(this).css("color", "#333333");        	
        	if ($(this).val() == "Password") {
        		$('.loginModalPassword').hide();        
                $('.loginModalPass').show();
                $('.loginModalPass').focus();
        	}
        });
        
        $('.loginModalPassword').live('keydown', function(e) {
        	$(this).css("color", "#333333");
        	if ($(this).val() == "Password") {
        		$('.loginModalPassword').hide();        
                $('.loginModalPass').show();
                $('.loginModalPass').focus();
        	}
        });

//        $('.loginModalPassword').focusin(function () {
//        	if(_this.ieHackForFocus) return;
//            $(this).css("color", "#333333");        
//            if ($(this).val() == "Password") {        	
//            	$('.loginModalPassword').hide();
//                $('.loginModalPass').show();
//                $('.loginModalPass').focus();
//            }
//        });
        
    $('.loginModalPass').focusout(function () {
        $('.loginModalPassword').css("color", "#999999");
        if ($(this).val() == "") {        	
        	$('.loginModalPass').hide();
        	$('.loginModalPassword').show();
            $('.loginModalPassword').val('Password');
        }
    });
    
    $('.registerModalPassword').live('click',function () {
        $(this).css("color", "#333333");
        if ($(this).val() == "Password") {
        	$('.registerModalPassword').hide();
            $('.registerModalPass').show();
            $('.registerModalPass').focus();
        }
    });
    $('.registerModalPassword').live('keyup',function () {
        $(this).css("color", "#333333");
        if ($(this).val() == "Password") {
        	$('.registerModalPassword').hide();
            $('.registerModalPass').show();
            $('.registerModalPass').focus();
        }
    });
    $('.registerModalPassword').live('keydown',function () {
        $(this).css("color", "#333333");
        if ($(this).val() == "Password") {
        	$('.registerModalPassword').hide();
            $('.registerModalPass').show();
            $('.registerModalPass').focus();
        }
    });

    $('.registerModalPass').focusout(function () {
        $('.registerModalPassword').css("color", "#999999");
        if ($(this).val() == "") {        	
        	$('.registerModalPass').hide();
        	$('.registerModalPassword').show();
            $('.registerModalPassword').val('Password');
        }
    });
    
    $('.loginModalConfPassword').live('click',function () {
        $(this).css("color", "#333333");
        if ($(this).val() == "Confirm Password") {
        	$('.loginModalConfPassword').hide();
            $('.loginModalConfPass ').show();
            $('.loginModalConfPass ').focus();           
        }
    });
    
    $('.loginModalConfPassword').live('keyup',function () {
        $(this).css("color", "#333333");
        if ($(this).val() == "Confirm Password") {
        	$('.loginModalConfPassword').hide();
            $('.loginModalConfPass ').show();
            $('.loginModalConfPass ').focus();           
        }
    });

    $('.loginModalConfPassword').live('keydown',function () {
        $(this).css("color", "#333333");
        if ($(this).val() == "Confirm Password") {
        	$('.loginModalConfPassword').hide();
            $('.loginModalConfPass ').show();
            $('.loginModalConfPass ').focus();           
        }
    });

    $('.loginModalConfPass').focusout(function () {
        $('.loginModalConfPassword').css("color", "#999999");
        if ($(this).val() == "") {        	
        	$('.loginModalConfPass').hide();
        	$('.loginModalConfPassword').show();
            $('.loginModalConfPassword').val('Confirm Password');
        }
    });
    
    //On login tab click Event
    $("#" + this.id + "_loginTabs").click(function () {
        $("ul.tabs li").removeClass("active"); //Remove any "active" class
        $(this).addClass("active"); //Add "active" class to selected tab
        $(".logintab_content").show(); //Hide login tab content
        $(".registertab_content").hide(); //Show register tab content
        $("#mygalleryregister").hide(); //hide the register button
        $("#mygallerylogin").show(); //show the login button
        var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
        $(activeTab).fadeIn(); //Fade in the active ID content   
        $(".loginModalErrorMsg").hide(); //Hide the login/register error message        

    });

    //On register tab click Event
    $("#" + this.id + "_registerTabs").click(function () {
        $("ul.tabs li").removeClass("active"); //Remove any "active" class
        $(this).addClass("active"); //Add "active" class to selected tab
        $(".registertab_content").show(); //Hide register tab content
        $(".logintab_content").hide(); //show the login tab content
        $('.registertab_content').css('margin-top','5px');
        var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
        $(activeTab).fadeIn(); //Fade in the active ID content                
        $("#mygallerylogin").hide(); // Hide the register button
        $("#mygalleryregister").show(); //show the login button
        $(".loginModalErrorMsg").hide(); //Hide the login/register error message
        
        if($.browser.msie)
		{
        	if(this.id=!"myGalleryLogin")
        		{
        			$("#mySaveToGalleryLogin_viewTerm").css("position","relative");
        			$("#mySaveToGalleryLogin_viewTerm").css("bottom","-110px");
        			$("#mySaveToGalleryLogin_viewTerm").css("left","-150px");
        		}
		}
    });
    //Close the login modal on esc key press
    $(document).bind('keydown', function (escapeKey) {
        if (escapeKey.which == 27 || escapeKey.keyCode == 27) {
            _this.close();
        }
    });
    
    $("#"+this.id+ "_forgetPassLink").click(function(){
    	//window.open="/asp/secure/your_account/get_password.asp";
    	window.open("/asp/secure/your_account/get_password.asp","","left=20,top=20,width=800,height=500,toolbar=0,resizable=0,menubar=0,scrollbars=1");
    });
    
    $("#"+this.id+ "_viewTerm").click(function(){
    	//window.open('/asp/customerservice/privacy_policy.asp','_blank');    	
    	window.open("/asp/customerservice/privacy_policy.asp","","left=20,top=20,width=800,height=500,toolbar=0,resizable=0,menubar=0,scrollbars=1");
    });    
    
    $("#" + _this.id + "_txtPassword").bind('keydown', function (enterKey) { 
    	if (enterKey.which == 13 || enterKey.keyCode == 13) {
    		var emailAddressVal = $("#" + _this.id + "_txtUsername").val();        	
    		var passwordVal = $("#" + _this.id + "_txtPassword").val();
    		if (_this.loginValidation(emailAddressVal, passwordVal, 'undefined')) {    			
    			if (_this.callbacks[_this.LOGIN_CLICKED] != undefined)
                  _this.callbacks[_this.LOGIN_CLICKED]();
    			}
    		}    	
    	});
    
    $("#" + _this.id + "_txtRegConfirmPassword").bind('keydown', function (enterKey) { 
    	if (enterKey.which == 13 || enterKey.keyCode == 13) {
    		var emailAddressVal = $("#" + _this.id + "_txtRegUsername").val();
            var passwordVal = $("#" + _this.id + "_txtRegPassword").val();
            var confirmPasswordVal = $("#" + _this.id + "_txtRegConfirmPassword").val();
            
            if (_this.loginValidation(emailAddressVal, passwordVal, confirmPasswordVal)) {
                if (_this.callbacks[_this.REGISTER_CLICKED] != undefined)
                    _this.callbacks[_this.REGISTER_CLICKED]();
            } 
    	}
  	});
    
    trace("BaseModal registerEvents");
    this.base.registerEvents();

    this.base.registerCallback(com.art.core.components.BaseModal.CLOSE_CLICKED, function () {
        
       // _this.close(); //this.base.close();
        if (_this.callbacks[_this.CLOSE_CLICKED] != undefined)
            _this.callbacks[_this.CLOSE_CLICKED]();
    });
    
    
    $("#facebookBtn").click(function () {
		_this.logIntoFaceBook();
  	});
    $("#regFacebookBtn").click(function () {
    	
		_this.logIntoFaceBook();
  	});
    
    
};
com.art.core.components.LoginModal.prototype.logIntoFaceBook = function () {
    var _this = this;
    FB.getLoginStatus(function(response) {
        if (response.authResponse) {
            // logged in and connected user, someone you know
            _this.handleFacebookLoginSuccess();

        } else {
            // no user session available, someone you dont know
            FB.login(function(response) {
                if (response.authResponse) {
                    // user successfully logged in
                	_this.handleFacebookLoginSuccess('refresh');
                } else {
                    // user cancelled login
                }
            }, { scope: 'email,read_stream' });
        }
    });
};



com.art.core.components.LoginModal.prototype.handleFacebookLoginSuccess = function()
{
	var _this = this;
    //Get the logged in user object.
    FB.api('/me', function(response) {
        try {
        	trace("facebook response: ");
        	trace(response);
        	if(_this.callbacks[_this.ON_FACEBOOK_LOGIN_SUCCESS] != undefined)        		
        		_this.callbacks[_this.ON_FACEBOOK_LOGIN_SUCCESS](response);
        } catch (e) { }
    }); 
};

/**
* Close slideshow
* @method close
*/
com.art.core.components.LoginModal.prototype.close = function () {
    
        $("#" + this.id).unbind("keypress");
        $("#" + this.id).die();
        $("#" + this.id).remove();    
};
/*
* This method is used to validate the login and register screen
* @method loginRegisterValidation()
*/
com.art.core.components.LoginModal.prototype.loginValidation = function (emailAddressVal, passwordVal, confirmPasswordVal) {
    $(".loginModalErrorMsg").hide();
    $(".loginErrorMsg").text('');
    
    $(".loginErrorMsg").css('top','76px'); 
    var hasError = false;

    if ((emailAddressVal == '' || emailAddressVal == 'Email Address') && (passwordVal == '' || passwordVal == 'Password')) {
        $(".loginErrorMsg").text('Email and Password are blank.');
        hasError = true;
    }
    else{
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
        if (emailAddressVal == '' || emailAddressVal == 'Email Address') {
            $(".loginErrorMsg").text('Please enter an email address.');
            hasError = true;
        }
        else if (!emailReg.test(emailAddressVal)) {
            $(".loginErrorMsg").text('Please enter a valid email address.');
            hasError = true;
        }
        if (passwordVal == '' || passwordVal == 'Password') {
            $(".loginErrorMsg").text('Please enter a password.');
            hasError = true;
        }
        else if (confirmPasswordVal != 'undefined') {
            if (confirmPasswordVal == '' || confirmPasswordVal == 'Confirm Password') {
                $(".loginErrorMsg").text('Please enter and confirm password.');
                hasError = true;
            }
            if ((passwordVal != '' || passwordVal != 'Password') && (confirmPasswordVal != '' || confirmPasswordVal != 'Confirm Password')) {
                if (passwordVal != confirmPasswordVal) {
                    $(".loginErrorMsg").text('The passwords do not match');
                    hasError = true;
                }
            }
        }
    }

    if (hasError == true) {    	
    	if($.browser.msie)
 		{
    		 if(this.id!="myGalleryLogin")
	  		   { 
    				$(".loginErrorMsg").css("top","70px");
	  		   }
 		}
        $(".loginModalErrorMsg").show();
        return false;
    }
    else
    {
        return true;
    }
};


/*
* This method is used to get the HTML template and render method use it
* @method getTemplate()
*/
com.art.core.components.LoginModal.prototype.getTemplate = function (zindex) {

    var z = zindex != undefined ? "z-index:" + zindex + ";" : "z-index:1000";
    trace("z: " + z);
    var strFacebook = this.facebookLoginButton;

    var strLogin = this.loginTemplate.replace(/\$NAME/g, this.id).replace("$LOGINTITLE", this.loginTitle).replace("$facebookbtn", strFacebook);
    var strRegister = this.registerTemplate.replace(/\$NAME/g, this.id).replace("$REGISTERTITLE", this.registerTitle).replace("$facebookbtn", strFacebook);
    var str = this.template.replace(/\$NAME/g, this.id).replace("$loginContent", strLogin).replace("$registerContent", strRegister).replace("$ZNDX", z).replace(/\$IMAGE_HOST/g, this.getImageHost());
	   
    return str;

};

/*
* This prototype is used to write the HTML content
* @prototype template
*/

com.art.core.components.LoginModal.prototype.template =
"<ul id='$NAME_tabs' class='tabs' style='$ZNDX;float:left;left:0px;top:0px;#top:0px;width:167px;#width:164px;'>" +
    "<li id='$NAME_loginTabs'><a href='#tab1'>Login</a></li>" +
    "<li id='$NAME_registerTabs'><a href='#tab2'>Sign Up</a></li>" +
"</ul>" +
"<div id='$NAME_loginTabContainer' class='tab_container' style='$ZNDX;'>" +
    "<div id='$NAME_loginTabContent' class='logintab_content'>$loginContent</div>" +
    "<div id='$NAME_registerTabContent' class='registertab_content'>$registerContent</div>"+
"</div>";

com.art.core.components.LoginModal.prototype.loginTemplate =
"<div id='$NAME_ErrorMsg' class='loginModalErrorMsg'><div class='loginModalErrorMsgImg'></div><span class='loginErrorMsg'></span>" +
"</div>" +
"<div id='$NAME_MainContent'>" +
"<div id='$NAME_Title' class='LoginModalTitle'>$LOGINTITLE</div>" +
 "<div style='margin-top:10px;'><input type='text' id='$NAME_txtUsername' name='$NAME_txtUsername' class='loginModalTxt' style='color:#999999;#padding-top:8px;' height='20px' value='Email Address' /></div>" +
 "<div style='margin-top:10px;margin-bottom:10px;'><input type='password' id='$NAME_txtPassword' name='$NAME_txtPassword' class='loginModalPass' style='color:#999999;#padding-top:8px;' height='20px' value='' /></div>" +
 "<div style='margin-top:10px;margin-bottom:10px;'><input type='text' id='$NAME_txtPass' name='$NAME_txtPass' class='loginModalPassword' style='color:#999999;#padding-top:8px;' height='20px' value='Password' /></div>" +
 "<div id='$NAME_forgetPassLink' style='font-family:verdana;font-size:11px;color:#0072BA;float:left;cursor:pointer;'>Forgot your password? </div><br/>" +
 "<div id='contentDivider' style='border:1px solid #CECECE;margin-top:14px;margin-bottom:24px'></div>" +
 "<div id='$NAME_facebookTitle' class='LoginModalTitle'>Login with your Facebook account</div>" +
 "<div id='facebookBtn' style='float:left'>$facebookbtn</div>" +
 "<div class='clear'></div>"+
 "</div>";

com.art.core.components.LoginModal.prototype.registerTemplate =
"<div id='$NAME_ErrorMsg' class='loginModalErrorMsg'><div class='loginModalErrorMsgImg'></div><span class='loginErrorMsg'></span>" +
"</div>" +
"<div id='$NAME_MainContent'>" +
"<div id='$NAME_Title' class='LoginModalTitle'>$REGISTERTITLE</div>" +
 "<div style='margin-top:10px;'><input type='text' id='$NAME_txtRegUsername' name='$NAME_txtRegUsername' class='loginModalTxt' style='color:#999999;#padding-top:8px;' height='20px' value='Email Address' /></div>" +
 "<div style='margin-top:10px;margin-bottom:10px;'><input type='password' id='$NAME_txtRegPassword' name='$NAME_txtRegPassword'  class='registerModalPass' style='color:#999999;padding-left:6px;#padding-top:8px;' height='20px' value='' />"+
 "<div style='margin-top:10px;margin-bottom:10px;'><input type='text' id='$NAME_txtRegPass' name='$NAME_txtRegPass' class='registerModalPassword' style='color:#999999;padding-left:6px;#padding-top:8px;' height='20px' value='Password' /></div>" + 
 "<div style='margin-top:10px;margin-bottom:20px;'><input type='password' id='$NAME_txtRegConfirmPassword' name='$NAME_txtRegConfirmPassword' class='loginModalConfPass' style='color:#999999;padding-left:6px;#padding-top:8px;' height='20px' />"+
 "<div style='margin-top:10px;margin-bottom:20px;'><input type='text' id='$NAME_txtRegConfirmPass' name='$NAME_txtRegConfirmPass' class='loginModalConfPassword' style='color:#999999;padding-left:6px;#padding-top:8px;' height='20px' value='Confirm Password' /></div>" +  
 "<div id='contentDivider' style='border:1px solid #CECECE;margin-top:14px;margin-bottom:24px'></div>" +
 "<div id='$NAME_facebookTitle' class='LoginModalTitle'>Login with your Facebook account</div>" +
 "<div id='regFacebookBtn' style='float:left'>$facebookbtn</div>" +
 "<div id='$NAME_viewTerm' style='font-family:verdana;font-size:11px;color:#0072BA;float:left;position:absolute;bottom:30px;#bottom:45px;left:20px;cursor:pointer;'>Privacy policy</div>" +
 "<div class='clear'></div>" +
 "</div>";

com.art.core.components.LoginModal.prototype.facebookLoginButton =
'<span class="LoginFacebook" style="display: inline;">'+
'<img id="LoginFacebookImg" src="$IMAGE_HOST/images/photostoart/facebook_login.gif">'+
'<div id="fb-root"></div>'+
'</span>';

com.art.core.components.BaseComponent.extend(com.art.core.components.LoginModal.prototype);