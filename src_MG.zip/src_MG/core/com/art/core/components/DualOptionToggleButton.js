/**
 * Dual action toggle button description
 * @class
 * @constructor
 * @param id
 * @param leftLabel
 * @param rightLabel
 * @param leftValue
 * @param rightValue
 * @param sideSelected
 */
com.art.core.components.DualOptionToggleButton = function (id,leftLabel,rightLabel,leftValue,rightValue,sideSelected) {
    this.id = id;
    this.rightLabel = rightLabel;
    this.leftLabel = leftLabel;
    this.rightValue = rightValue;
    this.leftValue = leftValue;
    this.sideSelected = sideSelected == undefined || sideSelected == com.art.core.components.DualOptionToggleButton.LEFT_SIDE ? com.art.core.components.DualOptionToggleButton.LEFT_SIDE : com.art.core.components.DualOptionToggleButton.RIGHT_SIDE;
    this.callbacks = {};
    this.CLICK = com.art.core.components.DualOptionToggleButton.CLICK;
    this.LEFT_SIDE = com.art.core.components.DualOptionToggleButton.LEFT_SIDE;
    this.RIGHT_SIDE = com.art.core.components.DualOptionToggleButton.RIGHT_SIDE;
    this.NAME = com.art.core.components.DualOptionToggleButton.NAME;
    this.states = {};
    this.states[this.LEFT_SIDE] = {selected:'0px -322px',active:'0px -380px',over:'0px -409px',down:'0px -438px'};
    this.states[this.RIGHT_SIDE] = {selected:'-5px -322px',active:'-5px -380px',over:'-5px -409px',down:'-5px -438px'};
    
    com.art.core.components.BaseComponent.extend(this);
};
com.art.core.components.DualOptionToggleButton.NAME = "DualOptionToggleButton";
com.art.core.components.DualOptionToggleButton.LEFT_SIDE = "DualOptionToggleButtonLeftSide";
com.art.core.components.DualOptionToggleButton.RIGHT_SIDE = "DualOptionToggleButtonRightSide";
com.art.core.components.DualOptionToggleButton.CLICK = "DualOptionToggleButtonCLICK";

com.art.core.components.DualOptionToggleButton.prototype.getValue = function()
{
	return this.sideSelected == this.LEFT_SIDE ? this.leftValue :this.rightValue;
};


com.art.core.components.DualOptionToggleButton.prototype.getActiveSide = function()
{
	return this.sideSelected == this.LEFT_SIDE ? $("#rightButton_"+this.id) : $("#leftButton_"+this.id);
};
com.art.core.components.DualOptionToggleButton.prototype.getDeactiveSide = function()
{
	return this.sideSelected == this.LEFT_SIDE ? $("#leftButton_"+this.id) : $("#rightButton_"+this.id);
};
com.art.core.components.DualOptionToggleButton.prototype.getState = function(state)
{
	var side = this.sideSelected == this.LEFT_SIDE ? this.RIGHT_SIDE : this.LEFT_SIDE;
	return this.states[side][state];
};
com.art.core.components.DualOptionToggleButton.prototype.getDeactiveState = function(state)
{
	var side = this.sideSelected == this.LEFT_SIDE ? this.LEFT_SIDE : this.RIGHT_SIDE;
	return this.states[side][state];
};
com.art.core.components.DualOptionToggleButton.prototype.setTextColors = function()
{
	var dSide = this.sideSelected == this.LEFT_SIDE ? $("#leftButton_"+this.id) : $("#rightButton_"+this.id);
	dSide.css("color","#FFFFFF");
	var aSide = this.sideSelected == this.LEFT_SIDE ? $("#rightButton_"+this.id) : $("#leftButton_"+this.id);
	aSide.css("color","#000000");
};
com.art.core.components.DualOptionToggleButton.prototype.resetButtons = function()
{
	$("#rightButton_"+this.id).unbind("mouseover");
	$("#rightButton_"+this.id).unbind("mouseout");
	$("#rightButton_"+this.id).unbind("mousedown");
	$("#rightButton_"+this.id).unbind("mouseup");
	$("#rightButton_"+this.id).die();
	
	$("#leftButton_"+this.id).unbind("mouseover");
	$("#leftButton_"+this.id).unbind("mouseout");
	$("#leftButton_"+this.id).unbind("mousedown");
	$("#leftButton_"+this.id).unbind("mouseup");
	$("#leftButton_"+this.id).die();
};
com.art.core.components.DualOptionToggleButton.prototype.registerEvents = function()
{
	this.resetButtons();
	this.setTextColors();
	var _this = this;
	var aSide = this.getActiveSide();
	var dSide = this.getDeactiveSide();
	
	aSide.css("cursor","pointer");
	aSide.css('background-position',_this.getState('active'));
	
	dSide.css('background-position',_this.getDeactiveState('selected'));
	dSide.css("cursor","default");
	
	aSide.mouseover(function(){
		aSide.css('background-position',_this.getState('over'));
	});
	aSide.mouseout(function(){
		aSide.css('background-position',_this.getState('active'));
	});
	aSide.mousedown(function(){
		aSide.css('background-position',_this.getState('down'));
	});
	aSide.mouseup(function(){
		//don't update selected until after we make callback
		_this.sideSelected = _this.sideSelected == _this.LEFT_SIDE ? _this.RIGHT_SIDE : _this.LEFT_SIDE;
		
		if(_this.callbacks[_this.CLICK] != undefined)
			_this.callbacks[_this.CLICK](_this.getValue());
		_this.registerEvents();
	});
};
/**
 * @method getTemplate
 * 
 */
com.art.core.components.DualOptionToggleButton.prototype.getTemplate = function()
{
	var aSide = this.getActiveSide();
	var dSide = this.getDeactiveSide();
	var leftPos 	= this.sideSelected == this.LEFT_SIDE ? '0px -322px': '0px -380px';
	var rightPos 	= this.sideSelected == this.LEFT_SIDE ? '-5px -380px': '-5px -322px';
	var rightCapPos	= this.sideSelected == this.LEFT_SIDE ? "-306px -380px" : "-306px -264px";
	var rightColor 	= this.sideSelected == this.LEFT_SIDE ? "#000000" : "#FFFFFF";
	var leftColor 	= this.sideSelected == this.LEFT_SIDE ? "#FFFFFF" : "#000000";
	trace("leftColor: "+leftColor);
	return this.template.replace(/\$ID/g,this.id).replace("$LEFT_LABEL",this.leftLabel).replace("$RIGHT_LABEL",this.rightLabel).replace("$RCAP", rightCapPos).replace("$LPOS", leftPos).replace("$RPOS",rightPos).replace("$RCOLOR",rightColor).replace("$LCOLOR", leftColor).replace(/\$IMAGE_HOST/g, this.getImageHost());
};
/**
 * Outputs markup for component
 * @method render
 * @returns {String}
 */
com.art.core.components.DualOptionToggleButton.prototype.render = function () {
    return this.getTemplate();
};
/**
* @method registerCallback
* @param eventName
* @param callback
*/
com.art.core.components.DualOptionToggleButton.prototype.registerCallback = function (eventName, callback) {
    this.callbacks[eventName] = callback;
};

com.art.core.components.DualOptionToggleButton.prototype.template =
"<div id='$ID' style='display:inline-block;'>" +
	"<div id='leftButton_$ID' style='padding-left:15px; padding-top:5px; padding-right:10px;float:left;height:24px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:$LPOS;background-repeat:no-repeat; color:$LCOLOR;'>$LEFT_LABEL</div>"+
	"<div id='centerDivider_$ID' style='float:left;width:1px;height:29px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:0px -351px;'></div>"+
	"<div id='rightButton_$ID' style='padding-top:5px; padding-left:10px;padding-right:15px;float:left;height:24px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:$RPOS;background-repeat:no-repeat; color:$RCOLOR;'>$RIGHT_LABEL</div>"+
	"<div id='rightButtonCap_$ID' style='padding-top:5px;float:left;height:24px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:$RCAP;background-repeat:no-repeat; width:5px;'></div>"+
	"<div style='clear:both'></div>"+
"</div>";
	
com.art.core.components.BaseButton.extend(com.art.core.components.DualOptionToggleButton.prototype);