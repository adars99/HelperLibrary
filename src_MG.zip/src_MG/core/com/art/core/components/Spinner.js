com.art.core.components.Spinner = function(target)
{
	this.init();
	
	this.id = com.art.core.utils.StringUtil.generateUID();
	this.target = target;
	this.message = "";
	this.ellipse = "";
	this.intervalID;
	
	this.width = 30;
	this.height = 30;
};


com.art.core.components.Spinner.prototype.show = function(zindex)
{
    var _this = this;
	$(this.target).append(this.getTemplate(zindex));
	
	//center
	$("#"+this.id).css("top", ( $(window).height() - $("#"+this.id).height() ) / 2+$(window).scrollTop() + "px");
	$("#"+this.id).css("left", ( $(window).width() - $("#"+this.id).width() ) / 2+$(window).scrollLeft() + "px");
	//only if a message was set, do we do the following...
	if (this.message.length > 0)
	{    
	    $("#" + _this.id + "-message").html(this.message);
	    this.intervalID = setInterval(function(){
	        //_this.ellipse = _this.ellipse.length > 2 ? "" : _this.ellipse + ".";
	        _this.ellipse += ".";
	        $("#" + _this.id + "-message").html(_this.message + _this.ellipse);
	        if (_this.ellipse.length > 15) {_this.ellipse = ""; clearInterval(this.intervalID);}
	    },800);
	}
	//center the spinner image in its parent container
	$('#' + this.id + '_img').centerElement();
		
	if($.browser.msie){
	    $('#' + this.id).css({'border':'1px solid #999999'});
	}
};

com.art.core.components.Spinner.prototype.getTemplate = function(zindex)
{
	trace("spinner zindex: "+zindex);
	var z = zindex != undefined ? zindex:1;
	var _template = "<div id='$ID' class='core_spinner' style='text-align:left;padding:15px;position:absolute;z-index:$ZINDEX;width:$WIDTHpx;height:$HEIGHTpx;background-color:#FFFFFF;-moz-border-radius: 3px;border-radius: 3px;background-position:-339px -88px;background-repeat:no-repeat;position:absolute; left:50px;top:20px;'>"+
    "<img id='$ID_img' style='width:32px;height:32px;' src='$IMAGE_HOST/images/photostoart/loading.gif'/>";
    if (this.message.length > 0)
        _template += "<div style='margin-top:60px;color:#666666;text-align:center;' id='$ID-message'></div>";
    _template += "</div>";

	
	return _template.replace(/\$ID/g,this.id)
	.replace("$ZINDEX",z)
	.replace(/\$IMAGE_HOST/g, this.getImageHost())
	.replace(/\$WIDTH/g, this.width)
	.replace(/\$HEIGHT/g, this.height);
};

com.art.core.components.Spinner.prototype.hide = function()
{
	clearInterval(this.intervalID);
	this.ellipse = "";
	$("#"+this.id).remove();
	$("#"+this.id).empty();
};

com.art.core.components.Spinner.prototype.setMessage = function(message)
{
    this.message = message;
};

com.art.core.components.Spinner.prototype.alterDefaultSize = function(newWidth,newHeight)
{
    this.width = newWidth;
    this.height = newHeight;
};
com.art.core.components.Spinner.prototype.appendOuterShadow = function()
{
    $('#' + this.id).addDropShadow('center');
};

com.art.core.components.BaseComponent.extend(com.art.core.components.Spinner.prototype);