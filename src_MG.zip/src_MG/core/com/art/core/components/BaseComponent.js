/**
 * Base component, which all others psuedo extend
 * @class BaseComponent
 * @static
 */
com.art.core.components.BaseComponent = function(){};
/**
 * Required methods all components need to implement
 * @property
 */
com.art.core.components.BaseComponent.extend = function(subclass)
{
	for(var k in this)
	{
		subclass[k] = this[k];
	};
};
com.art.core.components.BaseComponent.init = function()
{
	this.callbacks = {};
	this.zindex = 0; //default z-index
	this.uid = com.art.core.utils.StringUtil.generateUID(15);
	
};

/**
 * For https support include core.js file before setting SECURE_HOST on page
 * i.e:
 * <script>
 * com.art.core.components.SECURE_HOST = <% echo "https://secureimg.art.com" $>
 * </script>
 * if SECURE is set use it, otherwise use domain appropriat host ART/APC
 * 
 * see src/Packages.js
 * 
 */
com.art.core.components.BaseComponent.getImageHost = function(domain)
{
	//default to ART
	var h = domain == com.art.core.constants.APC ? com.art.core.constants.APC_HOST : com.art.core.constants.ART_HOST;
	
	return com.art.core.components.SECURE_HOST != "" ? com.art.core.constants.SECURE_HOST : h;
};
com.art.core.components.BaseComponent.registerCallback = function(name,callback)
{
	this['callbacks'][name] = callback;
};
com.art.core.components.BaseComponent.setZIndex = function(value)
{
	this['zindex'] = value;
};

com.art.core.components.BaseComponent.getUID = function()
{
	return this.uid;
};
//
//com.art.core.components.BaseComponent.render = function()
//{
//	trace("render function called"); //throw new Error("render error! Component did not implement 'render' method.");
//};
//
//com.art.core.components.BaseComponent.registerEvents = function()
//{
//	throw new Error("registerEvents error! Component did not implement 'registerEvents' method.");
//};
//
//com.art.core.components.BaseComponent.getTemplate = function()
//{
//	throw new Error("getTemplate error! Component did not implement 'getTemplate' method.");
//};
//
//com.art.core.components.BaseComponent.remove = function()
//{
//	throw new Error("remove error! Component did not implement 'remove' method.");
//};