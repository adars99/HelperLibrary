/**
 * Component to display content on element hover
 * @class ToolTip
 * @namespace com.art.core.components
 * @constructor
 * @param markupId
 */
com.art.core.components.ToolTip = function(markupId)
{   
    com.art.core.components.BaseComponent.extend(this);
    
    this.NAME       = com.art.core.components.ToolTip.NAME;

    this.callbacks = [];

    this.title = "";
    this.message = "";
    
    this.markupId = markupId + (Math.ceil(Math.random()*1000)).toString();
    this.toolTipContent = {'title' :'', 
                           'message' :''};
};

//SECTION: Component Static Properties
com.art.core.components.ToolTip.NAME = "ToolTip";

com.art.core.components.ToolTip.prototype.init = function(module)
{
	//if (module)
	this.registerEvents(module);
	return this.getTemplate();
};

com.art.core.components.ToolTip.prototype.setToolTip = function(title, message)
{
    this.toolTipContent.title = title;
    this.toolTipContent.message = message;
};

com.art.core.components.ToolTip.prototype.render = function(x,y)
{
    var markup = this.getTemplate();  
    $('body').append(markup);
    $("#" + this.markupId).css({'position':'absolute','top':y,'left':x ,'z-index':1005}); 
    //$("#" + this.markupId).addDropShadow('angle');
};

com.art.core.components.ToolTip.prototype.registerCallback = function(name,callback)
{
    this.callbacks[name] = callback;
    trace("callbacks:");
    trace(this.callbacks);
};

//SECTION: Component Functions - Standard 
com.art.core.components.ToolTip.prototype.destroy = function()
{
    $("#" + this.markupId).empty();
    $("#" + this.markupId).remove();
};

com.art.core.components.ToolTip.prototype.registerEvents = function(module)
{
    var _this = this;
        
    //EVENTS FOR OBJECTS - Click
    $("#" + this.markupId).live('click', function()
    {

    });

    //EVENTS FOR OBJECTS - Mouseover
    $("#" + this.markupId).live('mouseover', function() {
       _this.getToolTip();
    });
    
    //EVENTS FOR OBJECTS - Mouseout
    $("#" + this.markupId).live('mouseout', function() {
        _this.destroy();
    });
};

//SECTION: Component Functions - Specific to this component
com.art.core.components.ToolTip.prototype.getTemplate = function()
{
       var returnValue = "";
       returnValue += '<div id="' + this.markupId + '"><b>' + this.toolTipContent.title + '</b>' + this.toolTipContent.message
       + '</div>';
       
       return returnValue;

};
