/**
 * Base Request Value Object; common structure to pass via com.art.core.utils.Note();
 * @class RequstBaseVO
 * @constructor
 * @namespace com.art.core.vos
 * @param environment
 */
com.art.core.vos.RequestBaseVO = function(environment)
{
	this.countryCode = environment.countryCode;
	this.currencyCode = environment.currencyCode;
	this.currencyId = environment.currencyId;
	this.customerZoneId = environment.customerZoneId;
	this.languageId = environment.languageId;
	this.languageIso = environment.languageIso;
	this.searchServiceUrl = environment.searchServiceUrl;
	this.sessionid 		  = environment.sessionid;
	this.domain			= environment.domain;
	this.productServiceUrl=environment.productServiceUrl;
};