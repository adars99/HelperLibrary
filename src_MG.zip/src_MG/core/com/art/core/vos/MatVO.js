/**
 * Common value object classes
 * @module vos
 */

/**
 * Mat Value Object, standardized object for Mat object
 * @class MatVO
 * @namespace com.art.core.vos
 * @param title
 */
com.art.core.vos.MatVO = function(sourceMat,imagePath)
{
	this.Name = sourceMat.Name;
	this.apNum = sourceMat.ApNum;
	this.MatId = sourceMat.MatId;
	this.frameType = sourceMat.FrameType;
	this.hexColor = sourceMat.HexColor;
	this.maxWidth = sourceMat.MaxWidth;
	this.maxHeight = sourceMat.MaxHeight;
	this.isOverSized = sourceMat.IsOverSized;
	this.isAcidFree = sourceMat.IsAcidFree;
	this.imageFile = sourceMat.ImageFile;
	//english 
	//http://cache1.artprintimages.com
	this.imagePath			= imagePath;
	this.fallbackImageURL 	= "/images/framing/mats/transparent_mat_template_100x100.png";
	this.thumbBaseUrl 		= this.imagePath + "/images/framing/mats/hires/$ID/swatch/$ID_b.jpg"; //100x100
	this.medBaseUrl 		= this.imagePath + "/images/framing/mats/hires/$ID/swatch/$ID_a.jpg"; //400x400
	this.lrgBaseUrl 		= this.imagePath + "/images/framing/mats/hires/$ID/swatch/$ID.jpg";	//2000x2000
};
com.art.core.vos.MatVO.prototype.getThumbImageUrl 	= function(){	return this.getImageUrl(this.thumbBaseUrl);	};
com.art.core.vos.MatVO.prototype.getMedImageUrl 	= function(){	return this.getImageUrl(this.medBaseUrl);		};
com.art.core.vos.MatVO.prototype.getLrgImageUrl 	= function(){	return this.getImageUrl(this.lrgBaseUrl);		};


com.art.core.vos.MatVO.prototype.getFallbackImage = function()
{
	return this.imagePath + this.fallbackImageURL;
};

/**
 * Return image path if imageFile is "" use fallback image template and use hex color
 * @param base
 * @returns
 */
com.art.core.vos.MatVO.prototype.getImageUrl = function(base)
{
	if(this.MatId == undefined)
		throw new Error("MatVO.getImageUrl() failed! MatId is undefined.");
	

	return base.replace(/\$ID/g,this.MatId);
	
};
com.art.core.vos.MatVO.NAME = "MatVO"; //static
com.art.core.vos.MatVO.prototype.apNum= '';
com.art.core.vos.MatVO.prototype.matId= '';
com.art.core.vos.MatVO.prototype.frameType= '';
com.art.core.vos.MatVO.prototype.hexColor= '';
com.art.core.vos.MatVO.prototype.maxWidth= '';
com.art.core.vos.MatVO.prototype.maxHeight= '';
com.art.core.vos.MatVO.prototype.isOverSized= '';
com.art.core.vos.MatVO.prototype.isAcidFree= '';
com.art.core.vos.MatVO.prototype.yiq; //used for sorting by mat color

com.art.core.vos.MatVO.prototype.imageFile= '';

// Don't need?
com.art.core.vos.MatVO.prototype.vendorID= '';
com.art.core.vos.MatVO.prototype.legacyImageFile= '';

com.art.core.vos.MatVO.ConvertToMatVOArray = function(serviceSideMatsArray,imagePath)
{
	var outputMats = [];
	for(var inputMat in serviceSideMatsArray)
	{
		outputMats.push(new com.art.core.vos.MatVO(serviceSideMatsArray[inputMat],imagePath));
	}
	return outputMats;
};