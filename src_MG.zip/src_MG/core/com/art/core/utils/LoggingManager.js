/**
 * This is the LoggingManager which will centralize logging of error and such.
 */
com.art.core.utils.LoggingManager = function(environment)
{
    this.environment = environment;
    this.serviceProvider = new com.art.core.services.ServiceProvider(this.environment);
    this.apiKey = (environment.apiKey == undefined) ? "" : environment.apiKey ;
    this.sessionId = "";
};
/**
 * This will log a client JavaScript error by async calling a service to log it
 * @param errObj the built-in JavaScript error object
 */
com.art.core.utils.LoggingManager.prototype.logError = function(errObj, apiKey, sessionId)
{
	var methodInputs = this.errorObjToInputs(errObj);
	var errorMessage = methodInputs.errorMessage;
	var errorSource = methodInputs.errorSource;
	var description = methodInputs.description;
	if (apiKey == undefined) var apiKey = this.apiKey;
	if (sessionId == undefined) var sessionId = this.sessionId;
	var handlers = this.serviceProvider.createHandlers(
	        function(){}
			,
			function(){}
			,
			function(){}
	);

	this.serviceProvider.loggingAPIService.logError(
            handlers
            ,apiKey
            ,sessionId
            ,methodInputs.errorMessage
	        ,methodInputs.errorSource
            ,methodInputs.errorName
            ,methodInputs.errorLocation
            ,methodInputs.errorObjectAsString
	);
	trace(this.errorObjToString(errObj));
};
com.art.core.utils.LoggingManager.prototype.apiKeySet = function(apiKey)
{
	this.apiKey = apiKey;
};

com.art.core.utils.LoggingManager.prototype.sessionIdSet = function(sessionId)
{
	this.sessionId = sessionId;
};

com.art.core.utils.LoggingManager.prototype.errorObjToString = function(errorObject)
{
	var errObj = this.errorObjValidate(errorObject);
	return "fileName: " + errObj.fileName
	+ "\n"
	+ "lineNumber: " + errObj.lineNumber
	+ "\n"
	+ "message: " + errObj.message
	+ "\n"
	+ "name: " + errObj.name
	+ "\n"
	+ "stack: " + errObj.stack;

};

com.art.core.utils.LoggingManager.prototype.errorObjValidate = function(errObj)
{
	var returnObj = {};
	(errObj.fileName === undefined) ? returnObj.fileName = '' : returnObj.fileName = errObj.fileName;
	(errObj.lineNumber === undefined) ? returnObj.lineNumber = '' : returnObj.lineNumber = errObj.lineNumber;
	(errObj.message === undefined) ? returnObj.message = '' : returnObj.message = errObj.message;
	(errObj.name === undefined) ? returnObj.name = '' : returnObj.name = errObj.name;
	(errObj.stack === undefined) ? returnObj.stack = '' : returnObj.stack = errObj.stack;
	return returnObj;
};

com.art.core.utils.LoggingManager.prototype.errorObjToInputs = function(errorObject)
{
	var methodInputs = {errorMessage:'',errorSource:'',errorName:'',errorLocation:'',errorObjectAsString:''};
	var errObj = this.errorObjValidate(errorObject);
	
	methodInputs.errorName = errObj.name;
	methodInputs.errorSource = location.host;
	methodInputs.errorLocation = errObj.fileName + " | lineNumber: " + errObj.lineNumber;
	methodInputs.errorObjectAsString = errObj.message;
	methodInputs.errorMessage = errObj.stack;
	return methodInputs;
};
com.art.core.utils.LoggingManager.prototype.createError = function(name, message)
{
	var newError = new Error();
	newError.message = message;
	newError.name = name;
	return newError;

};