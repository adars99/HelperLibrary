/**
 * Common art.com Utilities
 * @module utils
 * 
 */
/**
 * Convience static classes to access Flash SWFs
 * @Class Flash
 * @namespace com.art.core.utils
 *  
 */
com.art.core.utils.Flash = function()
{
	
};
/**
 * Get reference to swf via swfobject
 * @Method getMovie
 * @static
 */
com.art.core.utils.Flash.getMovie = function(name)
{
	var obj = swfobject.getObjectById(name);
	if (obj)
	{
		return obj;
	}
	else
	{
		if (navigator.appName.indexOf("Microsoft") != -1)
		{
			return swfobject.getObjectById[name];
		}
		else
		{
			return document[name];
		}
	}
};

function Test1()
{
	trace('Test1');
};
function Test2()
{
	trace('Test2');
};
function Test3()
{
	trace('Test3');
};
