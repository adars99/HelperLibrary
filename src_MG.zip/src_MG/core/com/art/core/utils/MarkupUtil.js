com.art.core.utils.MarkupUtil = function(appName)
{
	this.prefix = appName;
	this.ButtonStates = {ACTIVE:'1',INACTIVE:'2',OVER:'3',SELECTED:'4',HIDDEN:'5'};
};
/**
 * @param base
 * @param arr
 * 
 * This function will take base string and replace tokens with array elements from arr
 * 
 * example usage
 * var myParams	= ['dev','someOperation',12345,'someSessionID'
 * var url = com.art.core.utils.StringUtil.substitute("http://$0-www.art.com/someService/$1/accountid/$2/sessionid/$3",myParams);
 * returns string http://dev-www.art.com/someService/someOperation/accountid/12345/sessionid/someSessionID
 */
com.art.core.utils.MarkupUtil.prototype.getClassName = function(name, module, state)
{
	var returnValue = this.getPrefix(module) + name;
	switch(state)
	{
		case this.ButtonStates.HIDDEN:
			returnValue += "_hide";
			break;
		case this.ButtonStates.INACTIVE:
			returnValue += "_inactive";
			break;
		case this.ButtonStates.OVER:
			returnValue += "_over";
			break;
		case this.ButtonStates.SELECTED:
			returnValue += "_select";
			break;
		case this.ButtonStates.ACTIVE:
		default:
			//do nothing
			break;
	}
	return returnValue;
};

com.art.core.utils.MarkupUtil.prototype.getIdName = function(name, module)
{
	var returnValue = this.getPrefix(module) + name;
	//trace('CSS LOG - ID: ' + returnValue);
	return returnValue;
};

com.art.core.utils.MarkupUtil.prototype.getPrefix = function(module)
{
	var sectionName = "x";
	if (module)
	{
	    if(module.NAME)
	        sectionName = module.NAME.replace(/([a-z])/g, "").toLowerCase();
	    else if (typeof module === 'string' && module.length > 0 )
	        sectionName = module.replace(/([a-z])/g, "").toLowerCase();
	}
	var returnValue = this.prefix + "_" + sectionName + "_";
	//trace('CSS LOG - CLASS: ' + returnValue);
	return returnValue;
};

com.art.core.utils.MarkupUtil.prototype.getInstance = function(module)
{
	var _this = this;
	return {
	
		"getName" : function(name,state)
		{
			if (state && state.length > 0)
				return (_this.getClassName(name,module,state));
			else
				return (_this.getIdName(name,module));
		}
		,"buttonStates" : _this.ButtonStates
		,"getPrefix" : function(){return _this.getPrefix(module);}
		,"getGenericClassName" : function(name, state)
		{
			if (state && state.length > 0)
				return (_this.getClassName(name,'',state));
			else
				return (_this.getIdName(name,''));
		}
		,"getModuleId" : function()
		{
			return _this.getPrefix(module) + "container";
		}
	};
};
