/**
 * Standard notification object
 * @class Note
 */
com.art.core.utils.Note = function(name,body,type)
{
	this.name = name;
	this.body = body;
	this.type = type;
};