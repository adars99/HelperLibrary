/**
 * @class SuperZoom
 * @static
 * 
 */
com.art.core.utils.SuperZoom = function(){};
/**
 * @method show
 * @param url image url to show as zoom image
 * @static
 */
com.art.core.utils.SuperZoom.prototype.show = function(zoomUrl)
{
	var id = Math.ceil(Math.random()*1000);
	var closeButton = '<img id="zoomImgClose'+id+'" class="zoomImgClose" src="http://cache1.artprintimages.com/images/photostoart/closebox.png" style="display:none;z-index:2001" onmouseover="this.style.cursor=\'-moz-zoom-out\'" onmouseout="this.style.cursor=\'hand\'" />';
	var zoomWidth = Math.floor($(window).width() * 0.9);
	var zoomHeight = Math.floor($(window).height() * 0.9);
		
	var windowWidth = $(window).width();
	var windowHeight = $(window).height();
			
	var divClickBlock = "<div id='zoomImgBlock' style='position:absolute;display:none;width:" + windowWidth + "px;z-index:1999;height:" + windowHeight + "px;top:0;left:0;background-image:url(http://cache1.artprintimages.com/images/misc/blank.gif);background-repeat:repeat'><div id='coverClose'></div></div>";
		
	$('body').append(
		divClickBlock + closeButton + '<img id="zoomImg' + id + '" class="zoomImg" src="' + zoomUrl
		+ '" style="display:none;z-index:2000" onmouseover="this.style.cursor=\'-moz-zoom-out\'" onmouseout="this.style.cursor=\'hand\'" />');

    //STEP: Create a lightbox
    var lightbox = new com.art.core.components.LightBox('superzoomlb','body','0.4');
    lightbox.show();
    //STEP: Get the z-index of the lightbox so that we can make the popup one higher:
    var superzoomZIndex = lightbox.getLightBoxZIndex()+1;
	
	
	$('#zoomImg' + id).load(function() {
		$('#zoomImgBlock').show();
		var newValue = $(this).scaleObjectToFitOrFill.Calculate({
			srcWidth : $(this).width(),
			srcHeight : $(this).height(),
			destWidth : zoomWidth,
			destHeight : zoomHeight,
			method : "fit"
		});
		
		$(this).css({
				'position' : 'absolute',
				'z-index' : superzoomZIndex,
				'width' : newValue.width,
				'height' : newValue.height
		});
		$(this).center(true);
			
		//CLOSE BUTTON - position the close button to top right of image
		var _this = this;
		var functionPutTopRight = function()
		{
			var positionClose = {
				top:Math.ceil ((( $(window).height() - $('#zoomImgClose'+id).height() ) / 2+$(window).scrollTop() ) - ($(_this).height()/2)),
				left:Math.ceil((( $(window).width()  - $('#zoomImgClose'+id).width()  ) / 2+$(window).scrollLeft()) + ($(_this).width()/2))
			};
				
			$('#zoomImgClose'+id).css({'position':'absolute','top':positionClose.top,'left':positionClose.left,'z-index':superzoomZIndex+1});
		};
			
		functionPutTopRight();
		$(window).bind('resize',function(){
			functionPutTopRight();
		});
					
		$(this).fadeIn(300);
		$('#zoomImgClose'+id).fadeIn(300);
			
		$('#zoomImg' + id + ',#zoomImgClose'+id).bind('click', function() {
			$(this).fadeOut(300);
			lightbox.close();
			$('#zoomImgBlock').hide();
			$('#zoomImg' + id).unbind('click');
			$('#zoomImgClose' + id).unbind('click');
			$('.zoomImg').remove();
			$('.zoomImgClose').remove();
		});
	});
};