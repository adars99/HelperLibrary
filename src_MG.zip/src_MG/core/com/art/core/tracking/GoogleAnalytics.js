/**
 * Tracking functionality
 * @module tracking
 * 
 * 
 */

/**
 * Convenience class for google analytics (GA) API, ensure _gaq is setup as global object; specifically outside application
 * @class GoogleAnalytics
 * @constructor
 * @namespace com.art.core.tracking
 * @param groupName
 */
com.art.core.tracking.GoogleAnalytics = function(groupName)
{
	this.groupName = groupName;
};
/**
 * Initialize GA functionality; convience method to call ga setup call
 * @method init
 */
com.art.core.tracking.GoogleAnalytics.prototype.init = function()
{
	var host = location.host;
	this.setup(this.getAccountId(host));
};

/**
 * @property accounts predefined accounts in organization domain:account-id
 */
com.art.core.tracking.GoogleAnalytics.prototype.accounts = {
		"art.com":"UA-15714084-1"
		,"art.co.uk":"UA-15714093-1"
		,"eu.art.com":"UA-15715374-1"
		,"potterybarn-photos.com":"UA-15714084-2"
		,"allposters.com":"UA-15715175-1"
		,"allposters.co.uk":"UA-15715653-1"
		,"allposters.fr":"UA-15714863-1"
		,"allposters.de":"UA-15714098-1"
		};
com.art.core.tracking.GoogleAnalytics.prototype.globalAccounts = {
		"art":"UA-15715646-1",
		"apc":"UA-15715169-1"
};

com.art.core.tracking.GoogleAnalytics.prototype.getGlobalAccountId = function()
{
	var host = location.host;
	if(host.indexOf("art.") >= -1)
    {           
          return this.globalAccounts["art"];
    }
	else
	{
		return this.globalAccounts["apc"];
	}
    
};
/*future
 * apcmasteraccount,UA-15715169-1|true
allposters.com,UA-15715175-1|true
allposters.co.uk,UA-15715653-1|true
allposters.de,UA-15714098-1|true
allposters.fr,UA-15714863-1|true
allposters.it,UA-15716519-1|true
allposters.es,UA-15715658-1|true
allposters.co.jp,UA-15716522-1|true
Allposters.nl,UA-15716525-1|true
allposters.nl,UA-15716525-1|true
allposters.dk,UA-15715389-1|true
allposters.se,UA-15715390-1|true
allposters.com.mx,UA-15715663-1|true
allposters.com.br,UA-15717213-1|true
allposters.pt,UA-15715188-1|true
allposters.pl,UA-15715394-1|true
allposters.p,UA-15715394-1|true
allposters.fi,UA-15714294-1|true
allposters.no,UA-15717504-1|true
allposters.ca,UA-15714870-1|true
allposters.com.au,UA-15715391-1|true
allposters.ch,UA-15716527-1|true
allposters.at,UA-15717116-1|true
allposters.be,UA-15717208-1|true
allposters.ie,UA-15717114-1|true
allposters.com.ar,UA-17385433-1|true
allposters.com.tr,UA-17386431-1|true
allposters.cz,UA-17385634-1|true

 */


com.art.core.tracking.GoogleAnalytics.prototype.trackPageView = function(pageViewName)
{
	trace("GA EVENT: " + pageViewName);
	_gaq.push(['t1._trackPageview', pageViewName]);
};
/**
 * The reason the default is eu.art.com in the below function as this is the sub domain of art.com.
 * For all the other sites, we have different domain extensions.
 * All the domains needs to be added to the com.art.core.tracking.Accounts list.
 * @method getAccountId
 * @param domain site domain name
 */
com.art.core.tracking.GoogleAnalytics.prototype.getAccountId = function(domain)
{
	var gaAccountId = "UA-15714084-1";
	var gaAccountName = "eu.art.com";
	if(domain.indexOf("www.") >= 0)
    {           
          gaAccountName = domain.substring(domain.indexOf(".") + 1,domain.length);
    }
    gaAccountId = this.accounts[gaAccountName];
    return gaAccountId;
};
/**
 * Primary method for tracking events
 * @method trackEvent
 * @param eventName
 * @returns {Boolean}
 */
com.art.core.tracking.GoogleAnalytics.prototype.trackEvent = function(eventName)
{
  if (typeof (_gaq) != "undefined")
  {
  	trace("GA Group Name : " + this.groupName +", GA Event Name : " + eventName);
  	
      _gaq.push(['t1._trackEvent', this.groupName, eventName, eventName]);
      return true;
  }
  else
	{
  	throw Error('GA is not setup; art.core.GoogleAnalytics');
	}
  return false;
};

/**
* Primary method for tracking events
* @method trackEvent
* @param eventName
* @returns {Boolean}
*/
com.art.core.tracking.GoogleAnalytics.prototype.trackEventWithCategory = function(categoryName, eventName) {
    if (typeof (_gaq) != "undefined") {
        trace("GA Group Name : " + this.groupName + ", GA Category Name : " + categoryName+", GA Event Name : " + eventName);

        _gaq.push(['t1._trackEvent', this.groupName, categoryName, eventName]);
        return true;
    }
    else {
        throw Error('GA is not setup; art.core.GoogleAnalytics');
    }
    return false;
};

/**
 * GA setup command, called via init() method
 * @method setup
 * @param id
 * @returns {Boolean}
 */
com.art.core.tracking.GoogleAnalytics.prototype.setup = function(id)
{
	
	// This code is not working properly - it is preventing setup of account in all cases.
//	try{
//		if(_gat)
//		{
//			trace("GA.setup: "+id);
//			if(_gat._createTracker(id)._getAccount() == id)
//			{
//				trace("GA Account already registered exists return");
//				return; //prevent duplicates
//			}
//			else
//			{
//				//gat will not be present if setup has not run
//				//skip
//			}
//			
//		}
//	}catch(e){};
	
	if(document.location.href.toLowerCase().indexOf('pottery') === -1)
	{
		_gaq.push(['t1._setAccount', id],
	      ['t1._trackPageview'],
	      ['t1._setAllowLinker', true],
	      ['t1._setDomainName', 'none'],
	      ['global._setAccount', this.getGlobalAccountId()],
	      ['global._trackPageview'],
	      ['global._setAllowLinker', true],
	      ['global._setDomainName', 'none']);
	}
	else
	{
		_gaq.push(['t1._setAccount', id],
			      ['t1._trackPageview'],
			      ['t1._setAllowLinker', true],
			      ['t1._setDomainName', 'none']);
	}
  (function()
  {
      var ga = document.createElement('script');
      ga.type = 'text/javascript';
      ga.async = true;
      ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(ga, s);
      return true;
  })();
  return false;
};
com.art.core.tracking.GoogleAnalytics.prototype.getDelimiter = function()
{	
	//return '-'; // to right  of zero on alpha keypad.
	return '-'; // numeric keypad minus sign (WORKS in IE and FF)
};

