com.art.core.services.SearchAPIService = function(base,apiKey,authToken)
{
	this.base = base;
	this.serviceUrl = this.base.environment.searchServiceUrl; 
    this.domainUrl = this.base.environment.domain;
};
com.art.core.services.SearchAPIService.prototype.getSimilarImagesForImage = function(callbacks,data)
{
	var operation = "GetSimilarImagesForImage";
	var url = this.serviceUrl;
	url+= "/ajax/" + operation;
	url+= "?method=?&Apnum="+data.Apnum;
	url+= "&RecordsPerPage=24";
	url+= "&PageNumber=1";
	url+= "&CustomerZoneId=" + this.base.environment.customerZoneId;
	url+= "&CurrencyCode=" + this.base.environment.currencyCode;
	url+= "&ImageFilePath="+data.ImageFilePath;
	url+= "&ArtistCategoryId=";
	url+= "&ImageId=";
	url+= "&Refinements=";
	url+= "&ImageIdList=";
	url+= "&apnumlist=";
	url+= "&imagefilelist=";
	url+= "&SearchType=";
	url+= "&NumberOfResults=";
	url+= "&DominantColorId=";
	url+= "&RefinementId=";
	url+= "&ArtistCategoryIdList=";
	url+= "&SortBy=P_SiteRank";
	url+= "&domain=com";
	url+= "&FilterBlackListItems=false";
	trace(url);
	this.base.doRequest(url,callbacks,'json');
};

