/**
 * Top level core object, common JS core library for art.com
 * @module services
 * @title art.com common components
 */

/**
 * Adc.Net Services JS API
 * This connects to the proxy pages of the ADC.NET application which serves as the cart for art.com brands. 
 * @class AdcNetService
 * @namespace com.art.core.services
 * @constructor
 */
com.art.core.services.AdcNetService = function(base)
{
	this.base = base;
    this.serviceUrlAddToCart = this.base.environment.serviceUrlAddToCart;
    this.serviceUrlGetEventMessage = this.base.environment.serviceUrlGetEventMessage;
};

com.art.core.services.AdcNetService.prototype.addToCart = function(callbacks, queryString)
{
    var url;
    url = this.base.getUrlSimple(this.base.environment.serviceUrlAddToCart, queryString);
    this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.XML);
};

com.art.core.services.AdcNetService.prototype.getEventMessageForProduct = function(callbacks
        , customerZoneId
        , languageIsoCode
        , countryIsoCode
        , apnum
        , podConfigId
        , serviceCode
        , dateUserCurrent
)
{

/*'-------------- Debug Start ------------------------------------------
    'Response.Write "GetHolidayMessagingForItemCollection begin.<br>"
    'Response.Write "PageName="&PageName&"<br>"
    'Response.Write "HolidayShippingTypeID="&HolidayShippingTypeID&"<br>"
    'Response.Write "HolidayShippingPriorityID="&HolidayShippingPriorityID&"<br>"
    'Response.Write "cutoffDate="&cutoffDate&"<br>"
    'Response.Write "EstimatedHours="&EstimatedHours&"<br>"
    'CountryCodeID ="840"
    'HolidayShippingPriorityID = "-1"
    'ServiceTypeID = "-1"
'-------------- Debug End Start --------------------------------------
*/
    this.serviceUrlGetEventMessage;
 
    HolidayShippingPriorityID = 1; //Hard coding to standard
    var Parameters = [];
    var MethodParameters = [];
       
        //Header Level Paramters ..single Parameters doesn't repeat with each item .
        
        Parameters["UserDate"] = dateUserCurrent;
        Parameters["customerZoneId"] =  customerZoneId;
        Parameters["languageId"] =  com.art.core.utils.LocalizationManager.convertLanguageIsoToLanguageId(languageIsoCode);
        Parameters["countryIsoA2"] =  countryIsoCode;
        Parameters["ItemCount"] =  1;
        
        MethodParameters["apnum"] =  apnum;
        MethodParameters["podconfigid"] =  podConfigId;   
        MethodParameters["S"] = serviceCode;
        MethodParameters["ZoneProductID"] =  apnum + "A"; //using the quick hand of making it apnum plus "A"

        Parameters["item0"] = escape(com.art.core.utils.StringUtil.getQueryStringFromHash(MethodParameters));
        
        var url;
        var queryString = com.art.core.utils.StringUtil.getQueryStringFromHash(Parameters);
        url = this.base.getUrlSimple(this.base.environment.serviceUrlGetEventMessage, queryString);
        this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.HTML);
};

