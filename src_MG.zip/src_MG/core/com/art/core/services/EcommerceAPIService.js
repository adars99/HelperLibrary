com.art.core.services.EcommerceAPIService = function(base)
{
	this.base = base;
	//this.serviceUrl = "http://qa-api.art.com/ECommerceAPI.svc";//this.base.environment.serviceUrlEcommerceApi;
	this.serviceUrl = this.base.environment.serviceUrlEcommerceApi;
};
com.art.core.services.EcommerceAPIService.prototype.cartAddItem = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.cartGetActiveCountryList = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.cartGetActiveStateListByCountryCode = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.cartGetShippingOptions = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.cartSubmitForOrder = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.cartUpdateCartItemQuantity = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.cartUpdateShippingAddress = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.cartUpdateShipmentPriority = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.catalogItemGet = function(callbacks, apiKey, sessionId, itemId, lookupType)
{
    /*
    <CatalogItemGet xmlns="http://api.art.com">
      <apiKey i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <sessionId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <itemId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <lookupType>ItemNumber</lookupType>
    </CatalogItemGet>
    */
    var url;
    var operation = "CatalogItemGet"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['itemId',itemId]; //NOTE: This is a "generic" id which is a string because, as is case with uploaded item, this is a GUID
    properties[3] = ['lookupType',lookupType];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};

com.art.core.services.EcommerceAPIService.prototype.catalogItemGetFrameRecommendations = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.catalogItemSearch = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.catalogItemSearchByImage = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.catalogGetContentBlock = function(callbacks, apiKey, sessionId, contentBlockName)
{
    
    var url;
    var operation = "CatalogGetContentBlock"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['contentBlockName',contentBlockName];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.catalogGetContentBlockString = function(callbacks, apiKey, sessionId, contentBlockName)
{
    
    var url;
    var operation = "CatalogGetContentBlockString"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['contentBlockName',contentBlockName];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.catalogGetFeaturedCategories = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.catalogItemGetVariations = function(callbacks, apiKey, sessionId, itemId, lookupType)
{
    var url;
    //var operation = "CatalogItemGetVariations"; 
    var operation = "ImageGetVariations"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['itemId',itemId]; //NOTE: This is a "generic" id which is a string because, as is case with uploaded item, this is a GUID
    properties[3] = ['lookupType',lookupType];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.catalogItemVariationsGetMaster = function(callbacks, apiKey, sessionId, lookupType)
{
    var url;
    //var operation = "CatalogItemVariationsGetMaster"; 
    var operation = "ImageGetMasterVariations"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['lookupType',lookupType];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.galleryAddItem = function(callbacks, apiKey, sessionId, authToken, galleryId, itemId, lookupType, userImageTitle)
{
    /*
    <GalleryAddItem xmlns="http://api.art.com">
      <apiKey i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <sessionId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <authToken i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <galleryId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <itemId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <lookupType>ItemNumber</lookupType>
      <userImageTitle i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
    </GalleryAddItem>

     */
    var url;
    var operation = "GalleryAddItem"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['authToken',authToken];
    properties[3] = ['galleryId',galleryId];
    properties[4] = ['itemId',itemId];
    properties[5] = ['lookupType',lookupType];
    properties[6] = ['userImageTitle',userImageTitle];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.galleryAddForUser = function(callbacks, apiKey, sessionId, authToken, galleryName, galleryVisibility )
{
    /*
        <GalleryAddForUser xmlns="http://api.art.com">
      <apiKey i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <sessionId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <authToken i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <galleryName i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <galleryVisibility>Public</galleryVisibility>
    </GalleryAddForUser>
     */
    var url;
    var operation = "GalleryAddForUser"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['authToken',authToken];
    properties[3] = ['galleryName',galleryName];
    properties[4] = ['galleryVisibility',galleryVisibility];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.galleryAddWallByImageGUID = function(callbacks, apiKey)
{
    /*
     *     <GalleryAddWallByImageGUID xmlns="http://api.art.com">
      <apiKey i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <sessionId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <authToken i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <galleryId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <wallName i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <wallImageGuid i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <wallAreaWidth>0</wallAreaWidth>
      <wallAreaHeight>0</wallAreaHeight>
      <wallAreaWidthInches>0</wallAreaWidthInches>
      <wallAreaHeightInches>0</wallAreaHeightInches>
      <rulerX1>0</rulerX1>
      <rulerX2>0</rulerX2>
      <rulerY1>0</rulerY1>
      <rulerY2>0</rulerY2>
      <rulerLength>0</rulerLength>
      <caption i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
    </GalleryAddWallByImageGUID>

     */
    var url;
    var operation = "GalleryAddWallByImageGUID"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.galleryGet = function(callbacks, apiKey, sessionId, galleryId)
{
    /*
     *     <GalleryGet xmlns="http://api.art.com">
      <apiKey i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <sessionId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <galleryId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
    </GalleryGet>

     */
    var url;
    var operation = "GalleryGet"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['galleryId',galleryId];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};

com.art.core.services.EcommerceAPIService.prototype.galleryGetByUser = function(callbacks, apiKey, sessionId, authToken)
{
    /*
     *     <GalleryGetByUser xmlns="http://api.art.com">
      <apiKey i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <sessionId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <authToken i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
    </GalleryGetByUser>

     */
    var url;
    var operation = "GalleryGetByUser"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['authToken',authToken];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.galleryGetUserDefaultMobileGallery = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.galleryGetUserDefaultWallGallery = function(callbacks, apiKey)
{
    
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.galleryRemoveItem = function(callbacks, apiKey, sessionId, authToken, galleryId, galleryItemId)
{
    /*
    <GalleryRemoveItem xmlns="http://api.art.com">
      <apiKey i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <sessionId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <authToken i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <galleryId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <galleryItemId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
    </GalleryRemoveItem>

     */
    var url;
    var operation = "GalleryRemoveItem"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['authToken',authToken];
    properties[3] = ['galleryId',galleryId];
    properties[4] = ['galleryItemId',galleryItemId];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.initializeApi = function(callbacks, apiKey, applicationId, twoDigitISOCountryCode, twoDigitISOLanguageCode, persistentId)
{
    /*
    <InitializeAPI xmlns="http://api.art.com">
      <apiKey i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <applicationId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <twoDigitISOCountryCode i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <twoDigitISOLanguageCode i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <persistentId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
    </InitializeAPI>
    */
    var url;
    var operation = "InitializeAPI"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['applicationId', applicationId];
    properties[2] = ['twoDigitISOCountryCode', twoDigitISOCountryCode];
    properties[3] = ['twoDigitISOLanguageCode', twoDigitISOLanguageCode];
    properties[4] = ['persistentId', persistentId];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};

com.art.core.services.EcommerceAPIService.prototype.getLanguageTranslations = function(callbacks, apiKey, sessionId, localizationAppId)
{
    /*
    <LocalizationGetLanguageTranslations xmlns="http://api.art.com">
      <apiKey i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <sessionId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <localizationAppId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
    </LocalizationGetLanguageTranslations>
    */
    var url;
    var operation = "LocalizationGetLanguageTranslations"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['appId',localizationAppId];
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    trace(url);
    this.base.doRequest(url,callbacks);
};

/**
 *  <ImageUpdateAndGetResults xmlns="http://api.art.com">
      <apiKey i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <sessionId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <imageId>0</imageId>
      <imageGuid i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
//      <ImageLargeWidth>0</ImageLargeWidth>
//      <ImageLargeHeight>0</ImageLargeHeight>
//      <PrintWidthInch>0</PrintWidthInch>
//      <PrintHeightInch>0</PrintHeightInch>
//      <ImageUrl i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <ImageCropId>0</ImageCropId>
      <cropX>0</cropX>
      <cropY>0</cropY>
      <cropW>0</cropW>
      <cropH>0</cropH>
      <podConfigId>0</podConfigId>
      <selectedService i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <selectedServiceSubType i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <maxImageAreaWidth>0</maxImageAreaWidth>
      <maxImageAreaHeight>0</maxImageAreaHeight>
    </ImageUpdateAndGetResults>
 */
com.art.core.services.EcommerceAPIService.prototype.imageUpdate = function(callbacks, apiKey, authToken, sessionId, imageId, imageGuid, ImageCropId, cropX, cropY, cropW, cropH, podConfigId, selectedService, selectedServiceSubType, maxImageAreaWidth, maxImageAreaHeight)
{
    var url;
    var operation = "ImageUpdate"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['authToken',authToken];
    properties[2] = ['sessionId', sessionId];
    properties[3] = ['imageId', imageId];
    properties[4] = ['imageGuid', imageGuid];
    properties[5] = ['ImageCropId', ImageCropId];
    properties[6] = ['cropX', cropX];
    properties[7] = ['cropY', cropY];
    properties[8] = ['cropW', cropW];
    properties[9] = ['cropH', cropH];
    properties[10] = ['podConfigId', podConfigId];
    properties[11] = ['selectedService', selectedService];
    properties[12] = ['selectedServiceSubType', selectedServiceSubType];
    properties[13] = ['maxImageAreaWidth', maxImageAreaWidth];
    properties[14] = ['maxImageAreaHeight', maxImageAreaHeight];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.frameCreateForUserImage = function(callbacks,apiKey,sessionId,authToken,imageGuid,podConfigId,imageCropId)
{
    var url;
    var operation = "FrameCreateForUserImage"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId', sessionId];
    properties[2] = ['authToken', authToken];
    properties[3] = ['imageGuid', imageGuid];
    properties[4] = ['podConfigId', podConfigId];
    properties[5] = ['imageCropId', imageCropId];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};

com.art.core.services.EcommerceAPIService.prototype.frameUpdateCrop = function(callbacks,apiKey,sessionId,frameIdentifier,imageCropIdentifier,cropX,cropY,cropWidth,cropHeight)
{
    var url;
    var operation = "FrameUpdateCrop"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['frameIdentifier', frameIdentifier];
    properties[3] = ['imageCropIdentifier', imageCropIdentifier];
    properties[4] = ['cropX', cropX];
    properties[5] = ['cropY', cropY];
    properties[6] = ['cropWidth', cropWidth];
    properties[7] = ['cropHeight', cropHeight];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};

com.art.core.services.EcommerceAPIService.prototype.frameCreate = function(callbacks,apiKey,sessionId,authToken,itemNumber,cropType,itemLookupType)
{
    var url;
    var operation = "FrameCreate"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['authToken',authToken];
    properties[2] = ['sessionId', sessionId];
    properties[3] = ['itemId', itemId];
    properties[4] = ['podConfigId', podConfigId];
    properties[5] = ['imageCropId', imageCropId];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.frameGetMoldingPriceByFrameId = function(callbacks,apiKey,sessionId,frameIdentifier,moldingItemNumber)
{
    var url;
    var operation = "FrameGetMoldingPriceByFrameId"; 
    var properties = [];
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId', sessionId];
    properties[2] = ['frameIdentifier', frameIdentifier];
    properties[3] = ['moldingItemNumber', moldingItemNumber];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.frameDuplicateForCart = function(callbacks,apiKey,sessionId,frameIdentifier)
{
    var url;
    var operation = "FrameDuplicateForCart"; 
    var properties = [];
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId', sessionId];
    properties[2] = ['frameIdentifier', frameIdentifier];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.frameGetMoldingPriceByDimensions = function(callbacks,apiKey,sessionId,moldingItemNumber,width,height)
{
    var url;
    var operation = "FrameGetMoldingPriceByDimensions"; 
    var properties = [];
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId', sessionId];
    properties[2] = ['moldingItemNumber', moldingItemNumber];
    properties[3] = ['innerDimensionWidth', width];
    properties[4] = ['innerDimensionHeight', height];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.frameUpdateMolding = function(callbacks,apiKey,sessionId,frameIdentifier,moldingItemNumber,position)
{
    var url;
    var operation = "FrameUpdateMolding"; 
    var properties = [];
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId', sessionId];
    properties[2] = ['frameIdentifier', frameIdentifier];
    properties[3] = ['moldingItemNumber', moldingItemNumber];
    properties[4] = ['position', position];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.frameUpdateMatCount = function(callbacks,apiKey,sessionId,frameId,matCount)
{
    var url;
    var operation = "FrameUpdateMatCount"; 
    var properties = [];
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId', sessionId];
    properties[2] = ['frameIdentifier', frameId];
    properties[3] = ['matCount', matCount];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.frameUpdateMat = function(callbacks,apiKey,sessionId,frameIdentifier,matItemNumber,position)
{
    var url;
    var operation = "FrameUpdateMat"; 
    var properties = [];
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId', sessionId];
    properties[2] = ['frameIdentifier', frameIdentifier];
    properties[3] = ['matItemNumber', matItemNumber];
    properties[4] = ['position', position];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.frameCreateForUserImage = function(callbacks,apiKey,sessionId,authToken,userIdentifier,imageGuid,podConfigId,imageCropId)
{
    var url;
    var operation = "FrameCreateForUserImage"; 
    var properties = [];
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId', sessionId];
    properties[2] = ['authToken', authToken];
    properties[3] = ['userIdentifier', userIdentifier];
    properties[4] = ['imageGuid', imageGuid];
    properties[5] = ['podConfigId', podConfigId];
   	properties[6] = ['imageCropId', imageCropId];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.frameUpdateCrop = function(callbacks, apiKey, sessionId, frameId, imageCropId, cropX, cropY, cropWidth, cropHeight)
{
    var url;
    var operation = "FrameUpdateCrop"; 
    var properties = [];
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId', sessionId];
    properties[2] = ['frameIdentifier', frameId];
    properties[3] = ['imageCropid', imageCropId];
    properties[4] = ['cropX', cropX];
    properties[5] = ['cropY', cropY];
    properties[6] = ['cropWidth', cropWidth];
    properties[7] = ['cropHeight', cropHeight];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.frameUpdateImageSize = function(callbacks, apiKey, sessionId, frameId, podConfigId)
{
    var url;
    var operation = "FrameUpdateImageSize"; 
    var properties = [];
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId', sessionId];
    properties[2] = ['frameIdentifier', frameId];
    properties[3] = ['podConfigId', podConfigId];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
com.art.core.services.EcommerceAPIService.prototype.frameGetComponentsForUserImage = function(callbacks,apiKey,sessionId,itemNumber,itemLookupType)
{
    var url;
    var operation = "FrameGetComponentsForUserImage"; 
    var properties = [];
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId', sessionId];
    properties[2] = ['podConfigId', itemNumber];
    properties[3] = ['itemLookupType', itemLookupType];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
/**
 * THIS IS THE OLD METHOD WHICH WILL BE OBSOLETE VERY SOON ================================================================= REMOVE THIS SOON========================
 * @param callbacks
 * @param apiKey
 * @param sessionId
 * @param podConfigId
 */
com.art.core.services.EcommerceAPIService.prototype.catalogItemGetFrameComponents = function(callbacks, apiKey, sessionId, podConfigId)
{
	var url;
	var operation = "CatalogItemGetFramingComponentsForUserImage";
	var properties = [];
	properties[0] = ['apiKey', apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['podConfigId',podConfigId];
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url, callbacks);
};
//string apiKey, string authToken, string sessionId, string itemAPNum, string PODConfigID, string imageID, 
//string unitOfMeasure, string frameId, int imageCropId, bool fixToFixedFrame, 
//string glassId, string moldingId, int matCount,bool matOversized, int mat1Id, int mat2Id, int mat3Id
com.art.core.services.EcommerceAPIService.prototype.imageUpdateFrame = function(callbacks, apiKey, authToken, sessionId, PODConfigID, imageID,
		unitOfMeasure, frameId, imageCropId, fixToFixedFrame, glassId, moldingId, matCount, matOversized, mat1Id, mat2Id, mat3Id)
{
    var url;
    var operation = "ImageUpdateFrame"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['authToken',authToken];
    properties[2] = ['sessionId', sessionId];
    properties[3] = ['podConfigId', PODConfigID];
    properties[4] = ['imageId', imageID];
    properties[5] = ['unitOfMeasure', unitOfMeasure];
    properties[6] = ['frameId', frameId];
    properties[7] = ['imageCropId', imageCropId];
    properties[8] = ['fixToFixedFrame', fixToFixedFrame];
    properties[9] = ['glassId', glassId];
    properties[10] = ['moldingId', moldingId];
    properties[11] = ['matCount', matCount];
    properties[12] = ['matOversized', matOversized];
    properties[13] = ['mat1Id', mat1Id];
    properties[14] = ['mat2Id', mat2Id];
    properties[15] = ['mat3Id', mat3Id];

    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url, callbacks);
};
