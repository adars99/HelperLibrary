/**
 * Convience class to enforce interfaces for various Classes
 * Used with JSTestDriver; Example usage:
 * @class InterfaceManager
 * @static
 * 
 */
com.art.core.interfaces.InterfaceManager = function(){};

/**
 * @method validateInterface
 * @param {Object} interfaceObj An interface Class to check obj against
 * @param {Object} obj An object to check to ensure implements given interface definition
 */
com.art.core.interfaces.InterfaceManager.validateInterface = function(interfaceObj,obj)
{
	var pass = true;
	for(var member in interfaceObj)
	{
		if(typeof obj[member] != typeof interfaceObj[member])
			pass = false;
	}
	return pass;
};