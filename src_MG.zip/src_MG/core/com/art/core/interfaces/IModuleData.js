/**
 * ModuleData is standarized VO object to pass into module when new Modules are instantiated
 * @class IModuleData
 * @constructor
 */
com.art.core.interfaces.IModuleData 					= function(){};
com.art.core.interfaces.IModuleData.prototype.id		= "";
com.art.core.interfaces.IModuleData.prototype.markup	= "";
com.art.core.interfaces.IModuleData.prototype.target	= "";
