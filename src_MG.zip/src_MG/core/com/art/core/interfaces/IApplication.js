/**
 * Interfaces go here
 * @module interfaces
 * @title art.com common interfaces
 */
com.art.core.interfaces.IApplication 					= function(){};
com.art.core.interfaces.IApplication.prototype.attach 	= function(){};
com.art.core.interfaces.IApplication.prototype.remove 	= function(){};