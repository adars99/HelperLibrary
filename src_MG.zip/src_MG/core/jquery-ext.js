function trace(msg)
{
   // try { console.log(msg); }
   // catch (e) { /*do nothing for IE*/ }   
    
	if( (window['console'] !== undefined) ){
        console.log( msg );
    }
}

if(typeof String.prototype.trim !== 'function')
{
	String.prototype.trim = function() {
	    return this.replace(/^\s+|\s+$/g, ''); 
	};
}
//SECTION - EXTEND JQUERY - adding centering function to jquery
//adding resize to Fill and to Fit functions
jQuery.fn.scaleObjectToFitOrFill = {
	   Calculate: function(options) {
	      // declare some local variables
	      var ratioX, ratioY, scale, newWidth, newHeight;
	      // Check to make sure all the required variables were sent and pass validation
	      if (typeof options.srcWidth !== "number" || typeof options.srcHeight !== "number" || typeof options.destWidth !== "number" || typeof options.destHeight !== "number" || typeof options.method !== "string") {
	         return;
	      }
	      // Grab scale ratios
	      ratioX = options.destWidth / options.srcWidth;
	      ratioY = options.destHeight / options.srcHeight;
	      // Determine which algorithm to use
	      if (options.method === "fit") {
	         scale = ratioX < ratioY ? ratioX: ratioY;
	      } else if (options.method === "fill") {
	         scale = ratioX > ratioY ? ratioX: ratioY;
	      }
	      // Set new dimensions
	      newWidth = parseInt(options.srcWidth * scale, 10);
	      newHeight = parseInt(options.srcHeight * scale, 10);
	      // Return the new dimensions, plus the offsets, and if the destination box
	      // is smaller or equal to the source image dimensions
	      return {
	         width: newWidth,
	         height: newHeight,
	         offset: {
	            x: parseInt((options.destWidth - newWidth) / 2, 10),
	            y: parseInt((options.destHeight - newHeight) / 2, 10)
	         },
	         fits: options.srcWidth >= options.destWidth && options.srcHeight >= options.destHeight ? true: false
	      };
	   }
	};

//adding resize to object parent 
jQuery.fn.resizeToParent = function(pixelMarginHorizontal, pixelMarginVertical)
{
	var parentObj = $(this).parent();
	var destinationWidth = parentObj.width();
	var destinationHeight = parentObj.height();
	if(this.width() > this.height())
		destinationWidth = destinationWidth - pixelMarginHorizontal;
	else
		destinationHeight = destinationHeight - pixelMarginVertical;
	
	//tr ace("before: " + this.width() + " x " + this.height() + " | fitting into space: " + destinationWidth + " x " + destinationHeight);
	var newValue = this.scaleObjectToFitOrFill.Calculate({
	      srcWidth: this.width(),
	      srcHeight: this.height(),
	      destWidth: destinationWidth,
	      destHeight: destinationHeight,
	      method: "fit"
	   });

	this.css({'width':newValue.width, 'height':newValue.height});
	//tr ace("after: " + this.width() + " x " + this.height() + " | fitting into space: " + destinationWidth + " x " + destinationHeight);
	
	return this;
};



jQuery.fn.centerNoDropShadow = function (keepCentered) {
	this.css("position","absolute");
	this.css("top", ( $(window).height() - this.height() ) / 2+$(window).scrollTop() + "px");
	this.css("left", ( $(window).width() - this.width() ) / 2+$(window).scrollLeft() + "px");
	if(keepCentered)
	{
		var _this = this;
		$(window).bind('resize',function(){
			_this.center(false);
		});
	}
	return this;
};


jQuery.fn.center = function (keepCentered) {
	var topValue = ( $(window).height() - this.height() ) / 2+$(window).scrollTop();
	//trace("Center: Top: window.height: " + $(window).height() + " | this.height: " + this.height() + " | window.scrollTop: " + $(window).scrollTop() + " | topValue: " + topValue);
	var leftValue = ( $(window).width() - this.width() ) / 2+$(window).scrollLeft();
	//trace("Center: left is " + leftValue + " window width: " + $(window).width() + " item width: " + this.width());
	if (topValue < 0) topValue = 0;
    this.css({"position":"absolute","top":topValue + "px","left":leftValue + "px"});

	$(this).addCenterOuterShadow();
	if(keepCentered)
	{
		var _this = this;
		$(window).bind('resize',function(){
		    //trace('Setting this to recenter on resize');
			_this.center(false);
		});
	}
	return this;
};

jQuery.fn.centerWithHeight = function(keepCentered, intHeight)
{
	var topValue = ( $(window).height() - intHeight ) / 2+$(window).scrollTop();
	//trace("Center: Top: window.height: " + $(window).height() + " | height: " + intHeight + " | window.scrollTop: " + $(window).scrollTop() + " | topValue: " + topValue);
	var leftValue = ( $(window).width() - this.width() ) / 2+$(window).scrollLeft();
	if (topValue < 0) topValue = 0;
    this.css({"position":"absolute","top":topValue + "px","left":leftValue + "px"});

	$(this).addCenterOuterShadow();
	if(keepCentered)
	{
		var _this = this;
		$(window).bind('resize',function(){
		    //trace('Setting this to recenter on resize');
			_this.center(false);
		});
	}
	return this;
};



jQuery.fn.centerElement = function () {
	this.css("position","relative");
	var parentObj = $(this).parent();
	this.css("top", ( parentObj.height() - this.height() ) / 2 + "px");
	this.css("left", ( parentObj.width() - this.width() ) / 2 + "px");
	return this;
};

jQuery.fn.addDropShadow = function (shadowType){
	if (shadowType != undefined)
		switch (shadowType.toLowerCase())
		{
			case 'none':
				break;
			case 'angle':
				$(this).addAngleShadow();
				break;
			case 'center':
				$(this).addCenterOuterShadow();
				break;
			default:
				$(this).addCenterOuterShadow();
		}
	else
		$(this).addCenterOuterShadow();
	return this;
};

jQuery.fn.addOuterGlow = function(blur,spread,opacity)
{
	this.css("-moz-box-shadow", "0px 0px " + blur + "px "+spread+"px rgba(0,0,0," + opacity + ")");
	this.css("-webkit-box-shadow", "0px 0px "+blur+"px " + spread + "px rgba(0,0,0," + opacity + ")");
	this.css("box-shadow", "0px 0px " + blur + "px " + spread + "px rgba(0,0,0," + opacity + ")");
	return this;
};
jQuery.fn.addCenterOuterShadow = function (){
	var topV = 0,leftV = 0, spreadV = 20, opacityV = .5;
	this.addDropShadowByValue(topV,leftV,spreadV,opacityV);
	return this;
};

jQuery.fn.addAngleShadow = function (){
	var topV = 3,leftV = 3, spreadV = 7, opacityV = .6;
	this.addDropShadowByValue(topV,leftV,spreadV,opacityV);
	return this;
};

jQuery.fn.addDropShadowByValue = function (topValue,leftValue,spreadValue,opacityValue){
	this.css("-moz-box-shadow", topValue + "px " + leftValue + "px " + spreadValue + "px rgba(0,0,0," + opacityValue + ")");
	this.css("-webkit-box-shadow", topValue + "px " + leftValue + "px " + spreadValue + "px rgba(0,0,0," + opacityValue + ")");
	this.css("box-shadow", topValue + "px " + leftValue + "px " + spreadValue + "px rgba(0,0,0," + opacityValue + ")");
	return this;
};

jQuery.fn.centerOnResize = function ()
{
	//Now add event to widow.resize to reposition module
	$(window).resize(function(theId) 
	{
		$($(this).attr('id')).center();
	});
	return this;
};

//$('img.photo',this).imagesLoaded(myFunction)
//execute a callback when all images have loaded.
//needed because .load() doesn't work on cached images

//mit license. paul irish. 2010.
//webkit fix from Oren Solomianik. thx!

//callback function is passed the last image to load
//as an argument, and the collection as `this`
//https://gist.github.com/268257

jQuery.fn.imagesLoaded = function(callback){
	var elems = this.filter('img'), len = elems.length;
   
	elems.bind('load',function(){
		if (--len <= 0){ callback.call(elems,this); }
	}).each(function(){
		// cached images don't fire load sometimes, so we reset src.
		if (this.complete || this.complete === undefined){
			var src = this.src;
			// webkit hack from http://groups.google.com/group/jquery-dev/browse_thread/thread/eee6ab7b2da50e1f
			// data uri bypasses webkit log warning (thx doug jones)
			this.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==";
			this.src = src;
		}
	});
	return this;
};
