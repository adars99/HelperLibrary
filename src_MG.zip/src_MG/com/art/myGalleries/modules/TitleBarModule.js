//CONSTRUCTOR: instantiates the instance, Every Object must implement the base
com.art.myGalleries.modules.TitleBarModule = function (data, app) {
    this.app = app;
    this.moduleData = data;
    this.NAME = com.art.myGalleries.modules.TitleBarModule.NAME;
    this.instance = this;
    this.loginBtn;
    this.addToCartBtn;
    this.modalLogin;
    this.loginLB;
    this.login= new com.art.core.components.LoginModal('myGalleryLogin', 'Login to your Art.com account', 'Sign up for a new Art.com account', 'myGallery');
    this.logoutBtn;    
    this.loginOption="";
};
com.art.myGalleries.modules.TitleBarModule.NAME = "TitleBarModule";

com.art.myGalleries.modules.TitleBarModule.prototype.init = function (viewmode) {

    this.loginBtn = new com.art.core.components.ArtButton("login", com.art.core.components.ArtButton.ART_BLUE, "Login", com.art.core.components.ArtButton.ARROW_RIGHT);
    this.logoutBtn = new com.art.core.components.ArtButton("logout", com.art.core.components.ArtButton.ART_BLUE, "Logout", com.art.core.components.ArtButton.ARROW_RIGHT);
    this.addToCartBtn = new com.art.core.components.ArtButton("titleBarModuleAddToCartBtn", com.art.core.components.ArtButton.ART_BLUE, "Add To Cart", com.art.core.components.ArtButton.ARROW_RIGHT);
    
    var _this = this;
    //$('#someContainer').html(btn.render());
    
    $(this.getTarget()).append(this.getTemplate());

    this.loginBtn.registerEvents();
    this.logoutBtn.registerEvents();
    this.addToCartBtn.registerEvents();
    
    // nullify the cookie on load
    var cookieobject = new com.art.core.cookie.Cookie();    
    cookieobject.setCookieDictionary('arts', 'sharemygalid', "",'/', cookieobject.getCookieDomain('art'));

    this.loginBtn.registerCallback(com.art.core.components.BaseButton.CLICK, function () {
        trace("login btn clicked");
        var cat = "";
        if(_this.app.getModel().currentViewMode == MyGalleriesCore.constants.GALLERY_HOME)
        	cat = "Entry";
        else if(_this.app.getModel().currentViewMode == MyGalleriesCore.constants.DETAIL_VIEW)
        	cat = "Details";
        else if(_this.app.getModel().currentViewMode == MyGalleriesCore.constants.GRID_VIEW)
        	cat = "Grid";
        	
        var evt = "Login or join - clicked";
        mygalleriesGA.trackEventWithCategory(cat, evt);
        _this.showLoginModal();
    });

    this.logoutBtn.registerCallback(com.art.core.components.BaseButton.CLICK, function () {
        trace("logout btn clicked");        
        _this.clearPersistantCookie();
    });

    this.addToCartBtn.registerCallback(com.art.core.components.ArtButton.CLICK, function () {
       // alert("add to cart btn clicked");
    });
};

/**
* Used this method to clear the authtoken,accouttype (if exist) and create anonymous authtoken the login modal
* @method showLoginModal
*/
com.art.myGalleries.modules.TitleBarModule.prototype.clearPersistantCookie = function () {    
    this.app.sendNotification(new com.art.core.utils.Note(this.app.events.LOGOUT_MYGALLERY));    
};
/**
* Used this method to call the login modal
* @method showLoginModal
*/
com.art.myGalleries.modules.TitleBarModule.prototype.showLoginModal = function () {

	
	
	
	var _this = this;
	
	
    this.loginLB = new com.art.core.components.LightBox('myLoginLB', 'body', .4);
    this.loginLB.zindex = this.app.getModel().getNextHighestZIndex();
    this.loginLB.show(); //append to target		

    this.login = new com.art.core.components.LoginModal('myGalleryLogin', 'Login to your Art.com account', 'Sign up for a new Art.com account ', 'myGallery',this.loginOption);

    $("body").append(this.login.render(this.app.getModel().getNextHighestZIndex() + 1));
    
    this.login.initSubmitButtons();
    
    this.login.registerEvents();

    this.login.registerCallback(com.art.core.components.LoginModal.CLOSE_CLICKED, function () {
    	// set the cookie to null when they close it
        var cookieobject = new com.art.core.cookie.Cookie();    
        cookieobject.setCookieDictionary('arts', 'sharemygalid', "",'/', cookieobject.getCookieDomain('art'));
    	_this.loginModalClose();
    });
    
    this.login.registerCallback(com.art.core.components.LoginModal.ON_FACEBOOK_LOGIN_SUCCESS,function(facebookResponse){    	
    	var data=facebookResponse.id;    	
    	_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.LOGIN_FACEBOOK_MYGALLERY,data));
    });

    this.login.registerCallback(com.art.core.components.LoginModal.REGISTER_CLICKED, function () {
        var data = _this.login.getRegisterAccountData();
        var note = new com.art.core.utils.Note(_this.app.events.REGISTER_ACCOUNT, { username: data.username, password: data.password }, "");
        _this.app.sendNotification(note);
    });
    this.login.registerCallback(com.art.core.components.LoginModal.LOGIN_CLICKED, function () {
        var data = _this.login.getLoginAccountData();
        
        
        
        var note = new com.art.core.utils.Note(_this.app.events.LOGIN_ACCOUNT, { username: data.username, password: data.password }, "");
        _this.app.sendNotification(note);
    });

};

/**
* Used this method to close the login modal as well as lightbox
* @method loginModalClose
*/
com.art.myGalleries.modules.TitleBarModule.prototype.loginModalClose = function ()
{    
    trace("login closed");
    this.login.close();
    this.loginLB.close();       
};

com.art.myGalleries.modules.TitleBarModule.prototype.notify = function()
{
	//NOTE: 
	this.app.sendNotification(note);
};

com.art.myGalleries.modules.TitleBarModule.prototype.listNotificationInterests = function()
{
    return [this.app.events.STARTUP,
     this.app.events.SHOW_LOGINMODAL,
     this.app.events.REGISTER_ACCOUNT_SUCCESS,
     this.app.events.REGISTER_ACCOUNT_FAILED,
     this.app.events.LOGIN_ACCOUNT_SUCCESS,
     this.app.events.LOGIN_ACCOUNT_FAILED,
     this.app.events.LOGOUT_MYGALLERY_SUCCESS,
     this.app.events.LOGOUT_MYGALLERY_FAILED,     
     this.app.events.LOGIN_FACEBOOK_MYGALLERY_SUCCESS,
     this.app.events.LOGIN_FACEBOOK_MYGALLERY_FAILED,
     this.app.events.GET_ALL_GALLERIES_SUCCESS,
     this.app.events.GET_ALL_GALLERIES_FAILED,
	];
};

com.art.myGalleries.modules.TitleBarModule.prototype.handleNotification = function (note) {
	var _this=this;
    trace('handleNotification');
    switch (note.name) {
        case this.app.events.STARTUP:
            //this.populateDetails(note.body);
            trace("json: " + note.body);
            break;
        case this.app.events.SHOW_LOGINMODAL:        	
        	this.loginOption=note.body;        		
            this.showLoginModal();
            break;
        case this.app.events.REGISTER_ACCOUNT_SUCCESS:
        	this.loginModalClose();
            //location.reload(true);
        	var cookieobject = new com.art.core.cookie.Cookie();
        	if(cookieobject.getCookieDictionary('ap','profileURL')!="")
    		{
    			var profileURL=cookieobject.getCookieDictionary('ap','profileURL')+"gallery/";
    			if(this.isMayGalShareCookieExists()){
    				this.app.getModel().environment.authToken=cookieobject.getCookieDictionary('ap','authToken');
    				this.redirecttoMyGalPageIfloginThroughShare(profileURL);
    			}
    			else{
    				window.location.href=profileURL;
    			}
    		}
        	else
    		{
            	window.location.href = window.location.href;        		
    		}
            break;
        case this.app.events.REGISTER_ACCOUNT_FAILED:
            $(".loginModalErrorMsg").css("display", "block");
            if (note.body == "exist") {
                //$(".loginErrorMsg").text('The email address you entered is already associated with an Art.com account. Would you like to retrieve your password?');
            	if($.browser.msie && parseInt($.browser.version)==7)
           		{
              		 if(this.id!="myGalleryLogin")
          	  		   { 
              			 $(".loginErrorMsg").css("top","60px");
          			 }
           		}
             	 else
         		 {
         		 	$(".loginErrorMsg").css('top','70px');
         		 }
             	
            	$(".loginErrorMsg").text('The email address you entered is already associated with an Art.com account.');
            }
            else if (note.body == "invalidemail") {
                //$(".loginErrorMsg").text('We were unable to recognize your email address. Please re-enter your information.');
            	$(".loginErrorMsg").text('Please enter a valid email address.');
            }
            else if (note.body == "invalidpassword") {
                //$(".loginErrorMsg").text('We were unable to recognize your password. Please re-enter your information or retrieve your password.');
            	$(".loginErrorMsg").text('Password must be at least 8 characters.');
            }
            else if (note.body == "failure") {
            	
            	if($.browser.msie)
            	{
              		 if(this.id!="myGalleryLogin")
          	  		   {
              			 $(".loginErrorMsg").css("top","40px");
          			   }
              		 else
              			 {
              			 	$(".loginErrorMsg").css("top","70px");
              			 }
            	}

                //$(".loginErrorMsg").text('We were unable to find an account associated with that email address. Please re-enter your information, or Sign Up for a new account.');
            	$(".loginErrorMsg").text('We were unable to find an account associated with that email address.');
            }
            break;
        case this.app.events.LOGIN_ACCOUNT_SUCCESS:
        	
        	this.loginModalClose();
        	var cookieobject = new com.art.core.cookie.Cookie();
        	if(cookieobject.getCookieDictionary('ap','profileURL')!="")
        		{
        			var profileURL=cookieobject.getCookieDictionary('ap','profileURL')+"gallery/";
        			if(this.isMayGalShareCookieExists()){
        				this.app.getModel().environment.authToken=cookieobject.getCookieDictionary('ap','authToken');
        				this.redirecttoMyGalPageIfloginThroughShare(profileURL);
        			}
        			else{
        				window.location.href=profileURL;
        			}
        			        			        			      			
        		}
        	else
        		{
                	window.location.href = window.location.href;        		
        		}

            break;
        case this.app.events.LOGIN_ACCOUNT_FAILED:
            if (note.body == "failure") {
                $(".loginModalErrorMsg").css("display", "block");
                if($.browser.msie)
          		{
                	$(".loginErrorMsg").css("top","70px");             		
          		}

                //$(".loginErrorMsg").text('We were unable to find an account associated with that email address. Please re-enter your information, or Sign Up for a new account.');
                $(".loginErrorMsg").text('We were unable to find an account associated with that email address.');
            }
            break;

        case this.app.events.LOGOUT_MYGALLERY_SUCCESS:
            	window.location.href ="http://" + location.host + this.app.getModel().environment.profileURL + "?logout=yes";
            break;
        case this.app.events.LOGOUT_MYGALLERY_FAILED:
        	trace("fail");
        	//var cookieobject = new com.art.core.cookie.Cookie();
        	//var profileURL=cookieobject.getCookieDictionary('ap','profileURL')+"gallery/";            
            //window.location.href = this.environment.customerZoneId;//"/asp/mygallery/mygalleries.asp";
        	//window.location.href = profileURL;//"/asp/mygallery/mygalleries.asp";
        	window.location.href = window.location.href;
            break;
        case this.app.events.LOGIN_FACEBOOK_MYGALLERY_SUCCESS:
        	trace("Facebook Success");        
        
        	this.loginModalClose();
        	var cookieobject = new com.art.core.cookie.Cookie();
        	if(cookieobject.getCookieDictionary('ap','profileURL')!="")
        		{
        			var profileURL=cookieobject.getCookieDictionary('ap','profileURL')+"gallery/";
        			if(this.isMayGalShareCookieExists()){
        				this.app.getModel().environment.authToken=cookieobject.getCookieDictionary('ap','authToken');
        				this.redirecttoMyGalPageIfloginThroughShare(profileURL);
        			}
        			else{
        				window.location.href=profileURL;
        			}
        		}
        	else
        		{
                	window.location.href = window.location.href;        		
        		}
        	break;        	
        case this.app.events.LOGIN_FACEBOOK_MYGALLERY_FAILED:
        	trace("Facebook fail");
        	break;
        	
        case this.app.events.GET_ALL_GALLERIES_SUCCESS:
			trace("GET_ALL_GALLERIES_SUCCESS in Titlebar module"+note.name);	
			window.location.href = this.getRedirectUrl(this.app.getModel().ProfileUrl);
			//this.getRedirectUrl(this.app.getModel().ProfileUrl);
			break;
		case this.app.events.GET_ALL_GALLERIES_FAILED:	
			trace("GET_ALL_GALLERIES_FAILED in Titlebar module"+note.name);
			window.location.href = this.getRedirectUrl(this.app.getModel().ProfileUrl);
			//this.getRedirectUrl(this.app.getModel().ProfileUrl);
			break;        	
        default:
            trace("default case");
    }
};

// redirects to right gallery after logging in before trying to share via facebook or email.
com.art.myGalleries.modules.TitleBarModule.prototype.redirecttoMyGalPageIfloginThroughShare = function(profileURL)
{
		this.app.getModel().ProfileUrl=profileURL;
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_ALL_GALLERIES));		
};

/**
 * Modify url if redirecting if login from share drop down
 * @param profileURL
 */
com.art.myGalleries.modules.TitleBarModule.prototype.getRedirectUrl = function(profileURL)
{
	// for story 122 get the key
	var newURL = "";
	var cookieobject = new com.art.core.cookie.Cookie();
	var mygalId=cookieobject.getCookieDictionary('arts','sharemygalid');
	
	trace("mygalId: "+mygalId);	
	
	if(mygalId.length>0){        				        			
		var mygalName=this.app.getModel().cacheByGalleryList[mygalId].ItemKey;        			        			
		if(mygalName.length>0){
			newURL=profileURL+mygalName+"/";			
		}        			
	}
	//else
	//{
	//	trace("mygalId is not set");
		newURL=newURL+this.getRoomViewQS(this.app.getModel().currentViewMode);
	//}	
	trace("newURL: "+newURL);	
	return newURL;
};

com.art.myGalleries.modules.TitleBarModule.prototype.isMayGalShareCookieExists = function()
{
	var cookieobject = new com.art.core.cookie.Cookie();
	var mygalId=cookieobject.getCookieDictionary('arts','sharemygalid');			
	if(mygalId.length>0){
		trace("mygalIdexists: "+mygalId);
		return true;
	}
	return false;
};

// this method gets the querystring values required for redirecting to room view after login
//example ?viewmode=roomView/<WALLID>[/<HEX_VALUE>]
com.art.myGalleries.modules.TitleBarModule.prototype.getRoomViewQS = function(viewmode)
{
	trace("getRoomView: "+viewmode);
	var str = "";
	if(typeof viewmode == "number" )
		throw new Error("TitleBarModule.getRoomViewQuerystringVals failed! Invalid input, expected string got number.");
	
	//get required selectedWallName
	var sWallName = this.app.getUserLibraryProxy().selectedWallName;
	if(sWallName == "" || sWallName == undefined)
		  throw new Error("TitleBarModule.getRoomViewQuerystringVals failed! selectedWallName is not defined.");
	
	
	if(viewmode == this.app.constants.ROOM_VIEW){		
	  str ="?viewmode=roomView/"+this.app.getUserLibraryProxy().getWallId(sWallName)+this.app.getUserLibraryProxy().getHexValue(sWallName); 	  	 
	}
	trace("str: "+str);
	return str;
};


//get wall id for getRoomViewQS

com.art.myGalleries.modules.TitleBarModule.prototype.populateDetails = function(response)
{
	if(response != undefined){
		if(response.galleryTitle != "")
			$('.MyGalleriesTitle').text(response.galleryTitle);
		else
			$('.MyGalleriesTitle').text("");
			;
		if(response.galleryDescription != "")
			{
				$('.MyGalleriesDescription').text(response.galleryDescription);
			}
		else
			{
				$('.MyGalleriesDescription').text("");
			}
	}
};

com.art.myGalleries.modules.TitleBarModule.prototype.getTemplate = function()
{
	return this.template.replace('$NAME', this.NAME).replace("$ADD_TO_CART_BUTTON",this.addToCartBtn.render()).replace("$LOGIN_BUTTON",this.loginBtn.render());
};

com.art.myGalleries.modules.TitleBarModule.prototype.getTarget = function()
{
	return this.moduleData.target;
};

com.art.myGalleries.modules.TitleBarModule.prototype.template
=		"<div id='$NAME' class='$NAME'>"
+			"<div class='MyGalleriesTitleLeft'>"
+				"<div class='MyGalleriesTitleRow1'>"
                + "<div class='MyGalleriesHeaderLogo'></div>"+
               // "<div style='float:left'>$LOGIN_BUTTON</div>" +
                 //   "<div style='float:left;display:none;'>$LOGOUT_BUTTON</div>" +
+					"<div class='clear'></div>"
+				"</div>"
+			"</div>"
+			"<div class='MyGalleriesTitleRight'>"
+				"<div class='MyGalleriesTitlePriceText MyGalleriesTitleTotalItems'>5 Items</div>"
+				"<div class='MyGalleriesTitlePriceText MyGalleriesTitleTotalItemRegularPrice MyGalleriesTitlePriceStrike'>$0.00</div>"
+				"<div class='MyGalleriesTitlePriceText MyGalleriesTitleTotalItemPrice MyGalleriesTitleRedColor'>$0.00</div>"
+				"<div style='display:inline-block'>"+
					"<div style='float:left'>$ADD_TO_CART_BUTTON</div>"+
					"<div style='float:left'>$LOGIN_BUTTON</div>" +
                   // "<div style='float:left;display:none;'>$LOGOUT_BUTTON</div>" +
				"</div>"
+			"</div>"
+			"<div class='clear'></div>"
+		"</div>";


