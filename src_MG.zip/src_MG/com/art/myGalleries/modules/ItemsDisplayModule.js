//CONSTRUCTOR: instantiates the instance, Every Object must implement the base
com.art.myGalleries.modules.ItemsDisplayModule = function(data,app)
{
	this.app 		= app;
	this.moduleData = data;
	this.NAME		= com.art.myGalleries.modules.ItemsDisplayModule.NAME;
	this.instance	= this;
	this.grid;
	this.itemHoverComponent;
};
com.art.myGalleries.modules.ItemsDisplayModule.NAME = "ItemsDisplayModule";

com.art.myGalleries.modules.ItemsDisplayModule.prototype.RecordsPerPage = 15;
com.art.myGalleries.modules.ItemsDisplayModule.prototype.RecordsPerRequest = 96;
com.art.myGalleries.modules.ItemsDisplayModule.prototype.TotalRecordCount = 24;
com.art.myGalleries.modules.ItemsDisplayModule.prototype.PageNo = 1;
com.art.myGalleries.modules.ItemsDisplayModule.prototype.initialLoad = false;

com.art.myGalleries.modules.ItemsDisplayModule.prototype.getTarget = function ()
{
	//NOTE: Init is where you initialize the handlers for this module and any variables, etc instantiated object will need
	return this.moduleData.target;
};

com.art.myGalleries.modules.ItemsDisplayModule.prototype.init = function ()
{
	var _this = this;
	
	$(this.getTarget()).html(this.getTemplate());
	this.notify();
	
};
com.art.myGalleries.modules.ItemsDisplayModule.prototype.getItemHoverComponent = function()
{
	if(this.itemHoverComponent == undefined)
	{
		this.itemHoverComponent = new com.art.myGalleries.components.ItemHoverComponent(this.app.getModel().currentViewMode);
		$("#items").append(this.itemHoverComponent.render());
	}
	return this.itemHoverComponent;
};
com.art.myGalleries.modules.ItemsDisplayModule.prototype.setImages = function(arr)
{
	var _this = this;
	$("#items").html("");//clear first
	
	for(var i=0; i < arr.length; i++)
	{
		trace("imageUrl: "+arr[i].ImageUrl);
		trace("apnum: "+arr[i].ItemId);
		var item = new com.art.myGalleries.components.ItemComponent(arr[i].ImageUrl,arr[i].ItemId,258,'http://imagecache1.art.com');
		item.registerCallback(com.art.myGalleries.components.ItemComponent.HOVER,function(apnum){
			trace("itemHover with data");
			var data = _this.app.getModel().getItemByApnum(apnum);
			trace(data);
			_this.getItemHoverComponent().setData(data,apnum);
			_this.getItemHoverComponent().update();
			_this.getItemHoverComponent().fadeIn();
			
		});
		$("#items").append(item.render());
		item.registerEvents();
	}
	
	$("#items").append("<div class='clear'></div>");
	
};
com.art.myGalleries.modules.ItemsDisplayModule.prototype.destroy = function()
{
	//NOTE: Destroy is where you destroy this object and clean up memory
};

com.art.myGalleries.modules.ItemsDisplayModule.prototype.notify = function()
{
	trace("pageNo: "+this.PageNo);
	var rvo = new com.art.myGalleries.vos.RequestVO(new art.core.vos.RequestBaseVO(this.app.getEnvironment()));
	rvo.init('sessionid','authToken','apiKey',this.PageNo);
	this.app.sendNotification(new art.core.Note(this.app.events.GALLERY_LIST_REQUEST,{requestVO:rvo},'vo'));
};

com.art.myGalleries.modules.ItemsDisplayModule.prototype.listNotificationInterests = function()
{
	return [
	        this.app.events.GALLERY_LIST_REQUEST_SUCCESS
	];
};

com.art.myGalleries.modules.ItemsDisplayModule.prototype.handleNotification = function(note)
{
	trace('handleNotification'+note.name);
	switch(note.name)
	{
		case this.app.events.GALLERY_LIST_REQUEST_SUCCESS:
			trace("galleryList:");
			trace(note.body.galleryList);
			this.setImages(note.body.galleryList);
			break;
	};
	
};

com.art.myGalleries.modules.ItemsDisplayModule.prototype.getTemplate = function()
{
	//STEP: Get the raw string for the template
	var returnValue = this.template;
	//STEP: Replace the [IMAGE_DOMAIN] placeholder with the imagePath value
	returnValue = returnValue.replace(/\[IMAGE_DOMAIN\]/gi, this.imagePath);
	//STEP: Now return the string (template)
	return returnValue.replace('$NAME', this.NAME);
};

com.art.myGalleries.modules.ItemsDisplayModule.prototype.getTarget = function()
{
	return this.moduleData.target;
};

com.art.myGalleries.modules.ItemsDisplayModule.prototype.template = '<div id="$NAME"><div id="topNavigation">top nav</div><div id="items">Items </div><div id="bottomNavigation">bottom nav</div></div>';
