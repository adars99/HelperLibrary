com.art.myGalleries.modules.ShareModule = function(data,app)
{
	this.app = app;	
	this.moduleData = data;
	this.NAME = com.art.myGalleries.modules.ShareModule.NAME;
	this.instance = this;
	this.shareType; //used w/RoomView
	this.loginScreen; 
};
com.art.myGalleries.modules.ShareModule.NAME= "ShareModule";
//init
com.art.myGalleries.modules.ShareModule.prototype.init = function(){};

com.art.myGalleries.modules.ShareModule.prototype.listNotificationInterests = function()
{
	return [
	        	this.app.events.SHARE_REQUEST,
	        	this.app.events.SHARE_ACTION_SUCCESS,
	        	this.app.events.SHOW_LOGIN_OR_JOIN,
	        ];

};

//handleNotification
com.art.myGalleries.modules.ShareModule.prototype.handleNotification = function(note)
{	
	switch(note.name)
	{
		case this.app.events.SHARE_REQUEST:
			var obj = note.body;
			var url = this.getShareURL(obj);
			obj.shareURL = url;		
			
			if(obj.viewMode == this.app.constants.SLIDESHOW || obj.viewMode == this.app.constants.GRID_VIEW)
			{	
				this.showPopUp(obj);
			}
			else if(obj.viewMode == this.app.constants.DETAIL_VIEW)
			{	
				this.showPopUp(obj);
			}
			else if(obj.viewMode == this.app.constants.ROOM_VIEW)
			{
				this.showPopUp(obj);
				
			}
			else
			{
				//send url to get shortened
			}
			
			break;
		case this.app.events.SHARE_ACTION_SUCCESS:
			var obj = note.body.rvo;
			obj.shareType = this.app.getModel().shareType;
			if(obj.galleryURL == "")
				throw new Error("ShareModule galleryURL is invalid!");
			
			trace(obj);
			this.showPopUp(obj);
			break;
		case this.app.events.SHOW_LOGIN_OR_JOIN:	
			this.showShareWithoutLoggedInModal(note.body);
			break;
		default:
			throw new Error("ShareModule failed! event not found");
	}
};
com.art.myGalleries.modules.ShareModule.prototype.showPopUp = function(data)
{		
	if(this.app.getModel().environment.accountType == this.app.constants.ANONYMOUS)
	{		
		//show need to login prompt
		this.showShareWithoutLoggedInModal();
	}
	else
	{		
		if(data.shareType == this.app.constants.FACEBOOK)
		{
			var _this = this;
			//prevent passing framed images to FB, replace with static image url
			data.imageURL = data.imageURL.indexOf("/frameimagehandler/") > - 1 ? "http://cache1.artprintimages.com/images/pub/navigation/global/art_com_logo.gif" : data.imageURL;
			FB.ui({
				app_id: FacebookAppID,
				display:'popup',
				method: 'feed',
				name: _this.app.getModel().environment.galleryKey,
				link: data.galleryURL,
				caption: (_this.app.getModel().facebookShare[data.viewMode].caption),
				picture:(data.imageURL),
				description: (_this.app.getModel().facebookShare[data.viewMode].description)
				},
				function(response) {
					if (response && response.post_id) { trace('FB Post was published.');}
					else{ trace('FB Post was not published.');}
				});
			
			//var temp = "http://www.art.com/visualsearch";
//			var win=null;
//			var mypage,myname,w,h,scroll,pos;
//			trace(data.galleryURL);
//			mypage = "http://www.addthis.com/bookmark.php?v=250&s=facebook&url="+data.galleryURL;
//			myname = "";
//			w = 750;
//			if($.browser.msie){h = 530;}
//			else{			
//			h = 500;
//			}
//			scroll = "no";
//			pos = "center";
//			if(pos=="random"){LeftPosition=(screen.width)?Math.floor(Math.random()*(screen.width-w)):100;TopPosition=(screen.height)?Math.floor(Math.random()*((screen.height-h)-75)):100;}
//			if(pos=="center"){LeftPosition=(screen.width)?(screen.width-w)/2:100;TopPosition=(screen.height)?(screen.height-h)/2:100;}
//			else if((pos!="center" && pos!="random") || pos==null){LeftPosition=0;TopPosition=20;}
//			settings='width='+w+',height='+h+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=no';
//			win=window.open(str,myname,settings);
		}
		if(data.shareType == this.app.constants.EMAIL)
		{	
			var _this = this;
			var w,h,scroll,pos;
			var arrURL, croppedImageURL, imageURL;  
			imageURL = data.imageURL;
			croppedImageURL = imageURL;
			
			if(_this.app.getModel().currentViewMode != _this.app.constants.ROOM_VIEW)
			{
				arrURL = data.imageURL.match(/MED\/([0-9]+)\/([0-9]+)\/([0-9A-Z]+)/);
			    if((arrURL != null || arrURL != undefined) && arrURL.length > 2)			    	
			    	croppedImageURL =  "http://imagecache5d.art.com/Crop/crop.jpg?img="+(arrURL[1]+"-"+arrURL[2]+"-"+arrURL[3])+"&x=0&y=0&w=1000&h=1000&size=2&maxw=100&maxh=100&q=100";			    		
			    	croppedImageURL= croppedImageURL.replace(/&/g,"<");			    				    	

			    imageURL = data.imageURL.replace("MED","LRG");
			    imageURL= imageURL.replace(/&/g,"<");
			    
			}
			
			mypage = "/asp/product/mailfriend.asp?mode=myGalleries&viewMode="+this.app.getModel().currentViewMode+"&imageURL="+imageURL+"&croppedImgURL="+croppedImageURL+"&GalleryURL="+data.galleryURL+"&title="+data.title+"&ItemCount="+data.additionalArgs;
			//http://loc-www.art.com/asp/product/mailfriend.asp?emailType=myGalleries&imageURL=http://cache2.artprintimages.com/LRG/27/2742/PWRND00Z.jpg&GalleryURL=http://loc-www.art.com/me/shyam/gallery/MyGalleries/
			myname = "Email";
			w = 510;
			if($.browser.msie){h = 485;}
			else{h = 485;}
			
			scroll = "no";
			pos = "center";
			if(pos=="random"){LeftPosition=(screen.width)?Math.floor(Math.random()*(screen.width-w)):100;TopPosition=(screen.height)?Math.floor(Math.random()*((screen.height-h)-75)):100;}
			if(pos=="center"){LeftPosition=(screen.width)?(screen.width-w)/2:100;TopPosition=(screen.height)?(screen.height-h)/2:100;}
			else if((pos!="center" && pos!="random") || pos==null){LeftPosition=0;TopPosition=20;}
			settings='width='+w+',height='+h+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=no';
			win=window.open(mypage,myname,settings);
			
			//emailType=myGalleries&imageURL=http://cache2.artprintimages.com/LRG/27/2742/PWRND00Z.jpg&GalleryURL=http://loc-www.art.com/me/shyam/gallery/MyGalleries/
			
			//window.location.href="/asp/product/mailfriend.asp";
			//launch email popup + data.url + data.title + data.image
			
		}
	}
	
};

/**
 * Used this method to call the lightbox and share without logged in Modal * 
 * @method showShareWithoutLoggedInModal
 */
com.art.myGalleries.modules.ShareModule.prototype.showShareWithoutLoggedInModal = function (action) {
	
	var displayTitle='Login to Share Your Gallery';
	var displayContent="To take full advantage of gallery features, including sharing with friends, please Sign Up for an account or Login.";
	
	var jointxt='Sign Up';
	// we have some customization for exit gaurd scenario
	if(action=="exitgaurdevent"){
		displayTitle="Login to Save Your Gallery";
		jointxt="Sign Up";
	}
	if(action=="inviteFriend"){
		displayTitle="Login to Change Privacy Options";
		displayContent="To change privacy options, please Sign Up for an account, or Login.";
		jointxt="Sign Up";
	}
	
	var _this = this;       
    this.shareWithoutLoggedInLB = new com.art.core.components.LightBox('myShareWithoutLoggedInLB', 'body', .4);
    this.shareWithoutLoggedInLB.show(); // append to target

    var shareWithoutLoggedIn = new com.art.myGalleries.components.CommonComponent('shareWithoutLoggedIn', displayTitle, 500, 230,'','','','','',displayContent);

    this.modalshareWithoutLoggedIn = new com.art.core.components.BaseModal("myModalShareWithoutLoggedIn", 400, "#f7f7ed", true);
    this.modalshareWithoutLoggedIn.setContents(shareWithoutLoggedIn.render());
    
    $("body").append(this.modalshareWithoutLoggedIn.render(this.shareWithoutLoggedInLB.getLightBoxZIndex() + 1));
    this.modalshareWithoutLoggedIn.registerEvents();
    
    shareWithoutLoggedIn.registerEvents();
    
    this.modalshareWithoutLoggedIn.registerCallback(
			com.art.core.components.BaseModal.CLOSE_CLICKED, function () {
			    _this.modalshareWithoutLoggedIn.close();
			    _this.shareWithoutLoggedInLB.close();

			});    
    
    this.modalshareWithoutLoggedIn.registerButton("notNowBtn", com.art.core.components.ArtButton.ART_ORANGE, "Not Now", function () {
        trace("Not now button clicked");
        _this.modalshareWithoutLoggedIn.close();
	    _this.shareWithoutLoggedInLB.close();
	    	   	    
	    if($('#dmyGalleriesPage').data('myGalMenuItemClickedHref')!=undefined)
		    window.location.href=$('#dmyGalleriesPage').data('myGalMenuItemClickedHref');
    });
    
//Used for sharewithout logged in code
    
    if(action=="inviteFriend")
    	$('.MyGalleriesLoginContainer').css('width','85%');
    
    if(action=="exitgaurdevent"){
    	$('.MyGalleriesLoginContainer').html(displayContent);
    	$('.MyGalleriesLoginContainer').css('width','365');
    }
//    $("#notNowBtn_rightcap").css("position","absolute");
    $("#notNowBtn_rightcap").css("left","76px");
    $("#notNowBtn").css("position","absolute");
    $("#notNowBtn").css("left","20px");
    $("#notNowBtn").css("width","88px");
    
    //end code
    
    this.modalshareWithoutLoggedIn.registerButton("joinBtn", com.art.core.components.ArtButton.ART_BLUE, jointxt, function () {
        trace("Join button clicked");
        
        _this.modalshareWithoutLoggedIn.close();
	    _this.shareWithoutLoggedInLB.close();
        _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.SHOW_LOGINMODAL,_this.app.constants.SIGNUP));
//        _this.showLogin();
    });
    this.modalshareWithoutLoggedIn.registerButton("loginBtn", com.art.core.components.ArtButton.ART_BLUE, "Login", function () {
        trace("Login button clicked");
        _this.modalshareWithoutLoggedIn.close();
	    _this.shareWithoutLoggedInLB.close();	
	    _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.SHOW_LOGINMODAL,_this.app.constants.LOGIN));  
       	  
        //_this.showLogin();        
    });
};


/**
* Used this method to call the login modal
* @method showLoginModal
*/
com.art.myGalleries.modules.ShareModule.prototype.showLogin = function () {
    var _this = this;
    
    this.loginScreen = new com.art.core.components.LoginModal('myGalleryLogin', 'Login to your Art.com account', 'Register a new Art.com account ', 'myGallery','register');
    $("body").append(this.loginScreen.render(this.app.getModel().getNextHighestZIndex() + 1));    
    this.loginScreen.initSubmitButtons();    
    this.loginScreen.registerEvents();    
    
    this.loginScreen.registerCallback(com.art.core.components.LoginModal.CLOSE_CLICKED, function () {
        _this.loginModalClose();
    });

    this.loginScreen.registerCallback(com.art.core.components.LoginModal.REGISTER_CLICKED, function () {
        var data = _this.loginScreen.getRegisterAccountData();
        var note = new com.art.core.utils.Note(_this.app.events.REGISTER_ACCOUNT, { username: data.username, password: data.password }, "");
        _this.app.sendNotification(note);
    });
    this.loginScreen.registerCallback(com.art.core.components.LoginModal.LOGIN_CLICKED, function () {
        var data = _this.loginScreen.getLoginAccountData();
        var note = new com.art.core.utils.Note(_this.app.events.LOGIN_ACCOUNT, { username: data.username, password: data.password }, "");
        _this.app.sendNotification(note);
    });

};

/**
* Used this method to close the login modal as well as lightbox
* @method loginModalClose
*/
com.art.myGalleries.modules.ShareModule.prototype.loginModalClose = function ()
{    
    trace("login closed");
    this.loginScreen.close();
};
com.art.myGalleries.modules.ShareModule.prototype.getShareURL = function(shareRequestVO)
{
	return shareRequestVO.imageURL;
};
/**
 * If shareType == Gallery format with galleryName/count
 * @param shareRequestVO
 * @returns {String}
 */
com.art.myGalleries.modules.ShareModule.prototype.getShareTitle = function(shareRequestVO)
{
	return "someURL";
};


