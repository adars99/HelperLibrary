//CONSTRUCTOR: instantiates the instance, Every Object must implement the base
com.art.myGalleries.modules.DetailView = function(data,app)
{
	this.app 		= app;
	this.moduleData = data;
	this.NAME		= com.art.myGalleries.modules.DetailView.NAME;
	this.instance	= this;
	this.modalGalleryLB;
	this.myModalSaveToGallery;
	this.superZoom = new com.art.core.utils.SuperZoom("detailsSZ",340);
	this.id;
	this.data;
	this.modalMoveToGallery;
	this.zW = 58;
    this.zH = 70;
};
com.art.myGalleries.modules.DetailView.NAME = "DetailView";
com.art.myGalleries.modules.DetailView.prototype.init = function()
{
	var _this = this;
	
	this.id = $('.MyGalHeroImageContainer').attr('id');
	_this.app.getModel().environment.selectedGalleryItemId = _this.id;
	
	_this.data = _this.app.getModel().cacheByGalleryItemList[_this.id];
	
	_this.app.getModel().setSelectedGridItem(_this.id);
	
	$("#MyGalProductPageShare").live('click', function(){
		 $("#MyGalProductPageShare_toggle").show();
	});
	$("#MyGalProductPageShare").mouseleave(function () {
		$("#MyGalProductPageShare_toggle").hide();
	});
	$("#MyGalProductPageShare").mouseenter(function () {
		//todo
	});
	
	$(".MyGalProductPageFrameDetailsClick").live('click', function(){

		$('.MyGalFrameDetailsContent').slideToggle("slow");
        if ($('.MyGalFrameArrowCollapse').css('display') != 'block') {
            $('.MyGalFrameArrowCollapse').show();
            $('.MyGalFrameArrowExpand').hide();
        }
        else {
            $('.MyGalFrameArrowCollapse').hide();
            $('.MyGalFrameArrowExpand').show();
        }
	});	
	
	// change the class name now , so that we can use later if needed
	$(".MyGalProductPageSimilarArtHeader123").live('click', function(){
		
		$('.MyGalSimilarArtContent').slideToggle("slow");
        if ($('.MyGalSimilarArtArrowCollapse').css('display') != 'block') {
            $('.MyGalSimilarArtArrowCollapse').show();
            $('.MyGalSimilarArtArrowExpand').hide();
        }
        else {
            $('.MyGalSimilarArtArrowCollapse').hide();
            $('.MyGalSimilarArtArrowExpand').show();
        }
	});
	
	$(".ViewArtWork").live('click', function(){
		 $(".restArtWork").show();
		 $(".ellpiseArtWork").hide();
		 $(this).hide();
	});
	
	
	$(".MyGalleriesZoomIcon, .centerMyGalleryProductPageImage").live('click', function(){
		
		//var icon2 = "<div style='background-image:url(http://cache1.artprintimages.com/images/mygallery/my_galleries_sprite.png); background-position:0px -169px;width:48px;height:24px;'/>";
		//var szob = new com.art.core.components.OptionButton("szOptionButton",icon2+"<div style='font-family:verdana;font-size:11px;width:48px;color:#333333; text-shadow: 0 1px #FFFFFF;'>Share</div>",50,50,[{label:"Share via Facebook",value:"facebook",selected:false},{label:"Send Email to Friend",value:"email",selected:false}]);
		
		
		//var sz = new com.art.core.components.SuperZoom("mySZ",1000);
		//sz.attachExternalComponent(szob);
		//var data = _this.app.getModel().getGalleryItemByGalleryId(_this.id);
		//trace("DetailView"+data);
		//sz.setPrice("$15.99");
		//sz.setSalePrice("$12.99");
		//_this.superZoom.registerCallback(com.art.core.components.SuperZoom.IMAGE_LOADED,function(){
			//trace("Zoom image loaded");
			//szob.zindex = sz.getNextHighestZIndex(); //relative to sz
			//szob.registerEvents();
		//});
		 
		//sz.show($(".centerMyGalleryProductPageImage").attr("src"));
		var zWidth, zHeight;

	    if (typeof window.innerWidth != 'undefined') {	    
	        zWidth = window.innerWidth - _this.zW;
	        zHeight = window.innerHeight - _this.zH;
	    }
	    else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
	        //IE 6+ in 'standards compliant mode' 
	    
	        zWidth = document.documentElement.clientWidth - _this.zW;
	        zHeight = document.documentElement.clientHeight - _this.zH;
	    }
		
		var zoomUrlImage = com.art.core.utils.BrowserUtil.getCroppedImageUrl(_this.data.ItemDetails.ImageInformation.CroppedSquareImage.HttpImageURL,zWidth, zHeight, com.art.core.utils.BrowserUtil.cropperModes.NONE);
		
		_this.superZoom.show(zoomUrlImage);		
	});
	
	$("#addToCartDetailView").live('click', function(){
		mygalleriesGA.trackEventWithCategory("Details", "Add to cart");

    	var data = _this.app.getModel().cacheByGalleryItemList[_this.id];
    	var sessionId = _this.app.getModel().environment.sessionId;
    	
    	if(data.PODConfigID!=undefined && data.PODConfigID!=null)
    	{
    		var PODConfigID = data.PODConfigID;
    	}
    	else
    	{
    		var PODConfigID=0;
    	}
    	
    	var props = {ItemId:data.ItemId,
    				 frameConfigurationId:data.FrameSku,
    			     artSku:data.ItemDetails.Sku,
    			     podconfigid:PODConfigID,
    			     apnum:data.APNum
    			};
    	
    	if(props.frameConfigurationId != null && props.frameConfigurationId.trim().length > 0)
    		_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.GET_FRAME_ID,props));
    	else
    	{
    		window.location.href = com.art.core.utils.BusinessUtil.getSimpleAddToCartUrl(data.ItemDetails.Sku,data.PODConfigID, data.SpecialHandlingID, sessionId);
    	}
	});
	
	$("#frame_label_add").live('click', function() {
        var data = _this.app.getModel().cacheByGalleryItemList[_this.id];
        var url;
        var sku = data.ItemDetails.Sku;
        var pd = sku.substring(0, sku.length - 1);
        var sp = sku.substring(sku.length - 1, sku.length);
        var APNum = data.APNum;
        if(data.PODConfigID!=undefined && data.PODConfigID!=null)
        	{
        		var PODConfigID = data.PODConfigID;
        	}
        else
        	{
        		var PODConfigID=0;
        	}
        var UIDATA = _this.app.getModel().environment.sessionId;
        var IID = "";
        var customerZoneId = _this.app.getModel().environment.customerZoneId;
        _this.setCookieForAddFrameGallery(_this.app.getModel().environment.galleryKey);
        url = "http://" + location.host + "/framestep/default.asp" + "?pd=" + pd + "&sp=" + sp + "&APNUM=" + APNum + "&PODConfigID=" + PODConfigID + "&ui=" + UIDATA + "&IID=" + IID + "&customerzoneid=" + customerZoneId;
        window.location = url;
    });
	
	$("#frame_label_edit").live('click', function() {
        var data = _this.app.getModel().cacheByGalleryItemList[_this.id];
        var url;
        //var sku = data.ItemDetails.Sku;
        //var pd = sku.substring(0, sku.length - 1);
        //var sp = sku.substring(sku.length - 1, sku.length);
        var APNum = data.APNum;
        if(data.PODConfigID!=undefined && data.PODConfigID!=null)
    	{
    		var PODConfigID = data.PODConfigID;
    	}
        else
    	{
    		var PODConfigID=0;
    	}
        var UIDATA = _this.app.getModel().environment.sessionId;
        var IID = "";
        var customerZoneId = _this.app.getModel().environment.customerZoneId;
        var frameSku = data.FrameSku;
        
        _this.setCookieForAddFrameGallery(_this.app.getModel().environment.galleryKey);
        url = "http://" + location.host + "/framestep/default.asp" + "?APNUM=" + APNum + "&PODConfigID=" + PODConfigID + "&ui=" + UIDATA + "&IID=" + IID + "&customerzoneid=" + customerZoneId + "&Sku=" + frameSku;
        
        window.location = url;
    });
	
	if(_this.data.ItemDetails.Artist.ArtistCategoryId > 0)
		this.setSimilarArtistItems();
	
	$("#MyGalProductPageDelete").live('click',function(){	
        _this.DeleteArt();
	});
	 $("#MyGalProductPageMove").die();
	$("#MyGalProductPageMove").live('click', function(){
		_this.MoveToGallery();
	});
	
};

com.art.myGalleries.modules.DetailView.prototype.setCookieForAddFrameGallery = function(param)
{
	if(param != "")
	{
		var cookieobject = new com.art.core.cookie.Cookie();
		cookieobject.setCookieDictionary('arts','SaveToGallery',param,'/', cookieobject.getCookieDomain('art'));
	}	
};

com.art.myGalleries.modules.DetailView.prototype.MoveToGallery = function () {
	var _this = this;
    this.moveToGalleryLB = new com.art.core.components.LightBox('myMoveToGalleryLB', 'body', .4);
    this.moveToGalleryLB.show(); //append to target
    

    //var SelectedGalleryId = globalthis.app.getModel().environment.selectedGalleryID;
    var SelectedGalleryId = this.app.getModel().environment.selectedGalleryID;
    this.app.getModel().setSelectedGridItem(this.app.getModel().environment.selectedGalleryItemId);
    var selectedid = this.app.getModel().getSelectedGridItem();
    var galleryItem = this.app.getModel().getGalleryItemByGalleryId(selectedid);
    
    var MyGalleriesModalObject = { id: "MoveToGallery", Title: "Move To Gallery", SelectedGalleryId: SelectedGalleryId, SelectedImageId: selectedid, galleryList: globalThis.app.getModel().galleryList, galleryItem: galleryItem.GalleryItemData };
    var moveToGallery = new com.art.myGalleries.components.MyGalleriesModal(MyGalleriesModalObject);

    this.modalMoveToGallery = new com.art.core.components.BaseModal("myModalMoveToGallery", 720, "#f7f7ed", true);
    this.modalMoveToGallery.setContents(moveToGallery.render());
    
    var privacyCheckbox = new com.art.core.components.CheckBox('privacyChk', 'privacy', 'Make Gallery Private', false);
    var strPrivacy = "<div><div style='float: left;position:absolute;top:-156px;#top:-172px;right:228px;'>" + privacyCheckbox.render() + "</div><div id='privacyTxt' style='float:left;padding-left:5px;position:absolute;top:-155px;#top:-172px;right:106px;font-family:verdana;font-size: 11px;font-color:#666666'>" + privacyCheckbox.label + "</div><div style='clear:both'></div></div>";

    $("body").append(this.modalMoveToGallery.render(this.moveToGalleryLB.getLightBoxZIndex() + 1));
    this.modalMoveToGallery.registerEvents();

    if(this.app.getModel().environment.accountType != this.app.constants.ANONYMOUS)
	{
    	this.modalMoveToGallery.setLeftButtonBarContent(strPrivacy);
	}
    
    privacyCheckbox.registerEvents();
    
    privacyCheckbox.registerCallback(com.art.core.components.CheckBox.CHECKED,
    		function (object) {    	
    		    var privacy = object.selected ? 3 : 1; //3-private 1-public    
    		    _this.app.getModel().setAddedGalleryPrivacy(privacy);
    		});
    

    this.modalMoveToGallery.registerButton("continue", com.art.core.components.ArtButton.ART_ORANGE, "Continue", function () {
        trace("Continue");
        var chkStatus = moveToGallery.ContinueToMove();

        if (chkStatus == 'Existing') {
            _this.app.getModel().setDestinationSelectedGalleryId(moveToGallery.getDestinationSelectedGalleryId());
            _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY));
        }
        else if(chkStatus == 'New')
        {        	
            var data = moveToGallery.getAddTitleData(); // {title:''}            
            _this.app.getModel().setAddedGalleryTitle(data.title);            
            _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY));
        }
    });    
    
    this.modalMoveToGallery.registerButton("visitGallery", com.art.core.components.ArtButton.ART_BLUE, "Visit Gallery", function () {
    	
    	if(_this.newCreatedGalleryId=="" || _this.newCreatedGalleryId==undefined)
 		 {  
    		var vanityURL=_this.app.getModel().cacheByGalleryList[moveToGallery.GetGalleryID()].VanityURL;
    		window.location.href = "http://"+window.location.hostname+vanityURL;
 		 }
    	else 
 		 { 
 			window.location.href = "http://"+window.location.hostname+_this.app.getModel().environment.profileURL +_this.newCreatedGalleryId +"/";
 		 }   		
 	  $("#" + _this.modalMoveToGallery.id).remove(); 
    });
    
    this.modalMoveToGallery.registerButton("doneBtn", com.art.core.components.ArtButton.ART_ORANGE, "Done", function () {
        _this.modalMoveToGallery.close();        
        $("#" + _this.modalMoveToGallery.id).remove();
        _this.moveToGalleryLB.close(); 
		window.location.href = window.location.href = "http://"+window.location.hostname+_this.app.getModel().environment.profileURL +_this.app.getModel().environment.galleryKey +"/";
    });
    
    this.modalMoveToGallery.registerCallback(com.art.core.components.BaseModal.CLOSE_CLICKED, function () {
        _this.moveToGalleryLB.close();
    });
    moveToGallery.registerEvents();
};


/**
* Used this method to call the lightbox and delete art
* @method DeleteArt
*/
com.art.myGalleries.modules.DetailView.prototype.DeleteArt = function () {
	
	var _this =this;
    var detailPageLB = new com.art.core.components.LightBox('detailPageDeleteArtLB', 'body', .4);
    detailPageLB.show(); //append to target		
    
    var data = _this.app.getModel().cacheByGalleryItemList[_this.id];    
    
    var artDeleteContent = "This will remove <span style='font-weight: bold;'>"+data.Item.Title+" </span> from your gallery.";

    this.deleteArt = new com.art.myGalleries.components.CommonComponent('deleteArtComponent', 'Remove', 500, 200, data.ItemGalleryItemID,'','','',data.Item.Title,artDeleteContent);    

    this.modalDeleteArt = new com.art.core.components.BaseModal("detailPageModalDeleteArt", 480, "#f7f7ed", true);
    this.modalDeleteArt.setContents(this.deleteArt.render());

    $("body").append(this.modalDeleteArt.render(detailPageLB.getLightBoxZIndex() + 1));
    this.modalDeleteArt.registerEvents();

    this.modalDeleteArt.registerButton("dontDelete", com.art.core.components.ArtButton.ART_ORANGE, "Don't Remove", function () {
    	_this.modalDeleteArt.close();
    	detailPageLB.close();        
    });
   
    this.modalDeleteArt.registerButton("delete", com.art.core.components.ArtButton.ART_BLUE, "Remove", function () {
        trace("delete button clicked");
        _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.DELETE_GALLERY_ITEM_DP, data.ItemGalleryItemID));
    });

    this.modalDeleteArt.registerCallback(com.art.core.components.BaseModal.CLOSE_CLICKED, function () {
    	detailPageLB.close();
    });

//    var dontAsk = new com.art.core.components.CheckBox('dontAskCB', 'dontAskMe', 'Don\'t Ask Me Again');
//    //modalDeleteArt.setContents(dontAsk.render());
//    var str = "<div><div style='float:left'>" + dontAsk.render() + "</div><div style='float:left; padding-left:3px;font-family: Verdana;font-size:11px;color:#666666'>" + dontAsk.label + "</div><div style='clear:both'></div></div>";
//    modalDeleteArt.setLeftButtonBarContent(str);
//    dontAsk.registerEvents();

    this.deleteArt.registerEvents();
};

com.art.myGalleries.modules.DetailView.prototype.setSimilarArtistItems = function()
{
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.ADD_SIMILAR_ARTIST_ITEM));
};

com.art.myGalleries.modules.DetailView.prototype.setSimilarArtistItemsRender = function(obj)
{
	if(obj.ImageDetails != null)
	{
		$('.MyGalProductPageSimilarArt').show();
		var strLiItem = "";
		strLiItem = this.getSimilarItemContent(obj.ImageDetails);
		if($('.MyGalSimilarArtContentUL li').length<1){
		    $('.MyGalSimilarArtContentUL').append(strLiItem);
		}
	}
	else
	{
		$('.MyGalProductPageSimilarArt').hide();
	}
};

$('.MyGalSimiliarItem').live('click', function() {
    mygalleriesGA.trackEventWithCategory("Details", "Similar Art - click");
});

com.art.myGalleries.modules.DetailView.prototype.getSimilarItemContent = function(data)
{
	var str=  "";
	var temp = "";
	var cnt = 0;
	for(var i=0; i<data.length; i++)
	{		
		if(data[i].Artist.ArtistCategoryId != temp && cnt < 3 && this.data.ItemDetails.Artist.ArtistCategoryId != data[i].Artist.ArtistCategoryId)
		{
			str +="<li class='MyGalSimiliarItem'>";
			if(data[i].UrlInfo.ProductPageUrl != null)
			{
				var ProductPageUrl="http://"+window.location.hostname+data[i].UrlInfo.ProductPageUrl+"?ui="+getCookie('CustSessionID');
				str +="<a href='"+ ProductPageUrl +"'>";
				str +=this.getImageWithDropShadow(data[i].UrlInfo.ImageUrl, data[i].ImageDimensions[0].PixelWidth, data[i].ImageDimensions[0].PixelHeight, 120, 170, "centerMyGalleryProductPageRelatedItem", data[i].AppendShadow );
				str +="</a>";
			}
			else
			{
				str +=this.getImageWithDropShadow(data[i].UrlInfo.ImageUrl, data[i].ImageDimensions[0].PixelWidth, data[i].ImageDimensions[0].PixelHeight, 120, 170, "centerMyGalleryProductPageRelatedItem", data[i].AppendShadow );
			}
			str +="</li>";
			temp = data[i].Artist.ArtistCategoryId;
			cnt++;
		}
		
	}
		
	return str;
};

com.art.myGalleries.modules.DetailView.prototype.getImageWithDropShadow = function(imageurl, iw, ih, len, totalwidth, ImgClass, AppendShadow)
{
	var _galleryItem = "";
	
	var _ShadowRightTopE5E7DC = "http://cache1.artprintimages.com/images/photostoart/shadow_righttop_E5E7DC.png";
	var _ShadowRightTilingE5E7DC = "http://cache1.artprintimages.com/images/mygallery/shadow_righttiling_E5E7DC.png";
	var _ShadowLeftBottomE5E7DC = "http://cache1.artprintimages.com/images/photostoart/shadow_bottomleft_E5E7DC.png";
	var _ShadowBottomTilingE5E7DC = "http://cache1.artprintimages.com/images/mygallery/shadow_bottomtiling_E5E7DC.png";
	var _ShadowBottomRightE5E7DC = "http://cache1.artprintimages.com/images/photostoart/shadow_bottomright_E5E7DC.png";
	
	var _ImageWidth = iw, _ImageHeight = ih, _LeftPadding = 0, _TopPadding = 0;
	var length = len;
	var w = 0, h = 0;
	
    var aspectRatio = _ImageWidth / _ImageHeight;
    if (aspectRatio > 1.0)
    {
       w = length;
       h = length / aspectRatio;
    }
    else
    {
       w = length * aspectRatio;
       h = length;
    }
    _LeftPadding = (totalwidth - w - 4) / 2;

    _ImageHeight = Math.floor(h);
    _ImageWidth = Math.floor(w);
    
    
    _galleryItem = "<img border='0' width='" + _ImageWidth + "' height='" + _ImageHeight + "' class='"+ ImgClass +"' alt='' title='' src='" + imageurl + "'"
    	+ " style='margin-left:" + _LeftPadding + "px;'"
    	+ " />";
    
    if(AppendShadow)
    {
	    _galleryItem = _galleryItem + "<div class='imgDropShadowContainer'><img  border='0' class='abs w8 h10' src='" + _ShadowRightTopE5E7DC + "' "
	    	+ " style='top:" + _TopPadding + "px;left:" + (_ImageWidth + _LeftPadding ) + "px;'/>";
	
	    _galleryItem = _galleryItem + "<img border='0' height='" + (_ImageHeight - 10) + "' class='abs w8' src='" + _ShadowRightTilingE5E7DC + "' "
	    	+ " style='top:" + (_TopPadding + 10) + "px;left:" + (_ImageWidth + _LeftPadding ) + "px;'/>";
	
	    _galleryItem = _galleryItem + "<img border='0' class='abs w8 h8' src='" + _ShadowLeftBottomE5E7DC + "' "
	                + " style='top:" + (_ImageHeight + _TopPadding) + "px;left:" + (_LeftPadding) + "px;'/>";
	
	    _galleryItem = _galleryItem + "<img border='0' width='" + (_ImageWidth - 8) + "' class='abs h8' src='" + _ShadowBottomTilingE5E7DC + "' "
	                            + " style='top:" + (_ImageHeight + _TopPadding) + "px;left:" + (_LeftPadding + 8) + "px;'/>";
	
	    _galleryItem = _galleryItem + "<img border='0' class='abs h8 w8' src='" + _ShadowBottomRightE5E7DC + "' "
	                            + " style='top:" + (_ImageHeight + _TopPadding) + "px;left:" + (_ImageWidth + _LeftPadding) + "px;'/></div>";
    }
    
    return _galleryItem;

};

com.art.myGalleries.modules.DetailView.prototype.destroy = function()
{
	//NOTE: Destroy is where you destroy this object and clean up memory
};

com.art.myGalleries.modules.DetailView.prototype.notify = function()
{
	//NOTE: 
	this.app.sendNotification(note);
};

com.art.myGalleries.modules.DetailView.prototype.listNotificationInterests = function()
{
	return [this.app.events.ADD_SIMILAR_ARTIST_ITEM_SUCCESS,
	        this.app.events.ADD_SIMILAR_ARTIST_ITEM_FAILED,
	        this.app.events.CHANGE_VIEWMODE,
	        this.app.events.DELETE_GALLERY_ITEM_DP_SUCCESS,
            this.app.events.DELETE_GALLERY_ITEM_DP_FAILED,
            this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY_SUCCESS,
            this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY_FAILED,
            this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY_SUCCESS,
            this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY_FAILED,
	       ];
};

com.art.myGalleries.modules.DetailView.prototype.handleNotification = function(note)
{
	var _this=this;
	switch(note.name)
	{
		case this.app.events.ADD_SIMILAR_ARTIST_ITEM_SUCCESS:
			trace(note);
			this.setSimilarArtistItemsRender(note.body);
			break;
		case this.app.events.CHANGE_VIEWMODE:
            if (note.body.module == this.app.constants.GRID_VIEW && note.body.page == 'details') {
            	this.app.getUserLibraryProxy().initialLoadComplete = false;
                $("#itemsDisplay").html(this.app.getModel().toggleDisplay);
                this.init();
                
                $("#MyGalleriesControlbarRight").hide();
            }
            break;
		case this.app.events.DELETE_GALLERY_ITEM_DP_FAILED:
        	trace("Move Failure Add Item To Gallery");
            //redirect to 404 error //todo
        	break;
        case this.app.events.DELETE_GALLERY_ITEM_DP_SUCCESS:
        	this.modalDeleteArt.close();
     		var vanityURL=this.app.getModel().cacheByGalleryList[this.app.getModel().environment.selectedGalleryID].VanityURL;
     		window.location.href ="http://" + location.host + vanityURL;
        	
        	break;
        	case this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY_SUCCESS:
        	
        	if(note.body.OperationResponse!=undefined && note.body.OperationResponse!=null)
        	{	var errorMsg=note.body.OperationResponse.ResponseMessage;
                $(".commonErrorMsg").text(errorMsg);            
            }
            else
            	{            		
	            	$(".MyGalleriesRightContainer").css("visibility","hidden");
	                $("#MoveToGalleryConfirm").css("visibility","visible");
	                $("#MoveToGalleryConfirm").css("position","absolute");
	         		$("#MoveToGalleryConfirm").css("margin-top","10px");
	         		$("#MoveToGalleryConfirm").css("margin-left","235px;");
	         		$("#MoveToGalleryConfirm").css("margin-bottom","20px;");
	                $("#continue").css("visibility","hidden");
	                $("#privacyChk").css("visibility","hidden");
	             	$("#privacyTxt").css("visibility","hidden");
	             	
	             	$("#doneBtn").css("visibility","visible");
	             	$("#doneBtn").css("position","absolute");
	             	$("#doneBtn").css("right","25px");
	             	
	             	$("#visitGallery").css("visibility","visible");		
	             	$("#visitGallery").css("position","absolute");
	             	$("#visitGallery").css("right","90px");              	
                	this.newCreatedGalleryId=note.body;	
            	}        	
            break;
        case this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY_FAILED:
        	 var errorMsg=note.body.OperationResponse.ResponseMessage;
        	 $(".commonErrorMsg").text(errorMsg);
            break;	
        case this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY_SUCCESS:
        	
            trace("Move Success Add Item To Gallery");
            $(".MyGalleriesRightContainer").css("visibility","hidden");
            $("#MoveToGalleryConfirm").css("visibility","visible");
            $("#MoveToGalleryConfirm").css("position","absolute");
    		$("#MoveToGalleryConfirm").css("margin-top","10px");
    		$("#MoveToGalleryConfirm").css("margin-left","235px;");
    		$("#MoveToGalleryConfirm").css("margin-bottom","20px;");
            $("#continue").css("visibility","hidden");
            $("#privacyChk").css("visibility","hidden");
        	$("#privacyTxt").css("visibility","hidden");
        	
        	$("#doneBtn").css("visibility","visible");
        	$("#doneBtn").css("position","absolute");
        	$("#doneBtn").css("right","25px");
        	
        	$("#visitGallery").css("visibility","visible");		
        	$("#visitGallery").css("position","absolute");
        	$("#visitGallery").css("right","90px");
           
            break;
        case this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY_FAILED:
            trace("Move Failure Add Item To Gallery");
            $(".commonErrorMsg").text("An unexpected error has occured,please reload the page or try again later.");
            break;
        default:
			trace("default case");
	}		
};

com.art.myGalleries.modules.DetailView.prototype.getTemplate = function()
{
	//STEP: Get the raw string for the template
	var returnValue = this.template;
	//STEP: Replace the [IMAGE_DOMAIN] placeholder with the imagePath value
	returnValue = returnValue.replace(/\[IMAGE_DOMAIN\]/gi, this.imagePath);
	//STEP: Replace the [$MYGALLERY] placeholder with the MyGallery Header Title value
	returnValue = returnValue.replace(/\[$MYGALLERY\]/gi, this.imagePath);
	
	//STEP: Now return the string (template)
	return returnValue.replace('$NAME', this.NAME);
};

com.art.myGalleries.modules.DetailView.prototype.getTarget = function()
{
	return this.moduleData.target;
};

com.art.myGalleries.modules.DetailView.prototype.template = ""; //not needed markup coming from server


