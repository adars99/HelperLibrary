com.art.myGalleries.modules.VerticalNavigationModule = function (data, app) {
    this.app = app;
    this.moduleData = data;
    this.NAME = com.art.myGalleries.modules.VerticalNavigationModule.NAME;
    this.createBtn;
    this.addGalleryTitleLB;
    this.modalAddGallery;
};
com.art.myGalleries.modules.VerticalNavigationModule.NAME = "VerticalNavigationModule";

com.art.myGalleries.modules.VerticalNavigationModule.prototype.getGalleries = function() {
	return this.moduleData.items;

};

com.art.myGalleries.modules.VerticalNavigationModule.prototype.init = function () {
    var _this = this;
    trace("vertNav module");
    var fc = new com.art.core.components.FixedContainer('myFixedContainer',
			com.art.core.components.FixedContainer.LEFT, "MyGalleriesMainBody",
			198, 60, 13);
    var btnFC = new com.art.core.components.ArtButton('myFCBtn',
			com.art.core.components.ArtButton.ART_BLUE,
			"My FixedContainer Comp");

    btnFC.registerCallback(com.art.core.components.BaseButton.CLICK,
			function () {    	
		    	var cat = _this.app.getModel().currentViewMode == MyGalleriesCore.constants.GALLERY_HOME ? "Entry" : "Details";
		        var evt = "Create new gallery - clicked";
		        mygalleriesGA.trackEventWithCategory(cat, evt);
			    _this.showAddTitleModal();
			});
    fc.registerEvents();
    btnFC.registerEvents();
    
    $('.MygalleryLeftViewLinks').live('click', function(){
    	var url = $(this).attr('iconurl');
    	window.location.href = "http://"+window.location.hostname+url;
    });
};

/**
 * Used this method to call the lightbox and add Gallery Title and Description
 * 
 * @method showAddTitleModal
 */
com.art.myGalleries.modules.VerticalNavigationModule.prototype.showAddTitleModal = function () {
    var _this = this;
       
    this.addGalleryTitleLB = new com.art.core.components.LightBox('myAddGalleryLB', 'body', .4);
    this.addGalleryTitleLB.show(); // append to target

    var addGalleryTitle = new com.art.myGalleries.components.CommonComponent('addGalleryTitle', 'New Gallery Title & Description', 500, 230);

    this.modalAddGallery = new com.art.core.components.BaseModal("myModalAddGallery", 500, "#f7f7ed", true);
    this.modalAddGallery.setContents(addGalleryTitle.render());

    var privacyCheckbox = new com.art.core.components.CheckBox('privacyChk', 'privacy', 'Make Gallery Private', false);
    var strPrivacy = "<div><div style='float:left;'>" + privacyCheckbox.render() + "</div><div style='float:left;padding-left:5px;font-family:verdana;font-size: 11px;font-color:#666666'>" + privacyCheckbox.label + "</div><div style='clear:both'></div></div>";

    $("body").append(this.modalAddGallery.render(this.addGalleryTitleLB.getLightBoxZIndex() + 1));
    this.modalAddGallery.registerEvents();
    addGalleryTitle.registerEvents();
    this.modalAddGallery.registerCallback(
			com.art.core.components.BaseModal.CLOSE_CLICKED, function () {
			    _this.modalAddGallery.close();
			    _this.addGalleryTitleLB.close();

			});
    
    if(this.app.getModel().environment.accountType != this.app.constants.ANONYMOUS)
	{
		this.modalAddGallery.setLeftButtonBarContent(strPrivacy);
	}
    
    privacyCheckbox.registerEvents();
    privacyCheckbox.registerCallback(com.art.core.components.CheckBox.CHECKED,
		function (object) {    	
		    var privacy = object.selected ? 3 : 1; //3-private 1-public			    
		    _this.app.getModel().setAddedGalleryPrivacy(privacy);
		});

    this.modalAddGallery.registerButton("apply", com.art.core.components.ArtButton.ART_ORANGE, "Apply", function () {
        trace("apply button clicked");
        if (addGalleryTitle.validateTitle()) {
            var data = addGalleryTitle.getAddTitleData(); // {title:'',desc:''}

            _this.app.getModel().setAddedGalleryTitle(data.title);
            _this.app.getModel().setAddedGalleryDesc(data.desc);
            _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.ADD_GALLERY_TITLE_DESC));
        }
    });
};

com.art.myGalleries.modules.VerticalNavigationModule.prototype.destroy = function() {
	// NOTE: Destroy is where you destroy this object and clean up memory
};

com.art.myGalleries.modules.VerticalNavigationModule.prototype.notify = function() {
	var rvo = new com.art.myGalleries.vos.RequestVO(
			new art.core.vos.RequestBaseVO(this.app.getEnvironment()));
	rvo.init('sessionid', 'authToken', 'apiKey', this.PageNo);
	this.app.sendNotification(new art.core.Note(
			this.app.events.GALLERY_LIST_REQUEST, {
				requestVO : rvo
			}, 'vo'));
};

com.art.myGalleries.modules.VerticalNavigationModule.prototype.listNotificationInterests = function() {
	return [ this.app.events.STARTUP,
	         this.app.events.ADD_GALLERY_TITLE_DESC_SUCCESS,
	         this.app.events.SHOW_CREATE_GALLERY_MODAL,
	         this.app.events.ADD_GALLERY_TITLE_DESC_FAILED];
};

com.art.myGalleries.modules.VerticalNavigationModule.prototype.handleNotification = function (note) {
    switch (note.name) {
        case this.app.events.STARTUP:
            trace("VerticalNavigationModule STARTUP");
            break;
        case this.app.events.ADD_GALLERY_TITLE_DESC_SUCCESS:
        	trace(note.body.OperationResponse.ResponseCode);
            if (note.body.OperationResponse.OperationStatus == 0) {
                this.addGalleryTitleLB.close();
                this.modalAddGallery.close();
                $("#" + this.modalAddGallery.id).remove();                
                window.location.href = this.app.getModel().environment.profileURL;
            }            
            else {            	
            		var errorMsg=note.body.OperationResponse.ResponseMessage;
            		$("#showErrorMsgContainer").show();
            		$("#showErrorMsg").text(errorMsg);
            }
            break;
        case this.app.events.ADD_GALLERY_TITLE_DESC_FAILED:
        	$("#showErrorMsgContainer").show();
        	$("#showErrorMsg").text("Sorry, operation is unavailable,please retry later.");            
            break;
        case this.app.events.SHOW_CREATE_GALLERY_MODAL:
        	this.showAddTitleModal();            
            break;
    };

};

com.art.myGalleries.modules.VerticalNavigationModule.prototype.getTemplate = function() {
	// STEP: Get the raw string for the template
	var returnValue = this.template;
	// STEP: Replace the [IMAGE_DOMAIN] placeholder with the imagePath value
	returnValue = returnValue.replace(/\[IMAGE_DOMAIN\]/gi, this.imagePath);
	// STEP: Now return the string (template)
	return returnValue.replace('$NAME', this.NAME);
};

com.art.myGalleries.modules.VerticalNavigationModule.prototype.getTarget = function() {
	return this.moduleData.target;
};

com.art.myGalleries.modules.VerticalNavigationModule.prototype.template = '<div id="$NAME" style="padding:5px;font-family:arial,sans-serif;font-size:12px"></div>';
