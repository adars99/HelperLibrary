//CONSTRUCTOR: instantiates the instance, Every Object must implement the base
com.art.myGalleries.modules.GridDisplayModule = function (data, app) {
    this.app = app;
    this.moduleData = data;
    this.NAME = com.art.myGalleries.modules.GridDisplayModule.NAME;
    this.instance = this;
    this.grid;
    this.itemHoverComponent = new com.art.myGalleries.components.ItemHoverComponent();
    this.paginationComponent;
    this.detailsDelayTimerID;
    this.editGalleryTitleLB;
    this.modalEditGallery;
    this.moveToGalleryLB;
    this.modalMoveToGallery;
    this.getNewCreatedGallery = {};
    this.newCreatedGalleryId=""; //Used for move and save to gallery
    this.deleteArt;
    this.modalDeleteArt;
    this.itemGridIndex = 0;
    
};
com.art.myGalleries.modules.GridDisplayModule.NAME = "GridDisplayModule";

com.art.myGalleries.modules.GridDisplayModule.prototype.initialLoad = false;
com.art.myGalleries.modules.GridDisplayModule.prototype.globalThis = "";
com.art.myGalleries.modules.GridDisplayModule.Apply_Click = "click";

com.art.myGalleries.modules.GridDisplayModule.prototype.init = function () {
    var _this = this;
    globalThis = this;
    //$(this.getTarget()).html(this.getTemplate());
    //this.notify();

    $('#items, .GalleryHomeItems').append(_this.itemHoverComponent.render());

    $('#' + _this.itemHoverComponent.id).hover(
	        function () {
	            _this.itemHoverComponent.popupHovered = true;
	        },
	        function () {
	            _this.itemHoverComponent.popupHovered = false;
	            _this.getItemHoverOut();
	        }
	);
    
    //Title & Description
    $('.MyGalleriesTitleDescLinks').unbind("hover");
    $('.MyGalleriesTitleDescLinks').hover(function () { $(this).css('text-decoration', 'underline'); }, function () { $(this).css('text-decoration', 'none'); });


    $('.centerMyGalleryImage, .ImgContainer').hoverIntent({
        over: _this.getItemHoverIn,
        timeout: 500,
        interval: 300,
        out: _this.getItemHoverOut
    });
    
    $('.GalleryHomeItems .ImgContainer').live('click', function(){
    	mygalleriesGA.trackEventWithCategory("Grid", "View grid");
    	window.location.href = "http://"+window.location.hostname + $(this).find('a').attr('href');
    });
    
    $('#MyGalleriesHoverAddFrame').live('click', function(){
    	 var id = _this.app.getModel().getSelectedGridItem();
    	 var data = _this.app.getModel().cacheByGalleryItemList[id];   
    	 trace(data); 	 
         var url;
         var sku="";
         var pd="";
         var sp="";
         var frameSkuVal="";
         
           var APNum = data.APNum;
                                              
           var podQueryString="";
           if(data.PODConfigID!=undefined && data.PODConfigID > 0 )
           {
             podQueryString="&PODConfigID="+data.PODConfigID;
           }
           else
           {
             podQueryString="&PODConfigID=0";
           }
         
         var UIDATA = _this.app.getModel().environment.sessionId;
         var IID = "";
         var customerZoneId = _this.app.getModel().environment.customerZoneId;
         
         // DFE item
         if(data.FrameSku!=null){
          sku=data.FrameSku;
          url = "http://" + location.host + "/framestep/default.asp" + "?APNUM=" + APNum + podQueryString + "&ui=" + UIDATA + "&IID=" + IID + "&customerzoneid=" + customerZoneId + "&Sku=" + sku;          
         }
         else{ // regular print item which has zone product id         
         sku= data.ItemDetails.Sku;         
         pd = sku.substring(0, sku.length - 1);
         sp = sku.substring(sku.length - 1, sku.length);
         url = "http://" + location.host + "/framestep/default.asp" + "?pd=" + pd + "&sp=" + sp + "&APNUM=" + APNum + podQueryString + "&ui=" + UIDATA + "&IID=" + IID + "&customerzoneid=" + customerZoneId;         
         }
         _this.setCookieForAddFrameGallery(_this.app.getModel().environment.galleryKey);
         window.location = url;
    });
    

    //EVENTS FOR OBJECTS - close button
    $('#' + _this.itemHoverComponent.id).find('.VSResultsInfoIcon img').bind('click', function () {
        _this.itemHoverComponent.popupHovered = false;
        _this.getItemHoverOut();
    });

    $('.MyGalleriesTitleDescLinks').die();
    $('.MyGalleriesTitleDescLinks').live("click", function () {
        _this.showEditTitleModal();
        //_this.MoveToGallery();
    });
    $("#MoveToAnotherGallery").die();
    $("#MoveToAnotherGallery").live('click', function () {
        _this.MoveToGallery();
    });
    
    $("#DeleteItem").live('click', function () {
        _this.DeleteArt();
    });    
    $("#CommentsGalleryItem").live('click', function(){
    	 var id = _this.app.getModel().getSelectedGridItem();
    	 var data = _this.app.getModel().cacheByGalleryItemList[id];
    	 window.location = "http://" + location.host + data.VanityURL;
    });
    $("#ImgfullResContainer").live('click', function(){
    	// this is not required
    	//window.location = "http://" + location.host + $(this).attr('galleryurl');
    });
    $("#MyGalleriesAddToCartIcon").live('click', function(){
    	mygalleriesGA.trackEventWithCategory("Grid", "Hover Add to cart");
    	
    	var data = _this.itemHoverComponent.data.GalleryItemData;
    	var galItem = _this.app.getModel().cacheByGalleryItemList[data.ItemId];
    	var sessionId = _this.app.getModel().environment.sessionId;
    		
    	var props = {ItemId:data.ItemId,
    				 frameConfigurationId:galItem.FrameSku,
    			     artSku:data.Sku,
    			     podconfigid:data.PODConfigID,
    			     apnum:galItem.APNum
    			};
    	
    	if(props.frameConfigurationId != null && props.frameConfigurationId.trim().length > 0)
    		_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.GET_FRAME_ID,props));
    	else
    	{
    		window.location.href = com.art.core.utils.BusinessUtil.getSimpleAddToCartUrl(data.Sku,data.PODConfigID, galItem.SpecialHandlingID, sessionId);
    	}
	});
};

com.art.myGalleries.modules.GridDisplayModule.prototype.setCookieForAddFrameGallery = function(param)
{
	if(param != "")
	{
		var cookieobject = new com.art.core.cookie.Cookie();
		cookieobject.setCookieDictionary('arts','SaveToGallery',param,'/', cookieobject.getCookieDomain('art'));
	}	
};

/**
* Used this method to call the lightbox and Edit Gallery Title and Description
* @method EditGalleryTitleDesc
*/
com.art.myGalleries.modules.GridDisplayModule.prototype.showEditTitleModal = function () {
    var _this = this;
    
    var selectedGallery = this.app.getModel().getSelectedGallery();
    trace(selectedGallery);
    var galleryId = this.app.getModel().environment.selectedGalleryID;
    var galleryTitle = decodeURIComponent(unescape(selectedGallery.Name));    
    //var galleryTitle = decodeURIComponent(selectedGallery.Name);
    
    if (selectedGallery.LongDescription == null || selectedGallery.LongDescription == undefined) {
        var galleryDesc = "";
    }
    else {
        var galleryDesc = decodeURIComponent(unescape(selectedGallery.LongDescription));    	
    }
    
    var privacy = (selectedGallery.GalleryVisibility == 3) ? true:false;    

    this.editGalleryTitleLB = new com.art.core.components.LightBox('myEditGalleryLB', 'body', .4);
    this.editGalleryTitleLB.zindex = this.app.getModel().getNextHighestZIndex();
    this.editGalleryTitleLB.show(); //append to target		

    var editGalleryTitle = new com.art.myGalleries.components.CommonComponent('editGalleryTitle', 'Edit Title & Description', 500, 230, galleryId, galleryTitle, galleryDesc, privacy);

    this.modalEditGallery = new com.art.core.components.BaseModal("myModalEditGallery", 500, "#f7f7ed", true);
    this.modalEditGallery.setContents(editGalleryTitle.render());

    var privacyCheckbox = new com.art.core.components.CheckBox('privacyChk', 'privacy', 'Make Gallery Private', privacy);
    var strPrivacy = "<div><div style='float:left;'>" + privacyCheckbox.render() + "</div><div style='float:left;padding-left:5px;font-family:verdana;font-size: 11px;font-color:#666666'>" + privacyCheckbox.label + "</div><div style='clear:both'></div></div>";
    
    trace("z-index: " + this.editGalleryTitleLB.getLightBoxZIndex());
    $("body").append(this.modalEditGallery.render(this.app.getModel().getNextHighestZIndex() + 1));
    this.modalEditGallery.registerEvents();
    editGalleryTitle.registerEvents();
    editGalleryTitle.setData(galleryTitle);

    this.modalEditGallery.registerCallback(com.art.core.components.BaseModal.CLOSE_CLICKED, function () {
        _this.modalEditGallery.close();
        _this.editGalleryTitleLB.close();

    });
    
    if(this.app.getModel().environment.accountType != this.app.constants.ANONYMOUS)
	{
    	this.modalEditGallery.setLeftButtonBarContent(strPrivacy);
	}
    
    privacyCheckbox.registerEvents();
    privacyCheckbox.registerCallback(com.art.core.components.CheckBox.CHECKED, function (object) {
    	
        var privacy = object.selected ? 3 : 1; //3-private 1-public
        _this.app.getModel().setSelectedGalleryPrivacy(privacy);
    });

    this.modalEditGallery.registerButton("apply", com.art.core.components.ArtButton.ART_ORANGE, "Apply", function () {
        trace("apply button clicked");
        if (editGalleryTitle.validateTitle()) {
        	
            var data = editGalleryTitle.getEditTitleData(); //{title:'',desc:''}
            _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.UPDATE_GALLERY_TITLE_DESC, data));
        }
    });
};

/**
* Used this method to call the lightbox and delete gallery
* @method DeleteGallery
*/
com.art.myGalleries.modules.GridDisplayModule.prototype.DeleteGallery = function () {

    var deleteGalleryLB = new com.art.core.components.LightBox('myDeleteGalleryLB', 'body', .4);
    deleteGalleryLB.show(); //append to target		

    var galleryName = "Gallery Name ?"; //TODO - call the service
    var galleryDeleteContent = "Are you sure you want to delete the Art Name, Please click on Don't Delete button if you don't want to delete art name.";
    //var galleryDeleteContent = "This will remove "Art Name" from your gallery.";
    
    var deleteGallery = new com.art.myGalleries.components.CommonComponent('deleteGalleryComponent', 'Remove', 500, 200, galleryName, galleryDeleteContent);

    var modalDeleteGallery = new com.art.core.components.BaseModal("myModalDeleteGallery", 480, "#f7f7ed", true);
    modalDeleteGallery.setContents(deleteGallery.render());

    $("body").append(modalDeleteGallery.render(deleteGalleryLB.getLightBoxZIndex() + 1));
    modalDeleteGallery.registerEvents();

    modalDeleteGallery.registerButton("dontDelete", com.art.core.components.ArtButton.ART_ORANGE, "Don't Remove", function () {
        trace("Don't delete button clicked");
        deleteGallery.DontDeleteGallery();
    });

    modalDeleteGallery.registerButton("delete", com.art.core.components.ArtButton.ART_BLUE, "Remove", function () {
        trace("delete button clicked");
        deleteGallery.DeleteGallery();
    });

    modalDeleteGallery.registerCallback(com.art.core.components.BaseModal.CLOSE_CLICKED, function () {
        deleteGalleryLB.close();
    });
    deleteGallery.registerEvents();
};

/**
* Used this method to call the lightbox and delete art
* @method DeleteArt
*/
com.art.myGalleries.modules.GridDisplayModule.prototype.DeleteArt = function () {
	
	var _this =this;
    var deleteArtLB = new com.art.core.components.LightBox('myDeleteArtLB', 'body', .4);
    deleteArtLB.show(); //append to target		
    
    var itemId = globalThis.app.getModel().getSelectedGridItem();
    
    var galleryItem = globalThis.app.getModel().getGalleryItemByGalleryId(itemId);

    //var artDeleteContent = "Are you sure you want to delete the <span style='font-weight: bold;'>"+galleryItem.GalleryItemData.Title +" </span>, Please click on Don't Delete button if you don't want to delete art name."; //TODO - call the service
    var artDeleteContent = "This will remove <span style='font-weight: bold;'>"+galleryItem.GalleryItemData.Title +" </span> from your gallery.";
    

   this.deleteArt = new com.art.myGalleries.components.CommonComponent('deleteArtComponent', 'Remove', 500, 200, itemId,'','','',galleryItem.GalleryItemData.Title,artDeleteContent);    

    this.modalDeleteArt = new com.art.core.components.BaseModal("myModalDeleteArt", 480, "#f7f7ed", true);
    this.modalDeleteArt.setContents(this.deleteArt.render());

    $("body").append(this.modalDeleteArt.render(deleteArtLB.getLightBoxZIndex() + 1));
    this.modalDeleteArt.registerEvents();

    this.modalDeleteArt.registerButton("dontDelete", com.art.core.components.ArtButton.ART_ORANGE, "Don't Remove", function () {
    	_this.modalDeleteArt.close();
        deleteArtLB.close();        
    });
   
    this.modalDeleteArt.registerButton("delete", com.art.core.components.ArtButton.ART_BLUE, "Remove", function () {
        trace("delete button clicked");
        _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.DELETE_GALLERY_ITEM, itemId));
    });

    this.modalDeleteArt.registerCallback(com.art.core.components.BaseModal.CLOSE_CLICKED, function () {
    	deleteArtLB.close();
    });

//    var dontAsk = new com.art.core.components.CheckBox('dontAskCB', 'dontAskMe', 'Don\'t Ask Me Again');
//    //modalDeleteArt.setContents(dontAsk.render());
//    var str = "<div><div style='float:left'>" + dontAsk.render() + "</div><div style='float:left; padding-left:3px;font-family: Verdana;font-size:11px;color:#666666'>" + dontAsk.label + "</div><div style='clear:both'></div></div>";
//    modalDeleteArt.setLeftButtonBarContent(str);
//    dontAsk.registerEvents();

    this.deleteArt.registerEvents();
};

/**
* Used this method to call the lightbox and move to Gallery
* @method MoveToGallery
*/
com.art.myGalleries.modules.GridDisplayModule.prototype.MoveToGallery = function () {

    var _this = this;
    this.moveToGalleryLB = new com.art.core.components.LightBox('myMoveToGalleryLB', 'body', .4);
    this.moveToGalleryLB.show(); //append to target		

    //var SelectedGalleryId = globalthis.app.getModel().environment.selectedGalleryID;
    var SelectedGalleryId = this.app.getModel().environment.selectedGalleryID;
    var selectedid = this.app.getModel().getSelectedGridItem();
    var galleryItem = this.app.getModel().getGalleryItemByGalleryId(selectedid);

    //var selectedid = globalThis.app.getModel().getSelectedGridItem();
    //var galleryItem = globalThis.app.getModel().getGalleryItemByGalleryId(selectedid);

    var MyGalleriesModalObject = { id: "MoveToGallery", Title: "Move To Gallery", SelectedGalleryId: SelectedGalleryId, SelectedImageId: selectedid, galleryList: globalThis.app.getModel().galleryList, galleryItem: galleryItem.GalleryItemData };
    var moveToGallery = new com.art.myGalleries.components.MyGalleriesModal(MyGalleriesModalObject);

    this.modalMoveToGallery = new com.art.core.components.BaseModal("myModalMoveToGallery", 720, "#f7f7ed", true);
    this.modalMoveToGallery.setContents(moveToGallery.render());
    
    var privacyCheckbox = new com.art.core.components.CheckBox('privacyChk', 'privacy', 'Make Gallery Private', false);
    var strPrivacy = "<div><div style='float: left;position:absolute;top:-156px;#top:-172px;right:228px;'>" + privacyCheckbox.render() + "</div><div id='privacyTxt' style='float:left;padding-left:5px;position:absolute;top:-155px;#top:-172px;right:106px;font-family:verdana;font-size: 11px;font-color:#666666'>" + privacyCheckbox.label + "</div><div style='clear:both'></div></div>";

    $("body").append(this.modalMoveToGallery.render(this.moveToGalleryLB.getLightBoxZIndex() + 1));
    this.modalMoveToGallery.registerEvents();

    if(this.app.getModel().environment.accountType != this.app.constants.ANONYMOUS)
	{
    	this.modalMoveToGallery.setLeftButtonBarContent(strPrivacy);
	}
    
    privacyCheckbox.registerEvents();
    
    privacyCheckbox.registerCallback(com.art.core.components.CheckBox.CHECKED,
    		function (object) {    	
    		    var privacy = object.selected ? 3 : 1; //3-private 1-public    
    		    _this.app.getModel().setAddedGalleryPrivacy(privacy);
    		});
    
    this.modalMoveToGallery.registerButton("continue", com.art.core.components.ArtButton.ART_ORANGE, "Continue", function () {
        trace("Continue");
        var chkStatus = moveToGallery.ContinueToMove();

        if (chkStatus == 'Existing') {
            _this.app.getModel().setDestinationSelectedGalleryId(moveToGallery.getDestinationSelectedGalleryId());
            _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY));
        }
        else if(chkStatus == 'New')
        {                   
            var data = moveToGallery.getAddTitleData(); // {title:''}            
            _this.app.getModel().setAddedGalleryTitle(data.title);            
            _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY));
        }
    });    
    
    this.modalMoveToGallery.registerButton("visitGallery", com.art.core.components.ArtButton.ART_BLUE, "Visit Gallery", function () {
    	
    	if(_this.newCreatedGalleryId=="" || _this.newCreatedGalleryId==undefined)
 		 {  
    		var vanityURL=_this.app.getModel().cacheByGalleryList[moveToGallery.GetGalleryID()].VanityURL;
    		window.location.href = "http://"+window.location.hostname+vanityURL;
 		 }
    	else 
 		 { 
 			window.location.href = "http://"+window.location.hostname+_this.app.getModel().environment.profileURL +_this.newCreatedGalleryId +"/";
 		 } 
 	  $("#" + _this.modalMoveToGallery.id).remove(); 
    });
    
    this.modalMoveToGallery.registerButton("doneBtn", com.art.core.components.ArtButton.ART_ORANGE, "Done", function () {
        _this.modalMoveToGallery.close();        
        $("#" + _this.modalMoveToGallery.id).remove();
        _this.moveToGalleryLB.close(); 
        window.location.href = window.location.href;
    });
    
    this.modalMoveToGallery.registerCallback(com.art.core.components.BaseModal.CLOSE_CLICKED, function () {
        _this.moveToGalleryLB.close();
    });
    moveToGallery.registerEvents();
};

com.art.myGalleries.modules.GridDisplayModule.prototype.setCookieForDropDown = function(param)
{
	if(param != "")
	{
		var cookieobject = new com.art.core.cookie.Cookie();
		cookieobject.setCookieDictionary('arts','MoveToGallery',param,'/', cookieobject.getCookieDomain('art'));
	}	
};

com.art.myGalleries.modules.GridDisplayModule.prototype.getItemHoverIn= function()
{
	var _this = this;
	if($(this).hasClass('ImgContainer'))
	{	
		var id = $(this).parent().attr('id');
		globalThis.app.getModel().setSelectedGridItem(id);
		var data = globalThis.app.getModel().getGalleryByGalleryId(id);
		globalThis.itemHoverComponent.setData(data, id);
		globalThis.itemHoverComponent.showGalleryListHover();
		globalThis.itemHoverComponent.fadeIn();
	}	
	else
	{
		var id = $(this).parent().parent().attr('id');
		globalThis.app.getModel().setSelectedGridItem(id);
		var data = globalThis.app.getModel().getGalleryItemByGalleryId(id);
		globalThis.itemHoverComponent.currencyCode = globalThis.app.getModel().environment.currencyCode;
		globalThis.itemHoverComponent.setData(data, id);
		globalThis.itemHoverComponent.showGalleryItemHover();
		globalThis.itemHoverComponent.fadeIn();
	}	
};
com.art.myGalleries.modules.GridDisplayModule.prototype.getItemHoverOut= function()
{
	globalThis.itemHoverComponent.fadeOut();
};
com.art.myGalleries.modules.GridDisplayModule.prototype.getItemHoverComponent = function()
{
	if(this.itemHoverComponent == undefined)
	{
		this.itemHoverComponent = new com.art.myGalleries.components.ItemHoverComponent();
		$("#items").append(this.itemHoverComponent.render());
	}
	return this.itemHoverComponent;
};
com.art.myGalleries.modules.GridDisplayModule.prototype.setImages = function(arr)
{
	var _this = this;
	$("#items").html("");//clear first
	
	for(var i=0; i < arr.length; i++)
	{
		trace("imageUrl: "+arr[i].ImageUrl);
		trace("apnum: "+arr[i].ItemId);
		var item = new com.art.myGalleries.components.ItemComponent(arr[i].ImageUrl,arr[i].ItemId,258,'http://imagecache1.art.com');
		item.registerCallback(com.art.myGalleries.components.ItemComponent.HOVER,function(apnum){
			trace("itemHover with data");
			var data = _this.app.getModel().getItemByGalleryId(apnum);
			trace(data);
			_this.getItemHoverComponent().setData(data,apnum);
			_this.getItemHoverComponent().update();
			//_this.getItemHoverComponent().fadeIn();
			
		});
		$("#items").append(item.render());
		item.dropShadow();
		item.registerEvents();
	}
	
	$("#items").append("<div class='clear'></div>");
};

com.art.myGalleries.modules.GridDisplayModule.prototype.setNavigation = function()
{
	var _this = this;
	var strTopNavigationLeft 	= "";
	var strTopNavigationRight 	= "";
	
	strTopNavigationLeft = '<div class="topNavigationLeft"><span class="MyGalleriesTitle">Kitchen:</span><span class="MyGalleriesDescription">I think these will look great in the loft!</span><span class="MyGalleriesSeparator">|</span><span class="MyGalleriesTitleDescLinks">Edit Title & Description</span></div>';
	
	var pageItem = new com.art.myGalleries.components.PaginationComponent('pagination',45);
	
	strTopNavigationRight = '<div class="topNavigationRight">'+ pageItem.render() + '</div>'; 
	
	$('#topNavigation').append(strTopNavigationLeft + strTopNavigationRight );
	$('#bottomNavigation').append(strTopNavigationRight);
	pageItem.registerEvent();
};

com.art.myGalleries.modules.GridDisplayModule.prototype.destroy = function()
{
	clearTimeout(this.detailsDelayTimerID);
	//NOTE: Destroy is where you destroy this object and clean up memory
};

com.art.myGalleries.modules.GridDisplayModule.prototype.notify = function()
{
	trace("pageNo: "+this.PageNo);
	var rvo = new com.art.myGalleries.vos.RequestVO(new art.core.vos.RequestBaseVO(this.app.getEnvironment()));
	rvo.init('sessionid','authToken','apiKey',this.PageNo);
	this.app.sendNotification(new art.core.Note(this.app.events.GALLERY_LIST_REQUEST,{requestVO:rvo},'vo'));
};

com.art.myGalleries.modules.GridDisplayModule.prototype.listNotificationInterests = function()
{
	return [
	        this.app.events.GALLERY_LIST_REQUEST_SUCCESS,
            this.app.events.UPDATE_BACKGROUND_COLOR,
            this.app.events.UPDATE_TITLE_SUCCESS,
            this.app.events.GALLERY_ITEM_SORT_SUCCESS,
            this.app.events.UPDATE_GALLERY_TITLE_DESC_SUCCESS,
            this.app.events.UPDATE_GALLERY_TITLE_DESC_FAILED,          
            this.app.events.CHANGE_VIEWMODE,
            this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY_SUCCESS,
            this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY_FAILED,
            this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY_SUCCESS,
            this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY_FAILED,
            this.app.events.DELETE_GALLERY_ITEM_SUCCESS,
            this.app.events.DELETE_GALLERY_ITEM_FAILED
            
	];
};

/**
 * not needed
 */
com.art.myGalleries.modules.GridDisplayModule.prototype.handleNotification = function (note) {
    trace('handleNotification ' + note.name);
    switch (note.name) {
        case this.app.events.UPDATE_BACKGROUND_COLOR:
            $("#items").css("float", "left").css("background-color", note.body);
            break;
        case this.app.events.CHANGE_VIEWMODE:
            if (note.body.module == this.app.constants.GRID_VIEW && note.body.page == 'grid') {
                $("#items").html(this.app.getModel().toggleDisplay);
                $(".topNavigationRight").show();
                this.init();
            }
            break;
        case this.app.events.UPDATE_GALLERY_TITLE_DESC_SUCCESS:
        	trace(note.body);
        	 if (note.body.OperationResponse.OperationStatus == 0) {
                this.editGalleryTitleLB.close();
                this.modalEditGallery.close();
                $("#" + this.modalEditGallery.id).remove();
                var selectedGallery = this.app.getModel().getSelectedGallery();
                $(".MyGalleriesTitle").html(unescape(selectedGallery.Name + ":"));
                $(".MyGalleriesDescription").html(decodeURIComponent(unescape(selectedGallery.LongDescription)));
                $(".MyGalleriesSelected .MyGalleriesLink").text(com.art.core.utils.StringUtil.autoEllipseText(selectedGallery.Name, 15));
                if(this.app.getModel().getSelectedGallery().GalleryVisibility=="3"){
                $(".MyGalleriesSelected .MygalleryRightViewLinks").show();
                }
                if(this.app.getModel().getSelectedGallery().GalleryVisibility=="1"){
                    $(".MyGalleriesSelected .MygalleryRightViewLinks").hide();
                }
            }
            else {
            	var errorMsg=note.body.OperationResponse.ResponseMessage;
            	$("#showErrorMsgContainer").show();
                $("#showErrorMsg").text(errorMsg);
            }

            break;
        case this.app.events.UPDATE_GALLERY_TITLE_DESC_FAILED:
        	
        	if(note.body.msg=='duplicate')
        		{        		
        			$("#showErrorMsgContainer").show();
        			$("#showErrorMsg").text("Please provide a unique gallery name.");
        		}        		
            break;
        case this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY_SUCCESS:
        	
        	if(note.body.OperationResponse!=undefined && note.body.OperationResponse!=null)
        	{	var errorMsg=note.body.OperationResponse.ResponseMessage;
                $(".commonErrorMsg").text(errorMsg);
                $(".commonErrorMsg").show();
            }
            else
            	{            		
	            	$(".MyGalleriesRightContainer").css("visibility","hidden");
	                $("#MoveToGalleryConfirm").css("visibility","visible");
	                $("#MoveToGalleryConfirm").css("position","absolute");
	         		$("#MoveToGalleryConfirm").css("margin-top","10px");
	         		$("#MoveToGalleryConfirm").css("margin-left","235px;");
	         		$("#MoveToGalleryConfirm").css("margin-bottom","20px;");
	                $("#continue").css("visibility","hidden");
	                $("#privacyChk").css("visibility","hidden");
	             	$("#privacyTxt").css("visibility","hidden");
	             	
	             	$("#doneBtn").css("visibility","visible");
	             	$("#doneBtn").css("position","absolute");
	             	$("#doneBtn").css("right","25px");
	             	
	             	$("#visitGallery").css("visibility","visible");		
	             	$("#visitGallery").css("position","absolute");
	             	$("#visitGallery").css("right","90px");              	
                	this.newCreatedGalleryId=note.body;	
                	this.setCookieForDropDown(this.newCreatedGalleryId);
            	}        	
            break;
        case this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY_FAILED:
        	 var errorMsg=note.body.OperationResponse.ResponseMessage;
        	 $(".commonErrorMsg").text(errorMsg);
        	 $(".commonErrorMsg").show();
            break;
        case this.app.events.GALLERY_ITEM_SORT_SUCCESS:
            //update model
            this.setGridImages();
            this.init();
            this.resetPage();
            break;
        case this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY_SUCCESS:
        	
            trace("Move Success Add Item To Gallery");
            $(".MyGalleriesRightContainer").css("visibility","hidden");
            $("#MoveToGalleryConfirm").css("visibility","visible");
            $("#MoveToGalleryConfirm").css("position","absolute");
    		$("#MoveToGalleryConfirm").css("margin-top","10px");
    		$("#MoveToGalleryConfirm").css("margin-left","235px;");
    		$("#MoveToGalleryConfirm").css("margin-bottom","20px;");
            $("#continue").css("visibility","hidden");
            $("#privacyChk").css("visibility","hidden");
        	$("#privacyTxt").css("visibility","hidden");
        	
        	$("#doneBtn").css("visibility","visible");
        	$("#doneBtn").css("position","absolute");
        	$("#doneBtn").css("right","25px");
        	
        	$("#visitGallery").css("visibility","visible");		
        	$("#visitGallery").css("position","absolute");
        	$("#visitGallery").css("right","90px");
        	this.setCookieForDropDown(this.app.getModel().cacheByGalleryList[this.app.getModel().selectedGalleryId].ItemKey);
            break;
        case this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY_FAILED:
            trace("Move Failure Add Item To Gallery");
            $(".commonErrorMsg").text("An unexpected error has occured,please reload the page or try again later.");
            $(".commonErrorMsg").show();
            break;
        case this.app.events.DELETE_GALLERY_ITEM_FAILED:
        	trace("Move Failure Add Item To Gallery");
            //redirect to 404 error //todo
        	break;
        case this.app.events.DELETE_GALLERY_ITEM_SUCCESS:
        	this.modalDeleteArt.close();
        	window.location.href = window.location.href;        	
        	break;
        default:
            throw new Error("GridDisplayModule Failure! Unknown note.name");
    };

};

com.art.myGalleries.modules.GridDisplayModule.prototype.resetPage = function()
{   
    var url=window.location.href;                  
    var finalUrl=""; 
    var aPosGal= url.indexOf("page=");
    if(aPosGal > 0 && url.indexOf("page=1")<0)
    {
        var newPageno= "page=1"; 
        var regex=/page=\d+\b/;
        finalUrl = url.replace(regex, newPageno);
        window.location.href=finalUrl; 	
    }       
};

com.art.myGalleries.modules.GridDisplayModule.prototype.setGridImages = function()
{
	$("#items").html("");
	var counter = 0;//google chrome fix; see jira bug mygal-118
	this.itemGridIndex = 0;
	for(var key in this.app.getModel().cacheByGalleryItemList)
	{
		this.itemGridIndex++;
		$("#items").append(this.GetGridImagesTemplate(this.app.getModel().getGalleryItemByGalleryId(key,counter)));
		counter++;
	}
     var extraItems = counter % 3;
     if (extraItems > 0)
     {
    	var strDummyDiv = "";
        for (var i = 0; i < 3 - extraItems; i++)
        {
        	if(i == (3 - extraItems - 1))
        		strDummyDiv += '<div mygalproductpageurl="" class="thumbs" style="float: left; width: 258px; height: 400px;"><span style="float: left; width:245px; height: 258px;"></span><div class="clear"></div><div style="float: left; width: 245px; text-align: center; height: 90px; font-family: Verdana; font-size: 11px; background-image: url(&quot;http://cache1.artprintimages.com/images/mygallery/grid_detail_background_new.png&quot;); background-repeat: repeat-x; padding-top: 10px; margin-left: 10px;"><div style="color: rgb(0, 0, 0); line-height: 14px;"></div><div class="clear"></div><div style="color: rgb(0, 114, 188); line-height: 14px;"><a href="" style="color: rgb(0, 114, 188); text-decoration: none;"></a></div><div class="clear"></div><div style="color: rgb(51, 51, 51); font-size: 10px; line-height: 14px;"></div><div class="clear"></div><div style="color: rgb(51, 51, 51); font-size: 10px; line-height: 14px;"></div><div class="clear"></div><div style="color: rgb(51, 51, 51); font-size: 10px; line-height: 14px;"></div></div></div>';
        	else
        		strDummyDiv += '<div mygalproductpageurl="" class="thumbs" style="float: left; width: 258px; height: 400px;"><span style="float: left; width:258px;height: 258px;"></span><div class="clear"></div><div style="float: left; width: 258px; text-align: center; height: 90px; font-family: Verdana; font-size: 11px; background-image: url(&quot;http://cache1.artprintimages.com/images/mygallery/grid_detail_background_new.png&quot;); background-repeat: repeat-x; padding-top: 10px; margin-left: 10px;"><div style="color: rgb(0, 0, 0); line-height: 14px;"></div><div class="clear"></div><div style="color: rgb(0, 114, 188); line-height: 14px;"><a href="" style="color: rgb(0, 114, 188); text-decoration: none;"></a></div><div class="clear"></div><div style="color: rgb(51, 51, 51); font-size: 10px; line-height: 14px;"></div><div class="clear"></div><div style="color: rgb(51, 51, 51); font-size: 10px; line-height: 14px;"></div><div class="clear"></div><div style="color: rgb(51, 51, 51); font-size: 10px; line-height: 14px;"></div></div></div>';
        }
        $("#items").append(strDummyDiv);
     }
	
};

com.art.myGalleries.modules.GridDisplayModule.prototype.GetGridImagesTemplate = function(galleryItem)
{
	var galleryItem = galleryItem.GalleryItemData;
	var _this     = this;
	var str="";
	var Imageid = galleryItem.Imageid;
	var ItemGalleryItemID = galleryItem.ItemId;
	var ImgContainer = "";
	var strDropShadow = "";
	var strItemDetails = "";
	var ImageUrl = galleryItem.ImageUrl;
	var ImageWidth = galleryItem.Width;
	var ImageHeight = galleryItem.Height;
	var VanityURL = galleryItem.VanityURL;

	var itemTitle   	= com.art.core.utils.StringUtil.autoEllipseText(galleryItem.ItemDetails.Title, 20);
	var artistName =(galleryItem.ItemDetails.Artist.FirstName || "") + " " +(galleryItem.ItemDetails.Artist.LastName || "");
	var itemArtistName  =  com.art.core.utils.StringUtil.autoEllipseText(artistName, 20);
	
	if(galleryItem.ItemDetails.Artist.ArtistUrl==null){	  
		var ArtistName= "";
	}
	else{
		var ArtistName= "<a style='color:#0072BC;text-decoration:none;' href='"+galleryItem.ItemDetails.Artist.ArtistUrl+"'>"+itemArtistName+"</a>";
	}		
	var convertToCmFlag = com.art.core.utils.LocalizationManager.determineConvertToCm("", globalThis.app.getModel().environment.currencyCode, "");
	if(convertToCmFlag)
		var ItemSize = com.art.core.utils.StringUtil.formatDimensions(galleryItem.ItemDetails.PhysicalDimensions.Width, galleryItem.ItemDetails.PhysicalDimensions.Height,convertToCmFlag);
	else
		var ItemSize = Math.round(galleryItem.ItemDetails.PhysicalDimensions.Width*2)/2 + ' x ' + Math.round(galleryItem.ItemDetails.PhysicalDimensions.Height*2)/2 + ' inches';
	
	var ItemDisplayTypeText = "";
	var specailhanfalingid = galleryItem.SpecialHandlingID != "undefined" ?  galleryItem.SpecialHandlingID : 0;
	
	if(specailhanfalingid == 6)
	{
		ItemDisplayTypeText = "Lamination";
	}
	else if(specailhanfalingid == 2)
	{
		ItemDisplayTypeText = "Wood Mounting";
	}
	else if(specailhanfalingid == 4)
	{
		ItemDisplayTypeText = "Canvas Transfer";
	}
	else
	{
		ItemDisplayTypeText = galleryItem.ItemDetails.ItemDisplayType;
	}

	if(galleryItem.ItemDetails.ItemPrice.ShowMarkDownPrice)
	{
		var ItemPrice   	= "<span style='text-decoration: line-through;margin-left:3px;'>"+galleryItem.ItemDetails.ItemPrice.DisplayMSRP+"</span><span style='color:indianred;margin-left:3px;font-style:italic;'>"+ galleryItem.ItemDetails.ItemPrice.DisplayPrice +"</span>";
	}
	else
	{
		var ItemPrice   	= galleryItem.ItemDetails.ItemPrice.DisplayPrice;
	}
	
	var length = 230;
	var w = 0, h = 0, mt = 0, ml = 0;
	var aspectRatio = ImageWidth/ImageHeight;
	   if (aspectRatio > 1.0)
	   {
	       w =length;
	       h = length / aspectRatio;
	       mt = (w - h) / 2;
	   }
	   else
	   {
	       w = length * aspectRatio;
	       h = length;
	       ml = (h - w) / 2;
	   }
	
	   ImageHeight = Math.floor(h);
	   ImageWidth = Math.floor(w);
	
	   var _HD = (258 - ImageHeight);
	   var _WD = (258 - ImageWidth);
	   
	   var tp, bt, rp, lp;
	   //Calculate the Padding needed.
	   if (_HD > 0)
	   {
	      tp = _HD / 2;
	      bp = (_HD - tp);
	   }
	   if (_WD > 0)
	   {
	      rp = _WD / 2;
	      lp = (_WD - rp);
	   }
	  /* tp = 0;
	   lp = 14;
	   if($.browser.msie) tp = 14; else  tp = 10;*/
	   
	   lp = Math.floor(lp);
	   tp = Math.floor(tp);
	   //var mygalppurl = "http://"+document.location.hostname+ "/asp/mygallery/mygalleries.asp?itemgalleryitemid="+ItemGalleryItemID+"&pp=1&galleryid="+this.app.getModel().environment.selectedGalleryID;
	   var mygalppurl = "http://"+document.location.hostname+ VanityURL;
	   ImgContainer	   = '<a href="'+ mygalppurl +'" style="float:left;height:258px;width:258px;"><img border="0" style="position:absolute;left:'+ lp +'px;top:'+ tp +'px;" width="'+ ImageWidth +'" height="'+ ImageHeight +'" class="centerMyGalleryImage" alt="" title="" src="'+ ImageUrl +'" /></a>';
	   var ImgRightTop     = '<img border="0" alt="" style="top:'+ tp +'px; left: '+(ImageWidth + lp ) +'px;" class="abs w8 h10" src="http://cache1.artprintimages.com/images/photostoart/shadow_righttop_E5E7DC.png" />';
	   var ImgRightTiling  = '<img border="0" height="'+ (ImageHeight  - 10)+'" alt="" style="top:'+ (tp + 10) +'px; left:'+(ImageWidth + lp ) +'px;" class="abs w8" src="http://cache1.artprintimages.com/images/mygallery/shadow_righttiling_E5E7DC.png" />';
	   var ImgBottomLeft   = '<img border="0" alt="" style="top:'+ (ImageHeight + tp ) +'px; left: '+ (lp ) +'px;" class="abs w8 h8" src="http://cache1.artprintimages.com/images/photostoart/shadow_bottomleft_E5E7DC.png" />';
	   var ImgBottomTiling = '<img border="0" width="'+(ImageWidth - 8 )+'" alt="" style="top:'+ (ImageHeight  + tp) +'px; left: '+(lp+8) +'px;" class="abs h8" src="http://cache1.artprintimages.com/images/mygallery/shadow_bottomtiling_E5E7DC.png" />';
	   var ImgBottomRight  = '<img border="0" alt="" style="top:'+ (ImageHeight  + tp) +'px; left: '+(ImageWidth + lp ) +'px;" class="abs w8 h8" src="http://cache1.artprintimages.com/images/photostoart/shadow_bottomright_E5E7DC.png" />';
	
	   strDropShadow
		= "<div class='imgDropShadowContainer'>"
		+ 		ImgRightTop
		+ 		ImgRightTiling
		+ 		ImgBottomLeft
		+ 		ImgBottomTiling
		+ 		ImgBottomRight
		+ "</div>";
	   	
	   	var ItemWidth =  this.itemGridIndex % 3 == 0 ? "width:245px;" : "width:258px";
	    strItemDetails = '<div style="float:left;'+ ItemWidth +';text-align:center;height:90px;font-family:Verdana;font-size:11px;;background-image:url(http://cache1.artprintimages.com/images/mygallery/grid_detail_background_new.png);background-repeat:repeat-x;padding-top:10px;margin-left:10px;">'
	    			   + '<div style="color:#000;line-height:14px;">'+ itemTitle +'</div>'
	    			   + '<div class="clear"></div>'
	    			   + ' <div style="color:#0072BC;line-height:14px;">'+ ArtistName +'</div>'
	    			   + '<div class="clear"></div>'
	    			   + '<div style="color:#333;font-size:10px;line-height:14px;">'+ ItemSize +'</div>'
	    			   + '<div class="clear"></div>'
	    			   + '<div style="color:#333;font-size:10px;line-height:14px;">'+ItemDisplayTypeText+'</div>'
	    			   + '<div class="clear"></div>'
	    			   + '<div style="color:#333;font-size:10px;line-height:14px;">'+ItemPrice+'</div>'
	    			   + '</div>';
	    			   
	    			   
   str = "<div id='"+ItemGalleryItemID+"' style='float: left; width: 258px; height: 400px;' class='thumbs' MyGalProductPageUrl='"+ mygalppurl+"'>"
   		+ ImgContainer
   		+ strDropShadow
   		+ '<div class="clear"></div>'
   		+ strItemDetails
   		+ "</div>";
   		
	return str;
};



com.art.myGalleries.modules.GridDisplayModule.prototype.getTemplate = function()
{
	//STEP: Get the raw string for the template
	var returnValue = this.template;
	//STEP: Replace the [IMAGE_DOMAIN] placeholder with the imagePath value
	returnValue = returnValue.replace(/\[IMAGE_DOMAIN\]/gi, this.imagePath);
	//STEP: Now return the string (template)
	return returnValue.replace('$NAME', this.NAME);
};

com.art.myGalleries.modules.GridDisplayModule.prototype.getTarget = function()
{
	return this.moduleData.target;
};

com.art.myGalleries.modules.GridDisplayModule.prototype.template; // '<div id="$NAME" class="floatLeft"><div id="topNavigation"></div><div id="items">Items </div><div id="bottomNavigation"></div></div>';

 
