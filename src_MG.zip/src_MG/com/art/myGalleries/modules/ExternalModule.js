//CONSTRUCTOR: instantiates the instance, Every Object must implement the base
com.art.myGalleries.modules.ExternalModule = function(data,app)
{
	this.app 		= app;
	this.moduleData = data;
	this.NAME		= com.art.myGalleries.modules.ExternalModule.NAME;
	this.instance	= this;
	this.modalGalleryLB;
	this.modalSignUpLB;
	this.myModalSaveToGallery;
	this.loginLink;
	this.modalGallery;
	this.selectedGalleryName = '';
	this.framingStudioCall;
	this.FSData={};
	this.loginOption="";
	this.wishList;
	this.modalWishList;
};
com.art.myGalleries.modules.ExternalModule.NAME = "ExternalModule";
com.art.myGalleries.modules.ExternalModule.prototype.init = function(obj)
{
	var _this=this;
	$(".myWishListMyAccount").live("click",function()
	{		
		_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.MYACCOUNT_WISHLIST));
		//MyGalleriesCore.sendNotification(new MyGalleriesCore.Note(MyGalleriesCore.events.MYACCOUNT_WISHLIST));		
	 });
	
	//Verify the condition of refresh page
//	if(this.app.getModel().environment.accountType != this.app.constants.ANONYMOUS && com.art.core.utils.BrowserUtil.getQueryString('myLoginProduct', location.href)=="true")		
//	{	
//		if(com.art.core.utils.BrowserUtil.getQueryString('myLoginChangeProduct', location.href)=="")
//		{
//			this.setModalInit();
//		}		
//	}
	
};

com.art.myGalleries.modules.ExternalModule.prototype.getUserGalleries = function()
{
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_ALL_GALLERIES));
};

com.art.myGalleries.modules.ExternalModule.prototype.setModalInit = function()
{	
	if(location.href.indexOf("/me/") > -1)
		return;
	
	var _this = this;
	this.modalGalleryLB = new com.art.core.components.LightBox('myMoveToGalleryLB', 'body', .4);
	this.modalGalleryLB.show(); //append to target	
	
	//set to false AFTER we've blocked other clicks
	//make sure modalGalleryLB get's added to DOM before we set to false
	//slight delay
	setTimeout(function(){
		MyGalleriesCore.getModel().frameStudioFlag = false;
	},250);
	
	var SelectedGalleryId = "";
	var selectedid = "";

	var galleryItem = _this.app.getModel().selectedImageObject;
	
	//var SelectedGalleryId = globalthis.app.getModel().environment.selectedGalleryID;
	var SelectedGalleryId = this.app.getModel().environment.selectedGalleryID;

	var MyGalleriesModalObject = {id:"SaveToGallery",Title:"Save to My Gallery",SelectedGalleryId:SelectedGalleryId,galleryList:_this.app.getModel().galleryList,galleryItem:galleryItem};
	if(this.framingStudioCall!="framingStudioCall")
		{
			var galleryItem = _this.app.getModel().selectedImageObject;			
			//var SelectedGalleryId = globalthis.app.getModel().environment.selectedGalleryID;
			var SelectedGalleryId = this.app.getModel().environment.selectedGalleryID;			
			var MyGalleriesModalObject = {id:"SaveToGallery",Title:"Save to My Gallery",SelectedGalleryId:SelectedGalleryId,galleryList:_this.app.getModel().galleryList,galleryItem:galleryItem};
		}
	else
		{		
			var MyGalleriesModalObject = {id:"SaveToGallery",Title:"Save to My Gallery",galleryList:_this.app.getModel().galleryList,galleryItem:this.FSData};
		}
	this.modalGallery = new com.art.myGalleries.components.MyGalleriesModal(MyGalleriesModalObject);
	var popwidth = $.browser.msie ? 750:720; 
    this.myModalSaveToGallery = new com.art.core.components.BaseModal("myModalSaveToGallery", popwidth, "#f7f7ed", false);
    this.myModalSaveToGallery.setContents(this.modalGallery.render());
    
    var privacyCheckbox = new com.art.core.components.CheckBox('privacyChk', 'privacy', 'Make Gallery Private', false);
    var strPrivacy = "<div class='privacy'><div style='float: left;'>" + privacyCheckbox.render() + "</div><div id='privacyTxt' style='float:left;padding-left:5px;font-family:verdana;font-size: 11px;font-color:#666666'>" + privacyCheckbox.label + "</div><div style='clear:both'></div></div>";
    
    $("body").append(this.myModalSaveToGallery.render(this.modalGalleryLB.getLightBoxZIndex() + 1));
    
    this.myModalSaveToGallery.registerEvents();
    if(this.app.getModel().environment.accountType != this.app.constants.ANONYMOUS)
	{
    	this.myModalSaveToGallery.setLeftButtonBarContent(strPrivacy);
	}
    
	$(".newGalleryTextBox").after(strPrivacy);
    privacyCheckbox.registerEvents();
    privacyCheckbox.registerCallback(com.art.core.components.CheckBox.CHECKED,
    		function (object) {    	
    		    var privacy = object.selected ? 3 : 1; //3-private 1-public    
    		    _this.app.getModel().setAddedGalleryPrivacy(privacy);
    		});
    
    //Begin Login Modal
    this.modalGallery.registerCallback(com.art.myGalleries.components.MyGalleriesModal.LOGIN_CLICKED, function () {
    	
    	trace("login btn clicked"); 
    	_this.loginOption="Login";
        _this.showLoginModal();
    });
    //Begin Login Modal
    this.modalGallery.registerCallback(com.art.myGalleries.components.MyGalleriesModal.REGISTER_CLICKED, function () {
    	trace("login btn clicked"); 
    	_this.loginOption="SignUp";
        _this.showLoginModal();
    });
    trace(this.myModalSaveToGallery);
    //End Login Modal
    var continueBtn = new com.art.core.components.ArtButton("continue",com.art.core.components.ArtButton.ART_ORANGE, "Save to Gallery");
    $(".MyGalleriesModalGalleryContainer").after(continueBtn.render());
    continueBtn.registerEvents();
    continueBtn.registerCallback(com.art.core.components.BaseButton.CLICK, function () {
    	trace("continue clicked");
        var chkStatus = _this.modalGallery.ContinueToMove();
        
        if (chkStatus=='Existing') {
        	_this.app.getModel().environment.selectedGalleryID = _this.modalGallery.getDestinationSelectedGalleryId();
        	_this.app.getModel().setDestinationSelectedGalleryId(_this.modalGallery.getDestinationSelectedGalleryId());
        	_this.selectedGalleryName =_this.app.getModel().cacheByGalleryList[_this.app.getModel().environment.selectedGalleryID].Name;
        	
        	if(_this.framingStudioCall=="framingStudioCall")
         	{         	
         		_this.app.getModel().setFramingStudioResponseObject(_this.FSData);
         		mygalleriesGA.trackEventWithCategory('Save to Gallery','Framing Studio Add - Completed');
         		_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.ADD_ITEM_TO_EXISTING_GALLERY,_this.FSData.FileName));
         	}
        	else
    		{
    		_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.ADD_ITEM_TO_EXISTING_GALLERY));
    		}
        }
        else if(chkStatus) {
        	
            var data = _this.modalGallery.getAddTitleData(); // {title:''}            
            _this.app.getModel().setAddedGalleryTitle(data.title);
            _this.selectedGalleryName = data.title;
            if(_this.framingStudioCall=="framingStudioCall")
        	{
        		_this.app.getModel().setFramingStudioResponseObject(_this.FSData);
        		_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.ADD_ITEM_TO_NEW_GALLERY,_this.FSData.FileName));
        	}
            else
            {
        		 _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.ADD_ITEM_TO_NEW_GALLERY));
        	}
           
        }
    });

    var visitGalleryeBtn = new com.art.core.components.ArtButton("visitGallery", com.art.core.components.ArtButton.ART_BLUE, "Visit Gallery");
    $(".MyGalleriesModalGalleryContainer").after(visitGalleryeBtn.render());
    visitGalleryeBtn.registerEvents();
    visitGalleryeBtn.registerCallback(com.art.core.components.BaseButton.CLICK, function () {
        
    	/*if(_this.newCreatedGalleryId=="" || _this.newCreatedGalleryId==undefined)
  		 {  
    		var vanityURL=_this.app.getModel().cacheByGalleryList[_this.modalGallery.GetGalleryID()].VanityURL;
    		window.location.href = "http://"+window.location.hostname+vanityURL;
  		 }
    	else 
  		 { 
  			window.location.href = "http://"+window.location.hostname+_this.app.getModel().environment.profileURL +_this.newCreatedGalleryId +"/";
  		 }*/
    	_this.modalGalleryLB.close();
    	if(_this.app.getModel().environment.selectedGalleryID != "")
    	{
        	var url = "http://"+window.location.hostname+_this.app.getModel().environment.profileURL +_this.app.getModel().cacheByGalleryList[_this.app.getModel().environment.selectedGalleryID].ItemKey +"/";
        	window.location.href = url;	
    	}
    	else
    	{
    		window.location.href = "http://"+window.location.hostname+_this.app.getModel().environment.profileURL +_this.newCreatedGalleryId +"/";
    	}
  	 $("#" + _this.myModalSaveToGallery.id).remove();
  	
    });
    
    var doneBtn = new com.art.core.components.ArtButton("doneBtn", com.art.core.components.ArtButton.ART_ORANGE, "Done");
    $(".MyGalleriesModalGalleryContainer").after(doneBtn.render());
    doneBtn.registerEvents();
    doneBtn.registerCallback(com.art.core.components.BaseButton.CLICK, function () {
    	var chkStatus = _this.modalGallery.ContinueToMove();
    	if (chkStatus=='Existing') {
    		_this.setCookieForDropDown(_this.app.getModel().cacheByGalleryList[_this.app.getModel().selectedGalleryId].ItemKey);
    	}
    	else if(chkStatus)
    	{
    		_this.setCookieForDropDown(_this.newCreatedGalleryId);
    	}
    	_this.app.getModel().galleryList="";
    	_this.myModalSaveToGallery.close();
    	_this.modalGalleryLB.close();
    	$("#loginSavetogallery").die('click');
     	 $("#loginSavetogallery").unbind('click');
     	$("#registerSavetogallery").die('click');
     	$("#registerSavetogallery").unbind('click');
        //window.location.href = window.location.href;
    });
   
    this.myModalSaveToGallery.registerCallback(com.art.core.components.BaseModal.CLOSE_CLICKED, function () {    	
    	$("#loginSavetogallery").die("click");
    	$("#loginSavetogallery").unbind("click");
    	$("#registerSavetogallery").die('click');
     	$("#registerSavetogallery").unbind('click');
    	_this.app.getModel().galleryList="";
    	
    	_this.modalGalleryLB.close();
        
        //window.location.href = window.location.href;
    });
    
    this.modalGallery.registerEvents();
    
};

com.art.myGalleries.modules.ExternalModule.prototype.setCookieForDropDown = function(param)
{
	if(param != "")
	{
		var cookieobject = new com.art.core.cookie.Cookie();
		cookieobject.setCookieDictionary('arts','SaveToGallery',param,'/', cookieobject.getCookieDomain('art'));
	}	
};


/**
* Used this method to call the login modal
* @method showLoginModal
*/
com.art.myGalleries.modules.ExternalModule.prototype.showLoginModal = function () {	
    var _this = this;    
    this.loginLink = new com.art.core.components.LoginModal('mySaveToGalleryLogin', 'Login to your Art.com account', 'Register a new Art.com account ', 'myGallery',this.loginOption);
    
    this.modalSignUpLB = new com.art.core.components.LightBox('signInmyMoveToGalleryLB', 'body', .4);
	this.modalSignUpLB.show(); //append to target	
    
    $("body").append(this.loginLink.render(this.modalSignUpLB.getLightBoxZIndex() + 1));
    
    this.loginLink.initSubmitButtons();    
    this.loginLink.registerEvents();    
    
    this.loginLink.registerCallback(com.art.core.components.LoginModal.CLOSE_CLICKED, function () {    	
    	_this.modalSignUpLB.close();    	 
    	$("#myModalLogin").die();
        $("#myModalLogin").unbind("click");
        $("#myModalLogin").remove();
        _this.modalGalleryLB.show();    	 
    });

    this.loginLink.registerCallback(com.art.core.components.LoginModal.REGISTER_CLICKED, function () {    	
        var data = _this.loginLink.getRegisterAccountData();
        var note = new com.art.core.utils.Note(_this.app.events.REGISTER_ACCOUNT, { username: data.username, password: data.password}, "");
        $("body").append(_this.loginLink.render(_this.modalSignUpLB.getLightBoxZIndex() + 1));
        _this.app.sendNotification(note);
    });
    this.loginLink.registerCallback(com.art.core.components.LoginModal.LOGIN_CLICKED, function () {    	
        var data = _this.loginLink.getLoginAccountData();
        var note = new com.art.core.utils.Note(_this.app.events.LOGIN_ACCOUNT, { username: data.username, password: data.password}, "");
        _this.app.sendNotification(note);
    });
    this.loginLink.registerCallback(com.art.core.components.LoginModal.ON_FACEBOOK_LOGIN_SUCCESS,function(facebookResponse){
    	
    	var data=facebookResponse.id;    	
    	_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.LOGIN_FACEBOOK_MYGALLERY,data));
    });
};



/**
* Used this method to close the login modal as well as lightbox
* @method loginModalClose
*/
com.art.myGalleries.modules.ExternalModule.prototype.loginModalClose = function ()
{   
	var _this=this;
    trace("login closed");
    $("#myModalLogin").die();
    $("#myModalLogin").unbind("click");
    $("#myModalLogin").remove();
    this.loginLink.close();
    this.modalSignUpLB.close();
    $("#mygallerylogin").unbind("click");
    $("#mygallerylogin").die('click');
    $("#mygallerylogin").remove();
    $("#mygalleryregister").unbind("click");
    $("#mygalleryregister").die('click');
    $("#mygalleryregister").remove();    
    $("#" + this.id).die();
    $("#" + this.id).unbind("click");
    $("#" + this.id).remove();
    
};

/**
* Used this method to open the wish list modal from my account external page
* @method OpenWishListModal
*/
com.art.myGalleries.modules.ExternalModule.prototype.OpenWishListModal = function () {
	
	var _this =this;
    var wishListLB = new com.art.core.components.LightBox('myAccountWishListLB', 'body', .4);
    wishListLB.show(); //append to target		
    
   this.wishList = new com.art.myGalleries.components.CommonComponent('wishlistMyAccount', 'Wish lists are now My Galleries', 500, 200);    

    this.modalWishList = new com.art.core.components.BaseModal("myModalWishlist", 480, "#f7f7ed", true);
    this.modalWishList.setContents(this.wishList.render());

    $("body").append(this.modalWishList.render(wishListLB.getLightBoxZIndex() + 1));
    this.modalWishList.registerEvents();

    this.modalWishList.registerCallback(com.art.core.components.BaseModal.CLOSE_CLICKED, function () {
    	wishListLB.close();
    });
    
    this.modalWishList.registerButton("closeBtn", com.art.core.components.ArtButton.ART_ORANGE, "Close", function () {
    	_this.modalWishList.close();
    	wishListLB.close();        
    });
       this.wishList.registerEvents();
};

com.art.myGalleries.modules.ExternalModule.prototype.destroy = function()
{
	//NOTE: Destroy is where you destroy this object and clean up memory
};

com.art.myGalleries.modules.ExternalModule.prototype.notify = function()
{
	//NOTE: 
	this.app.sendNotification(note);
};

com.art.myGalleries.modules.ExternalModule.prototype.listNotificationInterests = function()
{
	return [ this.app.events.ADD_ITEM_TO_EXISTING_GALLERY_EXT,
	         this.app.events.GET_ALL_GALLERIES_SUCCESS,
	         this.app.events.GET_ALL_GALLERIES_FAILED,
	         this.app.events.ADD_ITEM_TO_EXISTING_GALLERY_SUCCESS,
	         this.app.events.ADD_ITEM_TO_EXISTING_GALLERY_FAILED,
	         this.app.events.ADD_ITEM_TO_NEW_GALLERY_SUCCESS,
	         this.app.events.ADD_ITEM_TO_NEW_GALLERY_FAILED,
	         this.app.events.REGISTER_ACCOUNT_SUCCESS,
	         this.app.events.REGISTER_ACCOUNT_FAILED,
	         this.app.events.LOGIN_ACCOUNT_SUCCESS,
	         this.app.events.LOGIN_ACCOUNT_FAILED,
	         this.app.events.GET_FRAME_SKU_SUCCESS,
	         this.app.events.GET_FRAME_SKU_FAILED,
	         this.app.events.MYACCOUNT_WISHLIST,
	         this.app.events.LOGIN_FACEBOOK_MYGALLERY_SUCCESS,
	         this.app.events.LOGIN_FACEBOOK_MYGALLERY_FAILED
	        
	];
};

com.art.myGalleries.modules.ExternalModule.prototype.handleNotification = function(note)
{
	switch(note.name)
	{
	
		case this.app.events.GET_FRAME_SKU_SUCCESS:			
			trace("json object from external page: ");			
			this.FSData=note.body;	
			
			this.framingStudioCall="framingStudioCall";	
			
			if(this.app.getModel().galleryList.length == 0)
			{				
				this.getUserGalleries();
			}
			else
			{					
				this.setModalInit();
			}
		break;
		case this.app.events.GET_FRAME_SKU_FAILED:			
			trace("FRAME SKU FAILED");			
		break;
		
		case this.app.events.MYACCOUNT_WISHLIST:			
			trace("My Account wish list");
			
			this.OpenWishListModal();
			if($.browser.msie)
			{
				$("#baseModalButtonBarRight_myModalWishlist").css("width","35%");
				
				$("#closeBtn").css("height","32px");
				$("#closeBtn").css("left","120px");
				$("#closeBtn_label").css("height","32px");
				$("#closeBtn_rightcap").css("height","32px");
			}
		break;
		
		case this.app.events.ADD_ITEM_TO_EXISTING_GALLERY_EXT:
			
			trace("json object from external page: ");
			
			if(this.app.getModel().galleryList.length == 0)
				{				
					this.getUserGalleries();
				}
			else
				{				
					this.setModalInit();
				}
			break;
		case this.app.events.GET_ALL_GALLERIES_SUCCESS:
			trace("GET_ALL_GALLERIES_SUCCESS"+note.name);
			this.setModalInit();
			break;
		case this.app.events.GET_ALL_GALLERIES_FAILED:	
			trace("GET_ALL_GALLERIES_FAILED"+note.name);
			this.setModalInit();
			break;
	    case this.app.events.ADD_ITEM_TO_EXISTING_GALLERY_SUCCESS:
	    	trace("Success New Add Item To Gallery");
//            if (note.body == undefined) {
//                $(".commonErrorMsg").text("Gallery Name already exists");
//            }
//            else
//        	{            	          	
            	this.setBtnStyle();            	             	
            	this.newCreatedGalleryId=note.body;
        	//}
            break;
        case this.app.events.ADD_ITEM_TO_EXISTING_GALLERY_FAILED:
            trace("Failure Add Item To Gallery");
            break;	
        case this.app.events.ADD_ITEM_TO_NEW_GALLERY_SUCCESS:
        	
            trace("Success New Add Item To Gallery");
            if (note.body.OperationResponse.OperationStatus !=0) {
            	if(note.body.OperationResponse.ResponseCode==503)
            		{
            			$(".commonErrorMsg").css("width","450px");
            			$(".commonErrorMsg").css("top","200px");
            			$(".commonErrorMsg").text("You have an existing gallery with this name. Please enter a new name or select your existing gallery from the dropdown menu.");
            			$(".commonErrorMsg").show();
            		}
            	else
            		{
            			var errorMsg=note.body.OperationResponse.ResponseMessage;
            			$(".commonErrorMsg").text(errorMsg);
            			$(".commonErrorMsg").show();
            		}            	
            }
            else
        	{            	          	
            	this.setBtnStyle();            	             	
            	this.newCreatedGalleryId=note.body;
        	}
            /*
            
            this.modalGalleryLB.close();
            this.myModalSaveToGallery.close();
            $("#" + this.myModalSaveToGallery.id).remove();*/
            break;
        case this.app.events.ADD_ITEM_TO_NEW_GALLERY_FAILED:            
            var errorMsg=note.body.OperationResponse.ResponseMessage;
            $(".commonErrorMsg").text(errorMsg);
            $(".commonErrorMsg").show();
            break;	
            
        case this.app.events.REGISTER_ACCOUNT_SUCCESS:
        	trace("register success");
        	this.loginModalClose();
        	this.modalGalleryLB.close();
            this.myModalSaveToGallery.close();
            $("#" + this.myModalSaveToGallery.id).remove();
            location.reload(true);            
            break;
        case this.app.events.REGISTER_ACCOUNT_FAILED:
            $(".loginModalErrorMsg").css("display", "block");
            if (note.body == "exist") {
            	if($.browser.msie && parseInt($.browser.version)==7)
           		{
              		 if(this.id!="myGalleryLogin")
          	  		   { 
              			 $(".loginErrorMsg").css("top","60px");
          			 }
           		}             	 
             	
                //$(".loginErrorMsg").text('The email address you entered is already associated with an Art.com account. Would you like to retrieve your password?');
            	$(".loginErrorMsg").text('The email address you entered is already associated with an Art.com account.');
            }
            else if (note.body == "invalidemail") {
                //$(".loginErrorMsg").text('We were unable to recognize your email address. Please re-enter your information.');
            	$(".loginErrorMsg").text('Please enter a valid email address.');
            }
            else if (note.body == "invalidpassword") {
                //$(".loginErrorMsg").text('We were unable to recognize your password. Please re-enter your information or retrieve your password.');
            	$(".loginErrorMsg").text('Password must be at least 8 characters.');
            }
            else if (note.body == "failure") {
                //$(".loginErrorMsg").text('We were unable to find an account associated with that email address. Please re-enter your information, or Sign Up for a new account.');
            	
            	if($.browser.msie)
          		{
             		 if(this.id!="myGalleryLogin")
         	  		   {
             			 $(".loginErrorMsg").css("top","40px");
         	  		   }
             		 else
             			 {
             			 	$(".loginErrorMsg").css("top","70px");
             			 }
          		}            	 
            	$(".loginErrorMsg").text('We were unable to find an account associated with that email address.');
            }
            break;
        case this.app.events.LOGIN_ACCOUNT_SUCCESS:
        	
        	this.loginModalClose();        	
        	this.modalGalleryLB.close();
            this.myModalSaveToGallery.close();
            $("#" + this.myModalSaveToGallery.id).remove();

            window.location.href = window.location.href.indexOf('?')>-1?window.location.href+"&myLoginProduct=true":window.location.href+"?myLoginProduct=true";
//            window.location.href = window.location.href+"&myLoginProduct=true";
                        
            break;
        case this.app.events.LOGIN_ACCOUNT_FAILED:
        	if (note.body == "failure") {
                $(".loginModalErrorMsg").css("display", "block");
                if($.browser.msie)
          		{
             		 if(this.id!="myGalleryLogin")
         	  		   { 
             			 $(".loginErrorMsg").css("top","40px");
         			 }
             		 else
             			 {
             			 	$(".loginErrorMsg").css("top","70px");
             			 }
          		}
            	 
                //$(".loginErrorMsg").text('We were unable to find an account associated with that email address. Please re-enter your information, or Sign Up for a new account.');
                $(".loginErrorMsg").text('We were unable to find an account associated with that email address.');
            }
            break;           
        case this.app.events.GET_FRAME_SKU_FAILED:
        	trace("Frame sku Success");
		    break;
        case this.app.events.LOGIN_FACEBOOK_MYGALLERY_SUCCESS:
        	
        	trace("Facebook Success");
        	this.loginModalClose();
        	this.modalGalleryLB.close();
            this.myModalSaveToGallery.close();
            $("#" + this.myModalSaveToGallery.id).remove();
            window.location.href = window.location.href.indexOf('?')>-1?window.location.href+"&myLoginProduct=true":window.location.href+"?myLoginProduct=true";
        	break;        	
        case this.app.events.LOGIN_FACEBOOK_MYGALLERY_FAILED:
        	trace("Facebook fail");
        	break;
     
		default:
			trace("default case");
	}
};

com.art.myGalleries.modules.ExternalModule.prototype.setBtnStyle = function()
{
	$(".MyGalleriesRightContainer").css("visibility","hidden");
    $("#SavetoGalleryConfirm").css("visibility","visible");
    $("#SavetoGalleryConfirm").css("position","absolute");
	$("#SavetoGalleryConfirm").css("margin-top","10px");
	$("#SavetoGalleryConfirm").css("margin-left","235px;");
	$("#SavetoGalleryConfirm").css("margin-bottom","20px;");
	 
	$("#galleryName").text('"'+ this.selectedGalleryName + '"');
	
    $("#continue").css("visibility","hidden");
    $("#privacyChk").css("visibility","hidden");
	$("#privacyTxt").css("visibility","hidden");
	
	$("#doneBtn").css("visibility","visible");
	$("#doneBtn").css("position","absolute");
	$("#doneBtn").css("right","25px");
	$("#doneBtn").css("bottom", "25px");
	
	if($.browser.msie)
	{ 
		$("#doneBtn").css("width","65px");
		$("#doneBtn_label").css("height","32px");
		$("#doneBtn_rightcap").css("height","32px");
	}
	
	$("#visitGallery").css("visibility","visible");		
	$("#visitGallery").css("position","absolute");
	$("#visitGallery").css("right","90px");           
	$("#visitGallery").css("bottom", "25px");
	
	if($.browser.msie)
		{
			$("#visitGallery").css("width", "105px");
			$("#visitGallery_label").css("height", "32px");
			$("#visitGallery_rightcap").css("height","32px");
		}
};
com.art.myGalleries.modules.ExternalModule.prototype.getTemplate = function()
{
	//STEP: Get the raw string for the template
	var returnValue = this.template;
	//STEP: Replace the [IMAGE_DOMAIN] placeholder with the imagePath value
	returnValue = returnValue.replace(/\[IMAGE_DOMAIN\]/gi, this.imagePath);
	//STEP: Replace the [$MYGALLERY] placeholder with the MyGallery Header Title value
	returnValue = returnValue.replace(/\[$MYGALLERY\]/gi, this.imagePath);
	
	//STEP: Now return the string (template)
	return returnValue.replace('$NAME', this.NAME);
};

com.art.myGalleries.modules.ExternalModule.prototype.getTarget = function()
{
	return this.moduleData.target;
};

com.art.myGalleries.modules.ExternalModule.prototype.template = ""; //not needed markup coming from server


