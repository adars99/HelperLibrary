//CONSTRUCTOR: instantiates the instance, Every Object must implement the base
com.art.myGalleries.modules.GalleryHome = function(data,app)
{
	this.app 		= app;
	this.moduleData = data;
	this.NAME		= com.art.myGalleries.modules.GalleryHome.NAME;
	this.instance	= this;
};
com.art.myGalleries.modules.GalleryHome.NAME = "GalleryHome";

com.art.myGalleries.modules.GalleryHome.prototype.init = function (config)
{
	
	trace("startup GalleryHome");
	var _this = this;
	
	//wire up elements here
};

com.art.myGalleries.modules.GalleryHome.prototype.destroy = function()
{
	//NOTE: Destroy is where you destroy this object and clean up memory
};

com.art.myGalleries.modules.GalleryHome.prototype.notify = function()
{
	//NOTE: 
	this.app.sendNotification(note);
};

com.art.myGalleries.modules.GalleryHome.prototype.listNotificationInterests = function()
{
	return [ this.app.events.STARTUP
	];
};

com.art.myGalleries.modules.GalleryHome.prototype.handleNotification = function(note)
{
	switch(note.name)
	{
		case this.app.events.STARTUP:
			//this.populateDetails(note.body);
			trace("json: "+note.body);
			break;
		default:
			trace("default case");
	}
};



com.art.myGalleries.modules.GalleryHome.prototype.getTemplate = function()
{
	//STEP: Get the raw string for the template
	var returnValue = this.template;
	//STEP: Replace the [IMAGE_DOMAIN] placeholder with the imagePath value
	returnValue = returnValue.replace(/\[IMAGE_DOMAIN\]/gi, this.imagePath);
	//STEP: Replace the [$MYGALLERY] placeholder with the MyGallery Header Title value
	returnValue = returnValue.replace(/\[$MYGALLERY\]/gi, this.imagePath);
	
	//STEP: Now return the string (template)
	return returnValue.replace('$NAME', this.NAME);
};

com.art.myGalleries.modules.GalleryHome.prototype.getTarget = function()
{
	return this.moduleData.target;
};

com.art.myGalleries.modules.GalleryHome.prototype.template = ""; //not needed markup coming from server


