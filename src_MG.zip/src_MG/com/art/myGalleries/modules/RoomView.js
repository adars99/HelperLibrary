//CONSTRUCTOR: instantiates the instance, Every Object must implement the base
com.art.myGalleries.modules.RoomView = function(data,app)
{
	this.app 			= app;
	this.moduleData 	= data;
	this.NAME			= com.art.myGalleries.modules.RoomView.NAME;
	this.instance		= this;
	this.DIMMED			= com.art.myGalleries.modules.RoomView.DIMMED;
	this.toolTipTimer;

};
com.art.myGalleries.modules.RoomView.NAME = "RoomView";
com.art.myGalleries.modules.RoomView.DIMMED = "RoomViewItemDimmed";
com.art.myGalleries.modules.RoomView.prototype.init = function (viewmode)
{
	//this is for visiting page
	var tmp = com.art.core.utils.BrowserUtil.getQueryString('viewmode');
	tmp = unescape(tmp);
	trace("RoomView tmp: "+tmp);
	var options = tmp.match(/roomView\/([0-9]+)(\/hex_([0-9A-Za-z]+))?/);
	trace(options);
	if(options!=null)
	{
		var b = tmp.indexOf('roomView')  > -1;
		var b2 = options[1] != undefined;
		this.app.getModel().isViewingSharedRoomView = b && b2;
		this.app.getUserLibraryProxy().sharedWallId = options[1] != undefined ? options[1] : "";
		this.app.getUserLibraryProxy().sharedEmptyRoomHexColor = options[3] != undefined ? options[3] : "";
		trace("this.app.getModel().isViewingSharedRoomView: "+this.app.getModel().isViewingSharedRoomView);
	}
	

	if(this.app.getModel().isViewingSharedRoomView)
	{
		trace("OPEN ROOMVIEW");
		$("#rightButton_dualOptionToggleButton").trigger("mouseup");
	}
};

com.art.myGalleries.modules.RoomView.prototype.destroy = function()
{
	//NOTE: Destroy is where you destroy this object and clean up memory
};

com.art.myGalleries.modules.RoomView.prototype.notify = function()
{
	//NOTE: 
	this.app.sendNotification(note);
};

com.art.myGalleries.modules.RoomView.prototype.listNotificationInterests = function()
{
	return [
	        this.app.events.STARTUP,
	        this.app.events.CHANGE_VIEWMODE,
	        this.app.events.GET_ALL_GALLERY_ITEMS_SUCCESS,
	        this.app.events.GET_ALL_GALLERY_ITEMS_FAILED,
	        this.app.events.GET_SYSTEM_LIBRARY_SUCCESS,
	        this.app.events.GET_SYSTEM_LIBRARY_FAILED,
	        this.app.events.UPDATE_DLE,
	        this.app.events.GET_WALLS_SUCCESS,
	        this.app.events.GET_WALL_BY_ID_SUCCESS,
	        this.app.events.UPDATE_WALL_ITEMS_SUCCESS,
	        this.app.events.INITIAL_LOAD,
	        this.app.events.CREATE_WALL_SUCCESS,
	        this.app.events.GET_USER_LIBRARY_SUCCESS,
	        this.app.events.ADD_BARE_WALLS_SUCCESS,
	        this.app.events.UPDATE_BARE_WALL_SUCCESS,
	        this.app.events.UPDATE_BARE_WALL_ERROR,
	        this.app.events.ROOM_VIEW_SWF_LOADED,
	        this.app.events.GET_USER_LIBRARY_BY_PROFILE_SUCCESS
	];
};

com.art.myGalleries.modules.RoomView.prototype.handleNotification = function(note)
{
	var _this = this;
	switch(note.name)
	{
		case this.app.events.STARTUP:
			//this.populateDetails(note.body);
			trace("json: "+note.body);
			break;
		case this.app.events.CHANGE_VIEWMODE:
			
			//remove tooltip
			$("#naTT").remove();
			
			trace("RoomViewModule viewmode: "+note.body.module);
			var _this = this;
			if(note.body.module == this.app.constants.ROOM_VIEW)
			{
				//for detailView page show share btn
				var u = location.href;
				if(u.indexOf("/item/") > -1)
					$("#share").show();
				
				//ignore if shared mode
				this.app.getModel().restorePreviousVisit = (this.app.getUserLibraryProxy().selectedWallObject != undefined) && !this.app.getModel().isViewingSharedRoomView;
				trace("RoomView this.app.getModel().restorePreviousVisit: "+ this.app.getModel().restorePreviousVisit);
					
				this.app.sendNotification(new com.art.core.utils.Note(this.app.events.UPDATE_BACKGROUND_COLOR, "#FFFFFF"));
				this.app.getModel().updateFromDLE = false; //reset to false
				this.app.getUserLibraryProxy().initialLoadComplete = false; //reset
				this.app.getModel().dleIsLoaded 		= false;
				this.app.getModel().galleryItemsLoaded = false;
				this.app.getModel().toggleDisplay = $(this.getTarget(note.body.page)).html();
				$(this.getTarget(note.body.page)).html(this.getTemplate());
				$(".topNavigationRight").hide();
				this.loadRoomSWF();
				$("rv").live("click",function(){
					$(_this.getTarget()).html(_this.getTemplate());
				});
				if(this.app.getModel().isViewingSharedRoomView)
				{
					this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_WALL_BY_ID));
				}
				else
				{
					if(this.app.getModel().restorePreviousVisit)
						this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_USER_LIBRARY_SUCCESS));
					else
						this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_WALLS));
				}
			}
				
			break;
		case this.app.events.UPDATE_WALL_ITEMS_SUCCESS:
			com.art.core.utils.Flash.getMovie("roomViewFlashTarget").stopCursor();
			break;
		case this.app.events.GET_WALL_BY_ID_SUCCESS:
			//same as get walls
		case this.app.events.GET_WALLS_SUCCESS:
			trace("getWallsSuccess RoomView "+this.app.getModel().updateFromDLE);
			//skip if user moves images in DLE
			if(!this.app.getModel().updateFromDLE)
			{
				this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_SYSTEM_LIBRARY));
			}
			else
				this.app.events.updateFromDLE = false;
			break;
		case this.app.events.GET_SYSTEM_LIBRARY_SUCCESS:
			this.app.getModel().requestForAllItemsFromSlideShow = false;
			this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_ALL_GALLERY_ITEMS,{module:this.app.constants.ROOM_VIEW}));
			break;
		case this.app.events.ROOM_VIEW_SWF_LOADED:
			//now start the swf all services are loaded
			setTimeout(function(){
				try{
					com.art.core.utils.Flash.getMovie("roomViewFlashTarget").startApplication();
				}catch(e){}
			},250);
			
			//now enable checkboxes on right
			setTimeout(function(){
				trace("enable checkbox");
				for(var cb in _this.app.getUserLibraryProxy().checkBoxMap)
				{
					_this.app.getUserLibraryProxy().checkBoxMap[cb].enable(true);
				}
				
				//let's make sure all items are visible on right
				//_this.app.getUserLibraryProxy().RHVerticalTray.data('jsp').reinitialise();
			},500);
			
			
			trace("RoomView isViewingSharedRoomView: "+this.app.getModel().isViewingSharedRoomView);
			if(!this.app.getModel().isViewingSharedRoomView)
			{
				trace("this.app.getModel().LOGGED_IN: "+this.app.getModel().LOGGED_IN);
				if(this.app.getModel().restorePreviousVisit || this.app.getUserLibraryProxy().lastUpdatedWallObject != undefined)
					this.showSelectedRoom();
				//Anonymous users will have Permission == 200, must check account Type
//				if(this.app.getModel().environment.accountType == this.app.getModel().LOGGED_IN)
//				{
//					setTimeout(function(){
//						trace("setLoggedIn()");
//						try{
//							com.art.core.utils.Flash.getMovie("roomViewFlashTarget").setLoggedIn();
//						}catch(e){}
//					},1000);
//				}
					
			}
			else
			{
				this.showSelectedRoom();
				
				
			}
			
			//Anonymous users will have Permission == 200, must check account Type
			if(this.app.getModel().environment.accountType == this.app.getModel().LOGGED_IN)
			{
				setTimeout(function(){
					trace("setLoggedIn()");
					try{
						com.art.core.utils.Flash.getMovie("roomViewFlashTarget").setLoggedIn();
					}catch(e){}
				},1000);
			}
			break;
		case this.app.events.GET_ALL_GALLERY_ITEMS_SUCCESS:
			//ignore if coming from slideshow
			//if(this.app.getModel().requestForAllItemsFromSlideShow)
				//return;
			
			var vm = com.art.core.utils.BrowserUtil.getQueryString('viewmode');
			var isGridView = (vm == this.app.constants.GRID_VIEW || vm == this.app.constants.SLIDESHOW);
			if(this.app.getModel().isViewingSharedRoomView || isGridView)
				this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_USER_LIBRARY_BY_PROFILE));
			else
			{
				if(this.app.getModel().hasWritePermissions())
					this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_USER_LIBRARY));
				else
					this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_USER_LIBRARY_SUCCESS));//skip loading user barewalls; we wont share unless isViewingSharedRoomView==true
			}
			break;
		case this.app.events.GET_USER_LIBRARY_BY_PROFILE_SUCCESS:
		case this.app.events.GET_USER_LIBRARY_SUCCESS:
			trace("RoomView.getUserLibrarySuccess");
			_this.app.getUserLibraryProxy().RHVerticalTray = $("#tray");
			_this.app.getUserLibraryProxy().RHVerticalTray.jScrollPane({showArrows:true,autoReinitialise:true});
			this.items = []; //reset
			for(var i=0; i < this.app.getModel().getGalleryItemList().length;i++)
			{
				var galleryItem = this.app.getModel().getGalleryItemList()[i];
				if(galleryItem.ItemDetails != null && galleryItem.ItemDetails.ImageInformation.CroppedSquareImage.HttpImageURL != null)
				{
					var canViewInRoom = galleryItem.CanViewonWall;
					var thumbURL = galleryItem.ItemDetails.ImageInformation.CroppedSquareImage.HttpImageURL.replace("mode=sq&","");
					if(canViewInRoom)
					{
						this.app.getUserLibraryProxy().checkBoxMap['cb_'+i] = new com.art.core.components.CheckBox('cb_'+i,galleryItem,'Add to Room');
					}
					var uid = com.art.core.utils.StringUtil.generateUID();
					var markup = this.getGalleryItemTemplate(thumbURL,canViewInRoom,this.app.getUserLibraryProxy().checkBoxMap['cb_'+i],uid,i);
						
					if(_this.app.getUserLibraryProxy().RHVerticalTray.data('jsp')!=undefined)
					{						
						_this.app.getUserLibraryProxy().RHVerticalTray.data('jsp').getContentPane().append(markup);
					}
					
					$("#"+uid).addOuterGlow(2,2,.5);
						
					if(canViewInRoom)
					{
						$("#"+uid).live("click",function(){
							var index = $(this).attr('data');
							var cbi = "cb_"+index;
							trace("cb index: "+cbi);
							$("#"+cbi).trigger("mouseup");
						});
						this.app.getUserLibraryProxy().checkBoxMap['cb_'+i].registerEvents();
						this.app.getUserLibraryProxy().checkBoxMap['cb_'+i].enable(false); //disable until swf fully loads
						this.app.getUserLibraryProxy().checkBoxMap['cb_'+i].registerCallback(com.art.core.components.CheckBox.CHECKED,function(cb){
							if(cb.selected)
							{
								var obj = cb.value;
								//append positionInfo here only on first load
								trace("RoomView.checkbox checked");		
								
								
								if(_this.app.getUserLibraryProxy().wallItemExists(obj.ItemGalleryItemID,_this.app.getModel().hasWritePermissions()))
								{
									trace("wallItem exists");
									var pos = _this.app.getUserLibraryProxy().getPositionData(obj.ItemGalleryItemID, _this.app.getModel().hasWritePermissions());
									obj.positionData = pos;
								}
								else
								{
									trace("wallItem does not exist");
									//setup defaults for flash
									obj.positionData = {ProductCenterPositionY:-1,ProductCenterPositionX:-1,ProductTargetAreaPosX:-1,ProductTargetAreaPosY:-1};
								}
										
								_this.app.getUserLibraryProxy().countWallItem();
								mygalleriesGA.trackEventWithCategory("Room", "Add item to wall");
								com.art.core.utils.Flash.getMovie("roomViewFlashTarget").addItemToRoom(obj);
										
							}
							else
							{
								mygalleriesGA.trackEventWithCategory("Room", "Delete item from wall");
								_this.app.getUserLibraryProxy().getCheckBoxByItemGalleryItemID(cb.value.ItemGalleryItemID).value.initialLoad = false;
								_this.app.getUserLibraryProxy().removeWallItem(cb.value.ItemGalleryItemID,_this.app.getModel().hasWritePermissions());
								com.art.core.utils.Flash.getMovie("roomViewFlashTarget").removeImage(cb.value.ItemGalleryItemID);
								var items = _this.app.getUserLibraryProxy().getItemsForUpdate();
								_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.UPDATE_WALL_ITEMS,items));
							}
						});
					}
					else
					{
						//dim imagess that aren't available
						$("."+this.DIMMED).css("opacity",.6);
							
						//setup tooltip functionality
						this.registerNotAvailableToolTip();
					}
				}
			}
			setTimeout(function(){
				if(_this.app.getUserLibraryProxy().RHVerticalTray.data('jsp')!=undefined)
					{
						_this.app.getUserLibraryProxy().RHVerticalTray.data('jsp').getContentPane().append("<div style='height:20px;width:120px;'></div>");
					}
				trace("tray loaded dleIsLoaded:" + _this.app.getModel().dleIsLoaded);				
				_this.app.getModel().galleryItemsLoaded = true;
				if(_this.app.getModel().dleIsLoaded)
					_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.ROOM_VIEW_SWF_LOADED));
				//see MyGalleriesCore.swfReadyFromDLE if dleIsLoaded == false
				
			},250);
			break;
		case this.app.events.UPDATE_WALL_SUCCESS:
			trace("update wall success");
			break;
		case this.app.events.UPDATE_DLE:
			trace("update dle");
			var wallItemDetails = this.app.getUserLibraryProxy().getSelectedWallItems();
			com.art.core.utils.Flash.getMovie("roomViewFlashTarget").updateWallItems(wallItemDetails);
			break;
		case this.app.events.INITIAL_LOAD:
			trace("RoomView.initialLoad");
			this.loadSelectedWallItems();
			break;
		case this.app.events.CREATE_WALL_SUCCESS:
			trace("createWallSuccess");
			if(this.app.getUserLibraryProxy().totalItemsOnWall > 0)
			{	
				var items = this.app.getUserLibraryProxy().getItemsForUpdate();
				com.art.core.utils.Flash.getMovie("roomViewFlashTarget").updateImagePositions(items);
				this.app.sendNotification(new com.art.core.utils.Note(this.app.events.UPDATE_WALL_ITEMS,items));
			}
			else
			{
				//refresh list
				//no need to do this; we're now appending to list
				//this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_WALLS));
			}
			break;
		case this.app.events.ADD_BARE_WALLS_SUCCESS:
			//reset so we don't reload everything again
			//this.app.getUserLibraryProxy().initialLoadComplete = false;
			trace("RoomView ADD_BARE_WALLS_SUCCESS");
			//send user bareWalls to swf and stop spinner
			com.art.core.utils.Flash.getMovie("roomViewFlashTarget").setUserLibrary(this.app.getUserLibraryProxy().getUserBareWalls(),this.app.getModel().isViewingSharedRoomView);
			break;
		case this.app.events.UPDATE_BARE_WALL_SUCCESS:
			trace("RoomView UPDATE_BARE_WALL_SUCCESS");
			com.art.core.utils.Flash.getMovie("roomViewFlashTarget").updateBareWallSuccess('success');
			break;
		case this.app.events.UPDATE_BARE_WALL_ERROR:
			trace("RoomView UPDATE_BARE_WALL_ERROR");
			com.art.core.utils.Flash.getMovie("roomViewFlashTarget").updateBareWallError('error');
			break;
		default:
			trace("default case");
	}
};
//for shared room AND restoring previously viewed
com.art.myGalleries.modules.RoomView.prototype.showSelectedRoom = function()
{
	trace("RoomView.showSelectedRoom()");
	var _this = this;
	//select RoomCategory and thumbnail
	setTimeout(function(){
		
		var wallObject;
		if(_this.app.getModel().restorePreviousVisit && !_this.app.getModel().isViewingSharedRoomView)
		{
			wallObject = _this.app.getUserLibraryProxy().getSelectedWallObject();
		}
		else if(_this.app.getModel().isViewingSharedRoomView)
		{
			wallObject = _this.app.getUserLibraryProxy().getSelectedSharedWallObject();
		}
		else
		{
			//default, restore to lastUpdated
			wallObject = _this.app.getUserLibraryProxy().lastUpdatedWallObject;
		}
		if(wallObject == undefined)
			throw new Error("RoomView.showSelectedRoom failed! Required wallObject is undefined.");
		
		var gallery = _this.app.getUserLibraryProxy().getGalleryByWallId(wallObject);
		trace(gallery);
		
		var gid = gallery.GalleryId;
		var galleryName = gallery.Name;
		var hex;
		
		if(gallery.Name == "Roomsbysize")
		{
			if(_this.app.getModel().restorePreviousVisit || _this.app.getUserLibraryProxy().lastUpdatedWallObject)
			{
				var str = _this.app.getModel().restorePreviousVisit ? _this.app.getUserLibraryProxy().selectedWallName : _this.app.getUserLibraryProxy().lastUpdatedWallObject.WallDetails.Name;
				trace("_this.app.getUserLibraryProxy().selectedWallName: "+_this.app.getUserLibraryProxy().selectedWallName);
				trace("str: "+str);
				if(str.indexOf("hex") == -1)
				{
					//restoring from shared experience
					if(_this.app.getUserLibraryProxy().sharedEmptyRoomHexColor == undefined)
						throw new Error("selectedWallName is NOT hex color");
					else
						hex = _this.app.getUserLibraryProxy().sharedEmptyRoomHexColor;
				}
				else
				{
					var arr = str.match(/hex_([0-9A-Za-z]+)?/);
					hex = arr[1];
				}
			}
			else
			{
				hex = _this.app.getUserLibraryProxy().sharedEmptyRoomHexColor;
			}
			//var emptyRoomName = _this.app.getModel().restorePreviousVisit ? _this.app.getUserLibraryProxy().selectedWallGalleryName : _this.app.getUserLibraryProxy().wallsObject[0].WallDetails.Name;
			var emptyRoomName = _this.app.getModel().restorePreviousVisit ? _this.app.getUserLibraryProxy().selectedWallGalleryName : _this.app.getUserLibraryProxy().lastUpdatedWallObject.WallDetails.Name;
			galleryName = "Roomsbysize"+com.art.myGalleries.proxies.UserLibraryProxy.EMPTY_WALL_DELIMITER+emptyRoomName;
		}
		var galleryID = galleryName.indexOf("Roomsbysize") > -1 ? _this.app.getUserLibraryProxy().getEmptyRoomIdByName(galleryName) : gid;
		galleryID = galleryName.indexOf("Personal Bare Walls") > -1 ? "myWallsBrowseBtn" : galleryID;
		
		trace("hex: "+hex);
		var bareWallIndex = galleryName.indexOf("Roomsbysize") > -1 ? _this.app.getModel().getColorIndexByHex(hex) : _this.app.getUserLibraryProxy().selectedSharedBareWallIndex;
		trace("galleryID: "+galleryID);
		trace("galleryName: "+galleryName);
		trace("bareWallIndex: "+bareWallIndex);
		try{
			com.art.core.utils.Flash.getMovie("roomViewFlashTarget").selectCategory(galleryID,galleryName,bareWallIndex);
		}catch(e){}
		_this.loadSelectedWallItems();
	},1500); //let thumbs load and populate bottom tray
};
//display items saved for default wall ONLY if items are in righthand tray
com.art.myGalleries.modules.RoomView.prototype.loadSelectedWallItems = function()
{
	trace("loadSelectedWallItems");
	var items = this.app.getUserLibraryProxy().getFlattenedWallItems(this.app.getModel().isViewingSharedRoomView);
	var galleryItems = this.app.getModel().galleryItemList;
	for(var i=0; i < galleryItems.length; i++)
	{
		//populate for other walls
		if(items[galleryItems[i].ItemGalleryItemID] != undefined)
		{
			//only add if doesn't exist
			if(this.app.getUserLibraryProxy().wallItemsMap[galleryItems[i].ItemGalleryItemID] == undefined)
				this.app.getUserLibraryProxy().wallItemsMap[galleryItems[i].ItemGalleryItemID] = items[galleryItems[i].ItemGalleryItemID];
			
			trace('emulate click using toggle IE fix');
			this.app.getUserLibraryProxy().checkBoxMap['cb_'+i].value.initialLoad = true;
			this.app.getUserLibraryProxy().checkBoxMap['cb_'+i].toggle();
			//$("#cb_"+i).trigger("mouseup");
			this.app.getUserLibraryProxy().totalItemsOnWall++;
		}
	}
	trace("loadSelectedWallItems set to true");
	this.app.getUserLibraryProxy().initialLoadComplete = true;
};
com.art.myGalleries.modules.RoomView.prototype.registerNotAvailableToolTip = function()
{
	var _this = this;
	$("."+this.DIMMED).mouseover(function(e){
		clearTimeout(_this.toolTipTimer);
		var img = $(this);
		_this.toolTipTimer = setTimeout(function(){
			$("#naTT").remove();
			$('body').append("<div id='naTT' style='background-color:#FFFFFF;border:1px solid #666666;padding:20px;position:absolute;top:100px;left:100px;'>Room view is not available for this item.</div>");
			$("#naTT").css("top",img.offset().top+"px");
			$("#naTT").css("left",(img.offset().left + img.width())+"px");
			$("#naTT").css("opacity",0);
			$("#naTT").animate({opacity:1},500);
		},500);
	});
	$("."+this.DIMMED).mouseleave(function(e){
		$("#naTT").remove();
	});

};



com.art.myGalleries.modules.RoomView.prototype.getTemplate = function()
{
	trace("RoomView.getTemplate()");
	//STEP: Get the raw string for the template
	var returnValue = this.template;
	//STEP: Replace the [IMAGE_DOMAIN] placeholder with the imagePath value
	returnValue = returnValue.replace(/\[IMAGE_DOMAIN\]/gi, this.imagePath);
	//STEP: Replace the [$MYGALLERY] placeholder with the MyGallery Header Title value
	returnValue = returnValue.replace(/\[$MYGALLERY\]/gi, this.imagePath);
	
	//cross-browser height for righthand tray
	var k = $.browser.mozilla != undefined ? "mozilla" : $.browser.safari != undefined ? "safari" : "msie"; //$.browser.msie != "msie" ? "msie";
	var outerheights = {"mozilla":558,"safari":557,"msie":557};
	var innerheights = {"mozilla":558,"safari":557,"msie":557};
	returnValue = returnValue.replace("$OUTER_WIDTH",outerheights[k]).replace("$INNER_HEIGHT",innerheights[k]);
	
	//STEP: Now return the string (template)
	return returnValue; //.replace('$NAME', this.NAME);
};
com.art.myGalleries.modules.RoomView.prototype.getGalleryItemTemplate = function(thumbURL,canViewInRoomFlag,checkBoxObj,uid,checkboxIndex)
{
	var markup = "";
	
	if(canViewInRoomFlag)
	{
		var cbc = this.checkBoxTemplate.replace("$CB",checkBoxObj.render());
		markup = this.itemTemplate.replace("$URL",thumbURL).replace("FADE_CLASS","").replace("$CB_CONTAINER",cbc).replace("$UID", uid).replace("$INDEX",checkboxIndex);
	}
	else
	{
		var msg = '<div style="font-family:verdana,arial;font-size:11px;color:#999999;text-align:center;margin:0 auto;margin-right:15px;">Room View<br/>Not Available</div>';
		
		
		
		markup = this.itemTemplate.replace("$URL",thumbURL).replace("$FADE_CLASS",this.DIMMED).replace("$CB_CONTAINER",msg);
	}
	return markup;
};




com.art.myGalleries.modules.RoomView.prototype.loadRoomSWF = function()
{
	trace("loadRoomSWF called this.app.getModel().isViewingSharedRoomView:"+this.app.getModel().isViewingSharedRoomView);
	var xiSwfUrlStr = "playerProductInstall.swf";
	var flashvars = {};	
			
	flashvars.customer = '' +
		'<domain name=[DQ]art.com[DQ]/>'+
		'<brand>ART</brand>' +
		'<session id=[DQ]6675932430074C0C8409FD43B5F4F90B[DQ] />' +
		'<authToken></authToken>' +
		'<locale id=[DQ]en_US[DQ] />';
	
	flashvars.framedItems = '' + 
		'<item isPreFrame=[DQ]False[DQ] apNum=[DQ]336083[DQ] podConfigId=[DQ]0[DQ] imageId=[DQ]0[DQ] substrateId=[DQ][DQ] substrateName=[DQ]Art Print[DQ]>' +
			'<price>29.99</price>' +
			'<dimensions width=[DQ]39.5[DQ] height=[DQ]27.5[DQ] />' +
		'</item>' + 
'';

	flashvars.selectedItem = '' +
		'<selectedApNum>336083</selectedApNum>' +
		'<selectedPodConfigId>0</selectedPodConfigId>';
		
		
	flashvars.environment =
		'<dleRootUrl url=[DQ]http://dflecache.art.com[DQ]/>'+
		'<rooms url=[DQ]http://dflecache.art.com/xml/[DQ] configFile=[DQ]DFLERoomConfig.xml[DQ] imagesFile=[DQ]DFLERoomImages.xml[DQ]/>'+
		'<accountService>http://ws-account.art.com</accountService>'+
		'<frameService>http://ws-wfs.art.com/frameservice.asmx</frameService>' +
		'<apiKey>519BAAC8E607413CA1FC043C92D08AAD</apiKey>' +
		'<imageCacheRooms>http://cache1.allpostersimages.com/</imageCacheRooms>'+
		'<imageCacheCustom>http://cache2.artprintimages.com/</imageCacheCustom>';

	//dynamic JS members
	flashvars.JS_COMMAND 				= 'MyGalleriesCore';
	flashvars.JS_USER_LIBRARY_MODEL 	= 'MyGalleriesCore.getUserLibraryProxy()';
	flashvars.JS_MODEL 					= 'MyGalleriesCore.getModel()';
	flashvars.isViewingSharedRoomView	= this.app.getModel().isViewingSharedRoomView ? "true" : "false"; //block initial load of default images on startup
	flashvars.isRevisiting				=  this.app.getModel().restorePreviousVisit ? "true" : "false"; //block initial load different use case see Flex codebase ApplicationMediator
	flashvars.ImageAppServiceUrl		= this.app.getModel().environment.ImageAppServiceUrl;
	var params = {};
	/*
	params.quality = "high";
	params.bgcolor = "#ffffff";
	params.allowfullscreen = "false";
	*/
	params.allowScriptAccess  = "always";
	params.wmode = "transparent";
	
	var attributes = {};
	/*attributes.id = "DLE";
	attributes.name = "DLE";
	attributes.align = "top";*/
	
	var swfLocation = "";
	
	//swfobject.embedSWF(swfLocation, "dleSwf", "780", "625", swfVersionStr, xiSwfUrlStr, flashvars, params, attributes);
	//<!-- JavaScript enabled so display the flashContent div in case it is not replaced with a swf object. -->
	//swfobject.createCSS("#dleSwf", "display:block;text-align:left;");

//	var flashvars = {"notify":"VisualSearchCore.sendNotification",
//			"disable":this.app.events.DISABLE_UPLOAD_BUTTON,
//			"enable":this.app.events.ENABLE_UPLOAD_BUTTON,
//			"uploadComplete":this.app.events.UPLOAD_COMPLETE,
//			"uploadService":this.app.getEnvironment().imageAppServiceUrl,
//			"type":"file"
//			};
	var params = {"wmode":"transparent","AllowScriptAccess":"always"};
	var attributes = {};
	swfobject.embedSWF("/swfs/roomView-DLE.swf", "roomViewFlashTarget", "100%", "100%", "10", "www.art.com/swfs/expressInstall.swf",flashvars,params,attributes);
	//swfobject.embedSWF("pub/swfs/DLE.swf", "roomViewFlashTarget", "100%", "100%", "10", "www.art.com/swfs/expressInstall.swf",flashvars,params,attributes);


};

com.art.myGalleries.modules.RoomView.prototype.getTarget = function(key)
{
	var t = this.moduleData.targets[key];
	return t;
};

com.art.myGalleries.modules.RoomView.prototype.template =
	'<div style="float:left;width:630px; height:587px; #height:586px;">'+
		'<div id="roomViewFlashTarget"></div></div>'+
	'<div style="padding-top:10px;padding-left:10px;width:140px; #width:135px; height:$OUTER_HEIGHTpx;float:left;background-color:#f5f6f8;border-bottom:1px solid #aeaeae;">'+
		'<div style="width:115px; #width:105px; height:$INNER_HEIGHTpx;overflow:auto;" id="tray">'+
	'</div>'+
	'</div>'+
	'<div style="clear:both;"></div>'; //not needed markup coming from server

com.art.myGalleries.modules.RoomView.prototype.itemTemplate =
	'<div style="width:130px;#width:10px;margin-bottom:15px;">'+
		'<div style="margin-bottom:2px;text-align:center;">'+
			'<img id="$UID" src="$URL" class="$FADE_CLASS" border="0" data="$INDEX"/>'+
		'</div>'+
		'<div style="width:130px;#width:120px;">$CB_CONTAINER</div>'+
	'</div>';
com.art.myGalleries.modules.RoomView.prototype.checkBoxTemplate = '<div style="float:left;">$CB</div>'+
		'<div style="float:left;color:#666666;font-size:12px; font-family:arial, sans-serif;padding-top:2px;">&nbsp;&nbsp;Add to Room</div>'+
		'<div style="clear:both;"></div>';

