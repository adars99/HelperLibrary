//CONSTRUCTOR: instantiates the instance, Every Object must implement the base
/**
* ControlBarModule module class is used to call the different component.
* @class ControlBarModule
* @param data
* @param app
*/
com.art.myGalleries.modules.ControlBarModule = function (data, app) {
    this.app = app;
    this.moduleData = data;
    this.NAME = com.art.myGalleries.modules.ControlBarModule.NAME;
    this.instance = this;
    this.slideshowBtn;
    this.ssWM = 13;
    this.ssW = 58;
    this.ssH = 70;
    this.ssLB="";
    this.ss;
    this.modal;
    this.shareBtn;
    this.spinner;
    //block rapid clicking
    this.slideshowBtnTimeoutID;
};
com.art.myGalleries.modules.ControlBarModule.NAME = "ControlBarModule";


com.art.myGalleries.modules.ControlBarModule.prototype.init = function () {
	
    var _this = this;
    this.spinner = new com.art.core.components.Spinner('body');
		
    // TODO move to right place
    // This should get executed only for my galleries page.  
	$(".artlogo,.mnuArtStylesLink,.mnuSubjectsLink,.mnuArtistsLink,.mnuProductTypesLink,.mnuCollectionsLink,.headerMnuLink,.photosToArtMy").live("click", function () {
		var isMyGalpage=$('#dmyGalleriesPage').text();
		if(_this.app.getModel().environment.accountType == _this.app.constants.ANONYMOUS && isMyGalpage=="mygalleriespage"){
		_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.SHOW_LOGIN_OR_JOIN,"exitgaurdevent"));
		$('#dmyGalleriesPage').data('myGalMenuItemClickedHref',$(this).attr('href'));
		return false;
		}
    });
	
	
	$("#sharelogintext").live('click',function() {			 			 	
		 	var selectedGallery=_this.app.getModel().environment.selectedGalleryID;            			    
		    var mygalId=_this.app.getModel().cacheByGalleryList[selectedGallery].GalleryId;
		    trace(_this.app.getModel().cacheByGalleryList[selectedGallery]);
		    var cookieobject = new com.art.core.cookie.Cookie();    		    
	        cookieobject.setCookieDictionary('arts', 'sharemygalid', mygalId,'/', cookieobject.getCookieDomain('art'));
	       _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.SHOW_LOGINMODAL,_this.app.constants.LOGIN));
	});
	
	$("#shareEmail,#shareFacebook").live('mouseenter',function() {
		$(this).css('cursor','pointer');		
		$(this).css('color','#FFFFFF');		
	});	
	
	$("#shareEmail,#shareFacebook").live('mouseleave',function() {
		$(this).css('cursor','default');
		$(this).css('color','black');		
	});	
	
    //NOTE: Init is where you initialize the handlers for this module and any variables, etc instantiated object will need
   // var selectedGallery=this.app.getModel().getSelectedGallery();
	//var selectedGalleryPermission = selectedGallery.Permissions;
    
	var vm = com.art.core.utils.BrowserUtil.getQueryString('viewmode');
	if(this.app.getModel().environment.selectedGalleryID!=undefined && this.app.getModel().environment.selectedGalleryID!="")
    {
		if(this.app.getModel().cacheByGalleryList[this.app.getModel().environment.selectedGalleryID].ItemCount>0)
		{
			if(vm == this.app.constants.GRID_VIEW || vm == this.app.constants.SLIDESHOW)
			{   this.ssLB = new com.art.core.components.LightBox('mySlideShowLB', 'body', .8);
		    	this.ssLB.show(); //append to target
		    	this.spinner.show(this.ssLB.getLightBoxZIndex() + 1);
		    	this.app.getModel().requestForAllItemsFromSlideShow = true;
			    this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_ALL_GALLERY_ITEMS,{module: vm}));
			}
		}
	}
   
//    var cookieobject = new com.art.core.cookie.Cookie();        
//    var bgcolor=cookieobject.getCookieDictionary('ap','BGColor');
//
//    if(bgcolor!="" && bgcolor!=null)
//    	{
//    		$("#items").css("float", "left").css("background-color", bgcolor);	
//    	}
//	
    
    $(this.getTarget()).html(this.getTemplate());
    
    var gridTitle = 'Edit & Organize';
    if(this.app.getModel().environment.selectedGalleryID != undefined && this.app.getModel().environment.selectedGalleryID != "" && this.app.getModel().cacheByGalleryList[this.app.getModel().environment.selectedGalleryID].Permissions == 50)
    	gridTitle = 'Art Details';
    var dualOptionToggleButton = new com.art.core.components.DualOptionToggleButton('dualOptionToggleButton', gridTitle, 'View In Room', this.app.constants.GRID_VIEW, this.app.constants.ROOM_VIEW);
    trace("from module testing base class " + dualOptionToggleButton.testProp);

    dualOptionToggleButton.registerCallback(com.art.core.components.DualOptionToggleButton.CLICK, function (value) {
        trace("dualOptionToggle clicked: " + value);
        var qs = location.href;
        var page = qs.indexOf('item/') > -1 ? 'details' : 'grid';
        if (value == 'gridView')
            mygalleriesGA.trackEventWithCategory("Grid", "View grid");
        else if (value == 'roomView')
            mygalleriesGA.trackEventWithCategory("Room", "View room");
        
        _this.app.getModel().currentViewMode = value == "roomView" ? _this.app.constants.ROOM_VIEW : _this.app.constants.GRID_VIEW;
        if(_this.app.getModel().currentViewMode == _this.app.constants.GRID_VIEW )
        {
        	if(page == 'details')
        		_this.app.constants.DETAIL_VIEW;
        }
        _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.CHANGE_VIEWMODE, { module: value, page:page }, ''));
    });

    var slideShowBtn = new com.art.core.components.SingleOptionToggleButton('launchSSBtn', 'Slideshow', 'viewSlideShow', com.art.core.components.SingleOptionToggleButton.LIGHT);

    $("#MyGalleriesControlbarLeft").append(dualOptionToggleButton.render() + slideShowBtn.render());

    slideShowBtn.registerEvents();
    dualOptionToggleButton.registerEvents();
    if(this.app.getModel().environment.selectedGalleryID!=undefined && this.app.getModel().environment.selectedGalleryID!="")
    {
	if(this.app.getModel().cacheByGalleryList[this.app.getModel().environment.selectedGalleryID].ItemCount>0)
		{		
		    slideShowBtn.registerCallback(com.art.core.components.SingleOptionToggleButton.CLICK, function (value) {
		    	
			    	//prevent multi-clicks
			    	clearTimeout(_this.slideshowBtnTimeoutID);
			    	
			    	_this.slideshowBtnTimeoutID = setTimeout(function(){
			    		mygalleriesGA.trackEventWithCategory("Slideshow", "View Slideshow");
			        	//only show if items have not yet been loaded
			        	_this.ssLB = new com.art.core.components.LightBox('mySlideShowLB', 'body', .8);
			    	    _this.ssLB.show(); //append to target
			    	     
			    	    if(_this.app.getModel().getGalleryItemList().length == 0)
			        	{
			    	    	_this.app.getModel().requestForAllItemsFromSlideShow = true;
			        	    _this.spinner.show(_this.ssLB.getLightBoxZIndex() + 1);
			        	    _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.GET_ALL_GALLERY_ITEMS, { module: _this.app.constants.GRID_VIEW }));
			        	}
			    	    else
			    	    {
			    	    	_this.showSlideShow();
			    	    }
			    	},150);
			    	
			    });
      }
    }
    var backgroundWidth = 242;
    var backgroundHeight = 171;
    var backgroundLeft = -165;
    if ($.browser.msie) {
        var backgroundWidth = 275;
        var backgroundHeight = 171;
        var backgroundLeft = -202;
    }
    var background = new com.art.myGalleries.components.OptionButton('background', 'Background', this.getBackgroundBtnContent(), backgroundWidth, backgroundHeight, backgroundLeft);
    $("#MyGalleriesControlbarRight").append(background.render());
    background.registerEvents();

    background.registerCallback(com.art.myGalleries.components.OptionButton.COLOR_PICKER_CLICK, function (data) {
        var colorId = $(data).attr('id');
        var color = "#" + colorId.substring(4);
        _this.app.events.UPDATE_BACKGROUND_COLOR;
        $("#items").css("float", "left");
        
        _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.UPDATE_BACKGROUND_COLOR, color));
    });

    var sortby = new com.art.myGalleries.components.OptionButton('sortby', 'Sort By', this.getSortByBtnContent(), 220, 220, -146);
    $("#MyGalleriesControlbarRight").append(sortby.render());
    
   
    
    $('#img' + this.app.getModel().environment.galleryItemSort).addClass('imgSelected');
    $('#img' + this.app.getModel().environment.galleryItemSort).css("visibility", "visible");
    sortby.registerEvents();

    sortby.registerCallback(com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK, function (data) {
        var id = $(data).attr('id');
        trace("data:" + id);
        
        _this.app.getModel().environment.galleryItemSort = id;
        var cookieobject = new com.art.core.cookie.Cookie();        
        cookieobject.setCookieDictionary('arts', 'mygalitemsortby', _this.app.getModel().environment.galleryItemSort,'/', cookieobject.getCookieDomain('art'));
        
        var sortBy = "";
        var sortOrder = "";
        switch (id) {
            case 'newest':
                sortBy = com.art.core.services.GalleryAPIService.SORT_BY_DATE_ADDED;
                sortOrder = com.art.core.services.GalleryAPIService.SORT_DIRECTION_DESC;
                break;
            case 'oldest':
                sortBy = com.art.core.services.GalleryAPIService.SORT_BY_DATE_ADDED;
                sortOrder = com.art.core.services.GalleryAPIService.SORT_DIRECTION_ASC;
                break;
            case 'artistAZ':
                sortBy = com.art.core.services.GalleryAPIService.SORT_BY_ARTIST_NAME;
                sortOrder = com.art.core.services.GalleryAPIService.SORT_DIRECTION_ASC;
                break;
            case 'artistZA':
                sortBy = com.art.core.services.GalleryAPIService.SORT_BY_ARTIST_NAME;
                sortOrder = com.art.core.services.GalleryAPIService.SORT_DIRECTION_DESC;
                break;
            case 'priceLH':
                sortBy = com.art.core.services.GalleryAPIService.SORT_BY_PRICE;
                sortOrder = com.art.core.services.GalleryAPIService.SORT_DIRECTION_ASC;
                break;
            case 'priceHL':
                sortBy = com.art.core.services.GalleryAPIService.SORT_BY_PRICE;
                sortOrder = com.art.core.services.GalleryAPIService.SORT_DIRECTION_DESC;
                break;
            case 'artTitleAZ':
                sortBy = com.art.core.services.GalleryAPIService.SORT_BY_TITLE;
                sortOrder = com.art.core.services.GalleryAPIService.SORT_DIRECTION_ASC;
                break;
            case 'artTitleZA':
                sortBy = com.art.core.services.GalleryAPIService.SORT_BY_TITLE;
                sortOrder = com.art.core.services.GalleryAPIService.SORT_DIRECTION_DESC;
                break;
            default:
                trace("others");
        }
        _this.app.getModel().getAllItemsFlag = false;
        var note = new com.art.core.utils.Note(_this.app.events.GALLERY_ITEM_SORT, { sortBy: sortBy, sortOrder: sortOrder }, "");
        trace("note:");

        _this.app.sendNotification(note);
    });

//    var selectedGalleryPermission;
//    var selectedGallery;
//     	 
// 	if(this.app.getModel().getSelectedGallery()!="" &&  this.app.getModel().getSelectedGallery()!=null)
// 		{
// 			selectedGallery=this.app.getModel().getSelectedGallery();
// 			selectedGalleryPermission = selectedGallery.Permissions;
// 		}
// 	else
// 		{
// 			selectedGalleryPermission=0; 
// 		} 	 	
 	if(this.app.getModel().hasWritePermissions())
 	{
 		var privateBtn = new com.art.myGalleries.components.OptionButton('privacy', 'Privacy', this.getPrivateBtnContent(), 220, 70, -146,this.app.getModel().hasWritePermissions());
 		$("#MyGalleriesControlbarRight").append(privateBtn.render()); 		 		
 		
 	//	$('#img'+ this.app.getModel().environment.galleryItemPrivacy).addClass('imgSelected');
 	//    $('#img' + this.app.getModel().environment.galleryItemPrivacy).css("visibility", "visible");
 		privateBtn.registerEvents();

 		privateBtn.registerCallback(com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK, function (data) {
 			var id = $(data).attr('id');
 	        _this.app.getModel().environment.galleryItemPrivacy = id.charAt(0).toUpperCase() + id.slice(1);
 	       
 	        var cookieobject = new com.art.core.cookie.Cookie();        
 	        cookieobject.setCookieDictionary('arts', 'mygalitemprivacy', _this.app.getModel().environment.galleryItemPrivacy,'/', cookieobject.getCookieDomain('art'));
 	        
 			mygalleriesGA.trackEventWithCategory("Grid", "Privacy - select");
 			
 			switch (id) {
 			case 'everyone':  
 				if(_this.app.getModel().environment.accountType != _this.app.constants.ANONYMOUS){
 					_this.setPrivacySettings();
 					var galleryObj=_this.app.getModel().getSelectedGallery();
 					galleryObj.Name = escape(galleryObj.Name);                
 					galleryObj.LongDescription =  escape(galleryObj.LongDescription);     
 		        	
 					 galleryObj.GalleryIconURL="";
                     galleryObj.IconUrl="";
                     galleryObj.Icon = null;
 					_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.UPDATE_PRIVACY_SETTINGS, galleryObj));
 				}
                break;
 			case 'inviteFriend':             
            	if(_this.app.getModel().environment.accountType == _this.app.constants.ANONYMOUS){		            	            	
            		_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.SHOW_LOGIN_OR_JOIN, "inviteFriend"));
            	}
            	if(_this.app.getModel().environment.accountType != _this.app.constants.ANONYMOUS){
               _this.setPrivacySettings();
                
                var galleryObj=_this.app.getModel().getSelectedGallery();
                
                galleryObj.Name = escape(galleryObj.Name);                
				galleryObj.LongDescription =  escape(galleryObj.LongDescription);     
		        	
                galleryObj.GalleryIconURL="";
                galleryObj.IconUrl="";
                galleryObj.Icon = null;
                trace(galleryObj);
               _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.UPDATE_PRIVACY_SETTINGS, galleryObj));               
               	    $("#imgEveryone").css("visibility", "hidden");
               	    $("#imgEveryone").removeClass('imgSelected');
                    $(".imgPrivacyTick").removeClass('imgSelected');
                    $("#imgInviteFriend").css("visibility", "visible");
                    $("#imgInviteFriend").addClass('imgSelected');                		
            	}
                break;
            default:
                trace("others");
 			}
 		});
 	}
     
    this.shareBtn = new com.art.myGalleries.components.OptionButton('share', 'Share', this.getShareBtnContent(), 220, 80, -146, this.app.getModel().hasWritePermissions());
    
    $("#MyGalleriesControlbarRight").append(this.shareBtn.render());
    this.shareBtn.registerEvents();    
    
    this.shareBtn.registerCallback(com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK, function (data) {
       _this.app.getModel().shareType = $(data).attr('id') == "shareEmail" ? _this.app.constants.EMAIL : _this.app.constants.FACEBOOK;
            	
       //var productURL = window.location.href;
       var url = window.location.href+"?viewmode="+_this.app.getModel().currentViewMode;
       var selectedGallery=_this.app.getModel().environment.selectedGalleryID;            	
       var imageURL = _this.app.getModel().cacheByGalleryList[selectedGallery].GalleryIconURL;
       var title=_this.app.getModel().cacheByGalleryList[selectedGallery].Name;
       var itemCount=_this.app.getModel().cacheByGalleryList[selectedGallery].ItemCount;
       var cat = _this.app.getModel().currentViewMode == MyGalleriesCore.constants.GRID_VIEW ? "Grid" : "Room";
       var evt = _this.app.getModel().shareType == _this.app.constants.EMAIL ? "Share via email - click" : "Share via Facebook - click";

       mygalleriesGA.trackEventWithCategory(cat, evt);
       
       trace("viewMode");
       trace(_this.app.getModel().currentViewMode);
       if(_this.app.getModel().currentViewMode == _this.app.constants.ROOM_VIEW)
       {
    	   _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.SHARE_WALL));
       }
       else
       {   
    	   var srvo = new com.art.myGalleries.vos.ShareRequestVO(_this.app.getModel().currentViewMode,_this.app.getModel().shareType,title,imageURL,url,itemCount);
    	   
    	   trace(srvo);
    	   _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.SHARE_REQUEST,srvo));
       }
    });
        
    this.disableEventsForShare();
    
    // Shared Mode Disabling the  share by icon and privacy
    
    if(_this.app.getModel().environment.selectedGalleryID != undefined && _this.app.getModel().environment.selectedGalleryID != "" && _this.app.getModel().cacheByGalleryList[_this.app.getModel().environment.selectedGalleryID].Permissions < _this.app.constants.EDIT)
    {
    	trace("disable share control bar");
    	$("#share").hide();
        $("#privacy").hide();
    }
    
    $('#imgEveryone').addClass('imgSelected');	   
    
    // this takes of onload setting public , private image.
    if(_this.app.getModel().getSelectedGallery()!=undefined && _this.app.getModel().getSelectedGallery().GalleryVisibility=="3"){
 		
    	this.shareBtn.enabled(false);   
    	$('#share').attr('title','You cannot share a private gallery');
    	$('.share_icon').css('cursor','default');
    	trace("executing gallery");
 		$("#imgEveryone").css("visibility", "hidden"); // public
 		$("#imgInviteFriend").css("visibility", "visible"); // private 		
 		$('#imgInviteFriend').addClass('imgSelected');
 		$('#imgEveryone').removeClass('imgSelected'); 	 
	}	
    
    // we should hide the control bar when there are no galleries , we are showing a landing
    // page from CMS at this condition.
    var showControlBar=$("#dgalleryItemsExist").text();
    trace("showControlBar"+showControlBar);
    if(showControlBar.length>0){
    	if(showControlBar=="False"){
    		$('#controlBar').hide();
    	}
    }
};

/**
* Used this method to call the lightbox and slideshow component.
* @method showSlideShow
*/
com.art.myGalleries.modules.ControlBarModule.prototype.showSlideShow = function () {
	
    var _this = this;
    trace("show lightbox-component");

    var ssWidth, modalWidth, ssHeight;

    if (typeof window.innerWidth != 'undefined') {
        modalWidth = window.innerWidth - this.ssWM;
        ssWidth = window.innerWidth - this.ssW;
        ssHeight = window.innerHeight - this.ssH;
    }
    else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
        //IE 6+ in 'standards compliant mode' 
        modalWidth = document.documentElement.clientWidth - this.ssWM;
        ssWidth = document.documentElement.clientWidth - this.ssW;
        ssHeight = document.documentElement.clientHeight - this.ssH;
    }


    var images = this.app.getModel().getGalleryListForSlideShow(ssWidth, ssHeight, com.art.core.utils.BrowserUtil.cropperModes.NONE);
    
		this.ss = new com.art.core.components.SlideShow("mySlideShow", ssWidth, ssHeight, images);
	    this.modal = new com.art.core.components.BaseModal("myModalSlideShow", modalWidth, "", false, true);
	    this.modal.setContents(this.ss.render());
	    this.ssLB = new com.art.core.components.LightBox('mySlideShowLB', 'body', .8);
	    this.ssLB.show(); //append to target
	    $("body").append(this.modal.render(this.ssLB.getLightBoxZIndex() + 1));
	    this.modal.registerEvents();
	    this.modal.removeCloseButton();
	    var _this = this;
	    this.modal.registerCallback(com.art.core.components.BaseModal.BODY_CLICKED, function () {
	        _this.ssLB.close();
	        _this.ss.close();
	        _this.modal.close();
	    });
	    this.ss.registerCallback(com.art.core.components.SlideShow.ADD_TO_CART_CLICKED, function () {
	    	mygalleriesGA.trackEventWithCategory("Slideshow", "Add to cart");
	    	
	    	var imageIndex=_this.ss.getCurrentImageIndex();    	
			var data = _this.app.getModel().getGalleryItemList()[imageIndex];
	    	_this.app.getModel().setSelectedGridItem(data.ItemGalleryItemID);
	    	
	    	//var data = _this.app.getModel().cacheByGalleryItemList[_this.id];
	    	var sessionId = _this.app.getModel().environment.sessionId;
	    		
	    	var props = {ItemId:data.ItemId,
	    				 frameConfigurationId:data.FrameSku,
	    			     artSku:data.ItemDetails.Sku,
	    			     podconfigid:data.PODConfigID,
	    			     apnum:data.APNum
	    			};
	    	
	    	if(props.frameConfigurationId != null && props.frameConfigurationId.trim().length > 0)
	    		_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.GET_FRAME_ID,props));
	    	else
	    	{
	    		window.location.href = com.art.core.utils.BusinessUtil.getSimpleAddToCartUrl(data.ItemDetails.Sku,data.PODConfigID, data.SpecialHandlingID, sessionId);
	    	}
	    });
	    this.ss.registerCallback(com.art.core.components.SlideShow.CLOSE_BUTTON_CLICKED, function () {
	        trace("close button clicked");
	        _this.ssLB.close();
	        _this.ss.close();
	        _this.modal.close();
	    });
	    
	    this.ss.registerCallback(com.art.core.components.SlideShow.ESC_KEY_CLICKED, function () {
	        trace("esc key clicked");
	        _this.ssLB.close();
	        _this.ss.close();
	        _this.modal.close();
	    });
	
	    this.ss.registerEvents();
	//    this.shareBtn = new com.art.myGalleries.components.OptionButton('SlideShowShare', 'Share', this.getShareBtnContent(), 220, 70, 0);
	//    this.ss.attachExternalComponent(this.shareBtn.render());
	//    this.shareBtn.registerEvents();
	    this.ss.start();
	//
	//    this.shareBtn.registerCallback(com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK, function (data) {
	//    	
	//      var id = $(data).attr('id');
	//        switch (id) {
	//            case 'shareEmail':         
	//            	
	//            	 _this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.SHARE_REQUEST,new com.art.myGalleries.vos.ShareRequestVO(_this.app.constants.SLIDESHOW,_this.app.constants.EMAIL,"title",'ImageURL','50')));            	
	//                //$("#imgEveryone").css("visibility", "visible");
	//                //$("#imgInviteFriend").css("visibility", "hidden");
	//                break;
	//            case 'shareFacebook':
	//            	
	//               // $("#imgEveryone").css("visibility", "hidden");
	//               // $("#imgInviteFriend").css("visibility", "visible");
	//                break;
	//            default:
	//                trace("others");
	//        }
	//    });
	//    
	//    $("#" + this.shareBtn.id).live('click', function () {
	//    	
	//	    $("#" + _this.shareBtn.id + "_toggle").css("position", "absolute");
	//	    $("#" + _this.shareBtn.id + "_transparent").css("position", "absolute");
	//	    $("#" + _this.shareBtn.id + "_transparent").css("top", "-6px");
	//	    $("#" + _this.shareBtn.id + "_toggle").css("top", "-72px");
	//	    if ($.browser.msie) {
	//	        $("#" + _this.shareBtn.id + "_toggle").css("left", "-40px");
	//	    }
	//	    $("#" + _this.shareBtn.id + "_toggle").show();    
	//    });
	//
	//    $("#" + this.shareBtn.id).live('mouseleave', function () {
	//        $("#" + _this.shareBtn.id).removeClass("SlideShowShareBtn");
	//        $("#" + _this.shareBtn.id + "_toggle").hide();
	//    });
	//
	//    $("#" + this.shareBtn.id).live('mouseenter', function () {
	//        $("#" + _this.shareBtn.id).addClass("SlideShowShareBtn");
	//    });
   
};

com.art.myGalleries.modules.ControlBarModule.prototype.listNotificationInterests = function () {
    return [this.app.events.STARTUP,
            this.app.events.GALLERY_ITEM_LIST_REQUEST,
	        this.app.events.GALLERY_ITEM_LIST_REQUEST_SUCCESS,
            this.app.events.GALLERY_ITEM_LIST_REQUEST_FAILED,
            this.app.events.GALLERY_ITEM_SORT_SUCCESS,
            this.app.events.GALLERY_ITEM_SORT_FAILED,
            this.app.events.GALLERY_ITEM_SORT,
            this.app.events.GET_ALL_GALLERY_ITEMS_SUCCESS,
            this.app.events.CHANGE_VIEWMODE,
            this.app.events.SHARE_REQUEST,
            this.app.events.GET_FRAME_ID_SUCCESS,
            this.app.events.GET_FRAME_ID_FAILED
	        ];
};

com.art.myGalleries.modules.ControlBarModule.prototype.handleNotification = function (note) {
    var _this = this;
    switch (note.name) {
        case this.app.events.CHANGE_VIEWMODE:
            var display = note.body.module == this.app.constants.ROOM_VIEW ? "none" : "block";
            $("#background").css("display", display);
            $("#sortby").css("display", display);
            $("#privacy").css("display", display);
            break;
        case this.app.events.GET_ALL_GALLERY_ITEMS_SUCCESS:
        	var viewMode = com.art.core.utils.BrowserUtil.getQueryString('viewmode');
        	if(viewMode == this.app.constants.GRID_VIEW || viewMode == this.app.constants.SLIDESHOW)
        	{  
            	this.ssLB.close();
        	}
            if (note.body.module == this.app.constants.GRID_VIEW) {            	
            	mygalleriesGA.trackEventWithCategory("Slideshow", "View Slideshow");            	
            	this.spinner.hide();
                this.showSlideShow();
            }
            
            break;
        case this.app.events.GALLERY_ITEM_LIST_REQUEST_FAILED:
            trace("GALLERY_ITEM_LIST_REQUEST_FAILED");

            //this.slideshowComp.appendImages(this.app.getModel().getImages() );
            //ss.appendImages
            break;
        case this.app.events.GALLERY_ITEM_SORT_SUCCESS:            
            trace("Res:" + note.body.galleries);
            break;
        case this.app.events.GET_FRAME_ID_SUCCESS:
        	//adding here becuase common module
        	var frameid = note.body.frameid;
        	var sessionID = this.app.getModel().environment.sessionId;
        	location.href = com.art.core.utils.BusinessUtil.getFramedItemAddToCartUrl(frameid, note.body.apNum, sessionID);
        	break;
        case this.app.events.GET_FRAME_ID_FAILED:
        	location.href = com.art.core.utils.BusinessUtil.getSimpleAddToCartUrl("","");
        	break;
    }
};

com.art.myGalleries.modules.ControlBarModule.prototype.destroy = function () {
    //NOTE: Destroy is where you destroy this object and clean up memory
};

com.art.myGalleries.modules.ControlBarModule.prototype.notify = function () {
    //NOTE: 
    this.app.sendNotification(note);
};

com.art.myGalleries.modules.ControlBarModule.prototype.setPrivacySettings = function () {
	 var shared=this.app.getModel().getSelectedGallery().GalleryVisibility;
	  if(shared==3){
		  shared=1;
		    this.app.getModel().setSelectedGalleryPrivacy(shared);
		    return;
	  }
	  if(shared==1){
   	  shared=3;
		   	this.app.getModel().setSelectedGalleryPrivacy(shared);
		    return;
	  }	      
};

//story 122 changes
com.art.myGalleries.modules.ControlBarModule.prototype.disableEventsForShare = function () {
	if (this.app.getModel().environment.accountType == this.app.constants.ANONYMOUS) {
		var opacity = 0.25;
		$("#shareEmail").css('opacity', opacity);
		$("#shareFacebook").css('opacity', opacity);
		$("#share_toggle li").unbind("live");
		$("#share_toggle li").unbind("click");
		$("#share_toggle li").unbind("mouseenter");
		$("#share_toggle li").unbind("mouseleave");
		$("#share_toggle li").die();
		$("#share_toggle .dropDownText").unbind("live");
		$("#share_toggle .dropDownText").unbind("click");
		$("#share_toggle li").unbind("mouseenter");
		$("#share_toggle li").unbind("mouseleave");		
		$("#shareEmail,#shareFacebook").unbind("mouseenter");
		$("#shareEmail,#shareFacebook").unbind("mouseleave");
		$("#shareEmail,#shareFacebook").die();		
		$("#share_toggle .dropDownText").die();
	} 
	else {
		$(".lsharelogintext").hide();
		$("#share_toggle").css("height","70px");		
	}
};

/**
* Used this method to get the Sort by menu HTML on right nav. control bar.  
* @method getSortByBtnContent
*/
com.art.myGalleries.modules.ControlBarModule.prototype.getSortByBtnContent = function () {
    return [
	        '<ul id="navSortBy" class="nav">' +
                '<li><span class="imgTick" id="imgnewest"/><span id="newest" class="dropDownText">Date saved, newest</span></li>' +
                '<li><span class="imgTick" id="imgoldest"/><span href="#" id="oldest" class="dropDownText">Date saved, oldest</span></li>' +
	        	'<li><span class="imgTick" id="imgartistAZ"/><span href="#" id="artistAZ" class="dropDownText">Artist, A-Z</span></li>' +
                '<li><span class="imgTick" id="imgartistZA"/><span href="#" id="artistZA" class="dropDownText">Artist, Z-A</span></li>' +
	        	'<li><span class="imgTick" id="imgpriceLH"/><span href="#" id="priceLH" class="dropDownText">Price, lowest</span></li>' +
                '<li><span class="imgTick" id="imgpriceHL"/><span href="#" id="priceHL" class="dropDownText">Price, highest</span></li>' +
                '<li><span class="imgTick" id="imgartTitleAZ"/><span href="#" id="artTitleAZ" class="dropDownText">Title, A-Z</span></li>' +
                '<li><span class="imgTick" id="imgartTitleZA"/><span href="#" id="artTitleZA" class="dropDownText">Title, Z-A</span></li>' +
	        '</ul>'
	];
};

/**
* Used this method to select the color from color picker and change the background color accordingly. 
* @method getBackgroundBtnContent
*/
com.art.myGalleries.modules.ControlBarModule.prototype.getBackgroundBtnContent = function () {
    var colorMap = this.app.getModel().getBackgroundColors();
    var str = "", positionCount = "";
    for (var i = 0; i < colorMap.length; i++ ) {
        positionCount = -33 * i + "px 0px";
        str += "<li id='hex_" + colorMap[i] + "'  style='background-position:" + positionCount + "'><a href='#'></a></li>";
    }
    return [    
    '<div id="colorPicker">' +
    '<ul id="Myiconmenu">' + str + '</ul' +
    '</div>'    
	];
};

/**
* Used this method to get privacy menu HTML on right nav. control bar.
* @method getPrivateBtnContent
*/
com.art.myGalleries.modules.ControlBarModule.prototype.getPrivateBtnContent = function () {
    return [
	        '<ul id="navPrivacy" class="nav">' +
	        	'<li><span id="imgEveryone" class="imgPrivacyTick" style="visibility:visible" /><span id="everyone" class="dropDownText">Public: anyone can view</span></li>' +
	        	'<li><span id="imgInviteFriend" class="imgPrivacyTick" /><span id="inviteFriend" class="dropDownText">Private: only I can view</span></li>' +
	        '</ul>'
	];
};

/**
* Used this method to get share by menu HTML on right nav. control bar.
* @method getShareBtnContent
*/

com.art.myGalleries.modules.ControlBarModule.prototype.getShareBtnContent = function() {
	return [ '<ul id="navShare" class="nav">'+ 
	         '<li><div class="lsharelogintext"><span class="imgBulb"/><span id="sharelogintext">Please Login to Share</span></div></li>'+ 
	         '<li><span id="shareEmail" class="dropDownText">Share via Email</span></li>'+			 
			 '<li><span id="shareFacebook" class="addthis_toolbox addthis_default_style dropDownText"><a class="addthis_button_facebook">Share via Facebook</a></span></li>'+ 
			 '</ul>' ];
};

/**
* Used this method to get SlideShow button on left navigation bar.
* @method getViewModeBtnContent
*/
com.art.myGalleries.modules.ControlBarModule.prototype.getViewModeBtnContent = function () {
    return [
            '<ul id="leftNavBtn">' +	        	
                '<li id="slideShowView"><a href="#" id="leftMenuItem3" /></li>' +
	        '</ul>'
	];
};


/**
* Call this method on the render of javascript page load
* @method getTemplate
*/
com.art.myGalleries.modules.ControlBarModule.prototype.getTemplate = function () {
    //STEP: Get the raw string for the template
    var returnValue = this.template;
    //STEP: Replace the [IMAGE_DOMAIN] placeholder with the imagePath value
    returnValue = returnValue.replace(/\[IMAGE_DOMAIN\]/gi, this.imagePath);
    //STEP: Now return the string (template)
    return returnValue.replace('$NAME', this.NAME);
};


com.art.myGalleries.modules.ControlBarModule.prototype.getTarget = function () {
    return this.moduleData.target;
};

com.art.myGalleries.modules.ControlBarModule.prototype.template
= "<div id='$NAME'>"
+ "<div id='MyGalleriesControlbarLeft' class='MyGalleriesControlbarLeft floatLeft'></div>"
+ "<div id='MyGalleriesControlbarRight' class='MyGalleriesControlbarRight'></div>"
+ "<div class='clear'></div>"
+ "</div>";
