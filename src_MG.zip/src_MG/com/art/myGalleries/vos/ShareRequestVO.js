com.art.myGalleries.vos.ShareRequestVO = function(viewMode,shareType,title,imageURL,productURL,additionalArgs)
{	
	this.viewMode = viewMode;
	this.shareType = shareType;
	this.title = title;
	this.imageURL = imageURL;	
	this.galleryURL =productURL;
	this.additionalArgs = additionalArgs;
};