com.art.myGalleries.vos.WallItemVO = function(id,x,y,tx,ty)
{
	this.Item 					= {ItemGalleryItemID:id};
	this.ProductCenterPositionX = x;
	this.ProductCenterPositionY	= y;
	this.ProductTargetAreaPosX	= tx;
	this.ProductTargetAreaPosY	= ty;
};