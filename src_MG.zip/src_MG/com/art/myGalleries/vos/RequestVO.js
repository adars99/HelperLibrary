com.art.myGalleries.vos.RequestVO = function(obj)
{
	this.properties = obj;
	this.NAME 		= com.art.myGalleries.vos.RequestVO.NAME;
	this.sessionid 	= false;
	this.authToken	= false;
	this.apiKey 	= false;
	this.accountid	= false;
	this.pageNumber = -1;
};
com.art.myGalleries.vos.RequestVO.NAME = "RequestVO";
/**
 * 
 * @param sessionid
 * @param authToken
 * @param apiKey
 * 
 * TEMPORARY!
 */
com.art.myGalleries.vos.RequestVO.prototype.init = function(sessionid,authToken,apiKey,pageNumber)
{
	this.pageNumber = pageNumber;
};
