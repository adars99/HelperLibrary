com.art.myGalleries.vos.GalleryVO = function(obj)
{
	this.GalleryId			= obj.GalleryId;
	this.Name				= obj.Name;
	this.ShortDescription 	= obj.ShortDescription;
	this.LongDescription	= obj.LongDescription;
	this.Visibility			= obj.Visibility;
	this.GalleryItems		= obj.GalleryItems;
	this.WallImages			= obj.WallImages;
	this.DateCreated		= obj.DateCreated;
	this.DateModified		= obj.DateModified;
	this.galleryItemCount	= obj.GalleryItemCount;
	this.LastGalleryImageUrl = obj.LastGalleryImageUrl;
};