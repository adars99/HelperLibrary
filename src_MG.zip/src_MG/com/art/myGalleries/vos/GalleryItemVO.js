com.art.myGalleries.vos.GalleryItemVO = function(obj)
{
	if(obj == undefined)
		return;
    this.ItemId 					= obj.ItemGalleryItemID;
    this.ItemStatus					= obj.ItemStatus || false;
    this.APNum						= obj.ItemDetails.APNum || "";
	this.ItemDisplayedType			= obj.ItemDetails.ItemDisplayType || "";
    this.Imageid					= obj.ItemDetails.ImageId || "";
    this.Sku 						= obj.ItemDetails.Sku || "";
    this.Title 						= obj.ItemDetails.Title || "";
    this.ArtistName					= (obj.ItemDetails.Artist.FirstName || "") + " " +(obj.ItemDetails.Artist.LastName || ""); 
    this.ArtistUrl					= obj.ItemDetails.Artist.ArtistUrl;
    this.ImageUrl 					= obj.ItemDetails.ImageInformation.LargeImage.HttpImageURL;
    this.Height 					= obj.ItemDetails.ImageInformation.LargeImage.Dimensions.Height;
    this.Width 						= obj.ItemDetails.ImageInformation.LargeImage.Dimensions.Width;
    this.PhysicalDimensionHeight 	= obj.ItemDetails.PhysicalDimensions.Height;
    this.PhysicalDimensionWidth	 	= obj.ItemDetails.PhysicalDimensions.Width;
    this.Price 						= obj.ItemDetails.ItemPrice.DisplayPrice;
    this.DisplayMSRP				= obj.ItemDetails.ItemPrice.DisplayMSRP;
    this.MarkDownPrice 				= obj.ItemDetails.ItemPrice.MarkDownPrice;
    this.ShowMarkDownPrice			= obj.ItemDetails.ItemPrice.ShowMarkDownPrice;
    this.CanFrame 					= obj.ItemDetails.ServiceFlags.CanFrame || false;
    this.AppendShadow 				= obj.ItemDetails.AppendShadow;
    this.DateCreated 				= obj.DateCreated;
    this.DateCreated 				= obj.DateUpdated;
    this.ZoomUrl					= obj.ItemDetails.ImageInformation.LargeImage.HttpImageURL;
    this.CropperUrl					= obj.ItemDetails.ImageInformation.CroppedSquareImage.HttpImageURL || obj.ItemDetails.ImageInformation.LargeImage.HttpImageURL;
    this.AddToCartUrl				= "";//obj.ItemDetails.AdditionalUrls.AddtoCartUrl || "";
    this.ProductPageUrl				= "";//obj.ItemDetails.AdditionalUrls.ProductPageUrl || "";
    this.PODConfigID				= obj.PODConfigID || 0;
    this.VanityURL					= obj.VanityURL || "";
    this.ItemDetails				= obj.ItemDetails || null;
};