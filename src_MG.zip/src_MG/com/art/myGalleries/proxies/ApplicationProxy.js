com.art.myGalleries.proxies.ApplicationProxy = function (env,viewMode) {
    this.NAME = "ApplicationProxy";
    this.galleryPerPage = 16;
    this.galleryItemPerPage = 9;
    this.galleryList = [];
    this.galleryItemList = []; //holds all items for RoomView and Slideshow
    this.galleryListIsCachedFlag = false;
    this.cacheByGalleryList = {};
    this.cacheByGalleryItemList = {};
    this.toggleDisplay = "";
    this.galleryItemPageNumber = -1;
    this.galleryDefaultSort = false;
    this.gallerySortBy = 0;
    this.gallerySortDirection = 1;
    this.getAllItemsFlag = true;
    this.ProfileUrl="";
    this.myGalleryItemCount=0;
    this.environment = env;
    //this.galleryTemplate = { "ItemId": null, "DateUpdated": "\/Date(-62135568000000-0800)\/", "DateCreated": "\/Date(-62135568000000-0800)\/", "Name": null, "GalleryItemSource": 0, "PagingOptions": null, "ParentId": 0, "ItemCount": 0, "AccountId": 0, "Icon": null, "ItemSource": 0, "ItemKey": null, "ItemText": null, "ItemData": null, "GalleryId": null, "GalleryVisibility": 1, "Rooms": null, "Walls": null, "BackGround": null, "ShortDescription": null, "SortOptions": { "SortBy": 0, "SortDirection": 0, "DefaultSort": true }, "LongDescription": null, "BareWalls": null, "ChildGalleries": null, "Permissions": 0, "Items": null, "TotalItems": 0 };
    this.galleryTemplate = { "Name": null, "GalleryItemSource": 4, "GalleryId": null, "GalleryVisibility": 1, "BackGround": null, "ShortDescription": null, "SortOptions": { "SortBy": 0, "SortDirection": 0, "DefaultSort": true }, "LongDescription": null};
    
    //this.galleryItemTemplate = {"APNum":null,"FrameSku":null,"Imageid":0,"DateUpdated":"\/Date(-62135568000000-0800)\/","DateCreated":"\/Date(-62135568000000-0800)\/","Name":null,"GalleryItemSource":0,"AvailableInOtherSizes":false,"PagingOptions":null,"ParentId":0,"ItemCount":0,"AccountId":0,"GalleryIconURL":null,"ItemSource":0,"ItemKey":null,"ItemText":null,"ItemData":null,"ItemGalleryItemID":0,"ItemDisplayTypeID":0, "ImageDetails":null,"ItemDetails":null,"ServiceDetails":null,"ItemGroupType":0,"Item":{"ArtistId":0,"ArtistName":null,"ItemId":0,"Price":null,"Title":null},"ImageDetails":null,"Source":null};
    this.galleryItemTemplate = {"APNum":null,"FrameSku":null,"Imageid":0,"GalleryItemSource":4,"AvailableInOtherSizes":false,"ItemGalleryItemID":0,"ItemDisplayTypeID":0, "Item":{"ArtistId":0,"ArtistName":null," Price":null,"Title":null}};
    
    this.getDFEEngineParameters={"PrintAPNum":0,"PrintPODConfigID":0,"Crop":0,"ColorGrouping":{"ColorID":0,"ColorName":""},"StyleGrouping":{"StyleID":0,"StyleName":""},"MaxConfigurations":0,"CustomerZoneID":0,"LanguageID":0,"FitFixedFrame":true,"CurrencyCode":null,"WriteToDB":true,"ImageMaxW":"0","ImageMaxH":"0","ShowTrace":false,"MergePreFrameData":false,"FrameSKU":null,"Domain":null,"SendLiteResponse":false,"FSFrameConfiguration":{"Print":{"APNum":0},"MatCombo":{"NumMats":0,"TopMat":{"APNum":0,"LeftSize":2.5,"TopSize":2.5,"RightSize":2.5,"BottomSize":2.5},"MiddleMat":{"APNum":0,"LeftSize":0,"TopSize":0,"RightSize":0,"BottomSize":0},"BottomMat":{"APNum":0,"LeftSize":0,"TopSize":0,"RightSize":0,"BottomSize":0}},"Moulding":{"APNum":0},"GlassConfig":{"GlassAPNum":0}}};
    
    this.selectedItemId;
    this.selectedGalleryId;
    this.orderObject = []; //for GoogleChrome; automatically sorts array keys

    //persist lightbox z-index all modals show be > than this value
    //otherwise LightBox will dynamically find z-index everytime
    this.highestZIndex = -1;
    
    //for framestudio click open modal to save to gallery
    //block double clicks
    this.frameStudioFlag = false;
    
    //distinguish between slideshow / roomview calls to GET_ALL_GALLERY_ITEMS
    this.requestForAllItemsFromSlideShow = false;
    
    //set from ProductPage, GalleryPage
    this.selectedImageObject = {};
    
    this.currentViewMode = viewMode;
    
    this.updateFromDLE = false; //flag if user moves images in dle
    
    this.facebookShare = {};
    this.facebookShare[MyGalleriesCore.constants.GRID_VIEW] =
	{
		caption:"I've created a gallery on Art.com",
		description:"Come check out the gallery of art I created on Art.com, and let me know what you think!"
	};
    this.facebookShare[MyGalleriesCore.constants.SLIDESHOW] = 
    {
    		caption:"I've created a gallery on Art.com",
    		description:"Come check out the gallery of art I created on Art.com, and let me know what you think!"
    };
    this.facebookShare[MyGalleriesCore.constants.ROOM_VIEW] = 
	{
		caption:"I've decorated a room on Art.com",
		description:"Come check out the room view of art I created on Art.com, and let me know what you think!"
	};
   
     
    this.LOGGED_IN = com.art.myGalleries.proxies.ApplicationProxy.LOGGED_IN;
    this.LOGGED_OUT = com.art.myGalleries.proxies.ApplicationProxy.LOGGED_OUT;
    
    //see getSelectedGalleryClone function
    this.galleryRequiredProperites = ["GalleryId","ItemId","DateUpdated","DateCreated","Name","GalleryItemSource","PagingOptions","ParentId","ItemCount","AccountId","Icon","ItemSource","ItemKey","ItemText","ItemData","GalleryId","GalleryVisibility","Rooms","Walls","BackGround","ShortDescription","SortOptions","LongDescription","BareWalls","ChildGalleries","Permissions","Items","TotalItems"];
    this.ISOCurrencyENUM = {"AUD":0,"CAD":1,"DKK":2,"HKD":3,"JPY":4,"NZD":5,"NOK":6,"SGD":7,"ZAR":8,"SEK":9,"CHF":10,"GBP":11,"USD":12,"EUR":13,"ARS":14,"CNY":15,"CZK":16,"MXN":17,"TRY":18,"PLN":19,"BRL":20};
    this.ISOLangaugeENUM = {"EN" : 0,"FR" : 1,"DE" : 2,"ES" : 3,"IT" : 4,"JA" : 5,"NL" : 6,"SE" : 7,"DA" : 8,"NO" : 9,"FI" : 10};
    
    /*
     * Sharing related properties
     */
    this.shareTitle = "";
    this.shareURL	= "";

    this.selectedFramingStudioObject=[{}];
    this.shareType;//for roomView sharing
    this.isViewingSharedRoomView = false; //for roomView sharing
    
    //flag to indicate if we're coming back to previously viewed roomView
    //restore to last wall
    this.restorePreviousVisit = false;
    
    //handle dependencies between swf and gallery items
    this.dleIsLoaded 		= false;
    this.galleryItemsLoaded = false;
    
    //one-click add to gallery flag
    this.oneClickAddToGalleryIsEnabled = false;
    
    //Create one-click cookie in arts cookie base
    this.oneClickCookie='oneclick';
    //Create GalleryID cookie in arts cookie base
    this.GalleryIDCookie='galleryid';
    //Create GalleryID cookie in arts cookie base
    this.LastGalleryNameCookie='lastgalleryname';
    //Art cookie domain name
    this.artCookieBase='arts';
    //Declare the cookie object for one click add to gallery
    this.cookieobject = new com.art.core.cookie.Cookie();
};

com.art.myGalleries.proxies.ApplicationProxy.NAME = "ApplicationProxy";
com.art.myGalleries.proxies.ApplicationProxy.LOGGED_IN = "0";
com.art.myGalleries.proxies.ApplicationProxy.LOGGED_OUT = "1"; //anonymous
com.art.myGalleries.proxies.ApplicationProxy.ONECLICKCOOKIEVAL = "1";


/**
 * Checking permissions
 * Viewing a shared roomview will not have permission to save changes
 */
com.art.myGalleries.proxies.ApplicationProxy.prototype.hasWritePermissions = function()
{
	var g = {};
	if(typeof _galleryDataJson!='undefined'){
		for(var i=0; i < _galleryDataJson.length; i++)
		{
			var gObj = _galleryDataJson[i];
			if(location.href.indexOf(gObj.VanityURL))
			{
				return gObj.Permissions > Number(MyGalleriesCore.constants.VIEW);
			}
		}
	}
	return false;
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.getColorIndexByHex = function(hex)
{
	var colors = this.getBackgroundColors();
	for(var i=0; i < colors.length; i++)
	{
		if(colors[i] == hex)
			return i;
		
	}
	trace("Did not find hex color; use default 0.");
	return 0;
};

//get the Frame studio sku method
com.art.myGalleries.proxies.ApplicationProxy.prototype.getFramingSKURequestObjectAsString = function(obj)
{	
	return "dfeEngineParameters="+JSON.stringify(this.getDFEEngineParameters);
};
//set from product page Framing studio SKU value
com.art.myGalleries.proxies.ApplicationProxy.prototype.setFramingStudioResponseObject = function(obj)
{
	this.selectedFramingStudioObject = obj;	
};

//get from product page Framing studio SKU value
com.art.myGalleries.proxies.ApplicationProxy.prototype.getFramingStudioResponseObject = function()
{
	return this.selectedFramingStudioObject;
};

//set from product page or gallery page
com.art.myGalleries.proxies.ApplicationProxy.prototype.setSelectedImageObject = function(obj)
{
	this.selectedImageObject = obj;
};

com.art.myGalleries.proxies.ApplicationProxy.prototype.getNextHighestZIndex = function()
{
	if( this.highestZIndex == -1)
    {
    	this.highestZIndex = com.art.core.utils.BrowserUtil.getNextHighestZIndex();
    }
	return this.highestZIndex;
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.setInitialPageNumber = function(pageNumber)
{
    trace("setInitialPageNumber:  " + pageNumber);
	this.galleryItemPageNumber = (pageNumber != "") ? parseInt(pageNumber) : 1;
};

//Get the gallery title, desc and privacy
com.art.myGalleries.proxies.ApplicationProxy.prototype.getSelectedGallery = function ()
{
	var id = this.environment.selectedGalleryID;
	var obj = this.cacheByGalleryList[id]; 
    return obj;
};

//Get the onclick cookie value 
com.art.myGalleries.proxies.ApplicationProxy.prototype.getOneClickAddToGalleryEnabled = function ()
{
	var oneClickVal="";
	var bool = this.cookieobject.getCookieDictionary(this.artCookieBase,this.oneClickCookie) == '1';
	trace("getOneClickAddToGalleryEnabled: "+bool);
    return bool;
};

com.art.myGalleries.proxies.ApplicationProxy.prototype.setGalleryItemCountCookie = function ()
{	
	var itemCount=this.getGalleryItemCountFromCookie();	
	if(itemCount>0){
		 itemCount=parseInt(itemCount)+1;
		 this.cookieobject.setCookieDictionary(this.artCookieBase, 'mgitemcount', itemCount,'/', this.cookieobject.getCookieDomain('art'));
	}
	else{
		 itemCount=1;
		 this.cookieobject.setCookieDictionary(this.artCookieBase, 'mgitemcount', itemCount,'/', this.cookieobject.getCookieDomain('art'));
	}		 	
	this.myGalleryItemCount=parseInt(itemCount);	
	trace("itemcount"+itemCount);
};

com.art.myGalleries.proxies.ApplicationProxy.prototype.getGalleryItemCountFromCookie = function ()
{
	var itemCount=this.cookieobject.getCookieDictionary(this.artCookieBase,'mgitemcount');	
	if(itemCount.length>0)		
		return itemCount;		
	else
		return 0;	
};

//Set the on Click cookie value 
com.art.myGalleries.proxies.ApplicationProxy.prototype.setOneClickAddToGalleryEnabled = function (enable)
{
	if(typeof enable == "string")
		throw new Error("ApplicationProxy.setOneClickAddToGalleryEnabled failed! Invalid input.");
	
	if(typeof enable == "number")
		throw new Error("ApplicationProxy.setOneClickAddToGalleryEnabled failed! Invalid input.");
	
	var cookieValue = enable == true ? "1" : "0";
	
	trace("cookie value: "+cookieValue);
	
	this.cookieobject.setCookieDictionary(this.artCookieBase, this.oneClickCookie,cookieValue,'/', this.cookieobject.getCookieDomain('art')); //1 for Yes and 0 for No	
};



//Get the onclick cookie value 
com.art.myGalleries.proxies.ApplicationProxy.prototype.getLastSelectedGalleryID = function ()
{	
	var lastSelectedGalleryID="";
	lastSelectedGalleryID = this.cookieobject.getCookieDictionary(this.artCookieBase,this.GalleryIDCookie);	 
    return lastSelectedGalleryID;
};

//Set the on Click cookie value 
com.art.myGalleries.proxies.ApplicationProxy.prototype.setLastSelectedGalleryID = function (galleryID)
{	
	this.cookieobject.setCookieDictionary(this.artCookieBase, this.GalleryIDCookie,galleryID,'/', this.cookieobject.getCookieDomain('art')); 	
};

//Set the gallery name cookie value 
com.art.myGalleries.proxies.ApplicationProxy.prototype.setLastSelectedGalleryName = function (galleryName)
{	
	this.cookieobject.setCookieDictionary(this.artCookieBase, this.LastGalleryNameCookie,galleryName,'/', this.cookieobject.getCookieDomain('art'));    
};

//Get the gallery name cookie value  
com.art.myGalleries.proxies.ApplicationProxy.prototype.getLastSelectedGalleryName = function ()
{	
	var lastSelectedGalID=this.cookieobject.getCookieDictionary(this.artCookieBase,'galleryid');
	var lastSelectedGalName="";
	trace("lastSelectedGalID: "+lastSelectedGalID);	
	
	if(lastSelectedGalID.length>0){
		if(this.cacheByGalleryList[lastSelectedGalID]!=undefined)
		{
			lastSelectedGalName=this.cacheByGalleryList[lastSelectedGalID].Name;
		}
		else
		{
			lastSelectedGalName=this.cookieobject.getCookieDictionary(this.artCookieBase,this.LastGalleryNameCookie);	
		}		
	}
	return lastSelectedGalName;
};

/**
 * Get clone of selected gallery, in order to modify for service request without modifying actual gallery object in collection
 * Once the service returns successful, then we can update the actual object
 * 
 */
com.art.myGalleries.proxies.ApplicationProxy.prototype.getSelectedGalleryClone = function()
{
	var copy = {};
	var gallery = this.getSelectedGallery();
//	for(var i=0; i < this.galleryRequiredProperites; i++)
//	{
//		var property = this.galleryRequiredProperites[i];
//		trace("property"+property);
//		copy[property] = gallery[property];
//	}
//	return copy;
	for(var p in gallery)
	{
		copy[p] = gallery[p];
	}
	return copy;
};
/**
 * Check local data for matching gallery name before we make service call
 * @param name
 * @returns {Boolean}
 */
com.art.myGalleries.proxies.ApplicationProxy.prototype.galleyNameIsAvailable = function(name,id)
{
	for(var i=0; i< this.galleryList.length; i++)
	{
		if(this.galleryList[i].Name == name && id != this.galleryList[i].GalleryId)
			return false;
	}
	return true;
};
//Set the gallery title
com.art.myGalleries.proxies.ApplicationProxy.prototype.setSelectedGalleryTitle = function (title) {	
    this.cacheByGalleryList[this.environment.selectedGalleryID].Name = $.trim(title);
};
//Set the gallery desc
com.art.myGalleries.proxies.ApplicationProxy.prototype.setSelectedGalleryDesc = function (desc) {
    this.cacheByGalleryList[this.environment.selectedGalleryID].LongDescription = $.trim(desc);
};
//Set the gallery privacy
com.art.myGalleries.proxies.ApplicationProxy.prototype.setSelectedGalleryPrivacy = function (visibility) {    
    this.cacheByGalleryList[this.environment.selectedGalleryID].GalleryVisibility = visibility;
    
};

//Get the Added gallery title, desc and privacy
com.art.myGalleries.proxies.ApplicationProxy.prototype.setCreateGallery = function () {
    
    if (this.galleryTemplate.GalleryVisibility == undefined) {
        this.galleryTemplate.GalleryVisibility = 1;
    }
    if (this.galleryTemplate.LongDescription == "Enter a description (optional)") {
        this.galleryTemplate.LongDescription = "";
    }
    return this.galleryTemplate;
};

//Set the Added gallery title
com.art.myGalleries.proxies.ApplicationProxy.prototype.setAddedGalleryTitle = function (title) {
	var title=encodeURIComponent($.trim(title));	
   this.galleryTemplate.Name = escape(title);	
};
//Set the added gallery desc
com.art.myGalleries.proxies.ApplicationProxy.prototype.setAddedGalleryDesc = function (desc) {
	var desc=encodeURIComponent($.trim(desc));
    this.galleryTemplate.LongDescription = escape(desc);
	//this.galleryTemplate.LongDescription = desc;
};
//Set the added gallery privacy
com.art.myGalleries.proxies.ApplicationProxy.prototype.setAddedGalleryPrivacy = function (visibility) {    
    this.galleryTemplate.GalleryVisibility = visibility;
};

com.art.myGalleries.proxies.ApplicationProxy.prototype.getImagesPerPage = function()
{
	return this.imagesPerPage;
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.getSelectedMethodName = function()
{
	return "SomeService";
};
/**
 * 
 * @returns {Boolean}
 */
com.art.myGalleries.proxies.ApplicationProxy.prototype.galleryListIsCached = function()
{
	return this.galleryListIsCachedFlag;
};
/**
 * 
 * @param arr
 */
com.art.myGalleries.proxies.ApplicationProxy.prototype.setGalleryList = function (arr)
{
	this.galleryList = arr;
	this.flattenGalleryList(arr);
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.flattenGalleryList = function(galleries)
{
	for(var i=0; i < galleries.length; i++)
	{	
	    this.cacheByGalleryList[galleries[i].GalleryId] = galleries[i];
	}
};

/**
 * Index GalleryItems by ItemID for fast lookup, the only catch is GoogleChrome will auto sort the hash table
 * Making our sorting incorrecct when we render; so we're using the sortObject to maintain our sort order
 * @param items
 */
com.art.myGalleries.proxies.ApplicationProxy.prototype.flattenGalleryItemDetails = function(items)
{
	this.orderObject = [];
	this.cacheByGalleryItemList = {};
	for(var i=0; i < items.length; i++)
	{
		if(items[i] != null && items[i].ItemDetails != null)
		{
			this.orderObject.push(items[i].ItemGalleryItemID);
			this.cacheByGalleryItemList[items[i].ItemGalleryItemID] = items[i];
		}
	}
};


com.art.myGalleries.proxies.ApplicationProxy.prototype.getGalleryByGalleryId = function(apnum)
{
	return {GalleryData:this.cacheByGalleryList[apnum]};
};

com.art.myGalleries.proxies.ApplicationProxy.prototype.getGalleryItemByGalleryId = function(ItemId,indexCounter)
{
	
	var key = indexCounter != undefined ? this.orderObject[indexCounter]:ItemId;
	return {GalleryItemData:this.convertToGalleryItemVO(this.cacheByGalleryItemList[key])};
};


com.art.myGalleries.proxies.ApplicationProxy.prototype.convertToGalleryItemVO = function(object)
{
	trace("obj:"+ object);
	return new com.art.myGalleries.vos.GalleryItemVO(object);
};

/**
 * 
 * @param pageNumber
 * @returns {Array}
 */
com.art.myGalleries.proxies.ApplicationProxy.prototype.getGalleryList = function(pageNumber)
{
	var tmpArr = [];
	var start = (pageNumber - 1) * this.galleryPerPage;
	for(var i=0; i < this.galleryPerPage; i++)
	{
		if(this.galleryList[start] != undefined)
		{
			tmpArr.push(this.galleryList[start]);
		}
		else
		{
			tmpArr.push({placeholder:true,imageUrl:'http://spacer.gif'});
		}
		start++;
	}
	return tmpArr;
};

com.art.myGalleries.proxies.ApplicationProxy.prototype.getGalleryListForSlideShow = function (maxImageWidth, maxImageHeight, cropperMode) {

    var tmp = [];
    var items = this.getGalleryItemList();    
    trace(items);
    for (var i = 0; i < items.length; i++)
    {
    	if(items[i].ItemDetails != null)
    	{
    		var item = new com.art.myGalleries.vos.GalleryItemVO(items[i]);
    		if(item.CropperUrl != null) {
    			var url = com.art.core.utils.BrowserUtil.getCroppedImageUrl(item.CropperUrl, maxImageWidth, maxImageHeight, cropperMode);
    			
    			//tmp.push({ apnum: item.APNum, url: url, price: item.Price, showMarkDownPrice:item.ShowMarkDownPrice,markdownPrice:item.MarkDownPrice});
    			tmp.push({ apnum: item.APNum, url: url, price: item.Price, showMarkDownPrice:item.ShowMarkDownPrice,DisplayMSRP:item.DisplayMSRP});
    		}	
    	}
    }
    return tmp;
};

com.art.myGalleries.proxies.ApplicationProxy.prototype.galleryItemsCached = function () {
    return this.galleryItemList[this.galleryItemPageNumber] != undefined;
};
/**
 * GetColors for DLE see UserLibraryProxy.getThumbnailImageUrls
 * 
 * 
 */
com.art.myGalleries.proxies.ApplicationProxy.prototype.getBackgroundColorsForDLE = function()
{
	var tmp = [];
	var c = this.getBackgroundColors();
	for(var i=0; i < c.length; i++)
	{
		// {id:w.Name,url:this.baseUrl+w.ImageInformation.ThumbnailImage.HttpImageURL}
		tmp.push({id:'hex_'+c[i],url:null,emptyWallFlag:true,bgcolor:'0x'+c[i],hexAsString:c[i]});
	}
	return tmp;
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.getBackgroundColors = function()
{
	return [
	        'ffe3e4',
	        'fff4d6',
	        'fff7d0',
	        'efede7',
	        'ebf0e4',
	        'edf7fa',
	        'fcfaec',
	        'e2c7c7',
	        'f0debd',
	        'eee7c3',
	        'd4d0c2',
	        'ced7d3',
	        'cfd9dd',
	        'd6d7d3',
	        '9f6d73',
	        'e4bd8b',
	        'decfad',
	        'bdb1a5',
	        '94a6a1',
	        'b3c4ce',
	        '868f94',
	        '733b4b',
	        'ca9153',
	        '907761',
	        '847467',
	        '526965',
	        '607d90',
	        '4c545b',
	        '84303d',
	        '8b4a26',
	        '584035',
	        '584d43',
	        '364643',
	        '31343a',
	        'FFFFFF'
	    ];
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.setGalleryItems = function (galleryItems, isPageLoad)
{
	if(!isPageLoad)
		this.galleryItemList = galleryItems;
	this.flattenGalleryItemDetails(galleryItems);
};

com.art.myGalleries.proxies.ApplicationProxy.prototype.getGalleryItemList = function (pageNumber) {
   return this.galleryItemList;
};


com.art.myGalleries.proxies.ApplicationProxy.prototype.setGalleries = function(obj)
{
	this.galleryList = obj;
	this.flattenGalleryList(obj);
};

com.art.myGalleries.proxies.ApplicationProxy.prototype.getAccessKeyObjectAsString = function() { 
 var str = "accessKey=" + JSON.stringify({ "apikey": this.environment.apiKey, "authToken": this.environment.authToken }); 
 	return str;
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.getUserProfileObjectAsString = function()
{
	var str = "userProfile=" + JSON.stringify({"ClientIpAddress":this.environment.clientIpAddress,"ISOCurrencyCode":this.ISOCurrencyENUM[this.environment.currencyCode],"CustomerZoneId":this.environment.customerZoneId,"ISOLanguageCode":this.ISOLangaugeENUM[this.environment.languageIso]});
	//var str = "userProfile=" + JSON.stringify({"ClientIpAddress":this.environment.clientIpAddress,"ISOCurrencyCode":this.ISOCurrencyENUM["GBP"],"CustomerZoneId":"4","ISOLanguageCode":this.ISOLangaugeENUM["DE"]});
	return str;
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.getGallerySortObjectAsString = function()
{
	var str = "gallerySortOption=" + JSON.stringify({ "DefaultSort": this.environment.galleryDefaultSort, "SortBy": this.gallerySortBy, "SortDirection": this.gallerySortDirection });
	return str;
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.setPagingOptionsAllItems = function(flag)
{
	if(flag)
		this.getAllItemsFlag = true;
	else
		this.getAllItemsFlag = false;
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.getGalleryPagingOptionObjectAsString = function()
{
	var str = "pagingOptions=" + JSON.stringify({ "AllItems": this.getAllItemsFlag, "ItemsPerPage": this.galleryItemPerPage, "PageNumber": this.galleryItemPageNumber, "TotalPages": 0 });
	return str;
};

com.art.myGalleries.proxies.ApplicationProxy.prototype.getMoveOptions = function()
{
	return "moveOptions=" + this.environment.moveOption;
};

com.art.myGalleries.proxies.ApplicationProxy.prototype.getNewItemToGalleryFromFramingStudio = function () {
	var _this=this;
	var itemurl;
	var igitem = {};
	trace(this.galleryItemTemplate);
	igitem = this.galleryItemTemplate;
	igitem.AccountId = 1;
    igitem.Imageid = this.getFramingStudioResponseObject().Imageid;
    igitem.ItemGroupType = 1;
    igitem.GalleryItemSource = 0;
    igitem.APNum = this.getFramingStudioResponseObject().APNum;    
    igitem.FrameSku =this.getFramingStudioResponseObject().FrameSku;
    igitem.AvailableInOtherSizes = this.getFramingStudioResponseObject().AvailableInOtherSizes == "True" ? true : false;    
    igitem.ItemDisplayTypeID = this.getFramingStudioResponseObject().ItemDisplayedTypeID;
    igitem.Item.ArtistId = this.getFramingStudioResponseObject().ArtistId;
    igitem.Item.ArtistName= this.getFramingStudioResponseObject().ArtistName;
    igitem.Item.ItemId= 0;    
    igitem.Item.Price= this.getFramingStudioResponseObject().Price;
    igitem.Item.Title= this.getFramingStudioResponseObject().Title;
    itemurl=encodeURIComponent(this.getFramingStudioResponseObject().ImageUrl);
    trace("itemurl: "+itemurl);
    //igitem.ItemURL =  itemurl;
    igitem.ItemURL =  escape(itemurl.replace(/\+/g,"%2B"));
    trace("ItemURL: "+igitem.ItemURL);
    
    igitem.PODConfigID = this.getFramingStudioResponseObject().PODConfigID;
    igitem.Source = 0;
   
    return igitem;
};


com.art.myGalleries.proxies.ApplicationProxy.prototype.getNewItemToGallery = function () {
	
	var igitem = {};
	trace(this.galleryItemTemplate);
	igitem = this.galleryItemTemplate;   
	
	igitem.AccountId = 1;
    igitem.Imageid = this.selectedImageObject.Imageid;
    igitem.ItemGroupType = 1;
    igitem.GalleryItemSource = 0;
    igitem.APNum = this.selectedImageObject.APNum;
    igitem.FrameSku =this.selectedImageObject.FrameSku;
    igitem.AvailableInOtherSizes = this.selectedImageObject.AvailableInOtherSizes == "True" ? true : false;
    igitem.ItemDisplayTypeID = this.selectedImageObject.ItemDisplayTypeID;
    igitem.Item.ArtistId = this.selectedImageObject.ArtistId;
    igitem.Item.ArtistName= this.selectedImageObject.ArtistName;
    igitem.Item.ItemId= 0;
    igitem.Item.Price= this.selectedImageObject.ItemPrice;
    igitem.Item.Title= this.selectedImageObject.Title;
    igitem.ItemURL = encodeURIComponent(this.selectedImageObject.ImageUrl);
    igitem.PODConfigID = this.selectedImageObject.PODConfigID;
    igitem.Source = this.selectedImageObject.Source;
    igitem.SpecialHandlingID = this.selectedImageObject.SpecialHandlingID;
    
    return igitem;
};

com.art.myGalleries.proxies.ApplicationProxy.prototype.getExisitngItemToGallery = function (flag) {
    var igitem = {};

    if (flag) {
        igitem = this.galleryItemTemplate;
        //igitem = this.cacheByGalleryItemList[this.getSelectedGridItem()];
        igitem.AccountId = 1;
        igitem.APNum = this.cacheByGalleryItemList[this.getSelectedGridItem()].APNum;
        igitem.Name = this.cacheByGalleryItemList[this.getSelectedGridItem()].Name;
        igitem.Imageid = this.cacheByGalleryItemList[this.getSelectedGridItem()].Imageid;
        igitem.ItemText = this.cacheByGalleryItemList[this.getSelectedGridItem()].ItemText;
        igitem.ItemGroupType = this.cacheByGalleryItemList[this.getSelectedGridItem()].ItemGroupType;
        igitem.ItemData = this.cacheByGalleryItemList[this.getSelectedGridItem()].ItemData;
        igitem.ItemKey = this.cacheByGalleryItemList[this.getSelectedGridItem()].ItemKey;
        igitem.GalleryItemSource = this.cacheByGalleryItemList[this.getSelectedGridItem()].GalleryItemSource;
        igitem.ItemGalleryItemID = this.cacheByGalleryItemList[this.getSelectedGridItem()].ItemGalleryItemID;
        
        
        igitem.ItemURL = this.cacheByGalleryItemList[this.getSelectedGridItem()].ItemDetails.ImageInformation.LargeImage.HttpImageURL;
        igitem.Item.ArtistId = this.cacheByGalleryItemList[this.getSelectedGridItem()].Item.ArtistId;
        igitem.Item.ArtistName = this.cacheByGalleryItemList[this.getSelectedGridItem()].Item.ArtistName;
        igitem.Item.ItemId = this.cacheByGalleryItemList[this.getSelectedGridItem()].Item.ItemId;
        igitem.Item.Price = this.cacheByGalleryItemList[this.getSelectedGridItem()].Item.Price;
        igitem.Item.Title = this.cacheByGalleryItemList[this.getSelectedGridItem()].Item.Title;
        igitem.Source = this.cacheByGalleryItemList[this.getSelectedGridItem()].Item.Source;  
        igitem.SpecialHandlingID = this.cacheByGalleryItemList[this.getSelectedGridItem()].SpecialHandlingID;
        trace(this.cacheByGalleryItemList[this.getSelectedGridItem()]);
        trace(igitem);
    }
    else {        
        igitem = this.galleryTemplate;
        igitem = this.cacheByGalleryList[this.getDestinationSelectedGalleryId()];
    }
    return igitem;
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.getSelectedGridItem = function () {
	return this.selectedItemId;
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.setSelectedGridItem = function (id) {
	this.selectedItemId = id;
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.getDestinationSelectedGalleryId = function () {
	return this.selectedGalleryId;
};
com.art.myGalleries.proxies.ApplicationProxy.prototype.setDestinationSelectedGalleryId = function (id) {    
    this.selectedGalleryId = id;
};