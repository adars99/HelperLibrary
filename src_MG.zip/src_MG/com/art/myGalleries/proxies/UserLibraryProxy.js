/**
 * Used in conjunction with GalleryAPIService.getUserGallery service operation; Expose
 * @class UserLibraryProxy
 * 
 * 
 */
com.art.myGalleries.proxies.UserLibraryProxy = function (env)
{
	this.NAME = com.art.myGalleries.proxies.UserLibraryProxy.NAME;
	this.systemLibraryObject;
	this.userLibraryObject;
	this.wallsObject = []; //from galleryService.getWalls();
	
	
	this.selectedWallGalleryName = "LivingRoom"; //Top level menu item name
	this.selectedWallGalleryIndex = 1;
	this.selectedWallName = "LivingRoom_04"; //DEFAULTname of selected thumbnail
	//counter representing total "current" items displayed in DLE; opposed to number of items in userLibrary.Wall[x].WallItems
	this.totalItemsOnWall = 0;
	
	//used for identifying personal walls
	this.userBareWallNamePrefix = "UserBareWall_";
	
	//items that are currently selected and on wall
	this.wallItemsMap = {};
	this.selectedWallObject;
	this.EMPTY_WALL_DELIMITER = com.art.myGalleries.proxies.UserLibraryProxy.EMPTY_WALL_DELIMITER; //Used with Rooms By Size
	//TODO get from environmental variable
	this.baseUrl = "http://cache1.allpostersimages.com/";
	this.baseUrlUserWalls = "http://cache2.artprintimages.com";
	//flattend wallItem map
	this.flattenedWallItemsByWallId = {};
	
	//for roomview sharing
	this.tempWallItems = {};
	
	//flattend wallsByName
	this.flattenedWallsByName = {};
	
	 //user library for personal walls
    this.userLibraryObject;
    
    this.roomsCollection = [];
    
    
    this.selectedSharedBareWallIndex = 0; //for sharing roomView
    
    //for roomView
	this.checkBoxMap	= {}; //checkbox components on righthand side tray
	
	this.RHVerticalTray; //righthand vertical container for thumb images
	
	this.selectedSharedWallObject; //for sharing roomView
	this.sharedWallId; //for sharing roomView
	this.sharedEmptyRoomHexColor = "";
	
	//last updated wall, by default always return to this wall
	this.lastUpdatedWallObject;
	
	
	/*
	 * When moving from wall to wall and calling "wallChangedGetItemPositions"
	 * if x,y center positions have not yet been saved for a newly visited wall; save to db
	 * This flag is for that process see MyGalleriesCore.wallChangedGetItemPositions
	 */
	this.updateWalls = false;
	
	this.initialLoadComplete = false;
	
	this.RETRIEVE_ALL_WALLS = com.art.myGalleries.proxies.UserLibraryProxy.RETRIEVE_ALL_WALLS;
	
	
};
com.art.myGalleries.proxies.UserLibraryProxy.NAME = "UserLibraryProxy";
com.art.myGalleries.proxies.UserLibraryProxy.RETRIEVE_ALL_WALLS = "UserLibraryProxyRetrieveAllWalls";
com.art.myGalleries.proxies.UserLibraryProxy.EMPTY_WALL_DELIMITER = "@@@";

//Pull list from wallItemsMap but use data from flattened list


com.art.myGalleries.proxies.UserLibraryProxy.prototype.getCheckBoxByItemGalleryItemID = function(id)
{
	trace("UserLibraryProxy.getCheckBoxByItemGalleryItemID() id:"+id);
	for(var cb in this.checkBoxMap)
	{
		if(this.checkBoxMap[cb].value.ItemGalleryItemID == id )
			return this.checkBoxMap[cb];
	}
	throw new Error("UserLibraryProxy.getCheckBoxByItemGalleryItemID failed! No checkbox found by id: "+id+".");
};
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getSelectedWallGAEventName = function(wallName)
{
	trace("UserLibraryProxy.getSelectedWallGAEventName wallName: "+wallName);
	
	var wallName = wallName != undefined ? wallName : this.selectedWallName;
	var key = "Choose Public Wall";
	
	//GA track breaks ExternalInterface SYNC call; ensure it's at END of your ASYNC call
	if(wallName.indexOf(com.art.myGalleries.proxies.UserLibraryProxy.EMPTY_WALL_DELIMITER) > -1 || wallName.indexOf('hex') > -1 )
	{
		key = "Choose Bare Wall";
	}
	if(wallName.indexOf('myWallsBrowseBtn') > -1 || wallName.indexOf(this.userBareWallNamePrefix) > -1)
	{
		key = "Choose Personal Room";
	}
	return key;
};
com.art.myGalleries.proxies.UserLibraryProxy.prototype.flatten = function(walls)
{
	this.flattenWallItems(walls);
	this.flattenWallsByName(walls);
};
com.art.myGalleries.proxies.UserLibraryProxy.prototype.flattenWallItems = function(walls)
{
	for(var i=0; i < walls.length; i++)
	{
		var w = walls[i];
		this.flattenedWallItemsByWallId[w.WallId] = {};
		for(var ii=0; ii < w.WallItems.length;ii++)
		{
			var item = w.WallItems[ii];
			this.flattenedWallItemsByWallId[w.WallId][item.Item.ItemGalleryItemID] = item;
		}
	}
};
com.art.myGalleries.proxies.UserLibraryProxy.prototype.flattenWallsByName = function(walls)
{
	for(var i=0; i < walls.length; i++)
	{
		var w = walls[i];
		var n = w.WallDetails.Name;
		//check to see if it's a user uploaded image
		//n == "" uploaded from web
		//w.WallDetails.RulerX != undefined && n.indexOf(this.userBareWallNamePrefix) < 0) checking if it's from mobile; Name will be some arbitrary value; let's standardize
		if(n == "" || (w.WallDetails.RulerX1 != undefined && n.indexOf(this.userBareWallNamePrefix) < 0))
		{
			n = this.userBareWallNamePrefix + w.WallDetails.BareWallId;
		}
		this.flattenedWallsByName[n] = w;
	}
};

com.art.myGalleries.proxies.UserLibraryProxy.prototype.setUserLibrary = function(userLibrary)
{
	this.userLibraryObject = userLibrary;
};
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getUserLibrary = function()
{
	return this.userLibraryObject;
};

com.art.myGalleries.proxies.UserLibraryProxy.prototype.updateItemPosition = function(xpos,ypos)
{
	trace("UserLibraryProxy.updateItemPosition: "+xpos+","+ypos); //this.getUserLibrary
};

//for DLE
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getUserBareWalls = function()
{
	trace("UserLibraryProxy.getUserBareWalls()");
	if(this.userLibraryObject == undefined)
		return [];
	
	var tmp = [];
	if(this.userLibraryObject.BareWallGalleries.length == 0)
	{
		return tmp;
	}
	trace("UserLibraryProxy.getUserBareWalls: ");
	trace(this.userLibraryObject);
	var bareWalls = this.userLibraryObject.BareWallGalleries[0].BareWalls;
	for(var i = 0; i < bareWalls.length; i++)
	{
		var w = bareWalls[i];
		var n = w.Name == "" ? this.userBareWallNamePrefix+w.BareWallId: w.Name;
		w.Name = n; //reassign for later reference when coming from flash
		tmp.push({id:n,url:w.ImageInformation.ThumbnailImage.HttpImageURL});
	}
	return tmp;
};

com.art.myGalleries.proxies.UserLibraryProxy.prototype.getSelectedPersonalBareWallWithUpdates = function(obj)
{
	trace("UserLibraryProxy.getSelectedPersonalBareWallWithUpdates");
	trace("obj: ");
	trace(obj);
	
	var walls = this.userLibraryObject.BareWallGalleries[0].BareWalls;
	var currentPersonalBareWall = {};
	
	for(var i=0; i < walls.length; i++)
	{
		if(walls[i].Name == this.selectedWallName)
		{
			//copy first
			for(var p in walls[i])
			{
				currentPersonalBareWall[p] = walls[i][p];
			}
			trace("InchesConversionRate before: " + walls[i].InchesConversionRate);
			currentPersonalBareWall.InchesConversionRate = obj.inchesConversionRate;
			currentPersonalBareWall.ProductTargetAreaPosX = obj.productTargetAreaPosX;
			currentPersonalBareWall.ProductTargetAreaPosY = obj.productTargetAreaPosY;
			currentPersonalBareWall.RulerLength = obj.rulerLength;
			currentPersonalBareWall.RulerX1 = obj.rulerX1;
			currentPersonalBareWall.RulerX2 = obj.rulerX2;
			currentPersonalBareWall.RulerY1 = obj.rulerY1;
			currentPersonalBareWall.RulerY2 = obj.rulerY2;
			delete currentPersonalBareWall.__type;
			delete currentPersonalBareWall.ImageInformation;
			
			trace("InchesConversionRate after: " + currentPersonalBareWall.InchesConversionRate);
		}
	}
	if(currentPersonalBareWall.InchesConversionRate == undefined)
		throw new Error("UserLibraryProxy.getSelectedPersonalBareWallWithUpdates failed! currentPersonalBareWall not set.");
	trace(currentPersonalBareWall);
	
	return currentPersonalBareWall;

};

/**
 * When user uploads new barewall refresh list; from ApplicationCommand
 * @param sysLibrary
 */
com.art.myGalleries.proxies.UserLibraryProxy.prototype.refreshUserBareWalls = function(bareWallGalleryObject)
{
	//refresh bareWallGalleryObject
	this.userLibraryObject.BareWallGalleries[0] = bareWallGalleryObject;
};


//com.art.myGalleries.proxies.UserLibraryProxy.prototype.updateBareWall = function(library)
//{
//	trace("UserLibraryProxy.updateBareWall");
//	var bareWallID = library.BareWalls[0].BareWallId;
//	if(bareWallID == undefined)
//		throw new Error("UserLibraryProxy.updateBareWall failed! BareWallId not found in response.");
//	
//	var bareWalls = this.userLibraryObject.BareWallGalleries[0].BareWalls;
//	for(var i=0; i < bareWalls.length;i++)
//	{
//		if(bareWalls[i].Name == this.userBareWallNamePrefix+bareWallID)
//		{
//			trace("FOUND BARE WALL! UPDATE IT!");
//			bareWalls[i].InchesConversionRate = library.BareWalls[0].InchesConversionRate;
//			bareWalls[i].RulerLength = library.BareWalls[0].RulerLength;
//			bareWalls[i].RulerX1 = library.BareWalls[0].RulerX1;
//			bareWalls[i].RulerX2 = library.BareWalls[0].RulerX2;
//			bareWalls[i].RulerY1 = library.BareWalls[0].RulerY1;
//			bareWalls[i].RulerY2 = library.BareWalls[0].RulerY2;
//			bareWalls[i].RulerY2 = library.BareWalls[0].RulerY2;
//			
//		}
//	}
//};
//contains system/empty walls
com.art.myGalleries.proxies.UserLibraryProxy.prototype.setSystemLibrary = function(sysLibrary)
{
	this.systemLibraryObject = sysLibrary;
};

com.art.myGalleries.proxies.UserLibraryProxy.prototype.getSystemLibrary = function(userLibrary)
{
	return this.systemLibraryObject;
};





com.art.myGalleries.proxies.UserLibraryProxy.prototype.setSelectedWallGalleryIndexAndName = function(wallGalleryName)
{
	this.selectedWallGalleryName = wallGalleryName.indexOf(this.EMPTY_WALL_DELIMITER) > -1 ? wallGalleryName.split(this.EMPTY_WALL_DELIMITER)[1] : wallGalleryName;
	var wallGalleries = this.systemLibraryObject.BareWallGalleries;
	
	var name = wallGalleryName.indexOf(this.EMPTY_WALL_DELIMITER) > -1 ? wallGalleryName.split(this.EMPTY_WALL_DELIMITER)[0] : wallGalleryName;
	for(var i = 0; i < wallGalleries.length; i++)
	{
		if(wallGalleries[i].Name == name)
		{
			this.selectedWallGalleryIndex = i;
				return;
		}
	}
	return;
};
/**
 * Get gallery thumbnail images
 * Return array [{id:"",url:""},...]
 * 
 * @method getThumbnailImageUrls
 * @wallName - Name of wall type to filter on
 * @return {Array}
 */
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getThumbnailImageUrls = function(width,height,pw,ph,wallGalleryName)
{
	trace("getThumbnailImageUrls wallGalleryName "+wallGalleryName);
	trace("this.selectedWallGalleryIndex: "+this.selectedWallGalleryIndex);

	var wallGalleries = this.systemLibraryObject.BareWallGalleries;
	var tmp = [];
	
	var walls = wallGalleries[this.selectedWallGalleryIndex].BareWalls;
	for(var n = 0; n < walls.length; n++)
	{
		var w = walls[n];
		var u = this.baseUrl+w.ImageInformation.ThumbnailImage.HttpImageURL;
		tmp.push({id:w.Name,url:u});
	}
	trace(tmp);
	return tmp;
};
/**
 * Porting from AS3, 
 * <RoomImage Name="BathRoom_02" Order="2">
<IsAngledRoom>True</IsAngledRoom>
<RoomAngle>30</RoomAngle>
<URL>images/dfle/1/LifeStyle1/Bathroom/Bathroom_02.jpg</URL>
<ThumbnailURL>images/dfle/1/LifeStyle1/Bathroom/thmb_Bathroom_02.jpg</ThumbnailURL>
<Width>673</Width>
<Height>611</Height>
<UsableAreaWidth>657</UsableAreaWidth>
<UsableAreaHeight>357</UsableAreaHeight>
<UsableAreaPosY>8</UsableAreaPosY>
<UsableAreaPosX>8</UsableAreaPosX>
<ProductTargetAreaPosY>219</ProductTargetAreaPosY>
<WallAreaWidth>673</WallAreaWidth>
<WallAreaHeight>503</WallAreaHeight>
<WallAreaWidthInches>121</WallAreaWidthInches>
<WallAreaHeightInches>94</WallAreaHeightInches>
<InchesConversionRate>5.33</InchesConversionRate>
</RoomImage>
 */
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getImageObject = function(wallName)
{
	if(wallName.indexOf(this.userBareWallNamePrefix) > -1)
	{
		return this.getUserImageObject(wallName);
	}
	else
	{
		var isEmptyWall = wallName.indexOf('hex') > -1;
		if(this.selectedWallGalleryName == null || this.selectedWallGalleryIndex == null)
			throw new Error("UserLibraryProxy.getImageObject failure! Selected wall gallery and/or selected wall gallery index not set.");
		var tmp = {};
		var walls = this.systemLibraryObject.BareWallGalleries[this.selectedWallGalleryIndex].BareWalls;
	
		for(var n = 0; n < walls.length; n++)
		{
			wallName = isEmptyWall ? this.selectedWallGalleryName : wallName;
			if(walls[n].Name == wallName)
			{
				tmp = walls[n];
				tmp.url = walls[n].ImageInformation == null ? null : this.baseUrl + walls[n].ImageInformation.LargeImage.HttpImageURL;
				tmp.thumbUrl = walls[n].ImageInformation == null ? null : this.baseUrl + walls[n].ImageInformation.ThumbnailImage.HttpImageURL;
				this.selectedWallObject = tmp;
				return tmp;
			}
			else
			{
				if(wallName.indexOf("hex") > -1)
				{
					return {};
				}
			}
		}
		throw new Error("UserLibraryProxy.getImageObject failure! no Wall Object found.");
	}
};


/**
 * Used to retrieve shared Personal BareWall
 * @param wallName
 * @returns {___anonymous12266_12267}
 */
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getUserImageObject = function(wallName)
{
	trace("UserLibraryProxy.getUserImageObject()");
	trace(this.userLibraryObject.BareWallGalleries[0].BareWalls.length);
	var tmp = {};
	for(var i=0; i < this.userLibraryObject.BareWallGalleries[0].BareWalls.length; i++)
	{
		var w = this.userLibraryObject.BareWallGalleries[0].BareWalls[i];
		trace(w.Name+"=="+wallName);
		if(w.Name == wallName)
		{
			tmp = w;
			tmp.url = w.ImageInformation.LargeImage.HttpImageURL;
			tmp.thumbUrl = w.ImageInformation.ThumbnailImage.HttpImageURL;
			this.selectedWallObject = tmp;
			trace(tmp);
			return tmp;
		}
	}
	throw new Error("UserLibraryProxy.getUserImageObject failure! no User Wall Object found.");
};


com.art.myGalleries.proxies.UserLibraryProxy.prototype.getSelectedWallId = function()
{
	if(this.selectedWallName == undefined)
		throw new Error("UserLibraryProxy.UserLibraryProxy failed! selectedWallName is undefined.");
	var n = this.selectedWallName.indexOf('hex') > -1 ? this.selectedWallGalleryName : this.selectedWallName;
	trace("UserLibraryProxy.getSelectedWallId name: "+n);
	
	if(this.flattenedWallsByName[n] == undefined)
		return -1; //throw new Error("UserLibraryProxy.getSelectedWallId failed! Wall name was not found.");
	
	var wallid = this.flattenedWallsByName[n].WallId;
	return wallid;
};

/**
 * 
 * @param itemGalleryItemId
 * @param hasWritePermission Indicates if user is viewing shared room; false is viewing shared wall
 * @returns
 */
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getPositionData = function(itemGalleryItemId,hasWritePermission)
{
	trace("UserLibraryProxy.getPositionData()");
	var wid = this.getSelectedWallId();
	if(wid == -1 && !hasWritePermission)
		return this.tempWallItems[itemGalleryItemId];
	
	return this.flattenedWallItemsByWallId[wid][itemGalleryItemId];
};
com.art.myGalleries.proxies.UserLibraryProxy.prototype.wallItemExists = function(itemGalleryItemId, hasWritePermissions)
{
	trace("UserLibraryProxy.wallItemExists");
	var wid = this.getSelectedWallId();
	
	//-1 means shared RoomView
	if(wid == -1 && !hasWritePermissions)
		return this.tempWallItems[itemGalleryItemId] != undefined;
		
	return this.flattenedWallItemsByWallId[wid][itemGalleryItemId] != undefined;
};
/**
 * From Flash DLE cache changes made to individual wallItems
 * @param obj
 */
com.art.myGalleries.proxies.UserLibraryProxy.prototype.countWallItem = function()
{
	this.totalItemsOnWall++;
};
/**
 * From Flash DLE remove WallItem
 * @param uid
 */
com.art.myGalleries.proxies.UserLibraryProxy.prototype.removeWallItem = function(ItemGalleryItemID,hasWritePermissions)
{
	this.totalItemsOnWall--;
	if(this.totalItemsOnWall < 0)
		throw new Error("UserLibraryProxy.removeWallItme error! totalItemsOnWall is < 0");
	
	if(!hasWritePermissions)
		delete this.tempWallItems[ItemGalleryItemID];
	else
		delete this.wallItemsMap[ItemGalleryItemID];
};

com.art.myGalleries.proxies.UserLibraryProxy.prototype.getWallObjectAsStringForCreateWall = function()
{
	return JSON.stringify({WallDetails:{BareWallId:this.selectedWallObject.BareWallId}});
};

/**
 * 
 * 
 * @param obj
 * @param wallID
 * @returns
 */
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getWallObjectAsStringForUpdateWall = function(items,wallID)
{
	trace("UserLibraryProxy.getWallObjectAsStringForUpdateWall()");
	trace("items.length: " + items.length);
	var data = {WallItems:items,WallId:wallID};
	var str = JSON.stringify(data); //WallDetails:this.selectedWallObject});
	trace("str: "+str);
	return str;
};
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getWallByBareWallId = function(bareWallId)
{
	var wall;
	var walls = this.userLibraryObject.Walls;
	for(var i=0; i < walls.length; i++)
	{
		var w = walls[i];
		if(w.WallDetails.BareWallId == bareWallId)
		{
			wall = w;
			break;
		}
	}
	return wall;
};
com.art.myGalleries.proxies.UserLibraryProxy.prototype.lastUpdatedIsSet = function()
{
	return this.lastUpdatedWallObject != undefined;
};
com.art.myGalleries.proxies.UserLibraryProxy.prototype.setLastUpdatedWall = function(walls)
{
	trace("UserLibraryProxy.setLastUpdatedWall");
	var tmp; //temporary date obj
	var last;
	if(this.lastUpdatedWallObject == undefined && walls.length > 0)
	{
		this.lastUpdatedWallObject = walls[0];
		last = this.parseDateUpdated(this.lastUpdatedWallObject);
		trace("last update: "+last);
	}
	for(var i=0; i < walls.length; i++)
	{
		var w = walls[i];
		tmp = this.parseDateUpdated(w); //"/Date(1313006248000-0700)/"
		trace(w.WallId+":"+tmp);
		if(tmp > last)
		{
			trace("Newer updated found: "+w.WallId);
			this.lastUpdatedWallObject = w;
			last = this.parseDateUpdated(this.lastUpdatedWallObject);
		}
		
	}
};
com.art.myGalleries.proxies.UserLibraryProxy.prototype.parseDateUpdated = function(wallObject)
{
	var str = wallObject.DateUpdated;
	if(str.indexOf("Date") == -1)
		throw new Error("UserLibraryProxy.parseDateUpdated failed! Date object not found.");
	str = str.replace(/\//g,"");
	return eval("new "+str);
	
};

com.art.myGalleries.proxies.UserLibraryProxy.prototype.getWallByWallId = function(wallid)
{
	var wall;
	var walls = this.userLibraryObject.Walls;
	for(var i=0; i < walls.length; i++)
	{
		var w = walls[i];
		if(w.WallId == wallid)
		{
			wall = w;
			break;
		}
	}
	return wall;
};
com.art.myGalleries.proxies.UserLibraryProxy.prototype.wallExists = function()
{
	trace("wallExists: "+ this.selectedWallName);
	var name = this.selectedWallName.indexOf('hex') > -1 ? this.selectedWallGalleryName : this.selectedWallName;
	trace("name: "+name);
	var b = this.flattenedWallsByName[name] ? true : false; //may be undefined
	return b;
};

/**
 * create Array FROM this.wallItemsMap hash, IF wallId is found in this.flattenedWallItemsByWallId use that object
 */
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getItemsForUpdate = function()
{
	trace("UserLibraryProxy.getItemsForUpdate()");
	var wallid = this.getSelectedWallId();
	if(wallid == -1)
		return [];
	
	trace("--wallid:"+wallid);
	trace("--wallItemsMap");
	trace(this.wallItemsMap);
	var arr = [];
	for(var itemGalleryItemId in this.wallItemsMap)
	{
		
		trace("--itemGalleryItemId:"+itemGalleryItemId);
		if(itemGalleryItemId)
		{
			var o = this.wallItemsMap[itemGalleryItemId];
			
			//check for WallItem object type
			if(o.moved == undefined)
			{
				var newObj = {	
								centerXPos:o.ProductCenterPositionX,
								centerYPos:o.ProductCenterPositionY,
								initialLoad:false,
								itemGalleryItemID:itemGalleryItemId,
								moved:false
							};
				this.wallItemsMap[itemGalleryItemId] = newObj;
				o = this.wallItemsMap[itemGalleryItemId];
			}
				
				
			var obj = new com.art.myGalleries.vos.WallItemVO(itemGalleryItemId);
			//if item in wallItemsMap has centerXPos means it was set from Flash Or item in wallItemsMap is set from adding
			trace("--object:");
			trace(o);
			//if item was moved in RoomView-DLE will be set to true see FramedImage.getItemPosition() in DLE codebase
			//we'll use this position data
			if(o.moved)
			{
				trace(o.itemGalleryItemID+" item was moved");
				o.moved = false;
				obj.ProductCenterPositionX = o.centerXPos;
				obj.ProductCenterPositionY = o.centerYPos;
				obj.ProductTargetAreaPosX = -1;
				obj.ProductTargetAreaPosY = -1;
			}
			else
			{
				trace("use existing data wallid:"+wallid+" itemGalleryItemId:"+itemGalleryItemId);
				//use existing data if item is still selected
				if( this.flattenedWallItemsByWallId[wallid][itemGalleryItemId] != undefined)
				{
					trace("use position data from flattenedWallItemsByWallId["+wallid+"]["+itemGalleryItemId+"]");
					//pull position from wallItem collection
					obj.ProductCenterPositionX = this.flattenedWallItemsByWallId[wallid][itemGalleryItemId].ProductCenterPositionX;
					obj.ProductCenterPositionY = this.flattenedWallItemsByWallId[wallid][itemGalleryItemId].ProductCenterPositionY;
					obj.ProductTargetAreaPosX = this.flattenedWallItemsByWallId[wallid][itemGalleryItemId].ProductTargetAreaPosX;
					obj.ProductTargetAreaPosY = this.flattenedWallItemsByWallId[wallid][itemGalleryItemId].ProductTargetAreaPosY;
				}
				else
				{
					trace("existing position data not found! use defaults!");
					//use current position; we'll need an update too
					this.updateWalls = true;
					obj.ProductCenterPositionX = o.centerXPos;
					obj.ProductCenterPositionY = o.centerYPos;
					obj.ProductTargetAreaPosX = 0;
					obj.ProductTargetAreaPosY = 0;
				}
			}
			arr.push(obj);
		}
	}
	return arr;
};
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getFlattenedWallItems = function(isViewingSharedRoomView)
{
	trace("UserLibraryProxy.getFlattendWallItems()");
	//support emptyRooms
	this.selectedWallName = this.selectedWallName.indexOf('hex') > - 1 ? this.selectedWallGalleryName : isViewingSharedRoomView ? this.getPersonalWallName() : this.selectedWallName;
	trace("this.selectedWallName: "+this.selectedWallName);
	
	if(this.flattenedWallsByName[this.selectedWallName] != undefined && this.flattenedWallsByName[this.selectedWallName].WallId)
	{
		var wallid = this.flattenedWallsByName[this.selectedWallName].WallId;
		return this.flattenedWallItemsByWallId[wallid];
	}
	
};

com.art.myGalleries.proxies.UserLibraryProxy.prototype.getPersonalWallName = function()
{
	trace("UserLibraryProxy.getPersonalWallName()");
	//only 1 wall when shared
	for(var name in this.flattenedWallsByName)
	{
		return name;
	}
};
/**
 * To be consumed by Flash RoomView-DLE
 */
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getSelectedWallItems = function()
{
	return [];
};
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getRooms = function(width,height,parentWidth,parentHeight)
{
	trace("UserLibraryProxy.getRooms");
	
	if(this.roomsCollection.length > 0 )
		return this.roomsCollection;
	
	
	var tmp = [];
	var cnt = 0;
	for(var i=0; i < this.systemLibraryObject.BareWallGalleries.length; i++)
	{
		var wallGallery = this.systemLibraryObject.BareWallGalleries[i];
		var name = wallGallery.Name;
		if( name == "Roomsbysize")
		{
			for(var x=0; x < wallGallery.BareWalls.length;x++)
			{
				var uuid = "emptyRoom-"+com.art.core.utils.StringUtil.generateUID();
				var emptyWall = wallGallery.BareWalls[x];
				var n = emptyWall.Name;
				var cn = name+this.EMPTY_WALL_DELIMITER+n;
				var dim = (emptyWall.WallAreaWidth/12)+"' x "+(emptyWall.WallAreaHeight/12)+"'";
				this.roomsCollection.push({label:n,name:cn,id:uuid,selected:false,data:0,isEmptyWall:true,dimension:dim});
			}
		}
		else
		{
			var numberOfWalls = wallGallery.BareWalls.length; //this.getNumberOfWalls(wallGallery,width,height,parentWidth,parentHeight);
			if(numberOfWalls > 0)
			{
				var selected = cnt == 0;
				var uid = wallGallery.GalleryId; //com.art.core.utils.StringUtil.generateUID();
				this.roomsCollection.push({label:name,name:name,id:uid,selected:selected,data:numberOfWalls,isEmptyWall:false} );
				cnt++;
			}
		}
	}
	return this.roomsCollection;
};

com.art.myGalleries.proxies.UserLibraryProxy.prototype.getEmptyRoomIdByName = function(name)
{
	trace("UserLibraryProxy.getEmptyRoomIdByName");
	for(var i = 0; i < this.getRooms().length; i++)
	{
		if( this.getRooms()[i].name == name)
			return  this.getRooms()[i].id;
	}
};


//for retrieving wall object when viewing shared room
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getSelectedSharedWallObject = function()
{
	if(this.selectedSharedWallObject != null)
		return this.selectedSharedWallObject;
	
	for(var i=0; i < this.wallsObject.length; i++)
	{
		var w = this.wallsObject[i];
		if(w.WallId == this.sharedWallId)
		{
			this.selectedSharedWallObject = w;
			return this.selectedSharedWallObject;
		}
	}
	throw new Error("UserLibraryProxy.getSelectedSharedWallObject failed! SharedWallId can't be resolved.");
};

//for retrieving wall object when NOT viewing shared room
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getSelectedWallObject = function()
{	
	for(var i=0; i < this.wallsObject.length; i++)
	{
		var w = this.wallsObject[i];
		trace(w.WallDetails.Name+"=="+this.selectedWallObject.Name);
		if(w.WallDetails.Name == this.selectedWallObject.Name)
		{
			return w;
		}
	}
	throw new Error("UserLibraryProxy.getSelectedWallObject failed! SharedWallId can't be resolved.");
};

com.art.myGalleries.proxies.UserLibraryProxy.prototype.getGalleryByWallId = function(wallObject)
{
	trace("UserLibraryProxy.getGalleryByWallId()");
	//first check system
	var systemGalleries = this.systemLibraryObject.BareWallGalleries;
	for(var i=0; i < systemGalleries.length; i++)
	{
		var g = systemGalleries[i];
		for(var ii=0; ii < g.BareWalls.length;ii++)
		{
			if(g.BareWalls[ii].BareWallId == wallObject.WallDetails.BareWallId)
			{
				this.selectedSharedBareWallIndex  = ii;
				return g;
			}
		}
	}
	
	//lets check user library
	var userGalleries = this.userLibraryObject.BareWallGalleries;
	for(var h=0; h < userGalleries.length; h++)
	{
		var ug = userGalleries[h];
		for(var hh=0; hh < ug.BareWalls.length; hh++)
		{
			if(ug.BareWalls[hh].BareWallId == wallObject.WallDetails.BareWallId)
			{
				this.selectedSharedBareWallIndex = hh;
				return ug;
			}
			
		}
	}
	throw new Error("UserLibraryProxy.getGalleryByWallId failed! No System Gallery found.");
};
/**
 * Check if gallery has walls
 * 
 * 
 */
com.art.myGalleries.proxies.UserLibraryProxy.prototype.galleryHasWalls = function()
{
	var walls = this.systemLibraryObject.BareWallGalleries[this.selectedWallGalleryIndex].Walls;
	var bool = walls.length > 0;
	return bool;
};

com.art.myGalleries.proxies.UserLibraryProxy.prototype.getWallId = function(wallName)
{
	var key = wallName.indexOf("hex") > -1 ? this.selectedWallGalleryName : wallName;
	
	if(!this.flattenedWallsByName[key])
		throw new Error("TitleBarModule.getRoomViewQuerystringVals failed! Wall not found.");
	
	return this.flattenedWallsByName[key].WallId;
};

//get hex value by selectedWallName
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getHexValue = function(wallName)
{
	return wallName.indexOf("hex") > -1 ? "/"+wallName : "";  
};

/**
 * Filter out wall images that will NOT work with current hero image displayed on wall, non-custom walls have predefined usable surface area
 * if hero image is greater than this do not include in available wall collection
 * @method getNumberOfWalls
 * @param wallGalleryObject
 */
com.art.myGalleries.proxies.UserLibraryProxy.prototype.getNumberOfWalls = function(wallGalleryObject,width,height,parentWidth,parentHeight)
{
	var cnt = 0;
	for(var w=0; w < wallGalleryObject.BareWalls.length;w++)
	{
		if(this.wallCanAccomodateImage(wallGalleryObject.BareWalls[w],width,height,parentWidth,parentHeight)) cnt++;
	}
	return cnt;
};
/**
 * Ensure hero image can fit on wall see method getNumberOfWalls
 * @method wallCanAccomodateImage
 * @param wallObject
 * @param width
 * @param height
 * @param parentWidth
 * @param parentHeight
 * @returns {Boolean}
 */
com.art.myGalleries.proxies.UserLibraryProxy.prototype.wallCanAccomodateImage = function(wallObject,width,height,parentWidth,parentHeight)
{
	var usableWidthPixels 	= wallObject.UsableAreaWidth;
	//TODO fix this value is always 0
	var usableHeightPixels	= 500; //wallObject.UsableAreaHeight;
	var pixelsPerInch		= wallObject.WallAreaWidth / wallObject.WallAreaWidthInches;
	var usableWidthInches 		= Math.round(usableWidthPixels/pixelsPerInch);
	var usableHeightInches		= Math.round(usableHeightPixels/pixelsPerInch);
	var pWI = parentWidth/pixelsPerInch; //parent width Inches
	var pHI = parentHeight/pixelsPerInch; //parent height Inches
	return (usableWidthInches >= width) && (usableHeightInches>= height) && ((pWI) > width) && ((pHI) > height);
};