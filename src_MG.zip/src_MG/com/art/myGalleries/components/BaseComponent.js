com.art.myGalleries.components.BaseComponent = function(){};
/*
 * common elements of component library
 */
com.art.myGalleries.components.BaseComponent.requiredMethods 	= ['registerEvents','registerCallbacks','render','getTemplate'];
com.art.myGalleries.components.BaseComponent.properties 	= [{name:'callbacks',type:{}},{name:'initialized',type:false}];
com.art.myGalleries.components.BaseComponent.extend = function(subclass)
{
	
	for(var r = 0; r < com.art.myGalleries.components.BaseComponent.requiredMethods.length; r++)
	{
		var m = com.art.myGalleries.components.BaseComponent.requiredMethods[r];
		trace(r+": "+m);
		if(subclass[m] == undefined)
			subclass[m] = function(){ var methodName = m; trace("methodName: "+methodName);throw new Error(subclass.id+" failure! Required method "+methodName+" has not been implmented.");};
	}
	trace(subclass);
	subclass['callbacks'] = {};
	//subclass['prototype']['registerEvents'] = function(){ throw new Error(subclass.NAME+" BaseComponent.registerEvent() has not been overriden.");};

};