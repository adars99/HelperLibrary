com.art.myGalleries.components.ItemComponent = function(url,apnum,side,imageDomain)
{
	this.apnum = apnum;
	this.url = url;
	this.side = side;
	this.imageDomain = imageDomain;
	this.callbacks = {};
	this.uniqueid;
};
com.art.myGalleries.components.ItemComponent.HOVER = "hover";
com.art.myGalleries.components.ItemComponent.prototype.render = function()
{
	return this.getTemplate();
};
com.art.myGalleries.components.ItemComponent.prototype.dropShadow = function()
{
	var imgObj = $("#img_"+this.apnum);
	var _this = this;
	$(imgObj).hide();
	$(imgObj).load(function(){
		var imgProperties = {width:$(this).width(), height:$(this).height()};
		
		var _HD = ($("#"+_this.apnum).height() - imgProperties.height);
		var _WD = ($("#"+_this.apnum).width() - imgProperties.width);
    
		var tp, bt, rp, lp;
		//Calculate the Padding needed.
	    if (_HD > 0)
	    {
	       tp = _HD / 2;
	       bp = (_HD - tp);
	    }
	    if (_WD > 0)
	    {
	       rp = _WD / 2;
	       lp = (_WD - rp);
	    }
	    
	    trace(_HD+":"+imgProperties.height+":"+tp+":"+bt+":"+rp+":"+lp);
	    var ImgRightTop     = '<img alt="" style="top:'+ tp +'px; left: '+(imgProperties.width + lp ) +'px;" class="abs w8 h10" src="http://cache1.artprintimages.com/images/photostoart/shadow_righttop_E5E7DC.png" />';
		var ImgRightTiling  = '<img height="'+ (imgProperties.height  - 10)+'" alt="" style="top:'+ (tp + 10) +'px; left:'+(imgProperties.width + lp ) +'px;" class="abs w8" src="http://cache1.artprintimages.com/images/photostoart/shadow_righttiling_E5E7DC.png" />';
		var ImgBottomLeft   = '<img alt="" style="top:'+ (imgProperties.height + tp ) +'px; left: '+ (lp ) +'px;" class="abs w8 h8" src="http://cache1.artprintimages.com/images/photostoart/shadow_bottomleft_E5E7DC.png" />';
		var ImgBottomTiling = '<img width="'+(imgProperties.width - 8 )+'" alt="" style="top:'+ (imgProperties.height  + tp) +'px; left: '+(lp+8) +'px;" class="abs h8" src="http://cache1.artprintimages.com/images/photostoart/shadow_bottomtiling_E5E7DC.png" />';
		var ImgBottomRight  = '<img alt="" style="top:'+ (imgProperties.height  + tp) +'px; left: '+(imgProperties.width + lp ) +'px;" class="abs w8 h8" src="http://cache1.artprintimages.com/images/photostoart/shadow_bottomright_E5E7DC.png" />';
		
		var strDropShadow
			= "<div class='imgDropShadowContainer'>"
			+ 		ImgRightTop
			+ 		ImgRightTiling
			+ 		ImgBottomLeft
			+ 		ImgBottomTiling
			+ 		ImgBottomRight
			+ "</div>";
		$(imgObj).css('position', 'absolute');
		$(imgObj).css('left', lp);
		$(imgObj).css('top', tp);
		$(imgObj).after(strDropShadow);
		$(imgObj).show();
	});
	
};

com.art.myGalleries.components.ItemComponent.prototype.registerCallback = function(eventName,callback)
{
	this.callbacks[eventName] = callback;
};
com.art.myGalleries.components.ItemComponent.prototype.registerEvents = function()
{
	if(this.apnum != undefined)
	{
		var _this = this;
		$("#"+this.apnum).die();
		$("#"+this.apnum).unbind('mouseenter');
		$("#"+this.apnum).mouseenter(function(){
			trace("apnum: "+_this.apnum);
			setTimeout(function(){
				_this.callbacks[com.art.myGalleries.components.ItemComponent.HOVER](_this.apnum);
			},500);
		});
	}
};
com.art.myGalleries.components.ItemComponent.prototype.getTemplate = function()
{	
	if($.browser.msie) this.side = this.side+2;
	var str = this.template.replace(/\$S/g,this.side).replace("$B",this.url).replace("$I",this.apnum).replace("$Imd",this.apnum).replace('$D', this.imageDomain);
	return str;
};

com.art.myGalleries.components.ItemComponent.prototype.template 
= "<div class='thumbs' style='float:left;width:$Spx;height:$Spx;' id='$I'>"
+ 		"<img src='$B' id='img_$Imd'/>"
+ "</div>";

