/**
*
* @param id - SlideShow Button ID
* @param slideshowLabel - SlideShow string label* 
* 
* 
*/
com.art.myGalleries.components.SlideShowButton = function (id,slideshowLabel) {
    

    this.NAME = com.art.myGalleries.components.SlideShowButton.NAME;    
    this.ACTIVE_CLICKED = com.art.myGalleries.components.SlideShowButton.ACTIVE_CLICKED;
    
    this.id = id;
    this.label_3 = slideshowLabel;
    this.initialized = false;
    this.callbacks = {};
    this.CLICK = com.art.myGalleries.components.SlideShowButton.CLICK;
    com.art.core.components.BaseComponent.extend(this);
    
};
com.art.myGalleries.components.SlideShowButton.CLICK = "SlideShowButtonClick";
com.art.myGalleries.components.SlideShowButton.NAME = "SlideShowButton";
com.art.myGalleries.components.SlideShowButton.SSACTIVE_CLICKED = "activeSlideShowClicked";

/**
* call the getTemplate() method and render it
*/
com.art.myGalleries.components.SlideShowButton.prototype.render = function () {
    return this.getTemplate();
};

/**
* registerEvents is called only once on initialization
*/
com.art.myGalleries.components.SlideShowButton.prototype.registerEvents = function () {
      
};

/**
* Use this method to register the callback method
*@param name - name of the event e.g. click, hover etc
*@param callback - call the callback method to fire the event
*/

com.art.myGalleries.components.SlideShowButton.prototype.registerCallback = function (name, callback) {
 
    this.callbacks[name] = callback;
    trace("callbacks:");
    trace(this.callbacks);
};


/**
* Use this method to return the changed content
*/
com.art.myGalleries.components.SlideShowButton.prototype.getTemplate = function () {
    return this.template.replace("$ID", this.id).replace("$LABEL_3", this.label_3);
};

/**
* This is the HTML content which will render
*/
com.art.myGalleries.components.SlideShowButton.prototype.template = "<div id='$ID'>" +
    "<div class='leftMenubtn'></div>" +
    "<div id='slideShow' class='slideShowMenuLabel'>$LABEL_3</div>" +
	"<div class='rightMenubtn'></div>" +
    "<div class='clear'></div>"+
    "</div>";

