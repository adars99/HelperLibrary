com.art.myGalleries.components.PaginationComponent = function(id, totalcount)
{
	com.art.core.components.BaseComponent.extend(this);
	
	this.NAME = com.art.myGalleries.components.PaginationComponent.NAME;
	this.id = id;
	this.totalcount = totalcount;
	this.RecordsPerPage = 9;
	this.totalpage = Math.floor(this.totalcount/this.RecordsPerPage);;
	this.prevID = 'pagePrev';
	this.nextID = 'pageNext';
	this.contentID = 'pageContent';
	this.DATACONTENT = null;
	this.selectedPage = 1;
	this.nextLabelEnabled = false;
	this.previousLabelEnabled = false;
};
com.art.myGalleries.components.PaginationComponent.NAME = "PaginationComponent";


com.art.myGalleries.components.PaginationComponent.prototype.registerEvent = function()
{
	$('#page'+this.selectedPage).addClass('pageLISelected');
	// Page Click
	$('.pageLI').hover( function() {$(this).css('text-decoration', 'underline'); }, function() { $(this).css('text-decoration', 'none'); });
	$('.pageLI').click(function()
	{
		$('.pageLI').removeClass('pageLISelected');
		$(this).addClass('pageLISelected');
	});
	
	var n = $("#"+this.nextID);
	var p = $("#"+this.prevID);
	var _this = this;
	trace("Page:"+this.selectedPage);
	if(this.selectedPage > 1) this.previousLabelEnabled = true;
	if(this.selectedPage < this.totalpage) this.nextLabelEnabled = true;
	
	if(this.nextLabelEnabled)
	{
		n.css('cursor','pointer');
		n.hover( function(){$(this).css('text-decoration', 'underline'); }, function() { $(this).css('text-decoration', 'none'); });
		n.unbind('mouseenter');
		n.unbind('mouseleave');
		n.die(); //always clear first
		n.hover( function(){$(this).css('text-decoration', 'underline'); }, function() { $(this).css('text-decoration', 'none'); });
		n.live("click",function(){
			_this.doNext();
		});
	}
	else
	{
		n.css("cursor","default").css('color', 'red');
		n.die();
		n.unbind('mouseenter');
		n.unbind('mouseleave');
	}
	if(this.previousLabelEnabled)
	{
		p.css('cursor','pointer');
		p.hover( function(){$(this).css('text-decoration', 'underline'); }, function() { $(this).css('text-decoration', 'none'); });
		p.unbind('mouseenter');
		p.unbind('mouseleave');
		p.die();//always clear first
		p.hover( function(){$(this).css('text-decoration', 'underline'); }, function() { $(this).css('text-decoration', 'none'); });
		p.live("click",function(){
			_this.doPrevious();
		});
	}
	else
	{
		p.css("cursor","default").css('color', 'red');
		p.die();
		p.unbind('mouseenter');
		p.unbind('mouseleave');
	}
	
	
};


com.art.myGalleries.components.PaginationComponent.prototype.render = function()
{
	this.updateContent();
	return this.getTemplate();
};

com.art.myGalleries.components.PaginationComponent.prototype.updateContent = function()
{
	var strLi = '';
	this.totalpage = Math.floor(this.totalcount/this.RecordsPerPage);
	for(var i=0;i<this.totalpage;i++){
		if(i == this.totalpage-1){
			strLi +="<li id='page"+(i+1)+"' class='pageLI pageLILast'>"+(i+1)+"</li>";
		}	
		else {
			strLi +="<li id='page"+(i+1)+"' class='pageLI'>"+(i+1)+"</li>";
		}	
	}	
	var str
			=	'<ul class="pageUL">'
			+   	strLi	
			+	'</ul>';	
	this.DATACONTENT =  str;
};
com.art.myGalleries.components.PaginationComponent.prototype.getTemplate = function()
{
	return this.template.replace("$ID", this.id).replace("$PREV", this.prevID).replace("$NEXT", this.nextID).replace("$CONTENT", this.contentID).replace("$DATACONTENT",this.DATACONTENT);
};

com.art.myGalleries.components.PaginationComponent.prototype.template
= 		"<div id='$ID' style='float: left; margin-top: 15px;margin-right: 15px;color:#414D5B;'>"
+			"<div id='$PREV' style='float:left;margin-right: 5px;'>Previous</div>"
+			"<div id='$CONTENT' style='float:left;'>$DATACONTENT</div>"
+			"<div id='$NEXT' style='float:left;margin-left: 5px;'>Next</div>"
+		"</div>";