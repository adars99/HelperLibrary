com.art.myGalleries.components.ItemHoverComponent = function()
{
	this.apnum;
	this.id = "MyGalleryHover";
	this.data;
	this.detailsDelayTimerID;
	this.popupHovered = false;
	this.superZoom = new com.art.core.components.SuperZoom("itemHoverSZ",1000);
	this.currencyCode;
	this.zW = 58;
    this.zH = 70;
};


com.art.myGalleries.components.ItemHoverComponent.prototype.init = function()
{
	
	var _this = this;

	$('.MyGalleriesBtn').live('mouseover', function(){
		
    	var _this = this;
    	var id = $(this).attr('id');
    	if (id != null && id != undefined) {
            switch (id) {
                case "MyGalleriesHoverShare": case "MyGalleriesHoverAddFrame": case "MyGalleriesHoverZoom": case "MyGalleriesAddToCartIcon":
                    $("#" + id).addClass("dynamicRightMenuContainer");
                    break;
                default:
                    trace("others");
            }
        }
    });
    
    $('.MyGalleriesBtn').live('mouseout', function(){
    	var id = $(this).attr('id');
    	if (id != null && id != undefined) {
            switch (id) {
                case "MyGalleriesHoverShare": case "MyGalleriesHoverAddFrame": case "MyGalleriesHoverZoom": case "MyGalleriesAddToCartIcon":
                    $("#" + id).removeClass("dynamicRightMenuContainer");
                    break;
                default:
                    trace("others");
            }
        }
    });

	$('#modalfullDetailsArtist').live('mouseover', function(){
		$(this).css('text-decoration', 'underline');
	});
	
	$('#modalfullDetailsArtist').live('mouseout', function(){
		$(this).css('text-decoration', 'none');
	});
	
	$('.MyGalleriesLink').live('click', function() {
		var cat = MyGalleriesCore.getModel().currentViewMode == MyGalleriesCore.constants.GRID_VIEW ? "Grid" : "Entry";
		if(cat == "Entry"){
    		mygalleriesGA.trackEventWithCategory(cat, "Enter gallery - clicked");	
        }
        else
        	mygalleriesGA.trackEventWithCategory(cat, "View grid");
    });

    $('.MyGalleryTitleText').live('click', function() {
        mygalleriesGA.trackEventWithCategory("Entry", "Enter gallery - clicked");
        mygalleriesGA.trackEventWithCategory("Grid", "View grid");
    });
	
	$("#modalfullDetailsArtist").live('click', function(){
		var ArtistUrl="http://"+window.location.hostname+_this.data.GalleryItemData.ArtistUrl+"?ui="+getCookie('CustSessionID');		
		location.href = ArtistUrl;
	});	
	
    $('#MyGalleriesAddToCartIcon').live('click', function() {
        //GotoCart(RecordThumbDetails.MasterProductID, RecordThumbDetails.MasterSpecID, getCookie('CustSessionID'), SessionInfo.CustomerZoneID, '', '', RecordThumbDetails.PODConfigID);
    });
    
   
    $('#MyGalleriesHoverZoom').live('click', function() {
    	
    	var zWidth, zHeight;

	    if (typeof window.innerWidth != 'undefined') {	    
	        zWidth = window.innerWidth - _this.zW;
	        zHeight = window.innerHeight - _this.zH;
	    }
	    else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
	        //IE 6+ in 'standards compliant mode' 
	    
	        zWidth = document.documentElement.clientWidth - _this.zW;
	        zHeight = document.documentElement.clientHeight - _this.zH;
	    }
		
		var zoomUrl = com.art.core.utils.BrowserUtil.getCroppedImageUrl( _this.data.GalleryItemData.CropperUrl,zWidth, zHeight, com.art.core.utils.BrowserUtil.cropperModes.NONE);
		
    	//var icon2 = "<div style='background-image:url(http://cache1.artprintimages.com/images/mygallery/my_galleries_sprite.png); background-position:0px -169px;width:48px;height:24px;'/>";
		//var szob = new com.art.core.components.OptionButton("szOptionButton",icon2+"<div style='font-family:verdana;font-size:11px;width:48px;color:#333333; text-shadow: 0 1px #FFFFFF;'>Share</div>",50,50,[{label:"Share via Facebook",value:"facebook",selected:false},{label:"Send Email to Friend",value:"email",selected:false}]);

		
//		sz.attachExternalComponent(szob);
//		sz.registerCallback(com.art.core.components.SuperZoom.IMAGE_LOADED,function(){
//			trace("Zoom image loaded");
//			szob.zindex = sz.getNextHighestZIndex(); //relative to sz
//			//szob.registerEvents();
//		});
		_this.superZoom.show(zoomUrl);
    	
    });	
    
    //moved addToCart from here
};


com.art.myGalleries.components.ItemHoverComponent.prototype.render = function()
{
	this.init();
	return this.getTemplate();
};
com.art.myGalleries.components.ItemHoverComponent.prototype.positionHover = function(hoverflag)
{
	var $objParent = $("#"+this.apnum);
	var offset = ($('#'+this.id).width());
	var top;
	//alert($objParent.offset().top);
	//if($objParent.offset().top!=null)
	//	{
			top= $objParent.offset().top;
//		}
//	else
//		{
	//		top=20;
//		}
    var left = $objParent.offset().left;
    var margin = 15;
    var docViewTop = $(window).scrollTop();
    var docViewBottom = docViewTop + $(window).height();
    
    var elemBottom = top + $('#'+this.id).height();
    
    if (top < docViewTop)
        top = docViewTop;
    else if (elemBottom > (docViewBottom))
        top = docViewBottom - $('#'+this.id).height() - margin;
     /*if($objParent.offset().left > $objParent.width()*2){
    	left = $objParent.offset().left - ($('#'+this.id).width() - $objParent.width() - 12);
    	if($.browser.msie) left = $objParent.offset().left - ($('#'+this.id).width() - $objParent.width() - 7);
    }	
    else
    	left = $objParent.offset().left;*/
    if(hoverflag)
    {
    	$('#'+this.id).css("left",left-15);
    	$('#'+this.id).css("top",top-15);
    }
    else
    {
    	$('#'+this.id).css("left",left-89);
    	$('#'+this.id).css("top",top-1);
    }
};
com.art.myGalleries.components.ItemHoverComponent.prototype.fadeOut = function()
{
	if(this.popupHovered == false)
		$("#"+this.id).fadeOut();
};
com.art.myGalleries.components.ItemHoverComponent.prototype.fadeIn = function()
{
	$("#"+this.id).fadeIn();
};

com.art.myGalleries.components.ItemHoverComponent.prototype.setData = function(data, apnum)
{
	trace(data);
	this.data 				= data;
	this.apnum				= apnum;
};
com.art.myGalleries.components.ItemHoverComponent.prototype.showGalleryItemHover = function()
{
	trace("udpate");
	
	this.getGalleryItemHoverContent(); // render the hover content
	this.positionHover(false);
	var share = new com.art.myGalleries.components.OptionButton('MyGalleriesHoverShare', 'Share', this.getShareBtnContent(), 220, 70, 0);
	$("#MyGalleriesHoverShareContainer").append(share.render());	   
	
	var shareBtn = $('#MyGalleriesHoverShare');
	
	shareBtn.live('click', function () {
	    $("#MyGalleriesHoverShare_toggle").css("position", "absolute");
	    $("#MyGalleriesHoverShare_toggle").css("top", "-73px");
	    $("#MyGalleriesHoverShare_toggle").show();
	});
	
	shareBtn.mouseleave(function () {
	    shareBtn.removeClass("HoverShareBtn");
	    $("#MyGalleriesHoverShare_toggle").hide();
	});
	
	shareBtn.mouseenter(function () {
	    shareBtn.addClass("HoverShareBtn");
	});	
};
com.art.myGalleries.components.ItemHoverComponent.prototype.showGalleryListHover = function()
{
	trace("udpate");
	this.getGalleryListHoverContent(); // render the hover content
	this.positionHover(true);
};

com.art.myGalleries.components.ItemHoverComponent.prototype.getGalleryListHoverContent = function()
{
	var _this     = this;	
	var imgObj = $("#"+this.apnum+" .ImgContainer");
	var imgProperties = {width:imgObj.width(), height:imgObj.height()};
	
	var length = 175;
	var w = 0, h = 0, tp = 0, lp = 0;
    var aspectRatio = imgProperties.width / imgProperties.height; 
    if (aspectRatio > 1)
    {
        w = length;
        h = length / aspectRatio;
        tp = (w - h) / 2;
    }
    else
  	{
    	w = length * aspectRatio;
    	h = length;
    	lp = (210 - w) / 2;
    }
    
    imgProperties.width = Math.floor(w);
    imgProperties.height = Math.floor(h);
	
	//$('.VSResultsInfoIcon').remove();
	var src =$(imgObj).find('img').attr('src');
	var href =$(imgObj).find('a').attr('href');
	if($("#ImgfullResContainer").length > 0) $("#ImgfullResContainer").remove();
	$('#ImgfullResContainer').live('click', function() {
	    mygalleriesGA.trackEventWithCategory("Entry", "Enter gallery - clicked");
	    mygalleriesGA.trackEventWithCategory("Grid", "View grid");
	});
	//var imgContainer = "<a href='"+href+"'><img style='display:none;' src='"+src+"'></img></a>";
	var imgContainer = "";
	var u = _this.data.GalleryData.LastGalleryImageUrl;
	var newImg = "<div id='ImgfullResContainer' galleryurl='"+href+"' style='background-position:center center;background-repeat:no-repeat;cursor:pointer;margin-top:10px;margin-left:15px;margin-bottom:15px;width:175px;height:"+imgProperties.height+"px;'>"+ imgContainer +"</div>";
	$("#"+this.id).append(newImg);
	$('#ImgfullResContainer').css('background-image', "url('"+src+"')");
	//$('#ImgfullResContainer img').css('margin-top', tp);
	//$('#ImgfullResContainer img').css('margin-left', lp);
	/*$('#ImgfullResContainer img').attr('width', '100%');
	$('#ImgfullResContainer img').attr('height', '100%');*/
	$('#ImgfullResContainer img').show();
	
	if($("#showGalleryListHoverContainer").length > 0) $("#showGalleryListHoverContainer").remove();
	$('#showgalleryviewedit').live('click', function() {
	    mygalleriesGA.trackEventWithCategory("Entry", "Enter gallery - clicked");
	    mygalleriesGA.trackEventWithCategory("Grid", "View grid");
	});
	
	$('#ImgfullResContainer').live('click', function() {
	   window.location.href = $(this).attr('galleryurl');
	});
	
	var showDetails  = "<div id='showGalleryListHoverContainer'>";
		showDetails += "<div style='align:center' id='showgalleryviewedit' ><a style='text-decoration:none;' href='"+ href +"' alt='' title=''>View & Edit</a></div>";
		//showDetails += "<div style='float:left;color:#FFF;'>|</div>";
		//showDetails += "<div style='float:left;' id='showgallerydelete'>Delete</div>";
		showDetails += "</div>";
	$("#"+this.id).append(showDetails);
	
};

com.art.myGalleries.components.ItemHoverComponent.prototype.getGalleryItemHoverContent = function()
{
	this.getImageWithDropShadow();
	this.getItemDetails();
	this.getItemLinks();
	this.getItemButtons();
	
};

com.art.myGalleries.components.ItemHoverComponent.prototype.getImageWithDropShadow = function()
{
	var _this     = this;
	var imgProperties = {width:_this.data.GalleryItemData.Width, height:_this.data.GalleryItemData.Height};
	trace(imgProperties.width+"--"+ imgProperties.height);
	var length = 400;
	var w = 0, h = 0, tp = 0, lp = 0;
    var aspectRatio = imgProperties.width / imgProperties.height; 
    if (aspectRatio > 1)
    {
        w = length;
        h = length / aspectRatio;
        tp = (w - h) / 2;
    }
    else
  	{
    	w = length * aspectRatio;
    	h = length;
    	lp = (438 - w) / 2;
    }
    
    imgProperties.width = Math.floor(w);
    imgProperties.height = Math.floor(h);
    
    if($.browser.msie) tp = 14; else  tp = 10;
    
    if(lp == 0) lp = 18;
    
	var mygalleryproductpageurl = '';
	mygalleryproductpageurl = $("#"+this.apnum).attr('MyGalProductPageUrl');
	if($("#ImgfullResContainer").length > 0) $("#ImgfullResContainer").remove();
	var u = _this.data.GalleryItemData.ImageUrl;
	var newImg = "<div id='ImgfullResContainer' style='margin-bottom:10px;width:410px;margin-left:"+lp+"px;height:"+ imgProperties.height +"px;'><a href='"+ mygalleryproductpageurl +"' class='MyGalleryATag' ><img src='"+u+"' width='"+ imgProperties.width +"'  height='"+ imgProperties.height +"' id='imgFullRes' style='z-index:400;cursor:pointer;'/></a></div>";
	$("#"+this.id).append(newImg);
    
	$('#ImgfullResContainer').live('click', function() {
        mygalleriesGA.trackEventWithCategory("Details", "View Details");
    });
	
	if(_this.data.GalleryItemData.AppendShadow)
	{
		var ImgRightTop     = '<img alt="" style="top:'+ tp +'px; left: '+(imgProperties.width + lp ) +'px;" class="abs w8 h10" src="http://cache1.artprintimages.com/images/photostoart/shadow_righttop_E5E7DC.png" />';
		var ImgRightTiling  = '<img height="'+ (imgProperties.height  - 10)+'" alt="" style="top:'+ (tp + 10) +'px; left:'+(imgProperties.width + lp ) +'px;" class="abs w8" src="http://cache1.artprintimages.com/images/mygallery/shadow_righttiling_E5E7DC.png" />';
		var ImgBottomLeft   = '<img alt="" style="top:'+ (imgProperties.height + tp ) +'px; left: '+ (lp ) +'px;" class="abs w8 h8" src="http://cache1.artprintimages.com/images/photostoart/shadow_bottomleft_E5E7DC.png" />';
		var ImgBottomTiling = '<img width="'+(imgProperties.width - 8 )+'" alt="" style="top:'+ (imgProperties.height  + tp) +'px; left: '+(lp+8) +'px;" class="abs h8" src="http://cache1.artprintimages.com/images/mygallery/shadow_bottomtiling_E5E7DC.png" />';
		var ImgBottomRight  = '<img alt="" style="top:'+ (imgProperties.height  + tp) +'px; left: '+(imgProperties.width + lp ) +'px;" class="abs w8 h8" src="http://cache1.artprintimages.com/images/photostoart/shadow_bottomright_E5E7DC.png" />';
		
		var strDropShadow
			= "<div class='imgDropShadowContainer'>"
			+ 		ImgRightTop
			+ 		ImgRightTiling
			+ 		ImgBottomLeft
			+ 		ImgBottomTiling
			+ 		ImgBottomRight
			+ "</div>";
		$('#imgFullRes').after(strDropShadow);
	}
	$('#imgFullRes').css('position', 'absolute');
	$('#imgFullRes').css('left', lp);
	$('#imgFullRes').css('top', tp);
		
};
com.art.myGalleries.components.ItemHoverComponent.prototype.getItemDetails = function()
{
	var _this     = this;
	var imgParentObj = $("#imgFullRes").parent().parent();
	
	var itemTitle   	= _this.data.GalleryItemData.Title;
	var itemArtistName  = _this.data.GalleryItemData.ArtistName;
	var showArtistClass="";	
	var showArtistSubClass="";
			
	if(_this.data.GalleryItemData.ArtistUrl==null){	  
	  showArtistClass="hidden";
	}
	else{
	  showArtistSubClass="hidden";
	}		
	
	if(_this.data.GalleryItemData.ShowMarkDownPrice)
	{
		var itemPrice   	= "<span style='text-decoration: line-through;margin-left:3px;'>"+_this.data.GalleryItemData.ItemDetails.ItemPrice.DisplayMSRP+"</span><span style='color:indianred;margin-left:3px;font-style:italic;'>"+ _this.data.GalleryItemData.ItemDetails.ItemPrice.DisplayPrice +"</span>";
	}
	else
	{
		var itemPrice   	= _this.data.GalleryItemData.ItemDetails.ItemPrice.DisplayPrice;
	}
	_this.currencyCode = _this.currencyCode != "" ? _this.currencyCode : "USD";
	var convertToCmFlag = com.art.core.utils.LocalizationManager.determineConvertToCm("", _this.currencyCode, "");
	var itemSize		=  com.art.core.utils.StringUtil.formatDimensions(_this.data.GalleryItemData.PhysicalDimensionWidth, _this.data.GalleryItemData.PhysicalDimensionHeight,convertToCmFlag) ;
	
	var strItemTitleArtistName     = "<div class='MyGalleriesText' style='text-align:center;margin-bottom:1px;'>"+itemTitle+"<span id='modalfullDetailsArtist' class='"+showArtistClass+"' style='margin-left:5px;color:#0072BC;cursor:pointer'>"+itemArtistName+"</span><span id='myGalArtistName' class='"+showArtistSubClass+"' style='margin-left:5px;'>"+itemArtistName+"</span></div>";
	var strItemSize 		   	   = "<div class='MyGalleriesText' style='text-align:center;margin-bottom:1px;'>"+ itemSize+ "</div>";
	var strItemPrice			   = "<div class='MyGalleriesText' style='font-size:11px;font-weight:bold;text-align:center;margin-bottom:1px;color:#666666;'>"+itemPrice+"</div>";
	
	if($(".imgItemDetailsContainer").length > 0) $(".imgItemDetailsContainer").remove();
	var strItemDetails 
		= "<div class='imgItemDetailsContainer'>"
		+ 		strItemTitleArtistName
		+ 		strItemSize
		+ 		strItemPrice
		+ "</div>";
	$(imgParentObj).after(strItemDetails);
};
com.art.myGalleries.components.ItemHoverComponent.prototype.getItemLinks = function()
{
	var _this     = this;
	
	
	
	if($('.MyGalleriesTitleDescLinks').css('display') != "none")
	{
		var commentsItem		= "<div id='CommentsGalleryItem' class='MyGalleriesText' style='width:130px;padding:2px 0px;margin:0 5px;float:left;text-align:center;color:#0072BC;cursor:pointer;'>Comments</div>";
		var movetogalleryItem	= "<div id='MoveToAnotherGallery' class='MyGalleriesText' style='width:150px;padding:2px 0px;margin:0 5px;float:left;text-align:center;color:#0072BC;cursor:pointer;'>Move to Another Gallery</div>";
		var deleteItem			= "<div id='DeleteItem' class='MyGalleriesText' style='width:125px;padding:2px 0px;margin:0 5px;float:left;text-align:center;color:#0072BC;cursor:pointer;'>Remove</div>";
	}
	else
	{
		var commentsItem		= "<div id='CommentsGalleryItem' class='MyGalleriesText' style='width:100%;padding:2px 0px;float:left;text-align:center;color:#0072BC;cursor:pointer;'>Comments</div>";
		var movetogalleryItem = '';
		var deleteItem = '';
	}
	
	if($(".imgItemLinksContainer").length > 0) $(".imgItemLinksContainer").remove();
	var strItemLinks
		= "<div class='imgItemLinksContainer'>"
			+ 		commentsItem
			+ 		movetogalleryItem
			+ 		deleteItem
        + "<div class='clear'></div></div>";
	$(".imgItemDetailsContainer").after(strItemLinks);
};

/**
* Used this method to get share b(y menu HTML on right nav. control bar.
* @method getShareBtnContent
*/
com.art.myGalleries.components.ItemHoverComponent.prototype.getShareBtnContent = function () {
    return [
	        '<ul id="HoverNavShare" class="shareNav">' +
	        	'<li><a href="#" id="shareEmail">Share via Email</a></li>' +
	        	'<li><a href="#" id="shareFacebook">Share via Facebook</a></li>' +
	        '</ul>'
	];
};

com.art.myGalleries.components.ItemHoverComponent.prototype.getItemButtons = function()
{
	var _this     = this;
	var ShareItem			= "<div  id='MyGalleriesHoverShareContainer' class='MyGalleriesBtn MyGalleriesText'></div>";

	
	var itemGalleryItem = _this.data.GalleryItemData || "";
	var AddFrameItem		= "";
	if(itemGalleryItem != "")
	{
		var frameObj = itemGalleryItem.ItemDetails.FrameComponentInformation;
		if (frameObj != null && frameObj.Moulding.Width > 0)
		{
				AddFrameItem		= "<div  id='MyGalleriesHoverAddFrame' class='MyGalleriesBtn MyGalleriesText'><div class='MyGalleriesAddFrameIcon'></div><div class='clear'></div><div class=''>Edit Frame</div></div>";
		}
		else
		{
			if(itemGalleryItem.ItemDetails.ServiceFlags.CanFrame)
				AddFrameItem		= "<div  id='MyGalleriesHoverAddFrame' class='MyGalleriesBtn MyGalleriesText'><div class='MyGalleriesAddFrameIcon'></div><div class='clear'></div><div class=''>Add Frame</div></div>";
		}
		
	}
	
	if(AddFrameItem != "")
		var ZoomItem			= "<div id='MyGalleriesHoverZoom' class='MyGalleriesBtn MyGalleriesText'><div class='MyGalleriesZoomIcon'></div><div class='clear'></div><div class=''>Zoom</div></div>";
	else
		var ZoomItem			= "<div style='margin-left:120px;' id='MyGalleriesHoverZoom' class='MyGalleriesBtn MyGalleriesText'><div class='MyGalleriesZoomIcon'></div><div class='clear'></div><div class=''>Zoom</div></div>";
	
	var AddToCartItem		= "<div id='MyGalleriesAddToCartIcon' class='MyGalleriesBtn MyGalleriesText' ><div class='MyGalleriesAddToCartIcon'></div><div class='clear'></div><div class=''>Add to Cart</div></div>";;
	//var ItemHoverShare 		= "<div id='ItemHoverShare' class='MainToggleDiv' style='display:none;position:absolute;width: 220px; height: 70px; left: -1px; top:-72px;' id='ItemHoverShare_toggle'><ul class='shareNav' id='navShare'><li><a id='ItemHoverShareEmail' href='#'>Share via Email</a></li><li><a id='ItemHoverShareFacebook' href='#'>Share via Facebook</a></li></ul></div>";
	if($(".imgItemButtonContainer").length > 0) $(".imgItemButtonContainer").remove();
	var strItemButton
		= "<div class='imgItemButtonContainer' style='position:relative;'>"
			+		ShareItem
			+ 		AddFrameItem
			+ 		ZoomItem
			+ 		AddToCartItem
			//+		ItemHoverShare
        + "<div class='clear'></div></div>";
	$(".imgItemLinksContainer").after(strItemButton);
	
	
};

com.art.myGalleries.components.ItemHoverComponent.prototype.getTemplate = function()
{
	//var r = "<div class='VSResultsInfoIcon'><img src='http://cache1.artprintimages.com/images/blank.gif' title='close' alt='close' width='15' height='15'/></div>";
	return this.template.replace("$ID",this.id);//.replace("$INFO_ICON",r);
};
com.art.myGalleries.components.ItemHoverComponent.prototype.template = 
	"<div id='$ID' style='border:1px solid #787878;z-index:981;background-color:#FFFFFF;'>" +
		//"$INFO_ICON"+
		"<div class='clear'></div>" +
	"</div>";



