com.art.myGalleries.components.MyGalleriesModal = function (modal) {
	this.init();
    if (modal == null || modal == undefined) return false;
    this.id = modal.id;
    this.modal = modal;
    this.selectedGalleryId;
    this.btn;    
    this.LOGIN_CLICKED = com.art.myGalleries.components.MyGalleriesModal.LOGIN_CLICKED;
    this.REGISTER_CLICKED = com.art.myGalleries.components.MyGalleriesModal.REGISTER_CLICKED;
};
com.art.myGalleries.components.MyGalleriesModal.NAME = "MyGalleriesModal";
com.art.myGalleries.components.MyGalleriesModal.CLICK = "click";
com.art.myGalleries.components.MyGalleriesModal.UPDATE_GALLERY_TITLE = "MyGalleriesModalUpdateGalleryTitle";
com.art.myGalleries.components.MyGalleriesModal.LOGIN_CLICKED="LoginClicked";
com.art.myGalleries.components.MyGalleriesModal.REGISTER_CLICKED="RegisterClicked";
/**
* call the getTemplate() method and render it
*/
com.art.myGalleries.components.MyGalleriesModal.prototype.render = function()
{   
    return this.getTemplate();
};

/**
* Use this method to register the callback method
*@param name - name of the event e.g. click, hover etc
*@param callback - call the callback method to fire the event
*/
com.art.myGalleries.components.MyGalleriesModal.prototype.registerEvents = function () {

	$("#doneBtn").css("visibility","hidden");
	$("#visitGallery").css("visibility","hidden");
	
	if($.browser.msie)
		{ 
			$("#continue").css("width","155px");		
		}
	var rdName = "#" + this.modal.id + "_rdGallery";
	var rdNewName = "#" + this.modal.id + "_rdNewGalery";
    var txtName = "#" + this.modal.id + "_txtNewGallery";

    var _this = this;

	 if($.browser.msie && parseInt($.browser.version)==7)
		 {
    		if(this.modal.id=='MoveToGallery')
	    	{
	    		$('.MyGalleriesLeftContainer').css('height','365');
	    	}	    		 
    		else
	    	{
	    		$('.MyGalleriesLeftContainer').css('height','385');
	    	}
		 }
	 if($.browser.msie && parseInt($.browser.version)==8)
		 {	if(this.modal.id=='MoveToGallery')
	    	{
			 	$('#baseModalButtonBarRight_myModalMoveToGallery').css('height','0px');
	    	}
		 }
	
    if(this.modal.galleryList.length > 0)
    {
    	$("[class=radioModal]").removeAttr("checked");
    	$("[class=radioModal]").filter("[value=Existing]").attr("checked","checked");
    	$(txtName).attr("disabled", "true");
    	$("#existingDrpDownGalleries").removeClass('existingDrpDownGalleriesOpacity');
    }
    else
    {
    	$("[class=radioModal]").removeAttr("checked");
    	$("[class=radioModal]").filter("[value=New]").attr("checked","checked");
    	$("input[@name='" + txtName + "']:input").removeAttr('disabled');
    	$(rdName).attr('disabled', 'disabled');
    	$("#existingDrpDownGalleries").addClass('existingDrpDownGalleriesOpacity');
    	var alpha = 0.3;	
    	$("#txtExistingDrpDownGallery").css({
    	        "filter": "alpha (opacity=" + (alpha * 100) + ")",
    	        "filter": "progid:DXImageTransform.Microsoft.Alpha(style=0, opacity=" + (alpha * 100) + ")",
    	        "-moz-opacity": alpha,
    	        "opacity": alpha,
    	        "-khtml-opacity": alpha
    	    });
    }
    
    $("#privacyChk").css("visibility", "hidden");
    $("#privacyTxt").css("visibility", "hidden");
    
    $('input:radio').change(function () {
        if ($("input[name='SaveToGallery_rdGallery']:checked").val() == 'Existing' || $("input[name='MoveToGallery_rdGallery']:checked").val() == 'Existing' ) {
            $(txtName).val('Untitled Gallery');
            $(txtName).attr("disabled", "true");
            $("#privacyChk").css("visibility", "hidden");
            $("#privacyTxt").css("visibility", "hidden");
            $(".commonErrorMsg").text('');
            $(".commonErrorMsg").hide();
        }
        else if ($("input[name='SaveToGallery_rdGallery']:checked").val() == 'New' || $("input[name='MoveToGallery_rdGallery']:checked").val() == 'New') {
            $("input[@name='" + txtName + "']:input").removeAttr('disabled');
            $("#drpdownSelection").text($("#drpdownSelection").text().replace(($("#drpdownSelection").text()), "Select Gallery"));
            var cookieobject = new com.art.core.cookie.Cookie();        
            var accountType=cookieobject.getCookieDictionary('ap','accounttype');
            
            if(accountType!="1")	
            {
            	$("#privacyChk").css("visibility", "visible");
                $("#privacyTxt").css("visibility", "visible");
            }
            $("#txtExistingDrpDownGallery").unbind("live");
            $("#txtExistingDrpDownGallery").unbind("click");
            $("#txtExistingDrpDownGallery").unbind("mouseenter");
            $("#txtExistingDrpDownGallery").die();
            $(".commonErrorMsg").text('');
            $(".commonErrorMsg").hide();
            $("#drpDownLstGallery").hide();
        }
    });

    $("#txtExistingDrpDownGallery").live("click", function () {
        if ($("input[@name='" + rdName + "']:checked").val() == 'New') {
            $("#drpDownLstGallery").hide();
        }
    });
    
    $("#drpDownLstGallery").mouseenter(function () {
        $(this).show();
        $(".commonErrorMsg").hide();
    });
    
    $("#existingDrpDownGalleries, #drpDownLstGallery").mouseleave(function () {
        $("#drpDownLstGallery").hide();
        $(".commonErrorMsg").show();
    });

    $("#existingDrpDownGalleries").click(function () {       
        $(".commonErrorMsg").text('');
        if ($("input[name='SaveToGallery_rdGallery']:checked").val() == 'New' || $("input[name='MoveToGallery_rdGallery']:checked").val() == 'New') {            
            $("#drpDownLstGallery").hide();
        }
        else if ($("input[name='SaveToGallery_rdGallery']:checked").val() == 'Existing' || $("input[name='MoveToGallery_rdGallery']:checked").val() == 'Existing') {
            $("#drpDownLstGallery").show();           
        }
    });
    $('.drpDownLstItem').live('mouseover', function () {
        $(this).addClass('HoverSelected');
    });
    $('.drpDownLstItem').live('mouseout', function () {
        $(this).removeClass('HoverSelected');
    });
    $('.drpDownLstItem').live('click', function () {    	
        _this.selectedGalleryId = $(this).attr('id');
        
        var strExistingGallery=$("#drpdownSelection").text().replace(($("#drpdownSelection").text()), ($(this).text()));
        var strEclipseExistingGallery=com.art.core.utils.StringUtil.autoEllipseText(strExistingGallery,15);
        
        $("#drpdownSelection").text(strEclipseExistingGallery);
        $("#drpDownLstGallery").hide();
        
    });
    $("#" + this.modal.id + "_txtNewGallery").keypress(function () {
        $(".commonErrorMsg").text('');
        $(".commonErrorMsg").hide();
    });
    $("#registerSavetogallery").live("click", function () {    
    	trace("loginsaveclicked");
    	if(_this.callbacks[_this.REGISTER_CLICKED] != undefined)
           _this.callbacks[_this.REGISTER_CLICKED]();        
    });
    $("#loginSavetogallery").live("click", function () {    
    	trace("registerSavetogallery");
    	if(_this.callbacks[_this.LOGIN_CLICKED] != undefined)
           _this.callbacks[_this.LOGIN_CLICKED]();        
    });
};

/**
* Used this method to get the gallery ID for visit to gallery button 
* @method ContinueToMove
*/
com.art.myGalleries.components.MyGalleriesModal.prototype.GetGalleryID = function () {
if(this.selectedGalleryId!="" && this.selectedGalleryId!=undefined)
	{
		return this.selectedGalleryId;
	}
};

/**
* Register this method to continue to move to gallery events
* @method ContinueToMove
*/
com.art.myGalleries.components.MyGalleriesModal.prototype.ContinueToMove = function () {

    if ($("input[name=" + this.modal.id + "_rdGallery]:checked").val() == undefined) {
        $(".commonErrorMsg").text('Please select a option.');
        $(".commonErrorMsg").show();
        //  return 'New';
    }
    else {
        var GalleryVal = $("input[name=" + this.modal.id + "_rdGallery]:checked").val();
        switch (GalleryVal) {
            case 'New':
                if ($("#" + this.modal.id + "_txtNewGallery").val().trim().length <= 0) {
                    $(".commonErrorMsg").text('Please enter a gallery name. ');
                    $(".commonErrorMsg").show();
                    //return false;
                }
                else {
                    return 'New';
                }
                break;
            case 'Existing':
                if ($("#drpdownSelection").text() == 'Select Gallery') {
                    $(".commonErrorMsg").text('Please select an existing gallery from the dropdown menu.');
                    $(".commonErrorMsg").show();
                    //return 'Nothing';
                }
                else {
                    return 'Existing';
                }
                break;
            default:
                return GalleryVal;
                break;
        }
    }

};

/**
* Used this method to send edited title,desc and privacy
* @method getEditTitleData
*/
com.art.myGalleries.components.MyGalleriesModal.prototype.getAddTitleData = function () {
	var txtName = "#" + this.modal.id + "_txtNewGallery";
    return { title: $(txtName).val() };
};

/**
* Use this method to return the changed content
*/
com.art.myGalleries.components.MyGalleriesModal.prototype.getTemplate = function ()
{
    var strHtml = "";

    switch (this.modal.id) {
        case "MoveToGallery":
        	
        case "SaveToGallery":
            strHtml = this.getTemplateForMoveToGallery();
            break;        
        case "DeleteGallery":
            strHtml = this.getTemplateForDeleteGallery();
            break;

        default:
            throw new Error("Modal Failure! Unknown note.name");
    }

    return strHtml;
};

com.art.myGalleries.components.MyGalleriesModal.prototype.getTemplateForMoveToGallery = function ()
{
    var str = "<div id='" + this.modal.id + "' class='MyGalleriesModalContainer'>"
			+ this.ModalLeftContainer()
			+ this.ModalRightContainer()
			+ this.ModalConfirmContainer()
			+ "</div>"
			+ "<div class='clear'></div>";
    return str;
};

com.art.myGalleries.components.MyGalleriesModal.prototype.getTemplateForDeleteGallery = function () {
    var str = "<div id='" + this.modal.id + "' class='MyGalleriesModalContainer'>"
			+ this.ModalLeftContainer()
			+ this.ModalRightContainer()
			+ "</div>"
			+ "<div class='clear'></div>";
    return str;
};

com.art.myGalleries.components.MyGalleriesModal.prototype.ModalLeftContainer = function ()
{
	var _this     = this;
	var str="";
	var ImgContainer = "";
	var strDropShadow = "";
	var ItemGalleryItemID = "1";
	
	var ImageUrl = _this.modal.galleryItem.ImageUrl;	
	var ImageWidth = _this.modal.galleryItem.Width;	
	var ImageHeight = _this.modal.galleryItem.Height;
	
	var length = 180;
	var w = 0, h = 0, mt = 0, ml = 0;
	var aspectRatio = ImageWidth/ImageHeight;
		if (aspectRatio > 1.0)
	   {
	       w =length;
	       h = length / aspectRatio;
	       mt = (w - h) / 2;
	   }
	   else
	   {
	       w = length * aspectRatio;
	       h = length;
	       ml = (h - w) / 2;
	   }
	
	   ImageHeight = Math.floor(h);
	   ImageWidth = Math.floor(w);
	
	   var _HD = (220 - ImageHeight);
	   var _WD = (220 - ImageWidth);
	   
	   var tp, bt, rp, lp;
	   //Calculate the Padding needed.
	   if (_HD > 0)
	   {
	      tp = _HD / 2;
	      bp = (_HD - tp);
	   }
	   if (_WD > 0)
	   {
	      rp = _WD / 2;
	      lp = (_WD - rp);
	   }
	   lp = Math.floor(lp);
	   tp = Math.floor(tp);
	   
	   
	   ImgContainer	   = '<img style="position:absolute;left:'+ lp +'px;top:'+ tp +'px;" width="'+ ImageWidth +'" height="'+ ImageHeight +'" class="" alt="" title="" src="'+ ImageUrl +'" />';
	   var ImgRightTop     = '<img alt="" style="top:'+ tp +'px; left: '+(ImageWidth + lp ) +'px;" class="abs w8 h10" src="http://cache1.artprintimages.com/images/photostoart/shadow_righttop_E5E7DC.png" />';	   
	   var ImgRightTiling  = '<img height="'+ (ImageHeight  - 10)+'" alt="" style="top:'+ (tp + 10) +'px; left:'+(ImageWidth + lp ) +'px;" class="abs w8" src="http://cache1.artprintimages.com/images/mygallery/shadow_righttiling_E5E7DC.png" />';
	   var ImgBottomLeft   = '<img alt="" style="top:'+ (ImageHeight + tp ) +'px; left: '+ (lp ) +'px;" class="abs w8 h8" src="http://cache1.artprintimages.com/images/photostoart/shadow_bottomleft_E5E7DC.png" />';
	   
	   if(ImageWidth=='NaN')
	   {
		   var ImgBottomTiling = '<img width="220px" alt="" style="top:'+ (ImageHeight  + tp) +'px; left: '+(lp+8) +'px;" class="abs h8" src="http://cache1.artprintimages.com/images/mygallery/shadow_bottomtiling_E5E7DC.png" />';
	   }
	   else
	   {
		   var ImgBottomTiling = '<img width="'+(ImageWidth - 8 )+'" alt="" style="top:'+ (ImageHeight  + tp) +'px; left: '+(lp+8) +'px;" class="abs h8" src="http://cache1.artprintimages.com/images/mygallery/shadow_bottomtiling_E5E7DC.png" />';   
	   }
	   var ImgBottomRight  = '<img alt="" style="top:'+ (ImageHeight  + tp) +'px; left: '+(ImageWidth + lp ) +'px;" class="abs w8 h8" src="http://cache1.artprintimages.com/images/photostoart/shadow_bottomright_E5E7DC.png" />';
	
	   strDropShadow
		= "<div class='imgDropShadowContainer'>"
		+ 		ImgRightTop
		+ 		ImgRightTiling
		+ 		ImgBottomLeft
		+ 		ImgBottomTiling
		+ 		ImgBottomRight
		+ "</div>";
	
	   
	//var strItemSkuName  	= "<div class='MyGalleriesText'>"+_this.modal.galleryItem.ZoneProductID+ "&nbsp;&nbsp;&nbsp;" +_this.modal.galleryItem.Title+"</div>";
    var strItemSkuName  	= "<div class='MyGalleriesText'>"+_this.modal.galleryItem.Title+"</div>";
    
    if(_this.modal.galleryItem.ArtistName!=undefined)
    	{
    		var strItemArtistName  	= "<div class='MyGalleriesText'>"+_this.modal.galleryItem.ArtistName+"</div>";
    	}
    else
    	{
    		var strItemArtistName="";
    	}
    
    if(_this.modal.galleryItem.DisplayPrice!=undefined)
    	{
    		var strItemPrice  		= "<div class='MyGalleriesText'>"+_this.modal.galleryItem.DisplayPrice+"</div>";
    	}
    else
    	{
    		var strItemPrice  		= "<div class='MyGalleriesText'>"+_this.modal.galleryItem.Price+"</div>";
    	}

	str		=		"<div class='MyGalleriesLeftContainer'>"
			+			"<div class='MyGalleriesLeftImgContainer'>"
			+				ImgContainer
			+				strDropShadow
			+			"</div>"
			+			"<div class='MyGalleriesLeftItemDetailsContainer' style='margin-left:15px;'>"
			+				strItemSkuName
			+				strItemArtistName
			+				strItemPrice
			+			"</div>"
			+		"</div>";
	
	return str;
};

com.art.myGalleries.components.MyGalleriesModal.prototype.ModalRightContainer = function ()
{
    var strModalTitle = "<div class='MainModalTitle'>" + this.modal.Title + "</div>";
    var strModalGalleryContainer = this.getTemplateForGalleryContent();

    var str = "<div class='MyGalleriesRightContainer'>"
		+ strModalTitle
		+ strModalGalleryContainer
		+ "</div>";

    return str;
};

com.art.myGalleries.components.MyGalleriesModal.prototype.getTemplateForGalleryContent = function ()
{
    var str = "", hiddenClass="";
    var strExistingDropDownTextBox = this.getExistingDropDownTextBox();
    var strExistingDropDown = this.getExistingDropDownList();
    var strLoginText;
    var cookieobject = new com.art.core.cookie.Cookie();        
    var accountType=cookieobject.getCookieDictionary('ap','accounttype');
    
    
    if(this.modal.id == 'SaveToGallery' && accountType=="1")	
    {    
    	//strLoginText= "<div class='MyGalleriesLoginContainer "+hiddenClass+"'>Don't see your saved galleries? <a id ='loginSavetogallery' href='#' alt='' title=''>Login</a> to your account</span></div>";
    	strLoginText= "<div class='MyGalleriesLoginContainer'>Don't see your existing galleries? <span id ='loginSavetogallery' style='text-decoration: none;color:blue;cursor:pointer;font-weight: bold;text-decoration:underline;'>Login</span> to your account</span></div>";
    }
    else
	{
    	strLoginText="";
	}
    
    hiddenClass = this.modal.id == 'SaveToGallery' ? "" : "hidden";
    
    var strModalExistingGallery = "<div class='ModalExistingGallery'>"
								+ "<input type='radio' id='" + this.modal.id + "_rdGallery' name='" + this.modal.id + "_rdGallery' value='Existing' class='radioModal' style='vertical-align:top;margin-right:10px;' /><span id='ModalExistingGalleryLabel' class='ModalExistingGalleryLabel'>Existing Gallery</span>"
								+ "<div class='clear'></div>"
								+ strExistingDropDownTextBox
								+ "<div class='clear'></div>"
								+ strExistingDropDown
								+ "<div class='clear'></div>"
								+ strLoginText								
								//+ "<div class='MyGalleriesLoginContainer'>Don't see your saved galleries? <span id ='loginSavetogallery' style='text-decoration: none;'>Login</span> to your account</span></div>"
                                + "<div class='commonErrorMsg'></div>"
								+ "</div>";

    var strModalDashLine = "<div class='MygalleriesDashlines'></div>";

    var strModalNewGallery = "<div class='ModalNewGallery'>"
								+ "<input type='radio' id='" + this.modal.id + "_rdNewGallery' name='" + this.modal.id + "_rdGallery' value='New' class='radioModal' style='vertical-align:top;margin-right:10px;margin-left:0;' /><span id='ModalNewGalleryLabel' class='ModalNewGalleryLabel'>New Gallery</span>"
								+ "<div class='newGalleryTextBox'><input type='text' id='" + this.modal.id + "_txtNewGallery' name='" + this.modal.id + "_txtNewGallery' class='modalGallerytxtTitle' maxlength='25'  value='Untitled Gallery' /></div>"
								+ "</div>";

    str = "<div class='MyGalleriesModalGalleryContainer'>"
			+ strModalExistingGallery
			+ strModalDashLine
			+ strModalNewGallery
			+ "</div>";

    return str;
};


com.art.myGalleries.components.MyGalleriesModal.prototype.ModalConfirmContainer = function ()
{	
	if(this.modal.id == 'SaveToGallery')
	{	
	    var strConfirmTitle = "<div class='MainModalTitle' style='margin-bottom:20px;'>Successfully Saved!</div>";
        var strConfirmGalleryContainer = "<div id='txtConfirmationMessage' class='MyGalleriesText'>" + '"' + this.modal.galleryItem.Title + '"' + " was added to your <span id='galleryName'></span>&nbsp;gallery. You can access your gallery at any time from the My Galleries link at the top of each page, or by selecting Visit Gallery below.</div>";
        var strLoginConfirmContainer;
        
        var cookieobject = new com.art.core.cookie.Cookie();        
        var accountType=cookieobject.getCookieDictionary('ap','accounttype');
        
        if(this.modal.id == 'SaveToGallery' && accountType=="1")	
        {
        	strLoginConfirmContainer= "<hr/><div id='txtLoginConfirm' class='MyGalleriesText'>To take full advantage of gallery features, including accessing your saved items from any computer and sharing with friends, please <span id ='loginSavetogallery' style='text-decoration: none;color:blue;cursor:pointer;font-weight: bold;'>Login</span> or <span id ='registerSavetogallery' style='text-decoration: none;color:blue;cursor:pointer;font-weight: bold;'>Sign Up.</span></div>";
    	}        
        else
        {
        	strLoginConfirmContainer="";
        }
        
        var strBtnContainer = "<div id='btnContainer'></div>";
        
        var str = "<div id='SavetoGalleryConfirm' style='visibility:hidden;' class='MyGalleriesConfirmRightContainer'>"
    		+ strConfirmTitle
    		+ strConfirmGalleryContainer
    		+ strLoginConfirmContainer
    		+ strBtnContainer
    		+ "</div>";		
	}	
	else	
	{		
		 var strConfirmTitle = "<div class='MainModalTitle'  style='margin-bottom:20px;'>Move Successful</div>";
	     var strConfirmGalleryContainer = "<div id='txtConfirmationMessage' class='MyGalleriesText'>Your item has been successfully moved.</div>";
	     var strBtnContainer = "<div id='btnContainer'></div>";
	        
	     var str = "<div id='MoveToGalleryConfirm' style='visibility:hidden;' class='MyGalleriesConfirmRightContainer'>"
    		+ strConfirmTitle
    		+ strConfirmGalleryContainer    		
    		+ strBtnContainer
    		+ "</div>";
	}	
    return str;
};

com.art.myGalleries.components.MyGalleriesModal.prototype.getExistingDropDownTextBox = function ()
{
    var cookieobject = new com.art.core.cookie.Cookie();        
	var galleryID = cookieobject.getCookieDictionary('arts',this.modal.id);
	var galleryName = "";
	if (this.modal.galleryList.length > 0) {
        for (var i = 0; i < this.modal.galleryList.length; i++) {
        	if(this.modal.galleryList[i].ItemKey  == galleryID)
        		{
        			galleryName = unescape(this.modal.galleryList[i].Name);
        			this.selectedGalleryId = this.modal.galleryList[i].GalleryId;
        			break;
        		}
        }
	}    
	if(galleryName == "")
		galleryName = "Select Gallery";
	if(this.modal.id == 'SaveToGallery')
	{
		var str = '<div id="existingDrpDownGalleries">'
			  + '<div id="txtExistingDrpDownGallery"><div id="txtExistingDrpDownGallery_label"><div style="float: left;width:150px;" id="drpdownSelection">'+ galleryName+'</div><div style="float: left; background-image: url(&quot;http://cache1.artprintimages.com/images/coreimages/core-components-sprites.png&quot;); background-repeat: no-repeat; width: 20px; height: 25px;#height: 18px; background-position: -315px -73px;"></div></div><div style="" id="txtExistingDrpDownGallery_rightcap"></div></div>' 	
	 		  + '</div>';
	}	
	else	
	{	
	  
		var str = '<div id="existingDrpDownGalleries">'
			+ '<div id="txtExistingDrpDownGallery" style="float: left; display: inline-block; cursor: pointer; position: relative; height: 32px;"><div style="display: inline-block; float: left; height: 24px; padding-left: 20px; padding-top: 8px; padding-right: 10px; color: rgb(255, 255, 255); font-size: 11px; font-family: Verdana; width:175px;background-image: url(&quot;http://cache1.artprintimages.com/images/coreimages/core-components-sprites.png&quot;); background-position: 0px -128px; background-repeat: no-repeat;" id="txtExistingDrpDownGallery_label"><div style="float: left;width:150px;" id="drpdownSelection">'+ galleryName +'</div><div style="float: left; background-image: url(&quot;http://cache1.artprintimages.com/images/coreimages/core-components-sprites.png&quot;); background-repeat: no-repeat; width: 20px; height: 25px; background-position: -315px -73px;"></div><div style="clear: both;"></div></div><div style="display: inline-block; float: left; height: 26px; padding-top: 6px; width: 4px; background-image: url(&quot;http://cache1.artprintimages.com/images/coreimages/core-components-sprites.png&quot;); background-position: -305px -160px; background-repeat: no-repeat;" id="txtExistingDrpDownGallery_rightcap"></div><div style="display: inline-block; clear: both;"></div></div>'
			+ '</div>';
	}	
    return str;
};

com.art.myGalleries.components.MyGalleriesModal.prototype.getExistingDropDownList = function () {
    var strLi = "" , str = "";
    if (this.modal.galleryList.length > 0) {
        for (var i = 0; i < this.modal.galleryList.length; i++) {
        	//if(this.modal.galleryList[i].GalleryId  != this.modal.SelectedGalleryId)
        	strLi += '<li class="drpDownLstItem" id="' + this.modal.galleryList[i].GalleryId + '">' + unescape(this.modal.galleryList[i].Name) + '</li>';
        }
        str = '<ul id="drpDownLstGallery">'
				+ strLi
				+ '</ul>';
    }
    return str;
};
com.art.myGalleries.components.MyGalleriesModal.prototype.getDestinationSelectedGalleryId = function () {
	return this.selectedGalleryId;
};

com.art.core.components.BaseComponent.extend(com.art.myGalleries.components.MyGalleriesModal.prototype);