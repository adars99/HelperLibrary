com.art.myGalleries.components.CommonComponent = function (id, contentTitle, width, height, galleryId, galleryTitle, galleryDesc, privacy, contentName, content, imageURL, skuname, artistName, price, galleryList)
{
	this.init();
    this.id = id;
    this.contentTitle = contentTitle;
    this.width = width;
    this.height = height;
    this.galleryList = galleryList;
    this.galleryId = galleryId;
    this.galleryTitle = galleryTitle;
    this.galleryDesc = galleryDesc;
    this.privacy = privacy;
    this.contentName = contentName;
    this.content = content;
    this.imageURL = imageURL;
    this.skuName = skuname;
    this.artistName = artistName;
    this.price = price;
    this.data;
    this.UPDATE_GALLERY_TITLE = com.art.myGalleries.components.CommonComponent.UPDATE_GALLERY_TITLE;
};
com.art.myGalleries.components.CommonComponent.NAME = "CommonComponent";
com.art.myGalleries.components.CommonComponent.CLICK = "click";
com.art.myGalleries.components.CommonComponent.UPDATE_GALLERY_TITLE = "CommonComponentUpdateGalleryTitle";

/**
* call the getTemplate() method and render it
*/
com.art.myGalleries.components.CommonComponent.prototype.render = function () {    
    return this.getTemplate();
};
com.art.myGalleries.components.CommonComponent.prototype.setData = function (data) {    
    $('.modalGallerytxtTitle').val(data);    
};

/**
* Use this method to register the callback method
*@param name - name of the event e.g. click, hover etc
*@param callback - call the callback method to fire the event
*/

com.art.myGalleries.components.CommonComponent.prototype.registerCallback = function (name, callback) {
    this.callbacks[name] = callback;
    trace("callbacks:");
    trace(this.callbacks);
};

/**
* registerEvents is called only once on initialization
*/
com.art.myGalleries.components.CommonComponent.prototype.registerEvents = function () {
    var _this = this;

    
    if (this.galleryTitle == 'Enter Title') {
        $('input:text').css("color", "#666666");
    }
    if (this.galleryDesc == 'Enter a description (optional)') {
        $("textarea:#editGalleryTitle_txtDesc").css("color", "#666666");
    }  

    var rdName = "#" + this.id + "_rdGallery";
    var txtName = "#" + this.id + "_txtNewGallery";

    $('input:radio').change(function () {
        if ($("input[@name='" + rdName + "']:checked").val() == 'Existing') {
            $(txtName).val('');
            $(txtName).attr("disabled", true);
            $("#txtExistingDrpDownGallery").live("click", function () {
                $("#drpDownLstGallery").css("visibility", "visible");
            });
            $(".ExistingGalleryLI").live("click", function () {

                $("#drpdownSelection").text($("#drpdownSelection").text().replace(($("#drpdownSelection").text()), ($(this).attr('id'))));
                $("#drpDownLstGallery").css("visibility", "hidden");
            });
        }
        else if ($("input[@name='" + rdName + "']:checked").val() == 'New') {
            $("input[@name='" + txtName + "']:input").removeAttr('disabled');
            $("#drpdownSelection").text($("#drpdownSelection").text().replace(($("#drpdownSelection").text()), "Select Existing Gallery"));
            $("#txtExistingDrpDownGallery").unbind("live");
            $("#txtExistingDrpDownGallery").unbind("click");
            $("#txtExistingDrpDownGallery").unbind("mouseenter");
            $("#txtExistingDrpDownGallery").die();
            $("#drpDownLstGallery").css("visibility", "hidden");
        }
    });

    $("txtExistingDrpDownGallery").live("click", function () {
        if ($("input[@name='" + rdName + "']:checked").val() == 'New') {
            $("#drpDownLstGallery").css("visibility", "hidden");
        };
    });

    $("#existingDrpDownGalleries").mouseleave(function () {
        $("#drpDownLstGallery").css("visibility", "hidden");
    });

    $("#existingDrpDownGalleries").mouseenter(function () {
        if ($("input[@name='" + rdName + "']:checked").val() == 'New')
        {

            $("#drpDownLstGallery").css("visibility", "hidden");
        }
    });
    
    $("#" + this.id + "_txtTitle").focus(function ()
    {
    	$(this).css("color", "#333333");
    	var txtVal = $(this).val();    	
        if (txtVal == '' || txtVal == 'Enter Title')
        {
            $(this).val('');
        }
    });
    $("#" + this.id + "_txtTitle").blur(function () {
        $(this).css("color", "#666666");
        if ($(this).val() == "") {
            
            $(this).val('Enter Title');
        }
    });
    $('textarea[maxlength]').keyup(function () {
        var max = parseInt($(this).attr('maxlength'));
        if ($(this).val().length > max) {
            $(this).val($(this).val().substr(0, $(this).attr('maxlength')));
        }

    });
    $("#" + this.id + "_txtDesc").focus(function () {
        $(this).css("color", "#333333");
        var txtAreaVal = $(this).val();
        
        if (txtAreaVal == '' || txtAreaVal == 'Enter a description (optional)') {
            $(this).val('');
        }
    });
    $("#" + this.id + "_txtDesc").blur(function () {
        $(this).css("color", "#666666");
        if ($(this).val() == "") {
            $(this).val('Enter a description (optional)');
        }
    });    
};

/**
* registerEvents is called only once on initialization
*/
com.art.myGalleries.components.CommonComponent.prototype.existingGalleryEvent = function () {
    _this = this;
   
};

/**
* Register the edit Gallery Title method to edit the gallery Title and description 
* @method EditGalleryTitle
*/
com.art.myGalleries.components.CommonComponent.prototype.validateTitle = function () {
    var isValid = true;
    
    if ($("#" + this.id + "_txtTitle").val() == 'Enter Title') {        
        $("#" + this.id + "_txtTitle").val('');        
    }
    if ($("#" + this.id + "_txtDesc").val() == 'Enter a description (optional)') {
        $("#" + this.id + "_txtDesc").val('');
    }
    
    var title = $("#" + this.id + "_txtTitle").val();
    title = title.trim();
    var txtTitleLen = title.length;    
    if (txtTitleLen <= 0) {
        isValid = false;
        $("#" + this.id + "_txtTitle").css("border", "1px solid red");    
        $("#showErrorMsgContainer").show();
        $("#showErrorMsg").text("Please provide a unique gallery name.");
    }
    $("#" + this.id + "_txtTitle").keypress(function () {
        $("#" + this.id).css("border", "1px solid #9E9E9E");
        $("#showErrorMsgContainer").hide();
        $("#showErrorMsg").text('');
    });

    return isValid;

};
/**
* Used this method to send added title,desc and privacy
* @method getAddTitleData
*/
com.art.myGalleries.components.CommonComponent.prototype.getAddTitleData = function () {
	var galleryTitle=$("#addGalleryTitle_txtTitle").val();
	galleryTitle=$.trim(galleryTitle);
	var galleryDesc=$("#addGalleryTitle_txtDesc").val();
	galleryDesc=$.trim(galleryDesc);
	
    return { title: galleryTitle, desc: galleryDesc };

};
/**
* Used this method to send edited title,desc and privacy
* @method getEditTitleData
*/
com.art.myGalleries.components.CommonComponent.prototype.getEditTitleData = function ()
{
	var galleryTitle=$("#editGalleryTitle_txtTitle").val();
	galleryTitle=$.trim(galleryTitle);
	var galleryDesc=$("#editGalleryTitle_txtDesc").val();
	galleryDesc=$.trim(galleryDesc);
	
	return {title:galleryTitle,desc:galleryDesc};
};

/**
* Register this method to continue to move to gallery events
* @method ContinueToMove
*/
com.art.myGalleries.components.CommonComponent.prototype.ContinueToMove = function () {
       
};

/**
* Use this method to return the changed content
*/
com.art.myGalleries.components.CommonComponent.prototype.getTemplate = function () {

    var str;
    if (this.id == "editGalleryTitle") {
        if (this.galleryTitle == '') {
            this.galleryTitle = 'Enter Title';
        }
        if (this.galleryDesc == '') {
            this.galleryDesc = 'Enter a description (optional)';
        }
        str = this.editGalleryTemplate.replace(/\$NAME/g, this.id).replace("$CONTENTTITLE", this.contentTitle).replace("$GDESC", this.galleryDesc);        
    }
    else if (this.id == "addGalleryTitle") {
        str = this.addGalleryTemplate.replace(/\$NAME/g, this.id).replace("$CONTENTTITLE", this.contentTitle);
    }
    else if (this.id == 'deleteArtComponent') {    	
        str = this.deleteArtTemplate.replace(/\$NAME/g, this.id).replace("$CONTENTTITLE", this.contentTitle).replace("$ARTNAME", this.contentName).replace("$CONTENT", this.content);
    }
    else if (this.id == 'deleteGalleryComponent') {
        str = this.deleteGalleryTemplate.replace(/\$NAME/g, this.id).replace("$CONTENTTITLE", this.contentTitle).replace("$GALLERYNAME", this.contentName).replace("$CONTENT", this.content);
    }
    else if (this.id=='wishlistMyAccount'){
    	str = this.wishlistMyAccountTemplate.replace(/\$NAME/g, this.id).replace("$CONTENTTITLE", this.contentTitle).replace("$CONTENT", this.content);    
    }
    else if (this.id == 'moveToGalleryComponent') {

        var existingGalleryList = "<ul class='ExistingGallery' style='background-color:#FFFFFF;font-family:verdana;font-size:11x;'>";
        var strList = "";
        for (var i = 0; i < this.galleryList.length; i++) {
            strList += "<li class='ExistingGalleryLI' id='" + this.galleryList[i].galleryName + "'><a href='#'>" + this.galleryList[i].galleryName + "</a></li>";
        }
        existingGalleryList = existingGalleryList + strList + "</ul>";
        var GalleryList = this.existingGalleryItemsTemplate.replace("$existingListItems", existingGalleryList);

        str = this.moveToGalleryTemplate.replace(/\$NAME/g, this.id).replace("$CONTENTTITLE", this.contentTitle).replace("$SKUNAME", this.skuName).replace("$ARTISTNAME", this.artistName).replace("$PRICE", this.price).replace("$EXISTINGITEMSNAME", GalleryList).replace("$CONTENT", this.content).replace('$IMAGEURL', this.imageURL);
    }
    else if (this.id=='shareWithoutLoggedIn'){
    	str=this.shareWithoutLoggedInTemplate.replace(/\$NAME/g, this.id).replace("$CONTENTTITLE", this.contentTitle).replace("$CONTENT", this.content);;
    	}
    return str;
};

/**
* This is the HTML content which renders move to gallery template
* @property moveToGalleryTemplate
*/
com.art.myGalleries.components.CommonComponent.prototype.moveToGalleryTemplate =
 "<div id='$NAME' class='MainMoveToGalleryContainer'>" +
     "<div id='$NAME_LeftModalContainer' class='LeftModalContainer'>" +
         "<div id='$NAME_LeftInnerContainer' class='LeftInnerContainer'>" +
            "<div style='1px solid #B7B7B7;margin-bottom:10px;'><img src='$IMAGEURL' width='160px' style='1px solid red;' height='300px' alt='' title='' /> </div>" +
            "<div><span>SKU Name</span><span>$SKUNAME</span></div>"+
            "<div><span>Artist Name</span><span>$ARTISTNAME</span></div>" +
            "<div><span>Price</span><span>$PRICE</span></div>"+
         "</div>" +
     "</div>" +
     "<div id='$NAME_RightModalContainer' class='RightModalContainer'>" +
        "<div id='$NAME_RightInnerContainer' class='RightInnerContainer'>" +
                "<div id='$NAME_Title' class='MoveToGalleryTitle'>$CONTENTTITLE</div>" +
                "<div id='$NAME_GallerySpliter' class='MovetoGallerySpliter'>"+
                    "<div class='MoveToExistingItems'>" +
                            "<div style='margin-bottom:10px;'><input type='radio' id='$NAME_rdGallery' name='$NAME_rdGallery' value='Existing' class='radioModal' /><span id='spMsg' class='spRdMsg'>Existing Gallery</div>" +
                            "$EXISTINGITEMSNAME" +
                     "</div>"+
                     "<div class='MoveToNewItems'>" +
                            "<div style='margin-bottom:10px;'><input type='radio' id='$NAME_rdGallery' name='$NAME_rdGallery' value='New' class='radioModal' /><span id='spMsg' class='spRdMsg'>New Gallery</div>" +
                            "<div><input type='text' id='$NAME_txtNewGallery' name='$NAME_txtNewGallery' class='modalGallerytxtTitle' disabled='true' /></div>" +
                     "</div>"+
                 "</div>" +
        "</div>" +
     "<div style='font-family:verdana;font-size:11px;margin-top:280px;margin-right:30px'>$CONTENT</div>" +
     "</div>" +  
     "<div class='clear'></div>" +
 "</div>";

/**
* This is the HTML content which renders move to gallery template
* @property moveToGalleryTemplate
*/
com.art.myGalleries.components.CommonComponent.prototype.existingGalleryItemsTemplate =
 '<div id="existingDrpDownGalleries">' +
	  '<div id="txtExistingDrpDownGallery" style="display:inline-block;float:left;width:175px;height:24px;padding-left:20px;padding-top:6px;color:#FFFFFF;font-size:13px;font-family:arial,sans-serif;background-image:url(http://cache1.artprintimages.com/images/coreimages/core-components-sprites.png); background-position:0px 0px;background-repeat:no-repeat;"><label id="drpdownSelection">Select Existing Gallery</label></div>' +
      '<div id="txtExistingDrpDownGallery" style="display:inline-block;float:left;height:30px; width:20px;background-image:url(http://cache1.artprintimages.com/images/coreimages/core-components-sprites.png); background-position:-280px 0px;background-repeat:no-repeat;"></div>' +
     '<div id="drpDownLstGallery" style="visibility:hidden;">$existingListItems</div>' +
'</div>';

/**
* This is the HTML content which renders EditGallery Title and Description template
*@property editGalleryTemplate
*/
com.art.myGalleries.components.CommonComponent.prototype.editGalleryTemplate =
 "<div id='$NAME' style='margin-left:25px;margin-top:60px;margin-right:20px;'>" +
 "<div id='$NAME_Title' class='MainModalTitle'>$CONTENTTITLE</div>" +
 "<div style='float:left;display:none;' class='ErrorMsg dErrorMessage' id='showErrorMsgContainer'><div class='loginModalErrorMsgImg floatLeft'></div><div class='floatLeft galErrorMsg' id='showErrorMsg'></div></div>" +
 "<div style='margin-top:10px;'><input type='text' id='$NAME_txtTitle' name='$NAME_txtTitle' class='modalGallerytxtTitle' maxlength='25' value='' /><span id='spError' class='ErrorMsg'> *</span></div>" +
 "<div style='margin-top:10px;'><textarea id='$NAME_txtDesc' rows='6' cols='20' class='modalGallerytxtDesc' maxlength='100'>$GDESC</textarea></div>" +
 "<div style='float:left' class='ErrorMsg'>* <span id='ErrorMsg'>Required Field</span></div><br/>" +
 //"<div style='float:left' class='ErrorMsg'><span id='showErrorMsg' style='visibility:visible;color:red;font-size:12px'></span></div>" +
 "<div class='clear'></div>"+
 "</div>";

/**
* This is the HTML content which renders Share without logged in template
*@property shareWithoutLoggedInTemplate
*/
com.art.myGalleries.components.CommonComponent.prototype.shareWithoutLoggedInTemplate =
	"<div id='$NAME' style='margin-left:25px;margin-top:60px;margin-right:20px;'>" +
	 "<div id='$NAME_Title' class='MainModalTitle'>$CONTENTTITLE</div>" +
	 "<div id='txtContent' class='MyGalleriesLoginContainer' style='margin-top:10px;'>$CONTENT</div>" +	 
	 "<div class='clear'></div>"+
	 "</div>";

/**
* This is the HTML content which renders wishlist on my account page
*@property wishlistMyAccountTemplate
*/
com.art.myGalleries.components.CommonComponent.prototype.wishlistMyAccountTemplate =
	"<div id='$NAME' style='margin-left:25px;margin-top:60px;margin-right:20px;'>" +
	 "<div id='$NAME_Title' class='MainModalTitle'>$CONTENTTITLE</div>" +
	 "<div id='txtContent' class='MyGalleriesLoginContainer' style='margin-top:10px;'>Wish lists are now called My Galleries. Items saved to your galleries can be organized, compared, viewed in a room, and shared with friends via email or Facebook.</div>" +	 
	 "<div class='clear'></div>"+
	 "</div>";

/**
* This is the HTML content which renders Add Gallery Title and Description template
*@property addGalleryTemplate
*/
com.art.myGalleries.components.CommonComponent.prototype.addGalleryTemplate =
 "<div id='$NAME' style='margin-left:25px;margin-top:60px;margin-right:20px;'>" +
 "<div id='$NAME_Title' class='MainModalTitle'>$CONTENTTITLE</div>" +
 "<div style='float:left;display:none;' class='ErrorMsg dErrorMessage' id='showErrorMsgContainer'><div class='loginModalErrorMsgImg floatLeft'></div><div class='floatLeft galErrorMsg' id='showErrorMsg'></div></div>" +
 "<div style='margin-top:10px;'><input type='text' id='$NAME_txtTitle' name='$NAME_txtTitle' class='modalGallerytxtTitle' style='color:#666666;' maxlength='25' value='Enter Title' /><span id='spError' class='ErrorMsg'> *</span></div>" +
 "<div style='margin-top:10px;'><textarea id='$NAME_txtDesc' rows='6' cols='20' class='modalGallerytxtDesc' style='color:#666666;' maxlength='100'>Enter a description (optional)</textarea></div>" +
 "<div style='float:left' class='ErrorMsg'>* <span id='ErrorMsg'>Required Field</span></div><br/>" +
 //"<div style='float:left' class='ErrorMsg'><span id='showErrorMsg' style='visibility:visible;color:red;font-size:12px'></span></div>" +
 "<div class='clear'></div>"+
 "</div>";

/**
* This is the HTML content which renders Delete Art template
*@property deleteArtTemplate
*/
com.art.myGalleries.components.CommonComponent.prototype.deleteArtTemplate =
 "<div id='$NAME' style='margin-left:25px;margin-top:60px;margin-right:20px;'>" +
 "<div id='$NAME_Title' class='MainModalTitle' style='margin-bottom:10px;'>$CONTENTTITLE " +
 "\"$ARTNAME\"?</div>" +
 "<div id='$NAME_Content' class='modalContent'>$CONTENT</div>" +
 "<div class='clear'></div>" +
 "</div>";

/**
* This is the HTML content which renders Delete Gallery
*@property deleteGalleryTemplate
*/
com.art.myGalleries.components.CommonComponent.prototype.deleteGalleryTemplate =
 "<div id='$NAME' class='MainModalContainer'>" +
 "<div id='$NAME_Title' class='MainModalTitle'>$CONTENTTITLE " +
 " $GALLERYNAME</div>" +
 "<div id='$NAME_Content' class='modalContent'>$CONTENT</div>" +
 "<div class='clear'></div>" +
 "</div>";
com.art.core.components.BaseComponent.extend(com.art.myGalleries.components.CommonComponent.prototype);