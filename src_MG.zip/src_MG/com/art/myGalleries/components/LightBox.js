com.art.myGalleries.components.LightBox = function (id, data, app) {
    this.id = id;
    this.NAME = com.art.myGalleries.components.LightBox.NAME;
    this.app = app;
    this.moduleData = data;
    this.instance = this;
    this.callbacks = {};
};

com.art.myGalleries.components.LightBox.prototype.alpha = 0.4;
com.art.myGalleries.components.LightBox.NAME = "LightBox";

com.art.myGalleries.components.LightBox.prototype.getTemplate = function()
{
	return this.template.replace('$NAME',this.id);
};

com.art.myGalleries.components.LightBox.prototype.getDocHeight = function () {
    return Math.max($(document).height(), $(window).height(), /* For opera: */document.documentElement.clientHeight);
};

com.art.myGalleries.components.LightBox.prototype.getDocWidth = function () {
    return Math.max($(document).width(), $(window).width(), /* For opera: */document.documentElement.clientWidth);
};

com.art.myGalleries.components.LightBox.prototype.destroy = function () {

};

com.art.myGalleries.components.LightBox.prototype.doClose = function () {
    $("#" + this.id).remove();
};

com.art.myGalleries.components.LightBox.prototype.listNotificationInterests = function () {
    return [
	        this.app.events.CANCEL,
	        this.app.events.CLOSE_APP
	        ];
};

com.art.myGalleries.components.LightBox.prototype.handleNotification = function (note) {

    switch (note.name) {
        case this.app.events.CLOSE_APP:
            $("#" + this.NAME).remove();
            break;
        case this.app.events.CANCEL:
            trace('***** DESTROY: LightBox');
            //$("#"+this.NAME).remove();
            art.core.utils.destroyChildEvents($("#" + this.NAME));
            $("#" + this.NAME).remove();
            break;
    };
};

com.art.myGalleries.components.LightBox.prototype.render = function () {
    return this.getTemplate();
};
/**
* 
* @param eventName
* @param callback
*/
com.art.myGalleries.components.LightBox.prototype.registerCallback = function (eventName, callback) {
    this.callbacks[eventName] = callback;
};
com.art.myGalleries.components.LightBox.prototype.registerEvents = function () {
    
    $("#" + this.id).css({
        "position": "absolute",
        "top": "0px",
        "left": "0px",
        "background-color": "#000000",
        "z-index": 1001,
        "height": this.getDocHeight(),
        "width": this.getDocWidth(),
        "filter": "alpha (opacity=" + this.alpha + ")",
        "filter": "progid:DXImageTransform.Microsoft.Alpha(style=0, opacity=" + (this.alpha * 100) + ")",
        "-moz-opacity": this.alpha,
        "opacity": this.alpha,
        "-khtml-opacity": this.alpha
    });
    var _this = this;
    $(window).resize(function () {
        $("#" + _this.NAME).css({
            "height": _this.getDocHeight(),
            "width": _this.getDocWidth()
        });
    });

};

com.art.myGalleries.components.LightBox.prototype.template = '<div id="$NAME"><div id="mainLightboxContent"></div></div>';
	

