com.art.myGalleries.components.OptionButton = function (id, label, content, contentWidth, contentHeight, contentLeft,permission) {
    this.NAME = com.art.myGalleries.components.OptionButton.NAME;
    this.id = id;
    this.label = label;
    this.content = content;
    this.contentWidth = contentWidth;
    this.contentHeight = contentHeight;
    this.contentLeft = contentLeft;
    this.permission=permission;
    this._enabled=true;
    this.callbacks = {};
};
com.art.myGalleries.components.OptionButton.NAME = "OptionButton";
com.art.myGalleries.components.OptionButton.CLICK = "click";
com.art.myGalleries.components.OptionButton.HOVER = "hover";
com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK = "flyoutItemClicked";
com.art.myGalleries.components.OptionButton.COLOR_PICKER_CLICK = "colorPickerItemClicked";

com.art.myGalleries.components.OptionButton.prototype.render = function () {
    return this.getTemplate();
};
/**
* 
* @param eventName
* @param callback
*/
com.art.myGalleries.components.OptionButton.prototype.registerCallback = function (eventName, callback) {
    this.callbacks[eventName] = callback;
};
com.art.myGalleries.components.OptionButton.prototype.registerEvents = function () {
	
	if(!this._enabled)
		return;
    var _this = this;
    $("#" + this.id).live("click", function () {
        if (this.id != null && this.id != undefined) {
            switch (this.id) {
                case "background": case "sortby":  case "SlideShowShare":
                    if ($("#" + this.id + "_toggle").css("display") == "none") {                    	
                    	
                        $("#" + this.id + "_toggle").show();
                    }
                    else {
                        $("#" + this.id + "_toggle").hide();
                    }
                    break;
                    
                case "share": case "privacy":
                	var cookieobject = new com.art.core.cookie.Cookie(); 
                	var accountType=cookieobject.getCookieDictionary('ap','accounttype');                    
                    
                	//if(accountType!="1" && _this.permission!=200)
                	//	{
	                		if ($("#" + this.id + "_toggle").css("display") == "none") {                    	
	                        	
	                            $("#" + this.id + "_toggle").show();
	                        }
	                        else {
	                            $("#" + this.id + "_toggle").hide();
	                        }	
                		//}
                	
                	
                    break;
                default:
                    trace("others");
            }
        }
    });

    $("#" + this.id).mouseleave(function () {
        if (this.id != null && this.id != undefined) {
            switch (this.id) {
                case "background": case "sortby": case "privacy": case "share": case "SlideShowShare":
                    $("#" + this.id).removeClass("dynamicRightMenuContainer");
                    $("#" + this.id + "_toggle").hide();
                    break;
                default:
                    trace("others");
            }
        }
    });

    $("#" + this.id).mouseenter(function () {    	
        if (this.id != null && this.id != undefined) {
            switch (this.id) {
                case "background": case "sortby":
                    $("#" + this.id).addClass("dynamicRightMenuContainer");                    
                    break;
                case "privacy": case "share":
                	$("#" + this.id).addClass("dynamicRightMenuContainer");
                	//var cookieobject = new com.art.core.cookie.Cookie(); 
                	//var accountType=cookieobject.getCookieDictionary('ap','accounttype');
                	//if(accountType!="1" && _this.permission!=200)
            		//{
                	//	$("#" + this.id).addClass("dynamicRightMenuContainer");
                	//   $("#" + this.id).attr('title', 'You can not share this gallery');               	 
            		//}
                	//else
            		//{
                	//	$("#" + this.id).addClass("dynamicRightMenuContainer");            		
            		//}
                	break;                    
                default:
                    trace("others");
            }
        }
        var obj = { typeOfData: "FlyoutLinkClicked" };
        if (_this.callbacks[com.art.myGalleries.components.OptionButton.CLICK] != undefined) {
            _this.callbacks[com.art.myGalleries.components.OptionButton.CLICK](obj);
        }
    });

    $("#" + this.id + "_toggle li").mouseenter(function () {
        
        $(this).addClass("ControlBarMenuImgSelected");
        if ($.browser.msie) {
        }
        else {
            $(".nav li .dropDownText:hover").css("color", "#FFFFFF");
        }
    });

    $("#" + this.id + "_toggle li").mouseleave(function () {
        
        $(this).removeClass("ControlBarMenuImgSelected");
        if ($.browser.msie) {

        }
        else {
            $(".nav li .dropDownText").css("color", "#333333");
        }
    });

    var old = "";
    var flag = false;
    $("#" + this.id + "_toggle li").live("click", function () {
        if (_this.callbacks[com.art.myGalleries.components.OptionButton.COLOR_PICKER_CLICK] != null && _this.callbacks[com.art.myGalleries.components.OptionButton.COLOR_PICKER_CLICK] != undefined) {

            if (flag == true) {
                $("#" + old).add(document.getElementById("a")).css("border", "1px solid White");
                $("#" + this.id).add(document.getElementById("a")).css("border", "1px solid Red");
                old = this.id;
                flag = true;
            }
            if (flag == false) {
                old = this.id;
                $("#" + old).add(document.getElementById("a")).css("border", "1px solid Red");
                flag = true;
            }

            _this.callbacks[com.art.myGalleries.components.OptionButton.COLOR_PICKER_CLICK](this);
        }
    });

    $("#" + this.id + "_toggle .dropDownText").live("click", function () {    	
        if (_this.callbacks[com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK] != null && _this.callbacks[com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK] != undefined) {

            switch (this.id) {
                case "newest": case "oldest": case "artistAZ": case "artistZA": case "priceLH": case "priceHL": case "artTitleAZ": case "artTitleZA":
                    $(".imgTick").css("visibility", "hidden");
                    $(".imgTick").removeClass('imgSelected');
                    $("#img" + this.id).css("visibility", "visible");
                    $("#img" + this.id).addClass('imgSelected');
                    _this.callbacks[com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK](this);
                    break;
                case "everyone": case "inviteFriend":
                	if(this.id=="everyone")
                		{
                			 $("#imgInviteFriend").css("visibility", "hidden");
                			 $("#imgInviteFriend").removeClass('imgSelected');
                			 $(".imgPrivacyTick").removeClass('imgSelected');
                			 $("#imgEveryone").css("visibility", "visible");
                             $("#imgEveryone").addClass('imgSelected');
                            
                		}                	                    
                    _this.callbacks[com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK](this);
                    break;
                case "shareEmail": case "shareFacebook":
                    //$(".imgPrivacyTick").css("visibility", "hidden");
                    //$(".imgPrivacyTick").removeClass('imgSelected');
                    //$("#img" + this.id).css("visibility", "visible");
                    //$("#img" + this.id).addClass('imgSelected');
                    _this.callbacks[com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK](this);
                    break;
                default:
                    trace("others");
            }
        }
    });

    $("#" + this.id + "_toggle li").mouseenter(function () {
        if (_this.callbacks[com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK] != null && _this.callbacks[com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK] != undefined) 
        {
            if ($(this).find('.imgTick').hasClass('imgSelected'))
            	{
            		$('.imgTick').css('background-position', '-58px -78px');
            	}
            else if ($(this).find('.imgPrivacyTick').hasClass('imgSelected'))
            	{
                    $('.imgPrivacyTick').css('background-position', '-58px -78px');
            	}
        }       
    });
    $("#" + this.id + "_toggle li").mouseleave(function () {
        if (_this.callbacks[com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK] != null && _this.callbacks[com.art.myGalleries.components.OptionButton.FLYOUT_ITEM_CLICK] != undefined) 
        {
            $('.imgSelected').css('background-position', '-58px -92px');
        }
    });

    $("#" + this.id + "_toggle").bind('mouseleave', function () {
        setTimeout(function () { $("#sortby_transparent").fadeIn(); }, 2500);
    });

};

com.art.myGalleries.components.OptionButton.prototype.enabled = function (bool) {
	this._enabled=bool;
	var opacity=this._enabled?1:0.25;
	$("#" + this.id).css('opacity',opacity);	
	$("#" + this.id).unbind("live");
	$("#" + this.id).unbind("click");
	$("#" + this.id).unbind("mouseenter");
	$("#" + this.id).unbind("mouseleave");
	$("#" + this.id).die();
	this.registerEvents();
};

com.art.myGalleries.components.OptionButton.prototype.getTemplate = function () {
    //STEP: Get the raw string for the template
    var returnValue = this.template;
    //STEP: Now return the string (template)
    return returnValue.replace(/\$NAME/g, this.id).replace('$LABEL', this.label).replace('$CONTENT', this.content).replace("$W", this.contentWidth).replace("$H", this.contentHeight).replace("$L", this.contentLeft);
};
/**
* Main Div template for showing the right side menu e.g. background, sort by, privacy and share
* @param eventName
* @param callback
*/
com.art.myGalleries.components.OptionButton.prototype.template =
	'<div id="$NAME" class="RightMenuContainer">' +
		'<div id="$NAME_icon" class="$NAME_icon">' +
		'</div>' +
      '<div id="$NAME_label" class="RightMenuLabel">' +
			'<label>$LABEL</label>' +
		'</div>' +
        '<div id="$NAME_transparent" class="transparent" >' +
		    '<div id="$NAME_toggle" style="width:$Wpx;height:$Hpx;left:$Lpx;" class="MainToggleDiv">$CONTENT</div>' +
        '</div>' +
	'</div>';

