com.art.myGalleries.components.GridComponent = function(id,w,h,imagesPerPage,model,imageDomain,currencyCode)
{
	this.imagesPerPageSupported = {DEFAULT:24,SIX:6};
	
	if(typeof id != typeof 'someId')
		throw new Error("ImageScrollerComponent constructor failure! Invaid argument for id");
	if(typeof w != typeof 1 || typeof h != typeof 1)
		throw new Error("ImageScrollerComponent constructor failure! Invaid argument for w and/or h");
	//if(!(imagesPerPage == this.imagesPerPageSupported.DEFAULT || imagesPerPage == this.imagesPerPageSupported.SIX))
	//	throw new Error("ImageScrollerComponent constructor failure! imagesPerPage["+imagesPerPage+"] is NOT supported");
	if(model.NAME != com.art.myGalleries.proxies.ApplicationProxy.NAME)
		throw new Error("ImageScrollerComponent constructor failure! Model is invalid");
	
	this.id							= id;
	this.NAME 						= com.art.myGalleries.components.GridComponent.NAME;
	this.NEXT 						= com.art.myGalleries.components.GridComponent.NEXT;
	this.PREVIOUS 					= com.art.myGalleries.components.GridComponent.PREVIOUS;
	this.IMAGE_CLICK 				= com.art.myGalleries.components.GridComponent.IMAGE_CLICK;
	this.THUMB_CLICK 				= com.art.myGalleries.components.GridComponent.THUMB_CLICK;
	this.SLIDE_SHOW_STARTUP_CLICK 	= com.art.myGalleries.components.GridComponent.SLIDE_SHOW_STARTUP_CLICK;
	this.SLIDE_SHOW_CLOSE			= com.art.myGalleries.components.GridComponent.SLIDE_SHOW_CLOSE;
	this.SLIDE_SHOW_PAUSE			= com.art.myGalleries.components.GridComponent.SLIDE_SHOW_PAUSE;
	this.SLIDE_SHOW_NEXT			= com.art.myGalleries.components.GridComponent.SLIDE_SHOW_NEXT;
	this.SLIDE_SHOW_PREVIOUS		= com.art.myGalleries.components.GridComponent.SLIDE_SHOW_PREVIOUS;
	this.SLIDE_SHOW_RESUME			= com.art.myGalleries.components.GridComponent.SLIDE_SHOW_RESUME;
	this.PRODUCTPAGE_CLICK 			= com.art.myGalleries.components.GridComponent.PRODUCTPAGE_CLICK;
	this.ADD_TO_SELECTION			= com.art.myGalleries.components.GridComponent.ADD_TO_SELECTION;
	this.ADD_TO_PIVOT   			= com.art.myGalleries.components.GridComponent.ADD_TO_PIVOT;
	this.ADD_TO_CART				= com.art.myGalleries.components.GridComponent.ADD_TO_CART;
	this.ARTIST_ID					= com.art.myGalleries.components.GridComponent.ARTIST_ID;
	this.CLOSE_DETAILS				= com.art.myGalleries.components.GridComponent.CLOSE_DETAILS;
	this.ITEMSILIKE_EXACTMATCH		= com.art.myGalleries.components.GridComponent.ITEMSILIKE_EXACTMATCH;
	this.width = w;
	this.height = h;
	this.imagesPerPage = imagesPerPage;
	this.model = model;
	this.nextBtnID 		= 'imgScrollCompNext';
	this.previousBtnID 	= 'imgScrollCompPrev';
	this.nextButtonEnabled = false;
	this.previousButtonEnabled = false;
	this.callbacks = {};
	this.callbacks[this.id] = {};
	this.target;
	this.newMarginLeft = 0;
	this.activeGrid; //grid offscreen, to populate with images
	this.inactiveGrid; //grid that will be moved off screen; as soon as user triggers naviation control, current grid will become inactive
	this.processing = false; //true when async/animation call is in process; block additional interaction; blocks repeated clicks
	this.isPaused = false;
	this.currencyCode = currencyCode;
	this.hideArtistLink = false;
	this.setAPNUMForInfo = '';
	this.sizeSettings = 
	{
		options:{DEFAULT:'default',LARGE:'large'},
		sizeLabel:'large',
		thumbSizes:{
			6:{'default':{width:189,height:189},'large':{width:239,height:239}},
			24:{'default':{width:94,height:94},'large':{width:117,height:117}}
		},
		hoverPanelSizeOptions:{INIT:'initial',ENLARGED:'enlarged',DETAILS:'details'},
		hoverPanelSizes:{
			6:{
				'default':{initial:{width:200,height:200},enlarged:{width:360,height:360},details:{width:280,height:380}},
				'large':{initial:{width:250,height:250},enlarged:{width:460,height:460},details:{width:360,height:460}}
			},
			24:{
				'default':{initial:{width:120,height:120},enlarged:{width:200,height:200},details:{width:280,height:380}},
				'large':{initial:{width:150,height:150},enlarged:{width:230,height:230},details:{width:360,height:460}}
			}
		}
	};
	this.fullDetailsDisplayDisabled = false;
	this.addToSelectionDisabled	= false;
	this.addToPivotDisabled = true;

	
	
	this.detailsDelayTimerID;
	this.navigationButtonWidths = 22;
	this.autoAnimate = false; //animate after images are loaded
	this.imageDomain = imageDomain;
	this.slideShowToggle = false;
	this.slideShowTimerID;
	this.slideShowCursor = -1; //position of slideshow
	this.buttonStates = {};
	this.buttonStates['default'] = {previous:{disabled:"-137px -172px",hover:"-115px -172px",enabled:"-93px -172"},next:{disabled:"-93px -569px",hover:"-115px -569px",enabled:"-137px -569px"}};
	this.buttonStates['large'] = {previous:{disabled:"-44px -209px",hover:"-22px -209px",enabled:"0px -209px"},next:{disabled:"0px -703px",hover:"-22px -703px",enabled:"-44px -703px"}};
	this.slideShowControls = {};
	//play/pause share same div see slideShowStartupMainControls() method
	this.slideShowControlsIsPaused = false;
	this.slideShowControls['default'] = {
			show:{enabled:"-93px -147px",hover:"-116px -147px",disabled:"-139px -147px",width:'23px',height:'23px'},
			play:{enabled:"-93px -59px",hover:"-118px -59px",width:"25px",height:"25px"},
			pause:{enabled:"-93px -89px",hover:"-118px -89px",width:"25px",height:"25px"},
			previous:{enabled:"-93px 0px",hover:"-118px 0px",width:"25px",height:"25px"},
			next:{enabled:"-93px -30px",hover:"-118px -30px",width:"25px",height:"25px"},
			close:{enabled:"-93px -118px",hover:"-118px -118px",width:"25px",height:"25px"}
	};
	this.slideShowControls['large'] = {
			show:{enabled:"0px -179px",hover:"-28px -179px",disabled:"-56px -179px",width:'28px',height:'28px'},
			play:{enabled:"0px -71px",hover:"-31px -71px",width:"31px",height:"31px"},
			pause:{enabled:"0px -107px",hover:"-31px -107px",width:"31px",height:"31px"},
			previous:{enabled:"0px 0px",hover:"-31px 0px",width:"31px",height:"31px"},
			next:{enabled:"0px -36px",hover:"-31px -36px",width:"31px",height:"31px"},
			close:{enabled:"0px -143px",hover:"-31px -143px",width:"31px",height:"31px"}
	};
	/*
	 * flag object used to use fade transition instead of swipe
	 * used with initFadeTransition() & completeFadeTransition()
	 */
	this.fadeTransitionStates = {COMPLETE:'complete',STARTED:'started'};
	this.fadeTransition = {state:this.fadeTransitionStates.COMPLETE,use:false};
	this.ssProcessing = false;
	this.ssCurrent;
	this.ssNext;
	this.ssContainerWidth;
	this.ssContainerHeight;
	this.slideShowStartupButtonSelector = null;
	this.slideShowMainControlParentSeletor = null;
	this.activeItems = []; //{apnum:---,croppedURL:---} set in setImages; used for slideshow
	this.ssScrollDirectionOptions = {LEFT:'left',RIGHT:'right'};
	this.ssScrollDirection = this.ssScrollDirectionOptions.LEFT;
	this.ssCurrentCursor = 0;
	this.ssIsPaused = false;
	/*
	 * Required for both flows wizard and matchMyImage
	 */
	this.ssLoadImageModelMethodName = "getItemByApnum"; //default
	this.loadingStatusDelay = 2000; //2sec
	this.ResolutionFolder = {DEFAULT : "900x497",LARGE : "1120x618"};
	this.imagePath = "/images/VisualSearch/v2/";
	this.noEnoughResultsImgPrefix = "noenoughresults";
};
//static vars
com.art.myGalleries.components.GridComponent.NAME 						= "ImageScrollerComponent";
com.art.myGalleries.components.GridComponent.NEXT 						= "next";
com.art.myGalleries.components.GridComponent.PREVIOUS 					= "previous";
com.art.myGalleries.components.GridComponent.IMAGE_CLICK 					= "imageClick";
com.art.myGalleries.components.GridComponent.THUMB_CLICK 					= "thumbClick";
com.art.myGalleries.components.GridComponent.SLIDE_SHOW_STARTUP_CLICK 	= 'slideShowStartup';
com.art.myGalleries.components.GridComponent.SLIDE_SHOW_CLOSE				= 'slideShowClose';
com.art.myGalleries.components.GridComponent.SLIDE_SHOW_PAUSE				= 'slideShowPause';
com.art.myGalleries.components.GridComponent.SLIDE_SHOW_NEXT				= 'slideShowNext';
com.art.myGalleries.components.GridComponent.SLIDE_SHOW_PREVIOUS			= 'slideShowPrevious';
com.art.myGalleries.components.GridComponent.SLIDE_SHOW_RESUME			= 'slideShowResume';
com.art.myGalleries.components.GridComponent.PRODUCTPAGE_CLICK 			= "productPageClick";
com.art.myGalleries.components.GridComponent.ADD_TO_SELECTION				= 'addToSelection';
com.art.myGalleries.components.GridComponent.ADD_TO_PIVOT  				= 'addToPivot';
com.art.myGalleries.components.GridComponent.ADD_TO_CART					= 'addToCart';
com.art.myGalleries.components.GridComponent.ARTIST_ID					= 'artistID';
com.art.myGalleries.components.GridComponent.CLOSE_DETAILS				= 'closeDetails';
com.art.myGalleries.components.GridComponent.ITEMSILIKE_EXACTMATCH		= "itemsilike_exactmatch";

com.art.myGalleries.components.GridComponent.prototype.updateControls = function()
{
	var n = $("#"+this.nextBtnID);
	var p = $("#"+this.previousBtnID);
	var _this = this;
	if(this.nextButtonEnabled)
	{
		n.css("backgroundPosition",this.buttonStates[_this.sizeSettings.sizeLabel]['next'].enabled);
		n.unbind('mouseenter');
		n.unbind('mouseleave');
		n.die(); //always clear first
		n.hover(function(){ $(this).css("backgroundPosition",_this.buttonStates[_this.sizeSettings.sizeLabel]['next'].hover);},function(){ $(this).css("backgroundPosition",_this.buttonStates[_this.sizeSettings.sizeLabel]['next'].enabled);});
		n.live("click",function(){
			_this.doNext();
		});
	}
	else
	{
		n.css("backgroundPosition",this.buttonStates[this.sizeSettings.sizeLabel]['next'].disabled);
		n.die();
		n.unbind('mouseenter');
		n.unbind('mouseleave');
	}
	if(this.previousButtonEnabled)
	{
		p.css("backgroundPosition",this.buttonStates[this.sizeSettings.sizeLabel]['previous'].enabled);
		p.unbind('mouseenter');
		p.unbind('mouseleave');
		p.die();//always clear first
		p.hover(function(){ $(this).css("backgroundPosition",_this.buttonStates[_this.sizeSettings.sizeLabel]['previous'].hover);},function(){$(this).css("backgroundPosition",_this.buttonStates[_this.sizeSettings.sizeLabel]['previous'].enabled);});
		p.live("click",function(){
			_this.doPrevious();
		});
	}
	else
	{
		p.css("backgroundPosition",this.buttonStates[this.sizeSettings.sizeLabel]['previous'].disabled);
		p.die();
		p.unbind('mouseenter');
		p.unbind('mouseleave');
	}
};
com.art.myGalleries.components.GridComponent.prototype.getTemplate = function()
{
	//STEP: Get the raw string for the template
	var returnValue = this.template;
	//STEP: Replace the [IMAGE_DOMAIN] placeholder with the imagePath value
	//returnValue = returnValue.replace(/\[IMAGE_DOMAIN\]/gi, this.imagePath);
	//STEP: Now return the string (template)
	returnValue = returnValue.replace('$W', this.width+2);
	returnValue = returnValue.replace('$H', this.height);
	returnValue = returnValue.replace(/\$NAME/g,this.id);
	returnValue = returnValue.replace(/\$CW/g, this.getContentWidth()+2);
	returnValue = returnValue.replace('$X', this.nextBtnID);
	returnValue = returnValue.replace('$P', this.previousBtnID);
	returnValue = returnValue.replace(/\$SPRITE/g, this.imageDomain);
	returnValue = returnValue.replace("$BGPOS_NEXT",this.buttonStates[this.sizeSettings.sizeLabel]['next'].disabled).replace("$BGPOS_PREV",this.buttonStates[this.sizeSettings.sizeLabel]['previous'].disabled);
	return returnValue;
};
com.art.myGalleries.components.GridComponent.prototype.isCreated = function()
{
	return this.target.width() != null;
};
com.art.myGalleries.components.GridComponent.prototype.startup = function(targetName, showSplashScreen,data)
{
	this.target = $(targetName);
	if(this.target.width() == null || this.target.height() == null)
		throw new Error("ImageScrollerComponent.startup(target) failed! target is undefined");
		
	this.target.html(this.getTemplate());
	$("#"+this.id+"_content").css({width:(this.getContentWidth()*2)+10});
	
	//prep grid
	if(showSplashScreen && typeof showSplashScreen == "boolean")
	{
		var s = this.getSplashScreen(data);
		$("#"+this.id+"_contentClear").before(s);
	}
	else
	{
		this.appendGrid();
	}
	this.updateControls();
	
	
	var _this = this;
	//clear first
	
};
com.art.myGalleries.components.GridComponent.prototype.getDimensions = function(sizeOption)
{
	//we need to switch to full details mode if below is all true
	if(sizeOption == this.sizeSettings.hoverPanelSizeOptions.ENLARGED && !this.fullDetailsDisplayDisabled && this.imagesPerPage == this.imagesPerPageSupported.SIX)
	{
		sizeOption = this.sizeSettings.hoverPanelSizeOptions.DETAILS;
	}
	var sides = this.sizeSettings.hoverPanelSizes[this.imagesPerPage][this.sizeSettings.sizeLabel][sizeOption];
	if(!sides)
		throw new Error("ImageScrollerComponent.getDimensions() invalid sizes object");
	return sides;		
};
/*
 * return {top:00px,left:00px,width:0px,height:0px}
 */
com.art.myGalleries.components.GridComponent.prototype.getHoverPositionAndSize = function(sizeOption,originalThumbObj)
{
	var output 		= {width:false,height:false,top:false,left:false};
	
	var parentWidth 	= $("#"+this.id+"_clip").width(),
	parentHeight 		= $("#"+this.id+"_clip").height(),
	parentOffset 		= $("#"+this.id+"_clip").offset();
	
	//set width and height
	output.width 	= this.getDimensions(sizeOption).width;
	output.height 	= this.getDimensions(sizeOption).height;
	
	//lets find top and left position
	//first,find column/totalColumns and row/totalRows; only on initial load
	if(originalThumbObj != undefined)
	{
		var thumbWidth 	= originalThumbObj.width(),
		thumbHeight		= originalThumbObj.height(),
		thumbOffset		= originalThumbObj.offset();
		
		
		var col = Math.ceil((thumbOffset.left-parentOffset.left)/thumbWidth);
		var totalCols = Math.floor(parentWidth/thumbWidth);
		var row = Math.ceil((thumbOffset.top- parentOffset.top)/thumbHeight);
		var totalRows = Math.floor(parentHeight/thumbHeight);
		
		//difference between current width/height
		var diffWidth =  Math.round((output.width-thumbWidth)/2),
		diffHeight =  Math.round((output.height-thumbHeight)/2);
		
		output.left = (col == 1) ? 0 : (col == totalCols) ? (Math.round(thumbOffset.left - parentOffset.left)- Math.round(output.width-thumbWidth))+2 : Math.round((thumbOffset.left-parentOffset.left)-diffWidth);
		output.top = (row == 1) ? 0 : (row == totalRows) ? (Math.round(thumbOffset.top - parentOffset.top)- Math.round(output.height-thumbHeight))+2 : Math.round((thumbOffset.top-parentOffset.top)-diffHeight);
	}
	else
	{
		var obj = $("#"+this.getHoverName());
		if(obj != undefined && obj.attr('id') != undefined)
		{
			var pos = obj.position();
			if(pos.top == null || pos.top == undefined)
				return;
			
			var off = obj.offset();
			var diffTop = Math.abs(pos.top - parentOffset.top);
			var diffLeft = Math.abs(off.left - parentOffset.left);
			var diffWidth =  Math.round((output.width-obj.width())/2),
			diffHeight =  Math.round((output.height-obj.height())/2);
			var newLeft = Math.round(pos.left-(diffWidth/2));
			output.left = (pos.left <= 0) ? 0 : ((newLeft + output.width) > parentWidth) ? Math.round(parentWidth - (output.width+2)) : newLeft;
			var newTop = Math.round(pos.top-(diffHeight/2));
			output.top = (pos.top <= 0) ? 0 : ((newTop + output.height) > parentHeight) ? Math.round(parentHeight - (output.height+4)) : newTop;
		}
	}

	//trace(output);
	//trace('pwidth: '+parentWidth);
	//trace('pheight: '+parentHeight);
	return output;
};
/*
 * Initial Scale step
 */
com.art.myGalleries.components.GridComponent.prototype.showDetails = function(thumbObj)
{
	var _this 				= this;
	var hoverName 			= this.getHoverName();
	var apnum = thumbObj.attr('id');
	
	$("#"+this.id+"_clip").append(this.getHoverTemplate());
	
	//hide icon IF "i" icon is ENABLED
	$('.VSResultsInfoIcon').css("opacity",0);
	//get initial position and size
	var initPos = this.getHoverPositionAndSize(this.sizeSettings.hoverPanelSizeOptions.INIT,thumbObj);
	$('#'+this.getHoverName()).css({"left":initPos.left,"top":initPos.top,"width":+initPos.width,"height":initPos.height});
	var bgimg = thumbObj.css("background-image");
	var u = bgimg.replace(/url\(/,'');
	u = u.replace(/\)/,'');
	u = u.replace(/"/g,'');
	var enlargedSize = this.getHoverPositionAndSize(this.sizeSettings.hoverPanelSizeOptions.ENLARGED,thumbObj);
	var zoomImg = this.getBackgroundImage(u, 1000, 1000, enlargedSize.width, enlargedSize.height);
	$("#imgAspectRatio").attr('src',zoomImg);
	$("#imgAspectRatio").load(function(){
		$(this).hide();
		var h = $(this).height();
		var newTop = h+'px';
	});
	$('#heroHover').attr('src',u);
	 // var newDiff = Math.round((lrgHoverSides.width - smHoverSides.width)/2);
	this.detailsDelayTimerID = setTimeout(function(){
		 /*
		  * If 6 imagesPer and fullDetails is NOT disabled initial doGrow will show details; otherwise to default doGrow() and "i" icon will either be there or not see getHoverTemplate()
		  */
		 /*
		  * By default loading the bigger zoom on hover for both 6 and 24 images per view as per Roberto's request.
		  */
		 //var size = (_this.imagesPerPage == 6 && !_this.fullDetailsDisplayDisabled) ? _this.sizeSettings.hoverPanelSizeOptions.DETAILS : _this.sizeSettings.hoverPanelSizeOptions.ENLARGED;
		 var size = (!_this.fullDetailsDisplayDisabled) ? _this.sizeSettings.hoverPanelSizeOptions.DETAILS : _this.sizeSettings.hoverPanelSizeOptions.ENLARGED;
		 _this.animateNewHover(apnum, size);
	 },1500);
	 

	 
	$('#'+this.getHoverName() + ' > img#imgAspectRatio').bind('click',function(){
		trace("************* THis image was clicked");
		
		_this.processing = true;
		if(!_this.fullDetailsDisplayDisabled)
			_this.hideDetails();
		//STEP: Kill the timeout if it is there
		clearTimeout(_this.detailsDelayTimerID);
		_this.callbacks[_this.id][_this.IMAGE_CLICK](apnum);
	});	
	
	$('#'+this.getHoverName() + ' > img#heroHover').bind('click',function(){
		_this.callbacks[_this.id][_this.THUMB_CLICK](apnum);
	});
	
	 $('#'+this.getHoverName()).mouseleave(function() {
		//_this.hideDetails();
		//$('#'+this.getHoverName()).stop(true,true); //cancel all animations
		//STEP: Kill the timeout if it is there
		//clearTimeout(_this.detailsDelayTimerID);
	 });
	
	 // added this so that when animation is going on and user mouseout it will hide the details.
	 $("#"+this.id+"_clip").mouseleave(function() {
		//_this.hideDetails();
		//$('#'+_this.getHoverName()).stop(true,true); //cancel all animations
		//STEP: Kill the timeout if it is there
		//clearTimeout(_this.detailsDelayTimerID);
	 });
};
/*
 * After small hover animates to MED
 */
com.art.myGalleries.components.GridComponent.prototype.postAnimateToDefault = function(apnum,origWidth,origHeight)
{
	var _this = this;
	trace("postAnimateToDefault");
	var padding = 40;
	var obj = $("#"+this.getHoverName());
	//no longer needed; use crop service var scale = art.core.utils.scaleElement($("#imgAspectRatio").width(), $("#imgAspectRatio").height(), $(this).width(), $(this).height(), padding);
	$("#imgAspectRatio").css({top:Math.round(($(obj).height() - $("#imgAspectRatio").height())/2),left:Math.round(($(obj).width()-$("#imgAspectRatio").width())/2)});
	$("#imgAspectRatio").addDropShadow('angle');
	$("#imgAspectRatio").show();
	var p = $("#imgAspectRatio").position();
	
	
	$('#heroHover').animate({"opacity":"0"},500,function(){
		$(this).remove();
	});
	if(!this.fullDetailsDisplayDisabled && apnum != _this.model.getOtherCategoryResultsAPNum())
	{
		$('.VSResultsInfoIcon').animate({"opacity":"100"},500);
		$('.VSResultsInfoIcon').mouseenter(function() {
			$(this).css('background-position','-23px -25px');
		 });
		 $('.VSResultsInfoIcon').mouseleave(function() {
			$(this).css('background-position','4px -25px');
		 });
		 $('.VSResultsInfoIcon').click(function(e){
				e.stopPropagation();
				$("#imgAspectRatio").animate({"opacity":0},250);
				_this.animateHover(apnum, _this.sizeSettings.hoverPanelSizeOptions.DETAILS);
			});
	}
};
/*
 * After small hover animates to LRG
 */
com.art.myGalleries.components.GridComponent.prototype.postAnimateToDetails= function(apnum,origWidth,origHeight)
{
	
	//ensure this is not visible
	var op = parseInt($('#heroHover').css("opacity"));
	if(op > 0)
	{
		$('#heroHover').animate({"opacity":"0"},500,function(){
			$(this).remove();
		});
	}
			
	var _this = this;
	var imgVO = new art.core.vos.ImageVO();
	imgVO.parseSearchServiceImageDetail(this.model[this.ssLoadImageModelMethodName](apnum) );
	
	
	
	var perc = $('#'+this.getHoverName()).width() / origWidth;
	var tmpW = Math.round($("#imgAspectRatio").width() * perc);
	var tmpH = Math.round($("#imgAspectRatio").height() * perc);
	var l = Math.round(($('#'+this.getHoverName()).width()-tmpW)/2);
	var imgARPos = $("#imgAspectRatio").position();
	var t = imgARPos.top <= 0 ? 10 : imgARPos.top; //for 6 imagesPerPage
	$("#imgAspectRatio").css("top",t+"px");
	$("#imgAspectRatio").animate({"opacity":0},200,function(){
		//close button
		$('.VSResultsInfoIcon img').attr("title","close");
		$('.VSResultsInfoIcon img').attr("alt","close");
		$('.VSResultsInfoIcon').die();
		$('.VSResultsInfoIcon').unbind('mouseenter');
		$('.VSResultsInfoIcon').unbind('mouseleave');
		$('.VSResultsInfoIcon').width(10);
		$('.VSResultsInfoIcon').height(10);
		$('.VSResultsInfoIcon').css("background-image","url(http://cache1.artprintimages.com/images/visualsearch/v2/imagesprite.gif)");
		$('.VSResultsInfoIcon').css("background-position","0px -1210px");
		$('.VSResultsInfoIcon').css("background-repeat","no-repeat");
		$('.VSResultsInfoIcon').css("margin","8px");
		
		var iconOp = parseInt($('.VSResultsInfoIcon').css("opacity"));
		if(iconOp < 100)
			$('.VSResultsInfoIcon').animate({"opacity":"100"},500); //6 imagesPerPage needs this
		
		$('.VSResultsInfoIcon').mouseenter(function(){
			$(this).css("background-position","-17px -1210px");
		});
		$('.VSResultsInfoIcon').mouseleave(function(){
			$(this).css("background-position","0px -1210px");
		});
		$('.VSResultsInfoIcon').click(function(e){
			e.stopPropagation();
			_this.hideDetails();
			_this.resumeHover();
			_this.callbacks[_this.id][_this.CLOSE_DETAILS]();
		});
		
		var p = $(this).position();
		var u = _this.getBackgroundImage($(this).attr('src'),1000, 1000, parseInt($('#'+_this.getHoverName()).width()), parseInt($('#'+_this.getHoverName()).width()));
		var newImg = "<img src='"+u+"' id='fullRes' style='position:absolute;z-index:400;top:$Tpx;left:$Lpx;cursor:pointer;'/>";
		var tp = p.top <= 0 ? 25 : p.top;
		newImg = newImg.replace("$T",tp).replace("$L",p.left);
		$('#'+_this.getHoverName()).append(newImg);
		$("#fullRes").css("opacity",0);
		$("#fullRes").load(function(){
			$(this).addDropShadow('angle');
			$(this).css("left",Math.round(($('#'+_this.getHoverName()).width()-$(this).width())/2)+"px");
			
			$(this).animate({'opacity':100},2000);
			var p = $(this).position();
			if(p != null && p != undefined)
			{
				//top image area will always be a square with sides == to width; thus our info will begin after w + 10px for padding
				if(document.all)
					var top = p.top+Math.round($(this).height())+10;
				else
					var top = p.top+Math.round($(this).height())+20;
			}	
			else { top = 0; }
			var h = origHeight - top;
			var w = $('#'+_this.getHoverName()).width();
			
			//STEP: There is a "placeholder" apnum that separates result sets...this apnum should not get the hover treatment
			if (apnum != _this.model.getOtherCategoryResultsAPNum())
			{
				var artistLine = "";
				if(imgVO.ArtistName != "")
					if(_this.hideArtistLink)
						artistLine = "<div style='text-align:center;font-size:11px;font-family:Arial,sans-serif;'>by <span id='fullDetailsArtist'>"+imgVO.ArtistName+"</span></div>";
					else
						artistLine = "<div style='text-align:center;font-size:11px;font-family:Arial,sans-serif;'>by <span id='fullDetailsArtist' style='color:blue;text-decoration:underline;cursor:pointer'>"+imgVO.ArtistName+"</span></div>";					
					
				var addToSelectionBtn = _this.addToSelectionDisabled ? "" : "<td style='width:50%;'><div id='fullDetailsAddSelection'    style='display:inline;float:left;width:78px;margin:3px;height:22px;cursor:pointer;font-family:Arial,sans-serif;background-image:url(http://cache1.artprintimages.com/images/visualsearch/v2/imagesprite.gif); background-repeat:no-repeat;background-position:0px -1230px'/></td>";
				var addToPivotBtn = _this.addToPivotDisabled ? "" :         "<td style='width:50%;'><div id='fullDetailsAddPivot'        style='display:inline;float:left;width:105px;margin:3px;height:22px;cursor:pointer;font-family:Arial,sans-serif;background-image:url(http://cache1.artprintimages.com/images/visualsearch/v2/imagesprite.gif); background-repeat:no-repeat;background-position:0px -1330px'/></td>";
				var superZoomIcon =                                         "<td style='width:30px;' align=center><div id='iconImageZoom' style='margin:0;width:20;height:20;background-image:url(http://cache1.artprintimages.com/images/visualsearch/v2/imagesprite.gif); background-repeat:no-repeat;background-position:0px -1300px;cursor:pointer;'/></td>";
				var str =
					"<div id='fullRes_details'style='position:absolute; z-index:120;border:0px solid; width:"+w+"px;height:"+h+"px;top:"+(top-10)+"px'>"+
						"<div id='fullRes_details_copy' style='position:absolute;width:"+w+"px;'>"+
							"<div style='text-align:center;font-size:11px;font-family:Arial,sans-serif'>"+imgVO.Title+"</div>"+
							artistLine +
							"<div style='text-align:center;font-size:11px;font-family:Arial,sans-serif'>"+art.core.utils.formatDimensions(imgVO.PhysicalInchWidth, imgVO.PhysicalInchHeight, art.core.utils.doConvertToCentimeter(_this.currencyCode)) + "</div>"+
							"<div style='text-align:center;font-size:11px;font-family:Arial,sans-serif'>"+imgVO.MasterDisplayPrice+"</div>"+
							"<div id='fullRes_padding'></div>"+
							"<div style='height:30px;background-color:#f6f6f6;' class='fullRes_btnContainer'><table style='padding:0;margin:0;border:0;width:100%'><tr>"+
								addToSelectionBtn+
								addToPivotBtn+
								superZoomIcon+
								//"<td style='width:50%;' align=right><div id='fullDetailsAddToCart' style='margin:3px;height:22px;width:65px;cursor:pointer;background-image:url(http://cache1.artprintimages.com/images/visualsearch/v2/imagesprite.gif); background-repeat:no-repeat;background-position:0px -1263px'/></td>"+
								"<td style='width:50%;' align=right><div id='fullDetailsInfo' style='margin:3px;height:22px;width:65px;cursor:pointer;background-image:url(http://cache1.artprintimages.com/images/visualsearch/v2/icontraysprite.png); background-repeat:no-repeat;background-position:0 -27px;width:21px;height:21px;'/></td>"+
								"</tr></table><div style='clear'></div>"+
							"</div>"+
						"</div>"+
					"</div>";
								
				$('#'+_this.getHoverName()).append(str);
				var p = $("#fullRes_details").position();
				var padding = Math.round($('#'+_this.getHoverName()).height() - ($("#fullRes_details_copy").height()+p.top-1));
				
				var userAgent = navigator.userAgent.toLowerCase(); 
				$.browser.chrome = /chrome/.test(navigator.userAgent.toLowerCase()); 
				
				// Is this a version of Chrome?
				if($.browser.chrome){
					padding = padding - 5;
				}
				// This fix is for alignment issue for Portriat images in IE browsers.
				var numofDivs = $("#fullRes_details_copy div").size();
				if($.browser.msie && numofDivs >= 10){
					if($('#fullRes').width() < $('#fullRes').height()){
						$('#fullRes_padding').hide();
						$('.fullRes_btnContainer').css('margin-top','5px');
					}
				}
				//SECTION - EVENTS - Declare all events for the elements for Hover here...
				$('#'+_this.getHoverName() + ' > img#fullRes').bind('click',function(){					
					_this.processing = true;
					//STEP: Kill the timeout if it is there
					clearTimeout(_this.detailsDelayTimerID);
					_this.callbacks[_this.id][_this.IMAGE_CLICK](imgVO.Apnum);
				});
				
				$('#fullRes_padding').height(padding);
				$("#fullDetailsAddSelection").click(function(e){
					e.stopPropagation();
					_this.callbacks[_this.id][_this.ADD_TO_SELECTION](imgVO.Apnum);
				});
				$("#fullDetailsAddPivot").click(function(e){
					e.stopPropagation();
					_this.hideDetails();
					_this.processing = true;
					//STEP: Kill the timeout if it is there
					clearTimeout(_this.detailsDelayTimerID);
					_this.callbacks[_this.id][_this.ADD_TO_PIVOT](imgVO.Apnum);
				});
				$("#fullDetailsAddSelection").mouseenter(function(){
					$(this).css("background-position","-88px -1230px");
				});
				$("#fullDetailsAddSelection").mouseleave(function(){
					$(this).css("background-position","0px -1230px");
				});
				$("#fullDetailsAddPivot").mouseenter(function(){
					$(this).css("background-position","-115px -1330px");
				});
				$("#fullDetailsAddPivot").mouseleave(function(){
					$(this).css("background-position","0px -1330px");
				});	
				$("#fullDetailsAddToCart").mouseenter(function(){
					$(this).css("background-position","-88px -1263px");
				});
				$("#fullDetailsAddToCart").mouseleave(function(){
					$(this).css("background-position","0px -1263px");
				});
				$("#fullDetailsAddToCart").click(function(e){
					e.stopPropagation();
					_this.callbacks[_this.id][_this.ADD_TO_CART](imgVO);
				});
				$('#fullDetailsInfo').live('mouseenter', function() {
					$(this).css("background-position","-27px -27px");
				});
				$('#fullDetailsInfo').live('mouseleave', function() {
					$(this).css("background-position","0px -27px");
				});
				$("#fullDetailsInfo").click(function(e){
					e.stopPropagation();
					trace("ClickEvent - INFO");
					_this.model.setExactMatchAPNum(imgVO.Apnum);
					_this.callbacks[_this.id][_this.ITEMSILIKE_EXACTMATCH](imgVO.Apnum);
				});
				
				$("#fullDetailsArtist").click(function(e){
					e.stopPropagation();
					_this.callbacks[_this.id][_this.ARTIST_ID](imgVO.ArtistCategoryId);
				});
				$("#iconImageZoom").click(function(e){
					e.stopPropagation();
					art.core.utils.superZoom(imgVO.ZoomImageUrl);
				});	
				$("#iconImageZoom").mouseenter(function(){
					$(this).css("background-position","-29px -1300px");
				});	
				$("#iconImageZoom").mouseleave(function(){
					$(this).css("background-position","0px -1300px");
				});	
			}
		});
	});
};

//thumbObj only on initial hover
com.art.myGalleries.components.GridComponent.prototype.animateHover = function(apnum,size,thumbObj)
{
	var _this = this;
	var postAnimateMethod = size == this.sizeSettings.hoverPanelSizeOptions.DETAILS ? "postAnimateToDetails": "postAnimateToDefault";
	var pos = this.getHoverPositionAndSize(size,thumbObj);
	var origWidth = $('#'+this.getHoverName()).width();
	var origHeight = $('#'+this.getHoverName()).height();
	$('#'+this.getHoverName()).animate({left:pos.left,top:pos.top,width:pos.width,height:pos.height},250,function(){
		_this[postAnimateMethod](apnum,origWidth,origHeight);
	});
};
//thumbObj only on initial hover
com.art.myGalleries.components.GridComponent.prototype.animateNewHover = function(apnum,size,thumbObj)
{
	var _this = this;
	var pos = this.getHoverPositionAndSize(size,thumbObj);
	var origWidth = $('#'+this.getHoverName()).width();
	var origHeight = $('#'+this.getHoverName()).height();
	$('#'+this.getHoverName()).animate({left:pos.left,top:pos.top,width:pos.width,height:pos.height},250,function(){
		_this.newPostAnimateMethod(apnum,origWidth,origHeight);
	});
};

com.art.myGalleries.components.GridComponent.prototype.newPostAnimateMethod = function(apnum,origWidth,origHeight)
{
	
	//ensure this is not visible
	var op = parseInt($('#heroHover').css("opacity"));
	if(op > 0)
	{
		$('#heroHover').animate({"opacity":"0"},500,function(){
			$(this).remove();
		});
	}
			
	var _this = this;

	var perc = $('#'+this.getHoverName()).width() / origWidth;
	var tmpW = Math.round($("#imgAspectRatio").width() * perc);
	var tmpH = Math.round($("#imgAspectRatio").height() * perc);
	var l = Math.round(($('#'+this.getHoverName()).width()-tmpW)/2);
	var imgARPos = $("#imgAspectRatio").position();
	var t = imgARPos.top <= 0 ? 10 : imgARPos.top; //for 6 imagesPerPage
	$("#imgAspectRatio").css("top",t+"px");
	$("#imgAspectRatio").animate({"opacity":0},200,function(){
		//close button
		
		$('.VSResultsInfoIcon img').attr("title","close");
		$('.VSResultsInfoIcon img').attr("alt","close");
		$('.VSResultsInfoIcon').die();
		$('.VSResultsInfoIcon').unbind('mouseenter');
		$('.VSResultsInfoIcon').unbind('mouseleave');
		$('.VSResultsInfoIcon').width(10);
		$('.VSResultsInfoIcon').height(10);
		$('.VSResultsInfoIcon').css("background-image","url(http://cache1.artprintimages.com/images/visualsearch/v2/imagesprite.gif)");
		$('.VSResultsInfoIcon').css("background-position","0px -1210px");
		$('.VSResultsInfoIcon').css("background-repeat","no-repeat");
		$('.VSResultsInfoIcon').css("margin","8px");
		$('.VSResultsInfoIcon').css("float","right");
		
		var iconOp = parseInt($('.VSResultsInfoIcon').css("opacity"));
		if(iconOp < 100)
			$('.VSResultsInfoIcon').animate({"opacity":"100"},500); //6 imagesPerPage needs this
		
		$('.VSResultsInfoIcon').mouseenter(function(){
			$(this).css("background-position","-17px -1210px");
		});
		$('.VSResultsInfoIcon').mouseleave(function(){
			$(this).css("background-position","0px -1210px");
		});
		$('.VSResultsInfoIcon').click(function(e){
			e.stopPropagation();
			_this.hideDetails();
			_this.resumeHover();
			_this.callbacks[_this.id][_this.CLOSE_DETAILS]();
		});
		
		var p = $(this).position();
		var u = _this.getBackgroundImage($(this).attr('src'),1000, 1000, parseInt($('#'+_this.getHoverName()).width()), parseInt($('#'+_this.getHoverName()).width()));
		var newImg = "<div style='height:275px'><img src='"+u+"' id='fullRes' style='z-index:400;margin-top:$Tpx;margin-left:$Lpx;cursor:pointer;'/></div>";
		var tp = p.top <= 0 ? 25 : p.top;
		newImg = newImg.replace("$T",tp).replace("$L",p.left);
		$('#'+_this.getHoverName()).append(newImg);
		$("#fullRes").css("opacity",0);
		
       /* var length = 250;
        var w = 0, h = 0;
        var aspectRatio = parseInt(ZoomAttr[1]) / parseInt(ZoomAttr[2]);
        if (aspectRatio > 1) {
            w = length;
            h = length / aspectRatio;
        }
        else {
            w = length * aspectRatio;
            h = length;
        }*/

		
		
		$("#fullRes").load(function(){
			//alert($(this).width()+"--"+$(this).height());
			
			
			var length = 250;
	        var nw = 0, nh = 0;
	        var aspectRatio = $(this).width() / $(this).height();
	        if (aspectRatio > 1) {
	            nw = length;
	            nh = length / aspectRatio;
	        }
	        else {
	            nw = length * aspectRatio;
	            nh = length;
	        }
			
	        $(this).css('width',nw+"px");
	        $(this).css('height',nh+"px");
			
	        $(this).addDropShadow('angle');
			$(this).css("margin-left",Math.round(($('#'+_this.getHoverName()).width()-$(this).width())/2)+"px");
	        
	        
			$(this).animate({'opacity':100},2000);
			var p = $(this).position();
			if(p != null && p != undefined)
			{
				//top image area will always be a square with sides == to width; thus our info will begin after w + 10px for padding
				if(document.all)
					var top = p.top+Math.round($(this).height())+10;
				else
					var top = p.top+Math.round($(this).height())+20;
			}	
			else { top = 0; }
			var h = origHeight - top;
			var w = $('#'+_this.getHoverName()).width();
			$('#'+_this.getHoverName()).append("<div class='clear'></div>");
			var str = _this.getTemplateForHoverBottomContainer(_this.currencyCode);
			$('#'+_this.getHoverName()).append(str);
		/*var imgVO = {Title:"title",MasterDisplayPrice:"$12.55"};
		var artistLine = "Test";
		artistLine = "<div style='text-align:center;font-size:11px;font-family:Arial,sans-serif;'>by <span id='fullDetailsArtist' style='color:blue;text-decoration:underline;cursor:pointer'>"+artistLine+"</span></div>";					
			
		var addToSelectionBtn = _this.addToSelectionDisabled ? "" : "<td style='width:50%;'><div id='fullDetailsAddSelection'    style='display:inline;float:left;width:78px;margin:3px;height:22px;cursor:pointer;font-family:Arial,sans-serif;background-image:url(http://cache1.artprintimages.com/images/visualsearch/v2/imagesprite.gif); background-repeat:no-repeat;background-position:0px -1230px'/></td>";
		var addToPivotBtn = _this.addToPivotDisabled ? "" :         "<td style='width:50%;'><div id='fullDetailsAddPivot'        style='display:inline;float:left;width:105px;margin:3px;height:22px;cursor:pointer;font-family:Arial,sans-serif;background-image:url(http://cache1.artprintimages.com/images/visualsearch/v2/imagesprite.gif); background-repeat:no-repeat;background-position:0px -1330px'/></td>";
		var superZoomIcon =                                         "<td style='width:30px;' align=center><div id='iconImageZoom' style='margin:0;width:20;height:20;background-image:url(http://cache1.artprintimages.com/images/visualsearch/v2/imagesprite.gif); background-repeat:no-repeat;background-position:0px -1300px;cursor:pointer;'/></td>";
		var str =
			"<div id='fullRes_details'style='position:absolute; z-index:120;border:0px solid; width:"+w+"px;height:"+h+"px;bottom:40px;>"+ //top:"+(top-10)+"px'>"+
				"<div id='fullRes_details_copy' style='position:absolute;width:"+w+"px;'>"+
					"<div style='text-align:center;font-size:11px;font-family:Arial,sans-serif'>"+imgVO.Title+"</div>"+
					artistLine +
					"<div style='text-align:center;font-size:11px;font-family:Arial,sans-serif'>"+art.core.utils.formatDimensions(12, 17, art.core.utils.doConvertToCentimeter(_this.currencyCode)) + "</div>"+
					"<div style='text-align:center;font-size:11px;font-family:Arial,sans-serif'>"+imgVO.MasterDisplayPrice+"</div>"+
					"<div id='fullRes_padding'></div>"+
					"<div style='height:30px;background-color:#f6f6f6;' class='fullRes_btnContainer'><table style='padding:0;margin:0;border:0;width:100%'><tr>"+
						addToSelectionBtn+
						addToPivotBtn+
						superZoomIcon+
						//"<td style='width:50%;' align=right><div id='fullDetailsAddToCart' style='margin:3px;height:22px;width:65px;cursor:pointer;background-image:url(http://cache1.artprintimages.com/images/visualsearch/v2/imagesprite.gif); background-repeat:no-repeat;background-position:0px -1263px'/></td>"+
						"<td style='width:50%;' align=right><div id='fullDetailsInfo' style='margin:3px;height:22px;width:65px;cursor:pointer;background-image:url(http://cache1.artprintimages.com/images/visualsearch/v2/icontraysprite.png); background-repeat:no-repeat;background-position:0 -27px;width:21px;height:21px;'/></td>"+
						"</tr></table><div style='clear'></div>"+
					"</div>"+
				"</div>"+
			"</div>";
		
		$('#'+_this.getHoverName()).append(str);*/
		});
	});
};

com.art.myGalleries.components.GridComponent.prototype.getTemplateForHoverBottomContainer = function(currencyCode)
{
	trace("currencyCode:"+currencyCode);
	var imgVO = {Title:"Item Name",MasterDisplayPrice:"$12.55"};
	var artistLine = "Andy Warhol";
	var str  = "<div id='modalFullDetails' class='modalFullDetails'>" +
					"<div style='text-align:center;font-size:11px;font-family:Arial,sans-serif;margin-bottom:1px;'>"+imgVO.Title+"<span id='modalfullDetailsArtist' style='margin-left:3px;color:blue;cursor:pointer'>"+artistLine+"</span></div>"+
					"<div style='text-align:center;font-size:11px;font-family:Arial,sans-serif;margin-bottom:1px;'>"+ art.core.utils.formatDimensions(11, 14) + "</div>"+
					"<div style='text-align:center;font-size:11px;font-family:Arial,sans-serif;margin-bottom:1px;'>"+imgVO.MasterDisplayPrice+"</div>"+
			   "</div>";			
	return str;
};
com.art.myGalleries.components.GridComponent.prototype.disableAddToSelectionButton = function()
{
	
	this.addToSelectionDisabled = true;
};
com.art.myGalleries.components.GridComponent.prototype.enableAddToPivotButton = function()
{
	
	this.addToPivotDisabled = false;
};
com.art.myGalleries.components.GridComponent.prototype.disableFullDetails = function()
{
	this.fullDetailsDisplayDisabled = true;
};
com.art.myGalleries.components.GridComponent.prototype.hideDetails = function()
{
	$("#"+this.getHoverName()).remove();
};
com.art.myGalleries.components.GridComponent.prototype.getBackgroundImage = function(url,width,height,maxW,maxH)
{
	var w = width == -1 ? 1000 : width;
	var h = height == -1 ? 1000 : height;
	var aspectRatio = w/h;
	var finalUrl = url.replace(/x=[0-9]+/,"x=0").replace(/y=[0-9]+/,"y=0").replace(/w=[0-9]+/,"w="+w).replace(/h=[0-9]+/,"h="+h).replace(/maxw=[0-9]+/,"maxw="+(maxW-20)).replace(/maxh=[0-9]+/,"maxh="+(maxH-20)).replace("mode=sq&","");
	return finalUrl;
};
com.art.myGalleries.components.GridComponent.prototype.getHoverTemplate = function()
{
	var r = this.fullDetailsDisplayDisabled ? "" : "<div class='VSResultsInfoIcon'><img src='http://cache1.artprintimages.com/images/blank.gif' title='More Info' alt='More Info' width='15' height='15'/></div>";
	return this.hoverTemplate.replace("$INFO_ICON",r);
};

com.art.myGalleries.components.GridComponent.prototype.destroy = function()
{
	//clear timeout
	clearTimeout(this.slideShowTimerID);
	clearTimeout(this.detailsDelayTimerID);
	//stop animations first
	$('#'+this.getHoverName()).stop(true,true);
	$('.thumbs').die();
	$("#"+this.nextBtnID).die();
	$("#"+this.previousBtnID).die();
	//this.callbacks = [];
	$("#"+this.NAME).empty();
	$("#"+this.NAME).remove();
	/*
	this.activeGrid.remove();
	$('.grid').remove();
	this.newMarginLeft = 0;
	*/
};




/*
 * Use cases
 * doNext()
 * 	- append new grid to right will be div:last
 * 	- async call to get collection
 * 	- populate div:last
 * 	- animate right to left
 * 	- now we have 2 divs
 * 
 * -user hits next remove div:first append new grid
 * 
 * 
 */
com.art.myGalleries.components.GridComponent.prototype.doNext = function()
{
	if(this.processing)
		return;
	this.showLoading();
	this.processing = true;
	this.appendGrid();
	this.callbacks[this.id][this.NEXT]();
};
com.art.myGalleries.components.GridComponent.prototype.showLoading = function()
{
	var c = $("#"+this.id+"_clip");
	var w = parseInt(c.width())+"px";
	var h = parseInt(c.height())+"px";
	c.append("<div id='spinner' style='position:absolute;width:"+w+"; height:"+h+";top:0px; left:0px;background-color:#FFFFFF;'><img src='http://cache1.artprintimages.com/images/photostoart/loading.gif'/></div>");
	$("#spinner img").centerElement();
};
com.art.myGalleries.components.GridComponent.prototype.hideLoading = function()
{
	$("#spinner").remove();
};
/*
 * = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
 * useCurrentGrid
 * 
 */
com.art.myGalleries.components.GridComponent.prototype.initFadeTransition = function()
{
	if(this.processing)
		return;
	this.processing = true;
	var _this = this;
	this.fadeTransition = {state:this.fadeTransitionStates.STARTED,use:true}; //used by animate call
	var c = $("#"+this.id+"_clip");
	var w = parseInt(c.width())+"px";
	var h = parseInt(c.height())+"px";
	c.append("<div id='fade' style='position:absolute;width:"+w+"; height:"+h+";top:0px; left:0px;background-color:#FFFFFF;'></div>");
	$("#fade").css("opacity",99);
	$("#fade").animate({opacity:100},250,function(){
		_this.fadeTransition.state = _this.fadeTransitionStates.COMPLETE;
		trace("initFadeTransition: "+_this.processing);
		if(!_this.processing)
		{
			//payload recieved finish immediately
			_this.completeFadeTransition();
		}
		else
		{
			//let handleNotification call completeTransition()
		}
	});
};
com.art.myGalleries.components.GridComponent.prototype.completeFadeTransition = function(clearProcessingFlag)
{
	trace("complateFadeTransition: "+this.getGridCount());
	var _this = this;
	$("#fade").animate({opacity:0},500,function(){
		_this.fadeTransition = {state:'complete',use:false};
		if(clearProcessingFlag)
			_this.processing = false;
		$(this).remove();
	});
};
/*
 * = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
 * append new grid and set active grid to newly append grid item
 * set new marginLeft values
 * call setImages to load images
 * then
 * call animate to move into place
 * offscreen, on right
 * 
 */
com.art.myGalleries.components.GridComponent.prototype.appendGrid = function()
{
	var o = $("#"+this.id+"_content");
	var ml = this.getMarginLeft();
	var ct = this.getGridCount();
	trace("gridcount" + ct);
	
	if((ml < 0) || (ct>=3))
	{
		//means we have something off to the left pop and re-add to right
		$("#"+this.id+"_content div:first").remove();
		o.css("marginLeft",'4px');
	}
	var grid = this.getGridTemplate();
	$("#"+this.id+"_contentClear").before(grid);
	this.activeGrid = $("#"+this.id+"_contentClear").prev();
	this.newMarginLeft = - this.getContentWidth();
};
/*
 * = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
 *
 */
com.art.myGalleries.components.GridComponent.prototype.prependGrid = function()
{
	var o = $("#"+this.id+"_content");
	var marginLeft = parseInt(o.css("marginLeft"));
	var cnt = this.getGridCount();
	
	trace("prependgrid cnt: "+cnt);
	
	if((cnt >=3))
	{
		//remove last grid in list
		var last = $("#"+this.id+"_contentClear").prev();
		last.remove();
		
	}
	if(marginLeft <= -this.getContentWidth())
	{
		//means we have something off to the left; so lets just use that
		this.activeGrid = $("#"+this.id+"_content div:first");
	}
	else
	{
		//must be page 1!
		var grid = this.getGridTemplate();
		$("#"+this.id+"_content").prepend(grid);
		var m = -this.getContentWidth();
		$("#"+this.id+"_content").css("marginLeft",m);
	}
	this.activeGrid = $("#"+this.id+"_content div:first");
	this.newMarginLeft = 0;
	
};
com.art.myGalleries.components.GridComponent.prototype.cleanGrids = function()
{
	var o = $("#"+this.id+"_content");
	var marginLeft = parseInt(o.css("marginLeft"));
	var cnt = this.getGridCount();
	trace("cleanGrids cnt: "+cnt);
	
	if(cnt > 2 && marginLeft == 0)
	{
		//remove last grid in list
		var last = $("#"+this.id+"_contentClear").prev();
		last.remove();
	}
	
};
/*
 * = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
 *
 */
com.art.myGalleries.components.GridComponent.prototype.getMarginLeft = function()
{
	var n = parseInt($("#"+this.id+"_content").css("margin-left"));
	if(typeof n != typeof 1)
		throw new Error("ImageScrollerComponent.getMarginLeft() failed; Invalid return value.");
	return n;
};

//dispatchEvent for collection
com.art.myGalleries.components.GridComponent.prototype.doPrevious = function()
{
	if(this.processing)
		return;
	this.processing = true;
	this.prependGrid();
	this.callbacks[this.id][this.PREVIOUS]();
};
com.art.myGalleries.components.GridComponent.prototype.getCroppedImageURL = function(url)
{
	var r;
	if(this.imagesPerPage == this.imagesPerPageSupported.DEFAULT)
		r = (this.sizeSettings.sizeLabel == this.sizeSettings.options.DEFAULT) ? "&maxw=94&maxh=94" : "&maxw=117&maxh=117";
	else
		r = (this.sizeSettings.sizeLabel == this.sizeSettings.options.DEFAULT) ? "&maxw=191&maxh=191" : "&maxw=236&maxh=236";
	
	return url.replace('&maxw=100&maxh=100', r);
		
};
com.art.myGalleries.components.GridComponent.prototype.setImages = function(arr)
{
	this.activeItems = []; //reset
	this.hideLoading();
	var _this = this;
	var thumbs = "";
	this.imagesPerPage = this.model.getImagesPerPage();
	trace("ImageScrollerComponent.setImages > imagesPerPage: "+this.imagesPerPage);
	trace("arr.length: "+arr.length);
	trace(arr);
	for(var i=0;i < this.imagesPerPage;i++)
	{
		var bgimg = "",apnum = "";
		if(arr[i] != undefined)
		{
			apnum = arr[i].APNum;
			bgimg =arr[i].ImageUrl;
			//this.activeItems.push({apnum:'12345',croppedURL:bgimg,pageNumber:1});
			thumbs += this.getThumb("12345",bgimg);
		}
		else
		{
			thumbs += this.getThumb("blankPlaceHolder","");
		}
		
	    this.activeGrid.html(thumbs);
	}
	
	//now lets add remaining items to cache
	//use everything in cache per Madhav request
	//lets add page number so when user closes slide show they're on the right page
	//pageNumber6PerPage: pageNumber24PerPage
	var methodName = this.model.getSelectedMethodName();
	var cacheObj = this.ssLoadImageModelMethodName == "getItemByApnum" ? "cache" : "wizardCache"; 
	trace("methodName: "+methodName);
	trace("cacheObjName: "+cacheObj);
	//for(var pn in this.model[cacheObj][methodName])
	//{
		//trace("pageNumber: "+pn);
	//}
		//var obj = {apnum:apnum,croppedURL:bgimg,pageNumber:pn});
//		for(var img in this.model[cacheObj][pn])
//		{
//			obj.apnum = this.model[cacheObj][pn].APNum; 
//			obj.croppedURL = 
//			this.activeItems.push(obj
//		}
//	}
	
	//<img id='heroHover' src='http://cache1.artprintimages.com/images/blank.gif' width='100%' height='100%'
	
	$('.thumbs').die();
	$('.thumbs').unbind('mouseenter');
	$('.thumbs').live('mouseenter',function(){
		if(!_this.processing && $(this).attr('id') != 'blankPlaceHolder')
		{
			_this.setAPNUMForInfo = $(this).attr('id');
			$("#"+_this.getHoverName()).remove();
		    clearTimeout(_this.detailsDelayTimerID);
		    _this.showDetails($(this));
		}
	});
};
//freeze panel on screen; will not close on mouseleave
com.art.myGalleries.components.GridComponent.prototype.pauseHover = function()
{
	this.isPaused = true;
	$('#'+this.getHoverName()).die('mouseleave');
	$('#'+this.getHoverName()).unbind('mouseleave');
	$("#"+this.id+"_clip").die('mouseleave');
	$("#"+this.id+"_clip").unbind('mouseleave');
};
//resume panel mouseleave functionality
com.art.myGalleries.components.GridComponent.prototype.resumeHover = function()
{
	this.isPaused = false;
	var _this = this;
	 $('#'+this.getHoverName()).mouseleave(function() {
		_this.hideDetails();
		$('#'+this.getHoverName()).stop(true,true); //cancel all animations
		//STEP: Kill the timeout if it is there
		clearTimeout(_this.detailsDelayTimerID);
	 });
	 $("#"+this.id+"_clip").mouseleave(function() {
			_this.hideDetails();
			$('#'+_this.getHoverName()).stop(true,true); //cancel all animations
			//STEP: Kill the timeout if it is there
			clearTimeout(_this.detailsDelayTimerID);
	});
};
com.art.myGalleries.components.GridComponent.prototype.getImageForgetOtherCategoryResultsAPNum = function()
{
	var sizeOfImage = (this.imagesPerPage == this.imagesPerPageSupported.DEFAULT) ? this.sizeSettings.options.DEFAULT : this.sizeSettings.options.LARGE;
	var folderPath = (this.sizeSettings.sizeLabel == this.sizeSettings.options.DEFAULT ? this.ResolutionFolder.DEFAULT : this.ResolutionFolder.LARGE);
	var imagenameSuffix =  this.noEnoughResultsImgPrefix + "_" + sizeOfImage + ".jpg";
	var bgimg = this.imageDomain  + this.imagePath + folderPath + "/" + imagenameSuffix;
	return bgimg;
};
/*
 * 
 * Animate pagination happens here
 */
com.art.myGalleries.components.GridComponent.prototype.animate = function(setImmediate)
{
	var _this = this;
	if(this.fadeTransition.use)
	{
		if(this.fadeTransition.state == this.fadeTransitionStates.COMPLETE)
		{
			this.completeFadeTransition(true);
		}
		else
		{
			setTimeout(function(){_this.animate();},100);
		}
	}
	else if(setImmediate)
	{
		$("#"+this.id+"_content").css("margin-left",this.newMarginLeft);
		this.processing = false;
	}
	else
	{
		$("#"+this.id+"_content").animate({marginLeft:this.newMarginLeft},1000,function(){
			_this.processing = false;
		});
	}
};
com.art.myGalleries.components.GridComponent.prototype.getHoverName = function()
{
	return "MG_ImageScrollerComponentHover";
};
com.art.myGalleries.components.GridComponent.prototype.hoverTemplate =
	"<div id='MG_ImageScrollerComponentHover' style='border:1px solid #999999;position:absolute;-moz-box-shadow:0px 0px 10px rgba(0,0,0,.7);z-index:100;background-color:#FFFFFF;'>" +
		"$INFO_ICON"+
		"<img id='heroHover' src='http://cache1.artprintimages.com/images/blank.gif' width='100%' height='100%' style='position:absolute;top:0px;left:0px;z-index:20'/>"+
		"<img src='http://cache1.artprintimages.com/images/blank.gif' id='imgAspectRatio' style='position:absolute'/>"+
	"</div>";
/*
 * 
 * $LINK = product page link
 */

com.art.myGalleries.components.GridComponent.prototype.getThumb = function(apnum,bgimage)
{	
	var side = this.sizeSettings.thumbSizes[this.imagesPerPage][this.sizeSettings.sizeLabel].width; //square
	var tmpl = "<div class='thumbs' style='float:left;background-image:url($B);background-repeat:no-repeat;background-position:center center;width:$Spx;height:$Spx;margin-right:1px;margin-bottom:1px;border:1px solid #E7E3DE;' id='$I'></div>";
	if($.browser.msie) side = side+2;
	var str = tmpl.replace(/\$S/g,side).replace("$B",bgimage).replace("$I",apnum).replace('$D', this.imageDomain);
	return str;
};
com.art.myGalleries.components.GridComponent.prototype.getGridCount = function()
{
	var cnt = 0;
	
	$("#"+this.id+"_content > div").each(function(){
		cnt++;
	});
	
	return cnt;
};

com.art.myGalleries.components.GridComponent.prototype.getThumbsCount = function()
{
	var cnt = 0;
	var thumbsCount = 0;
	
	$("#"+this.id+"_content > div").each(function(){
		cnt++;
	});
	
	$("#"+this.id+"_content > div > div.thumbs").each(function(){
		thumbsCount++;
	});
	
	return thumbsCount;
};

com.art.myGalleries.components.GridComponent.prototype.disable = function()
{
	trace("disable scroller");
};
com.art.myGalleries.components.GridComponent.prototype.updatePaginationControls = function(pageNumber,totalPages)
{
	trace("updatePaginationControls.pageNumber:"+pageNumber+"totalPages"+totalPages);
	this.nextButtonEnabled = pageNumber < totalPages;
	this.previousButtonEnabled = pageNumber > 1;
	this.updateControls();
	
};
com.art.myGalleries.components.GridComponent.prototype.getContentWidth = function()
{
	return this.width - (this.navigationButtonWidths*2); //reduce width so float nav items
};
com.art.myGalleries.components.GridComponent.prototype.setImagesPerPage = function(num)
{
	this.imagesPerPage = num;
	this.cleanGrids();
};

com.art.myGalleries.components.GridComponent.prototype.registerEvent = function(name,callback)
{
	this.callbacks[this.id][name] = callback;
};

com.art.myGalleries.components.GridComponent.prototype.getSplashScreen = function(imageURL)
{
	var str = '<div id="splash" style="width:$Wpx;height:$Hpx;background-color:#DDDDDD;float:left"><img src="$U"/></div>';
	return str.replace("$W",this.getContentWidth()).replace("$H",this.height).replace("$U",imageURL);
};
com.art.myGalleries.components.GridComponent.prototype.getGridTemplate = function(color)
{
	return this.gridTemplate.replace('$W',this.getContentWidth()).replace('$H', this.height);
};
/*
 * ======================================================================
 * Slideshow functionality Start
 */
com.art.myGalleries.components.GridComponent.prototype.slideShowStartupButton = function(selectorTarget)
{
	this.slideShowStartupButtonSelector = selectorTarget;
	var s = $(this.slideShowStartupButtonSelector);
	if(s == null)
		throw new Error("ImageScrollerComponent > slideShowStartupButton() failed! SelectorTarget is invalid");
	var _this = this;
	s.css("width",this.slideShowControls[this.sizeSettings.sizeLabel].show.width+"px");
	s.css("height",this.slideShowControls[this.sizeSettings.sizeLabel].show.height+"px");
	s.html(this.getSlideShowIcon());
};
/*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
 */
com.art.myGalleries.components.GridComponent.prototype.slideShowStartupMainControls = function(selectorTarget)
{
	var _this = this;
	this.slideShowMainControlParentSeletor = selectorTarget;
	var s = $(this.slideShowMainControlParentSeletor);
	if(s == null)
		throw new Error("ImageScrollerComponent > slideShowStartupMainControls() failed! SelectorTarget is invalid");
	var _this = this;
	s.html(this.getSlideShowMainControls());
	//close~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~
	var c = $('#ssClose');
	this.validateSlideShowControl(c);
	this.setSlideShowHover(c, 'close');
	c.live('click',function(){
		trace('close slideshow');
		_this.resetPlayPause();
		_this.doClose();
	});
	
	//previous ~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~
	var p = $('#ssPrev');
	this.validateSlideShowControl(p);
	this.setSlideShowHover(p, 'previous');
	p.live('click',function(){
		_this.resetPlayPause();
		clearTimeout(_this.slideShowTimerID); //stop
		_this.ssScrollDirection = _this.ssScrollDirectionOptions.RIGHT;
		_this.loadImage();
	});
	
	//pause~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~
	var pl= $('#ssPlayPause');
	this.validateSlideShowControl(pl);
	this.setSlideShowHover(pl, 'pause');
	pl.live('click',function(){
		_this.playPauseToggle();
	});
	
	//next~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~
	var n = $('#ssNext');
	this.validateSlideShowControl(n);
	this.setSlideShowHover(n, 'next');
	n.live('click',function(){
		_this.resetPlayPause();
		clearTimeout(_this.slideShowTimerID); //stop
		_this.ssScrollDirection = _this.ssScrollDirectionOptions.LEFT;
		_this.loadImage();
	});
	
	
};
/*
 * called from external controls
 * tab clicks etc.
 */
com.art.myGalleries.components.GridComponent.prototype.doCloseSlideShow = function()
{
	this.doClose();
	this.resetPlayPause();
};
/*
 * trigger slideShow ONLY if toggle == true
 */
com.art.myGalleries.components.GridComponent.prototype.doClose = function()
{
	if(this.slideShowToggle)
	{
		this.slideShow();
		this.callbacks[this.id][this.SLIDE_SHOW_CLOSE]();
	}
};
com.art.myGalleries.components.GridComponent.prototype.resetPlayPause = function()
{
	trace('reset play pause button');
	if(this.ssIsPaused)
	{
		this.ssIsPaused = false;
		this.setSlideShowHover($('#ssPlayPause'),'pause');
		var _this = this;
		$('#ssPlayPause').die();
		$('#ssPlayPause').live('click',function(){
			_this.playPauseToggle();
		});
		_this.resetPlayPause();
	}
};
com.art.myGalleries.components.GridComponent.prototype.playPauseToggle = function()
{
	trace("playPausToggle clicked");
	this.ssIsPaused = ! this.ssIsPaused;
	if(this.ssIsPaused)
	{
		clearTimeout(this.slideShowTimerID); //stop timer
	}
	else
	{
		this.loadImage();
	}
	
	//toggle button play or pause
	var key =  this.ssIsPaused ? 'play' : 'pause';
	var _this = this;
	this.setSlideShowHover($('#ssPlayPause'),key);
	$('#ssPlayPause').live('click',function(){
		_this.playPauseToggle();
	});
};

com.art.myGalleries.components.GridComponent.prototype.validateSlideShowControl = function(obj)
{
	var id = obj.attr("id");
	if(obj.width() <= 0)
		throw new Error("ImageScrollerComponent > slideShowStartupMainControls() failed! "+id+" is invalid");	
};

com.art.myGalleries.components.GridComponent.prototype.setSlideShowHover = function(obj,key)
{
	var _this = this;
	obj.css("backgroundPosition",this.slideShowControls[this.sizeSettings.sizeLabel][key].enabled);
	obj.unbind('mouseenter');
	obj.unbind('mouseleave');
	obj.die();
	obj.hover(
			function(){obj.css("backgroundPosition",_this.slideShowControls[_this.sizeSettings.sizeLabel][key].hover);},
			function(){obj.css("backgroundPosition",_this.slideShowControls[_this.sizeSettings.sizeLabel][key].enabled);
	});
};
/*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
 */
com.art.myGalleries.components.GridComponent.prototype.enableSlideShowStartupButton = function()
{
	var b = $(this.slideShowStartupButtonSelector+" > div");
	var _this = this;
	try
	{
		if(b.width() <= 0)
			throw new Error("ImageScrollerComponent > enableSlideShowStartupButton() failed! SelectorTarget is invalid");
	}
	catch(e){}
	trace("enableSlideShowStartupButton");
	b.css("backgroundPosition",this.slideShowControls[this.sizeSettings.sizeLabel]['show'].enabled);
	b.unbind('mouseenter');
	b.unbind('mouseleave');
	b.die(); //always clear first
	b.hover(function(){$(this).css("backgroundPosition",_this.slideShowControls[_this.sizeSettings.sizeLabel]['show'].hover);},function(){$(this).css("backgroundPosition",_this.slideShowControls[_this.sizeSettings.sizeLabel]['show'].enabled);});
	b.live("click",function(){
		_this.slideShow();
		_this.callbacks[_this.id][_this.SLIDE_SHOW_STARTUP_CLICK]();
	});
	
};
/*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
 */
com.art.myGalleries.components.GridComponent.prototype.disableSlideShowStartupButton = function()
{
	if($(this.slideShowStartupButtonSelector).width() <= 0)
		throw new Error("ImageScrollerComponent > enableSlideShowStartupButton() failed! SelectorTarget is invalid");
	
};

/*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
 this.css("");
	this.css("");
	this.css(");
	*/
com.art.myGalleries.components.GridComponent.prototype.slideShow = function()
{
	if(!this.slideShowToggle)
	{
		trace("toggle ss: "+!$("#ss").height());
		if($("#ss").height() == null)
		{
			trace("ss not defined append!");
			$("#"+this.id).append("<div id='ss' style='width:"+this.width+"px;height:"+this.width+"px;position:absolute;z-index:200;top:"+this.height+"px;left:0px;'></div>");
			this.ssContainerWidth = this.width;
			this.ssContainerHeight= this.height;
			
		}
		this.startSlideShow();
	}
	else
	{
		trace("stopSlideShow");
		this.stopSlideShow();
		
	}
	this.slideShowToggle = !this.slideShowToggle;
	trace("slideShowToggle: "+this.slideShowToggle);
};
/*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
 */
com.art.myGalleries.components.GridComponent.prototype.setLoadImageModelMethod = function(methodName)
{
	this.ssLoadImageModelMethodName = methodName;
};
com.art.myGalleries.components.GridComponent.prototype.startSlideShow = function()
{
	//reset counter
	this.slideShowCursor = -1;
	
	var _this = this;
	$("#ss").find("div").css("opacity",0); //reset
	$("#"+this.id+"_clip").animate({top:(-this.height)+"px"},1500);
	$("#imgScrollCompNext").animate({top:(-this.height)+"px"},1500);
	$("#imgScrollCompPrev").animate({top:(-this.height)+"px"},1500);
	$("#ss").animate({top:"0px"},1500,function(){
		
		_this.loadImage();
	});
	
};
/*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
 */
com.art.myGalleries.components.GridComponent.prototype.loadImage = function()
{
	if(this.ssProcessing)
		return;
	
	this.ssProcessing = true;
	var _this = this;
	var randid ="id_"+ Math.round(Math.random()*10000);
	this.ssNext = randid;

	if(this.ssScrollDirection ==this.ssScrollDirectionOptions.LEFT)
	{
		this.slideShowCursor = this.slideShowCursor == this.activeItems.length-1 ? 0 : this.slideShowCursor + 1;
	}
	else
	{
		this.slideShowCursor = (this.slideShowCursor <= 0) ? this.activeItems.length -1 : this.slideShowCursor - 1;
	}
	var apnum = this.activeItems[this.slideShowCursor].apnum+"";
	trace("apnum "+apnum);
	var urlZoom = this.model[this.ssLoadImageModelMethodName](apnum).UrlInfo.ZoomUrlWithoutWatermark;
	$("#ss").append('<img id="'+randid+'" src="'+urlZoom+'" style="position:absolute;top:0px;left:0px"/>');
	var initPos = this.ssScrollDirection == this.ssScrollDirectionOptions.LEFT ? this.ssContainerWidth + 10 : -(this.ssContainerWidth + 10);
	
	if(this.ssScrollDirection ==this.ssScrollDirectionOptions.LEFT)
	{
		if($("#"+randid).width() > initPos)
			initPos = $("#"+randid).width();
	}
	else
	{
		if(-$("#"+randid).width() < initPos)
			initPos = -$("#"+randid).width();
	}
		
	
	$("#"+randid).css("left",initPos);
	
	//pause when clicked
	$("#"+randid).live('click',function(){
		_this.playPauseToggle();
	});
	$("#"+randid).imagesLoaded(function(img){
		$(this).unbind('load');
		var scaleObj = art.core.utils.scaleElement($("#"+randid).width(),$("#"+randid).height(),_this.ssContainerWidth,_this.ssContainerHeight,40);
		var newh = parseInt(scaleObj.height);
		var neww = parseInt(scaleObj.width);
		$(this).width(neww);
		$(this).height(newh);
		var top = Math.round((_this.ssContainerHeight-newh)/2); //center vertically
		$(this).addDropShadow();
		$(this).css("top",top+"px");
		var tmp = _this.ssCurrent;
		if(_this.ssCurrent != undefined && !_this.ssIsPaused)
		{
			var left = _this.ssScrollDirection == _this.ssScrollDirectionOptions.LEFT ?-_this.width : _this.width;
			$("#"+tmp).animate({"left":left+"px"},2000,function(){
				$("#"+tmp).die();
				$("#"+tmp).remove();
			});
		}
		if(!_this.ssIsPaused)
		{
			var leftPos = Math.round((_this.ssContainerWidth - neww)/2);
			$("#"+_this.ssNext).animate({"left":leftPos +"px"},2000,function(){
				$("#"+_this.ssCurrent).remove();
				_this.ssCurrent = _this.ssNext;
				_this.ssNext = '';
				_this.ssScrollDirection = _this.ssScrollDirectionOptions.LEFT;
				_this.continueSlideShow();
			});
		}
	});
};
com.art.myGalleries.components.GridComponent.prototype.continueSlideShow = function()
{
	this.ssProcessing = false;
	var _this = this;
	//only continue if user has not closed slideshow AND is not paused
	if(this.slideShowToggle && !this.ssIsPaused)
	{
		this.slideShowTimerID = setTimeout(function(){
			_this.loadImage();
		},4000);
	}	
	
};
/*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
 */
com.art.myGalleries.components.GridComponent.prototype.stopSlideShow = function()
{
	clearTimeout(this.slideShowTimerID);
	$("#"+this.id+"_clip").animate({top:'0px'},1500);
	$("#imgScrollCompNext").animate({top:"0px"},1500);
	$("#imgScrollCompPrev").animate({top:"0px"},1500);
	$("#ss").animate({top:this.height+"px"},1500,function(){
		//$(this).remove();
	});
	this.slideShowCursor = -1;
};

/*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
 */
com.art.myGalleries.components.GridComponent.prototype.getSlideShowIcon = function()
{
	var s = this.slideShowControls[this.sizeSettings.sizeLabel].show.disabled;
	var str = "<div style='float:left;height:$SS_ICON_W;width:$SS_ICON_H;background-image:url($SPRITE/images/visualsearch/v2/imagesprite.gif);background-position:$SS_ICON_POS;'><img width='100%' height='100%' src='http://cache1.artprintimages.com/images/blank.gif' alt='slideshow'/></div>";
	str = str.replace("$SPRITE",this.imageDomain).replace("$SS_ICON_W", this.slideShowControls[this.sizeSettings.sizeLabel].show.width).replace("$SS_ICON_H", this.slideShowControls[this.sizeSettings.sizeLabel].show.height).replace("$SS_ICON_POS", s);
	return str;
};
com.art.myGalleries.components.GridComponent.prototype.getSlideShowMainControls = function()
{
	var buttonSide = this.slideShowControls[this.sizeSettings.sizeLabel].previous.width; //common for all buttons + they're square
	//var  = this.slideShowControls[this.size].show.disabled;
	//previous
	var previous 	= "<div id='ssPrev' style='float:left;height:$SS_BTN_SIDE;width:$SS_BTN_SIDE;background-image:url($SPRITE/images/visualsearch/v2/imagesprite.gif);background-position:0px 0px;'></div>";
	var playPause	= "<div id='ssPlayPause' style='float:left;height:$SS_BTN_SIDE;width:$SS_BTN_SIDE;background-image:url($SPRITE/images/visualsearch/v2/imagesprite.gif);background-position:0px 0px;'></div>";
	var next		= "<div id='ssNext' style='float:left;height:$SS_BTN_SIDE;width:$SS_BTN_SIDE;background-image:url($SPRITE/images/visualsearch/v2/imagesprite.gif);background-position:0px 0px;'></div>";
	var close		= "<div id='ssClose' style='float:right;height:$SS_BTN_SIDE;width:$SS_BTN_SIDE;background-image:url($SPRITE/images/visualsearch/v2/imagesprite.gif);background-position:0px 0px;' alt='return to grid view' title='return to grid view' ></div>";
	var str 		= previous + playPause + next + close;
	str				= str.replace(/\$SS_BTN_SIDE/g, buttonSide);
	str				= str.replace(/\$SPRITE/g, this.imageDomain);
		//str = str.replace("$SPRITE",this.imageDomain).replace("$SS_ICON_W", this.slideShowControls[this.size].show.width).replace("$SS_ICON_H", this.slideShowControls[this.size].show.height).replace("$SS_ICON_POS", s);
	return str;
};
/*
 * Slideshow functionality End
 * ======================================================================
 */
com.art.myGalleries.components.GridComponent.prototype.getFullImageDetailsTemplate = function()
{	
	var str = this.fullImageDetailsTemplate.replace(/\$A/g, layoutObj.outerWidth);
	str 	= str.replace(/\$B/g, layoutObj.outerHeight);
	str 	= str.replace(/\$C/g, layoutObj.detailsHeight);
	str 	= str.replace(/\$D/g, layoutObj.buttonRowHeight);
	str 	= str.replace(/\$E/g, layoutObj.buttonWidth);
	return str;
};
com.art.myGalleries.components.GridComponent.prototype.fullImageDetailsTemplate =
	'<div style="border:1px solid; width:$Apx; height:$Bpx;">'+
		'<div style="width:$Apx;height:$Cpx;" id="fullDetails">'+
		'</div><div style="width:$Apx;height:$Dpx"><div id="fid_addSelection" style="float:left;width:$Epx;height:$Dpx"></div><div style="float:right;width:$Epx;height:$Dpx;" id="fid_addToCart"></div><div class="clear"></div></div>';

com.art.myGalleries.components.GridComponent.prototype.gridTemplate = '<div class="grid gridContainer" style="background-color:#FFFFFF;width:$Wpx;height:$Hpx;float:left;margin-left:5px;margin-top:6px;"></div>';
com.art.myGalleries.components.GridComponent.prototype.template = 
	'<div id="$NAME" style="width:$Wpx;height:$Hpx;background-color:#FFFFFF;position:relative;overflow:hidden;">'+
		'<div class="fixedHeight" style="position:relative;width:22px;background:url($SPRITE/images/visualsearch/v2/imagesprite.gif);background-position:$BGPOS_PREV;float:left" id="$P"/>'+
		'<div style="width:$CWpx;height:99%;float:left;overflow:hidden;position:relative;" id="$NAME_clip">'+
			'<div id="$NAME_content" style="width:$CWpx;height:$100%;margin-left:0px;background-color:#FFFFFF;"><div id="$NAME_contentClear" style="clear:both"/></div>'+
		'</div>'+
		'<div class="fixedHeight" style="position:relative;width:22px;background:url($SPRITE/images/visualsearch/v2/imagesprite.gif);background-position:$BGPOS_NEXT;float:left" id="$X"/>'+
		'<div style="clear:both"></div>'+
	'</div>';


/**
* itemRenderers
*/

com.art.myGalleries.components.GridComponent.prototype.itemRenderers = {};

