com.art.myGalleries.components.MoveGalleryItemModal = function(id,width,height)
{
	
	this.id = id;
	this.width = width;
	this.height = height;
	
	com.art.core.components.BaseModal.extend(this);
};
com.art.myGalleries.components.MoveGalleryItemModal.prototype.id;
com.art.myGalleries.components.MoveGalleryItemModal.prototype.width;
com.art.myGalleries.components.MoveGalleryItemModal.prototype.height;
com.art.myGalleries.components.MoveGalleryItemModal.prototype.render = function()
{
	return this.getTemplate();
};
com.art.myGalleries.components.MoveGalleryItemModal.prototype.getTemplate = function()
{
	var content = "";
	var btn = new com.art.core.components.ArtButton('submit',com.art.core.components.ArtButton.ART,"Submit Form");
	return btn.render();
};
com.art.myGalleries.components.MoveGalleryItemModal.prototype.template = "<div>Subclass content goes here</div>";