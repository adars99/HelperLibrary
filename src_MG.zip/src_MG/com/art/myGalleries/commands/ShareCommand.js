com.art.myGalleries.commands.ShareCommand = function(data,app)
{
	this.data 	= data;
	this.app	= app;
};

com.art.myGalleries.commands.ShareCommand.prototype.init = function()
{
	
};

com.art.myGalleries.commands.ShareCommand.prototype.listNotificationInterests = function()
{
	return [
	        ];
};


com.art.myGalleries.commands.ShareCommand.prototype.handleNotification = function(note)
{
	switch(note.name)
	{
		default:
			throw new Error("ShareCommand Failure! Unrecognized note.name");
		
	}
};


