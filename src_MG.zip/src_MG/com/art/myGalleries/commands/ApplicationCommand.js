com.art.myGalleries.commands.ApplicationCommand = function (data, app) {
    this.NAME = com.art.myGalleries.commands.ApplicationCommand.NAME;
    this.app = app;
    this.serviceProvider = new com.art.core.services.ServiceProvider(this.app.getEnvironment());
    this.model = this.app.getModel();
    this.processing = false;
    this.pageNumber = 1;
    this.currentNote;
    this.username;
    this.password;
    this.tempNewCreatedGalleryId; //Used for move and save to gallery
    this.printFileName;
};

com.art.myGalleries.commands.ApplicationCommand.NAME = "ApplicationCommand";

com.art.myGalleries.commands.ApplicationCommand.prototype.init = function () {

};
com.art.myGalleries.commands.ApplicationCommand.prototype.listNotificationInterests = function () {
    return [this.app.events.STARTUP,
	        this.app.events.GALLERY_ITEM_LIST_REQUEST,
            this.app.events.GALLERY_ITEM_LIST_REQUEST_SUCCESS,
            this.app.events.GALLERY_ITEM_LIST_REQUEST_FAILED,
            this.app.events.GET_ALL_GALLERY_ITEMS,
            this.app.events.UPDATE_GALLERY_TITLE_DESC,
            this.app.events.GALLERY_ITEM_SORT,
            this.app.events.ADD_ITEM_TO_EXISTING_GALLERY,
            this.app.events.ADD_GALLERY_TITLE_DESC,
            this.app.events.GALLERY_ITEM_SORT,
            this.app.events.GET_SYSTEM_LIBRARY,
            this.app.events.GET_ALL_GALLERY_ITEMS,
            this.app.events.UPDATE_GALLERY_TITLE_DESC,
            this.app.events.GALLERY_ITEM_SORT,
            this.app.events.ADD_GALLERY_TITLE_DESC,
            this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY,
            this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY,
            this.app.events.GET_ALL_GALLERIES,
            this.app.events.ADD_ITEM_TO_NEW_GALLERY,
            this.app.events.REGISTER_ACCOUNT,
            this.app.events.LOGIN_ACCOUNT,
            this.app.events.LOGOUT_MYGALLERY,
            this.app.events.CREATE_WALL,
            this.app.events.UPDATE_WALL_ITEMS,
            this.app.events.GET_WALLS,
            this.app.events.ADD_SIMILAR_ARTIST_ITEM,
            this.app.events.ADD_BARE_WALLS,
            this.app.events.SHARE_WALL,
            this.app.events.GET_USER_LIBRARY,
            this.app.events.DELETE_GALLERY_ITEM,
            this.app.events.UPDATE_BARE_WALL,
            this.app.events.DELETE_GALLERY_ITEM_DP,
            this.app.events.UPDATE_PRIVACY_SETTINGS,
            this.app.events.GET_FRAME_SKU,
            this.app.events.GET_WALL_BY_ID,
            this.app.events.GET_USER_LIBRARY_BY_PROFILE,
            this.app.events.LOGIN_FACEBOOK_MYGALLERY,
            this.app.events.GET_FRAME_ID
	        ];
};
com.art.myGalleries.commands.ApplicationCommand.prototype.handleNotification = function (note) {
	
    var _this = this;
    switch (note.name) {
        case this.app.events.STARTUP:
            trace("coreServiceProvider test");
            //this.coreServiceProvider.galleryAPIService.getGalleryById('token', sessionid, accountid, callbacks);
            break;
        case this.app.events.GET_ALL_GALLERIES:
            var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + this.app.getModel().getGallerySortObjectAsString() + "&" + this.app.getModel().getGalleryPagingOptionObjectAsString();
            this.serviceProvider.galleryAPIService.getUserGalleries({ command: this, app: this.app, successHandler: this.getUserGalleriesSuccess, errorHandler: this.getUserGalleriesError, beforeSendHandler: function () { } }, data);
            break;
        case this.app.events.GALLERY_ITEM_SORT:
            trace("note.body");
            trace(note.body);
            this.app.getModel().setPagingOptionsAllItems(false);
            var sort = "gallerySortOption=" + JSON.stringify({ "DefaultSort": true, "SortBy": note.body.sortBy, "SortDirection": note.body.sortOrder });
            this.app.getModel().gallerySortBy = note.body.sortBy;
            this.app.getModel().gallerySortDirection = note.body.sortOrder;
            
            var ResultFilterOptions = "ResultFilterOptions="+ JSON.stringify({ "IncludeGalleryItems": true, "IncludeSavedRooms": false, "IncludeSavedWalls": false, "IncludeSavedWallsItems": false  });
            //var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "galleryID=" + this.app.getModel().environment.selectedGalleryID + "&" + sort + "&" + this.app.getModel().getGalleryPagingOptionObjectAsString();
            
            var data  = this.app.getModel().getAccessKeyObjectAsString() + "&";
            data 	 += this.app.getModel().getUserProfileObjectAsString() + "&";
            data	 += "persona=" + this.app.getModel().environment.profileKey + "&";
            data	 += "galleryKey=" + this.app.getModel().environment.galleryKey + "&";
            data	 += "galleryAuthToken=" + this.app.getModel().environment.galleryAuthToken + "&";
            data	 += sort + "&" + this.app.getModel().getGalleryPagingOptionObjectAsString() + "&";
            data	 += ResultFilterOptions;
            	
            //this.serviceProvider.galleryAPIService.getGalleryWithItems({ command: this, app: this.app, successHandler: this.galleryItemSortSuccess, errorHandler: this.galleryItemSortError, beforeSendHandler: function () { } }, data);
            this.serviceProvider.galleryAPIService.getGalleryDetailswithResultFilter({ command: this, app: this.app, successHandler: this.galleryItemSortSuccess, errorHandler: this.galleryItemSortError, beforeSendHandler: function () { } }, data);
            break;
        case this.app.events.GET_SYSTEM_LIBRARY:
            trace("ApplicationCommand.handleNotification GET_SYSTEM_LIBRARY");
            if(this.app.getUserLibraryProxy().systemLibraryObject != undefined)
            {
            	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_SYSTEM_LIBRARY_SUCCESS, {}, 'ajax'));
            }
            else
            {
            	//var sort = "gallerySortOption=" + JSON.stringify({ "DefaultSort": false, "SortBy": "0", "SortDirection": 1 });
            	var sort = "gallerySortOption=" + JSON.stringify({ "DefaultSort": true, "SortBy": this.app.getModel().gallerySortBy, "SortDirection": this.app.getModel().gallerySortDirection });
            	var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "galleryId=" + this.app.getModel().environment.selectedGalleryID + "&" + sort + "&" + this.app.getModel().getGalleryPagingOptionObjectAsString();
            	this.serviceProvider.galleryAPIService.getSystemLibrary({ command: this, app: this.app, successHandler: this.getSystemLibrarySuccess, errorHandler: this.getSystemLibraryError, beforeSendHandler: function () { } }, data);
            }
            break;
        case this.app.events.GET_ALL_GALLERY_ITEMS:
            trace("ApplicationCommand.handleNotification GET_ALL_GALLERY_ITEMS");
            this.currentNote = note;
            if (this.app.getModel().galleryItemList.length > 0) {
                this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_ALL_GALLERY_ITEMS_SUCCESS, this.currentNote.body));
            }
            else {
                this.app.getModel().setPagingOptionsAllItems(true);
                
                var sort = "gallerySortOption=" + JSON.stringify({ "DefaultSort": true, "SortBy": this.app.getModel().gallerySortBy, "SortDirection": this.app.getModel().gallerySortDirection });
                //var sort = "gallerySortOption=" + JSON.stringify({ "DefaultSort": false, "SortBy": "0", "SortDirection": 1 });
                var ResultFilterOptions = "ResultFilterOptions="+ JSON.stringify({ "IncludeGalleryItems": true, "IncludeSavedRooms": false, "IncludeSavedWalls": false, "IncludeSavedWallsItems": false  });
                //var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "galleryID=" + this.app.getModel().environment.selectedGalleryID + "&" + this.app.getModel().getGallerySortObjectAsString() + "&" + this.app.getModel().getGalleryPagingOptionObjectAsString();
                var data  = this.app.getModel().getAccessKeyObjectAsString() + "&";
                data 	 += this.app.getModel().getUserProfileObjectAsString() + "&";
                data	 += "persona=" + this.app.getModel().environment.profileKey + "&";
                data	 += "galleryKey=" + this.app.getModel().environment.galleryKey + "&";
                data	 += "galleryAuthToken=" + this.app.getModel().environment.galleryAuthToken + "&";
                data	 += sort + "&" + this.app.getModel().getGalleryPagingOptionObjectAsString() + "&";
                data	 += ResultFilterOptions;
                //this.serviceProvider.galleryAPIService.getGalleryWithItems({ command: this, app: this.app, successHandler: this.getGalleryWithItemsSuccess, errorHandler: this.getGalleryWithItemsError, beforeSendHandler: function () { } }, data);
                this.serviceProvider.galleryAPIService.getGalleryDetailswithResultFilter({ command: this, app: this.app, successHandler: this.getGalleryWithItemsSuccess, errorHandler: this.getGalleryWithItemsError, beforeSendHandler: function () { } }, data);
            }
            break;
        case this.app.events.UPDATE_GALLERY_TITLE_DESC:
        	var gallery = this.app.getModel().getSelectedGalleryClone();            
            if (this.app.getModel().galleyNameIsAvailable(note.body.title, gallery.GalleryId)) {
                this.currentNote = note;
                var name=encodeURIComponent(note.body.title);
                gallery.Name = escape(name);                
                gallery.LongDescription =  encodeURIComponent(escape(note.body.desc));               
                                
                // galleryiconurl and iconurl are not needed for service so making them empty
                gallery.GalleryIconURL="";
                gallery.IconUrl="";
                //remove Icon for update
                gallery.Icon = null;
                
                var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "gallery=" + JSON.stringify(gallery);
                
                this.serviceProvider.galleryAPIService.updateGallery({ command: this, app: this.app, successHandler: this.updateGallerySuccess, errorHandler: this.updateGalleryError, beforeSendHandler: function () { } }, data);
            }
            else {
                this.app.sendNotification(new com.art.core.utils.Note(this.app.events.UPDATE_GALLERY_TITLE_DESC_FAILED, { msg: "duplicate" }));
            }
            break;
        case this.app.events.ADD_ITEM_TO_EXISTING_GALLERY:
            var galleryItems = [{}];
           
            if(this.app.getModel().getNewItemToGalleryFromFramingStudio().FrameSku!=null||this.app.getModel().getNewItemToGalleryFromFramingStudio().FrameSku!=undefined)
            	{
            		galleryItems[0]=this.app.getModel().getNewItemToGalleryFromFramingStudio();
            		galleryItems[0].Item.Title=escape(this.app.getModel().getNewItemToGalleryFromFramingStudio().Item.Title);
            		galleryItems[0].Item.ArtistName=escape(galleryItems[0].Item.ArtistName);
            		galleryItems[0].Item.ItemURL=escape(note.body);
            		galleryItems[0].ItemURL=escape(note.body);
            	}
            else
            	{
            		galleryItems[0] = this.app.getModel().getNewItemToGallery();
            		galleryItems[0].Item.Title=escape(this.app.getModel().getNewItemToGallery().Item.Title);
            		galleryItems[0].Item.ArtistName=escape(galleryItems[0].Item.ArtistName);
            		if(this.app.getModel().selectedImageObject.FrameSku!=undefined && this.app.getModel().selectedImageObject.FrameSku!=null && this.app.getModel().selectedImageObject.FrameSku.length>0)
    		        {
    		             //galleryItems[0].Item.ItemURL=this.app.getModel().selectedImageObject.DFEPrintImageUrl; 
    		             galleryItems[0].ItemURL=this.app.getModel().selectedImageObject.DFEPrintImageUrl;    		
    		        }
            	}
            
            var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "galleryItems=" + JSON.stringify(galleryItems) + "&" + "galleryID=" + this.app.getModel().environment.selectedGalleryID;                         
            this.serviceProvider.galleryAPIService.addItemsToGallery({ command: this, app: this.app, successHandler: this.addItemsToGallerySuccess, errorHandler: this.addItemsToGalleryError, beforeSendHandler: function () { } }, data);
            break;
        case this.app.events.ADD_GALLERY_TITLE_DESC:

            var gallery = this.app.getModel().setCreateGallery();
            var parentGalleryId = 1; // As we don't have any parent ID, this is for future use.            
            var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "parentGalleryId=" + parentGalleryId + "&" + "gallery=" + JSON.stringify(gallery);
            
            this.serviceProvider.galleryAPIService.createGallery({ command: this, app: this.app, successHandler: this.addGallerySuccess, errorHandler: this.addGalleryError, beforeSendHandler: function () { } }, data);
            break;
        case this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY:     
        	
            var gallery = this.app.getModel().setCreateGallery();
            var parentGalleryId = 1; // As we don't have any parent ID, this is for future use.
            trace("gallery");
            trace(gallery);
            var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "parentGalleryId=" + parentGalleryId + "&" + "gallery=" + JSON.stringify(gallery);

            this.serviceProvider.galleryAPIService.createGallery({ command: this, app: this.app, successHandler: this.moveAddNewItemsToGallerySuccess, errorHandler: this.moveAddNewItemsToGalleryError, beforeSendHandler: function () { } }, data);
            break;
        case this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY:        	
            var galleryItems = [{}];
            galleryItems[0] = this.app.getModel().getExisitngItemToGallery(true);
            //trace(galleryItems[0]);
            var destinationGalleries = [{}];
            var gallery = this.app.getModel().galleryTemplate;
            gallery.GalleryId = this.app.getModel().getDestinationSelectedGalleryId();            
            destinationGalleries[0] = gallery;
            galleryItems[0].ItemURL="";
            galleryItems[0].Item.Title=escape(galleryItems[0].Item.Title);
    		galleryItems[0].Item.ArtistName=escape(galleryItems[0].Item.ArtistName);
    		
    		//destinationGalleries[0].Item.Title=escape(destinationGalleries[0].Item.Title);
    		//destinationGalleries[0].Item.ArtistName=escape(destinationGalleries[0].Item.ArtistName);
    		
    		//alert(destinationGalleries[0].Item.Title + "" + destinationGalleries[0].Item.ArtistName);
            //trace("desinationGalleries"+destinationGalleries[0]);
           // destinationGalleries[0].ItemURL="";
    		
            trace(destinationGalleries[0]);
           // destinationGalleries[0].ItemURL=""
            //destinationGalleries[0] = this.app.getModel().getExisitngItemToGallery(false);

            var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "sourceGalleryID=" + this.app.getModel().environment.selectedGalleryID + "&" + "galleryItem=" + JSON.stringify(galleryItems) + "&" + "destinationGalleries=" + JSON.stringify(destinationGalleries) + "&" + this.app.getModel().getMoveOptions();
            this.serviceProvider.galleryAPIService.moveGalleryItem({ command: this, app: this.app, successHandler: this.moveExistingItemsToGallerySuccess, errorHandler: this.moveExistingItemsToGalleryError, beforeSendHandler: function () { } }, data);
            
            break;
        case this.app.events.ADD_ITEM_TO_NEW_GALLERY:
            var gallery = this.app.getModel().setCreateGallery();
            var parentGalleryId = 1; // As we don't have any parent ID, this is for future use.
            this.printFileName=note.body;
            var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "parentGalleryId=" + parentGalleryId + "&" + "gallery=" + JSON.stringify(gallery);

            this.serviceProvider.galleryAPIService.createGallery({ command: this, app: this.app, successHandler: this.addNewItemsToGallerySuccess, errorHandler: this.addNewItemsToGalleryError, beforeSendHandler: function () { } }, data);
            break;
        case this.app.events.REGISTER_ACCOUNT:
            this.username = note.body.username;
            this.password = note.body.password;
            var data = "account=CreateAccount&usr=" + this.username + "&" + "pwd=" + this.password;
            this.serviceProvider.galleryAPIService.callAccountProxy({ command: this, app: this.app, successHandler: this.registerAccountSuccess, errorHandler: this.registerAccountError, beforeSendHandler: function () { } }, data);
            break;
        case this.app.events.LOGIN_ACCOUNT:
            this.username = note.body.username;
            this.password = note.body.password;
            var data = "account=LoginAccount&usr=" + this.username + "&" + "pwd=" + this.password;
            this.serviceProvider.galleryAPIService.callAccountProxy({ command: this, app: this.app, successHandler: this.loginAccountSuccess, errorHandler: this.loginAccountError, beforeSendHandler: function () { } }, data);
            break;
        case this.app.events.LOGOUT_MYGALLERY:
        	var cookieobject = new com.art.core.cookie.Cookie();
            var sesssionID = cookieobject.getCookieBase('sessionid');
            var data = "myaccount=LogoutMyGallery&sessionID="+sesssionID;
            
            this.serviceProvider.galleryAPIService.callMyAccountProxy({ command: this, app: this.app, successHandler: this.logoutAccountSuccess, errorHandler: this.logoutAccountError, beforeSendHandler: function () { } }, data);
            break;
        case this.app.events.CREATE_WALL:
        	trace("ApplicationCommand CREATE WALL");
        	var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString()+"&galleryId="+this.app.getModel().environment.selectedGalleryID+"&wall="+this.app.getUserLibraryProxy().getWallObjectAsStringForCreateWall();
        	trace(data);
        	this.serviceProvider.galleryAPIService.createWall({command:this,app:this.app,successHandler:this.createWallSuccess,errorHandler:this.createWallError,beforeSendHandler:function(){}},data);
        	break;
        case this.app.events.UPDATE_WALL_ITEMS:
        	var items = note.body;
        	trace("ApplicationCommand UPDATE_WALL_ITEMS");
            var wid = this.app.getUserLibraryProxy().getSelectedWallId();
            var wallStr = this.app.getUserLibraryProxy().getWallObjectAsStringForUpdateWall(note.body,wid);
            var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString()+"&galleryId="+this.app.getModel().environment.selectedGalleryID+"&WallID="+wid+"&Wall="+wallStr;
            trace(data);
            this.serviceProvider.galleryAPIService.updateWall({command:this,app:this.app,successHandler:this.updateWallItemsSuccess,errorHandler:this.updateWallItemsError,beforeSendHandler:function(){}},data);
        	//always a single item will trigger this event
        	break;
        case this.app.events.ADD_SIMILAR_ARTIST_ITEM:
        	var data = {}; 
        	data.Apnum = this.app.getModel().cacheByGalleryItemList[this.app.getModel().environment.selectedGalleryItemId].APNum;
        	data.ImageFilePath = this.app.getModel().cacheByGalleryItemList[this.app.getModel().environment.selectedGalleryItemId].ItemDetails.ImageInformation.LargeImage.HttpImageURL;
        	trace("ApplicationCommand > ADD_SIMILAR_ARTIST_ITEM");
        	trace(data);
        	
        	this.serviceProvider.searchAPIService.getSimilarImagesForImage({command:this, app:this.app,  successHandler: this.searchSimilarArtistSuccess, errorHandler: this.searchSimilarArtistError, beforeSendHandler: function () { } }, data);
        	break;
        case this.app.events.GET_WALLS:
        	var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString()+"&galleryId="+this.app.getModel().environment.selectedGalleryID;
        	this.serviceProvider.galleryAPIService.getWalls({command:this,app:this.app,successHandler:this.getWallsSuccess,errorHandler:this.getWallsError,beforeSendHandler:function(){}},data);
        	break;
        case this.app.events.ADD_BARE_WALLS:
        	var data = this.app.getModel().getAccessKeyObjectAsString()+"&";
        	data += this.app.getModel().getUserProfileObjectAsString() + "&";
        	data += "galleryID="+this.app.getModel().environment.selectedGalleryID+"&";
        	data += "Wall="+JSON.stringify([note.body]);
        	this.serviceProvider.galleryAPIService.addBareWalls({command:this,app:this.app,successHandler:this.addBareWallSuccess,errorHandler:this.addBareWallError,beforeSendHandler:function(){}},data);
        	break;
        case this.app.events.GET_USER_LIBRARY:
        	if(this.app.getModel().userLibraryObject == undefined)
        	{
        		trace("ApplicationCommand.handleNotification GET_USER_LIBRARY");
        		var sort = "gallerySortOption=" + JSON.stringify({ "DefaultSort": false, "SortBy": "0", "SortDirection": 1 });
        		var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "galleryId=" + this.app.getModel().environment.selectedGalleryID + "&" + sort + "&" + this.app.getModel().getGalleryPagingOptionObjectAsString();
        		this.serviceProvider.galleryAPIService.getUserLibrary({ command: this, app: this.app, successHandler: this.getUserLibrarySuccess, errorHandler: this.getUserLibraryError, beforeSendHandler: function () { } }, data);
        	}
        	else
        	{
        		return this.app.getModel().userLibraryObject;
        	}
        	break;
        case this.app.events.SHARE_WALL:
        	var wallid = this.app.getUserLibraryProxy().getSelectedWallId();
        	trace("wallid "+wallid);
        	var data = this.app.getModel().getAccessKeyObjectAsString() + "&";
        	data += this.app.getModel().getUserProfileObjectAsString() + "&";
        	data += "galleryId=" + this.app.getModel().environment.selectedGalleryID + "&";
        	data += "persona="+ this.app.getModel().environment.profileKey + "&";
        	data += "galleryKey="+this.app.getModel().environment.galleryKey + "&";
        	data += "galleryAuthToken="+this.app.getModel().environment.galleryAuthToken + "&";
        	data += "WallID="+wallid+"&";
        	data += "createSnapshot=true";
        	trace("Share_Wall data:");
        	trace(data);
        	this.serviceProvider.galleryAPIService.shareWall({ command: this, app: this.app, successHandler: this.shareWallSuccess, errorHandler: this.shareWallError, beforeSendHandler: function () { } }, data);
        	break;
        case this.app.events.DELETE_GALLERY_ITEM:        	 
        	 var deleteItem =[{}];        	
        	 deleteItem[0].ItemGalleryItemID=note.body;
        	 var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "galleryId=" + this.app.getModel().environment.selectedGalleryID + "&itemstoRemove="+JSON.stringify(deleteItem) +"&removeOptions=1";        	 
        	 this.serviceProvider.galleryAPIService.deleteGalleryItem({ command: this, app: this.app, successHandler: this.deleteGalleryItemSuccess, errorHandler: this.deleteGalleryItemError, beforeSendHandler: function () { } }, data);             
        	break;
        case this.app.events.DELETE_GALLERY_ITEM_DP:        	
       	 	var deleteItem =[{}];        	
       	 	deleteItem[0].ItemGalleryItemID=note.body;       	 	
       	 	var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "galleryId=" + this.app.getModel().environment.selectedGalleryID + "&itemstoRemove="+JSON.stringify(deleteItem) +"&removeOptions=1";        	 
       	 	this.serviceProvider.galleryAPIService.deleteGalleryItem({ command: this, app: this.app, successHandler: this.detailPageDeleteGalleryItemSuccess, errorHandler: this.detailPageDeleteGalleryItemError, beforeSendHandler: function () { } }, data);             
       	 break;
        case this.app.events.UPDATE_BARE_WALL:
        	trace("ApplicationCommand > UPDATE_BARE_WALL");
        	var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&";
        	data += "galleryId=" + this.app.getModel().environment.selectedGalleryID+ "&";
        	data += "Wall="+JSON.stringify(this.app.getUserLibraryProxy().getSelectedPersonalBareWallWithUpdates(note.body));
        	this.serviceProvider.galleryAPIService.updateBareWall({command:this,app:this.app,successHandler:this.updateBareWallSuccess,errorHandler:this.updateBareWallError,beforeSendHandler:function(){}},data);
        	break;
        case this.app.events.UPDATE_PRIVACY_SETTINGS:
        	 var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "gallery=" + JSON.stringify(note.body);            
           	 this.serviceProvider.galleryAPIService.updateGallery({ command: this, app: this.app, successHandler: this.privacyUpdateGalleryItemSuccess, errorHandler: this.privacyUpdateGalleryItemError, beforeSendHandler: function () { } }, data);       
        	 trace("ApplicationCommand > UPDATE_PRIVACY_SETTINGS");          	
        	break;
        case this.app.events.GET_FRAME_SKU:
        	var data="dfeEngineParameters="+JSON.stringify(note.body);  
        	trace(data);        	
          	this.serviceProvider.dfeAPIService.GetFrameSkuForFrameConfiguration({command: this, app: this.app, successHandler: this.getFrameSKUSuccess, errorHandler: this.getFrameSKUError, beforeSendHandler: function () { } }, data);       
          	break;
        case this.app.events.GET_WALL_BY_ID:
        	var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString()+"&";
        	data += "wallId="+ this.app.getUserLibraryProxy().sharedWallId+ "&";
        	data += "profileKey=" + this.app.getModel().environment.profileKey + "&";
        	data += "galleryKey=" + this.app.getModel().environment.galleryKey + "&";
        	data += "galleryAccessKey=" + this.app.getModel().environment.galleryAuthToken;
        	trace("GET_WALL_BY_ID "+data);
        	//this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_WALL_BY_ID_SUCCESS, {}, 'ajax'));
        	this.serviceProvider.galleryAPIService.getWallByWallId({ command: this, app: this.app, successHandler: this.getWallByIdSuccess, errorHandler: this.getWallByIdError, beforeSendHandler: function () { } }, data);       
        	break;
        case this.app.events.GET_USER_LIBRARY_BY_PROFILE:
        	var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString()+"&";
        	data += this.app.getModel().getGalleryPagingOptionObjectAsString + "&";
        	data += "gallerySortOption=" + JSON.stringify({ "DefaultSort": false, "SortBy": "0", "SortDirection": 1 }) + "&";
        	data += "profileKey=" + this.app.getModel().environment.profileKey + "&";
        	trace("GET_USER_LIBRARY_BY_PROFILE "+data);
        	this.serviceProvider.galleryAPIService.getUserLibraryByProfileKey({ command: this, app: this.app, successHandler: this.getUserLibraryByProfileKeySuccess, errorHandler: this.getUserLibraryByProfileKeyError, beforeSendHandler: function () { } }, data);       
        	break;
        case this.app.events.LOGIN_FACEBOOK_MYGALLERY:        	  
              var data = "account=FaceBookLogin&FUID=" + note.body;              
              this.serviceProvider.galleryAPIService.callAccountProxy({ command: this, app: this.app, successHandler: this.facebookLoginAccountSuccess, errorHandler: this.facebookLoginAccountError, beforeSendHandler: function () { } }, data);
              break;
        case this.app.events.GET_FRAME_ID:
        	var data = this.app.getModel();
        	var DFEunitOfMeasure = (com.art.core.utils.LocalizationManager.determineConvertToCm("", data.environment.currencyCode, "")) ?  this.app.constants.DFEUNITOFMEASURECM :  this.app.constants.DFEUNITOFMEASUREINCH;
        	var props = "ui="+data.environment.sessionId+"&frameSKU=" + note.body.frameConfigurationId+"&imageMaxW="+this.app.constants.DFEIMAGEMAXW+"&imageMaxH="+this.app.constants.DFEIMAGEMAXH;
        	props += "&unitofmeasure="+DFEunitOfMeasure+"&customerZoneId="+data.environment.customerZoneId+"&languageId="+data.environment.languageId+"&currencyId="+data.environment.currencyId+"&currencyCode="+data.environment.currencyCode;
        	props += "&IsDFEAjax=Y";
        	this.serviceProvider.framingServiceAPI.getFrameIdForDFE({command: this, app: this.app, successHandler: this.getFrameIdForDFESuccess, errorHandler: this.getFrameIdForDFEError, beforeSendHandler: function () { } }, props);
        	break;
        default:
            throw new Error("ApplicationCommand failure! Invalid event: " + note.name);
    }
};


/**
* Used this method when user is able to successfully login into facebook account 
* facebookLoginAccountSuccess
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.facebookLoginAccountSuccess = function (response) {
	
	trace("facebook Login Account Success");	
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.LOGIN_FACEBOOK_MYGALLERY_FAILED));
	
};

/**
* Used this method when user is able to successfully login into facebook account
* facebookLoginAccountError
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.facebookLoginAccountError = function (response) {
	trace("facebook Login Account Success,It's success as Ajax call is return fine but response is coming failure.");
	 if (response.responseText == "{'success'}") {
		 
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.LOGIN_FACEBOOK_MYGALLERY_SUCCESS));
     }
    else {  
    	
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.LOGIN_FACEBOOK_MYGALLERY_FAILED));
    }		 
};



/**
* Used this method to get the frame sku value which will use in add to gallery from frame studio
* getFrameSKUSuccess
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.getFrameSKUSuccess = function (response) {
	
	trace("getFrameSKUSuccess");
	trace(response);
	
	var data=[{}];
	data.ImageUrl=response.d.FrameConfigurations[0].FrameImageUrl;
	data.FrameSku=response.d.FrameConfigurations[0].FrameSku;
	data.Height=response.d.FrameConfigurations[0].ImageHeight;	
	data.Width=response.d.FrameConfigurations[0].ImageWidth;	
	data.Price=response.d.FrameConfigurations[0].PriceConfig.Price;
	data.DisplayPrice=response.d.FrameConfigurations[0].PriceConfig.DisplayPrice;
	data.Title=response.d.FrameConfigurations[0].Print.Title;
	data.APNum=response.d.FrameConfigurations[0].Print.APNum;
	data.ArtistID=response.d.FrameConfigurations[0].Print.ArtistCategoryID;
	data.Imageid=response.d.FrameConfigurations[0].Print.ImageID;	
	data.ItemDisplayedTypeID=response.d.FrameConfigurations[0].Print.ItemDisplayedTypeID;
	data.PODConfigID=response.d.FrameConfigurations[0].Print.PODConfigID;  
	data.ArtistName=response.d.FrameConfigurations[0].Print.ArtistLastName + " " + response.d.FrameConfigurations[0].Print.ArtistFirstName;
	
	var imageurl=response.d.FrameConfigurations[0].Print.FileName;	
	imageurl= "http://"+this.app.getModel().environment.ImageDynPath  + "/lrg"+imageurl;	
	//imageurl=imageurl.replace("\\","/").replace("\\","/").replace("\\","/");
	imageurl=imageurl.replace(/\134/g,"/");
	//this.command.printFileName=imageurl;
	data.FileName=imageurl;
	data.Source = "FramingStudioPage";
	
	this.app.getModel().setSelectedImageObject(data);
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_FRAME_SKU_SUCCESS,data));
};

/**
* Error Handler  : Used this method to get the frame sku value which will use in add to gallery from frame studio
* getFrameSKUError
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.getFrameSKUError = function (response) {
	trace("getFrameSKUError");
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_FRAME_SKU_FAILED));	 
};



/**
* Used this method to handle delete the item from the gallery
*deleteGalleryItemSuccess
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.privacyUpdateGalleryItemSuccess = function (response) {
	window.location.href=window.location.href;
};

/**
* Used this method to handle delete the gallery item from the detail page
*detailPageDeleteGalleryItemError
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.privacyUpdateGalleryItemError = function (response) {
		 
};

/**
* Used this method to handle delete the item from the gallery
*deleteGalleryItemSuccess
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.detailPageDeleteGalleryItemSuccess = function (response) {
	 this.app.sendNotification(new com.art.core.utils.Note(this.app.events.DELETE_GALLERY_ITEM_DP_SUCCESS));
};

/**
* Used this method to handle delete the gallery item from the detail page
*detailPageDeleteGalleryItemError
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.detailPageDeleteGalleryItemError = function (response) {
	trace("delete item from the gallery");
	 this.app.sendNotification(new com.art.core.utils.Note(this.app.events.DELETE_GALLERY_ITEM_DP_FAILED)); 
};

/**
* Used this method to handle delete the item from the gallery
*deleteGalleryItemSuccess
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.deleteGalleryItemSuccess = function (response) {
	 this.app.sendNotification(new com.art.core.utils.Note(this.app.events.DELETE_GALLERY_ITEM_SUCCESS));
};

/**
* Used this method to handle delete the item from the gallery
*logoutAccountSuccess
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.deleteGalleryItemError = function (response) {
	trace("delete item from the gallery");
	 this.app.sendNotification(new com.art.core.utils.Note(this.app.events.DELETE_GALLERY_ITEM_FAILED));
};


/**
* Used this method to logout from mygallery,art.com and clear the cookies
*logoutAccountSuccess
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.logoutAccountSuccess = function (response) {    
};
/**
* Used this method to successfully/failed logout from mygallery,art.com and clear the cookies (Please change to success after ajax call change)
*logoutAccountError
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.logoutAccountError = function (response) {    
    var _this = this;   
    if (response.responseText == "{'success'}") {                                   
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.LOGOUT_MYGALLERY_SUCCESS));
     }
    else {        
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.LOGOUT_MYGALLERY_FAILED));
    }
};

/**
* Used this method to get the successful login response from the login account service
*loginAccountSuccess
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.loginAccountSuccess = function (response) {    
    //this.app.sendNotification(new com.art.core.utils.Note(this.app.events.LOGIN_ACCOUNT_SUCCESS));
};
/**
*Used this method to get the successful and failed login response from the login account service.
* and after success, call my account proxy to to create the cookie  (Please modify failed to success in ajax call)
*loginAccountError
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.loginAccountError = function (response) {    
    var _this = this;
    
    if (response.responseText == "{'success'}") {    
        var cookieobject = new com.art.core.cookie.Cookie();
        var sesssionID = cookieobject.getCookieBase('sessionid');
        var data = "myaccount=myLoginAccount&usr=" + this.command.username + "&" + "pwd=" + this.command.password + "&" + "sessionID=" + sesssionID;
        this.command.serviceProvider.galleryAPIService.callMyAccountProxy({ command: this.command, app: this.app, successHandler: this.command.loginMyAccountSuccess, errorHandler: this.command.loginMyAccountError, beforeSendHandler: function () { } }, data);
    }
    else {        
      this.app.sendNotification(new com.art.core.utils.Note(this.app.events.LOGIN_ACCOUNT_FAILED, "failure"));
    }
};

/**
*Used this method to get the successful login response and send the login notification to component  (Please modify failed to success in ajax call)
*loginMyAccountSuccess
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.loginMyAccountSuccess = function (response) {

    //this.app.sendNotification(new com.art.core.utils.Note(this.app.events.LOGIN_ACCOUNT_SUCCESS));
};

/**
*Used this method to get the successful/failed login response and send the notification to component 
*loginMyAccountError
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.loginMyAccountError = function (response) {
    trace(response);    
    if (response.responseText == "{'success'}") {        
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.LOGIN_ACCOUNT_SUCCESS));
    }
    else {
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.LOGIN_ACCOUNT_FAILED, "failure"));        
    }
};
/**
*Used this method to get the successful register response (please modify it later)
*registerMyAccountSuccess
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.registerMyAccountSuccess = function (response) {
    trace(response);    
    //this.app.sendNotification(new com.art.core.utils.Note(this.app.events.REGISTER_ACCOUNT_SUCCESS));
};
/**
*Used this method to get the successful/failed register response and send the notification to component
*registerMyAccountError
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.registerMyAccountError = function (response) {
	trace(response.responseText);
    if (response.responseText == "{'success'}") {        
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.REGISTER_ACCOUNT_SUCCESS));
    }
    else {
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.REGISTER_ACCOUNT_FAILED, "failure"));
    }
};
/**
*Used this method to get the successful register response
*registerAccountSuccess
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.registerAccountSuccess = function (response) {
    trace(response);    
    //this.app.sendNotification(new com.art.core.utils.Note(this.app.events.REGISTER_ACCOUNT_SUCCESS));
};
/**
*Used this method to get the successful/failed register response and call the another proxy to generate the cookie
*registerAccountError
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.registerAccountError = function (response) {
    trace(response);
    if (response.responseText == "{'success'}") {        
        var cookieobject = new com.art.core.cookie.Cookie();
        var sesssionID = cookieobject.getCookieBase('sessionid');
        var data = "myaccount=myLoginAccount&usr=" + this.command.username + "&" + "pwd=" + this.command.password + "&" + "sessionID=" + sesssionID;
        this.command.serviceProvider.galleryAPIService.callMyAccountProxy({ command: this.command, app: this.app, successHandler: this.command.registerMyAccountSuccess, errorHandler: this.command.registerMyAccountError, beforeSendHandler: function () { } }, data);
    }
    else if (response.responseText == "{'exist'}") {
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.REGISTER_ACCOUNT_FAILED, "exist"));
    }
    else if (response.responseText == "{'invalidemail'}") {
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.REGISTER_ACCOUNT_FAILED, "invalidemail"));
    }
    else if (response.responseText == "{'invalidpassword'}") {
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.REGISTER_ACCOUNT_FAILED, "invalidpassword"));
    }
    else {        
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.REGISTER_ACCOUNT_FAILED, "failure"));
    }
};

/**
* 
* 
* 
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.moveAddNewItemsToGallerySuccess = function (response) {

    if (response.OperationResponse.OperationStatus == 0) {    	
        var galleryItems = [{}];
   
        galleryItems[0] = this.app.getModel().getExisitngItemToGallery(true);
        galleryItems[0].ItemURL="";
        galleryItems[0].Item.Title=escape(galleryItems[0].Item.Title);
		galleryItems[0].Item.ArtistName=escape(galleryItems[0].Item.ArtistName);
		
        trace(galleryItems[0]);
        var destinationGalleries = [{}];
        trace(response.Library.Galleries);
        
        var gallery = this.app.getModel().galleryTemplate;
        gallery.GalleryId = response.Library.Galleries[0].GalleryId;
        this.command.tempNewCreatedGalleryId=response.Library.Galleries[0].ItemKey;
        destinationGalleries[0] = gallery;        
        var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&" + "sourceGalleryID=" + this.app.getModel().environment.selectedGalleryID + "&" + "galleryItem=" + JSON.stringify(galleryItems) + "&" + "destinationGalleries=" + JSON.stringify(destinationGalleries) + "&" + this.app.getModel().getMoveOptions();    
        this.command.serviceProvider.galleryAPIService.moveGalleryItem({ command: this.command, app: this.app, successHandler: this.command.moveAddItemsToGallerySuccess, errorHandler: this.command.moveAddItemsToGalleryError, beforeSendHandler: function () { } }, data);
    }
    else {
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY_SUCCESS, response));
    }
};

com.art.myGalleries.commands.ApplicationCommand.prototype.moveAddNewItemsToGalleryError = function (response) {
    this.app.sendNotification(new com.art.core.utils.Note(this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY_FAILED,response));
};

/**
* 
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.moveAddItemsToGallerySuccess = function (response) {	
	
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY_SUCCESS,this.command.tempNewCreatedGalleryId));	
};

com.art.myGalleries.commands.ApplicationCommand.prototype.moveAddItemsToGalleryError = function (response) {	
   this.app.sendNotification(new com.art.core.utils.Note(this.app.events.MOVE_ADD_ITEM_TO_NEW_GALLERY_FAILED,response));
};


/**
* 
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.addNewItemsToGallerySuccess = function (response) {
   if (response.Library != null || response.Library != undefined) {
        var galleryItems = [{}];
        
        if(this.app.getModel().getNewItemToGalleryFromFramingStudio().FrameSku!=null||this.app.getModel().getNewItemToGalleryFromFramingStudio().FrameSku!=undefined)
    	{	
        	galleryItems[0]=this.app.getModel().getNewItemToGalleryFromFramingStudio();
        	galleryItems[0].Item.Title=escape(this.app.getModel().getNewItemToGalleryFromFramingStudio().Item.Title);        	
        	galleryItems[0].Item.ArtistName=escape(galleryItems[0].Item.ArtistName);        	
        	galleryItems[0].Item.ItemURL=escape(this.command.printFileName);
        	galleryItems[0].ItemURL=escape(this.command.printFileName);
    	}
        else	
    	{    	    
    		galleryItems[0] = this.app.getModel().getNewItemToGallery();    		
    		galleryItems[0].Item.Title=escape(this.app.getModel().getNewItemToGallery().Item.Title);
    		galleryItems[0].Item.ArtistName=escape(galleryItems[0].Item.ArtistName);
    		if(this.app.getModel().selectedImageObject.FrameSku!=undefined && this.app.getModel().selectedImageObject.FrameSku!=null && this.app.getModel().selectedImageObject.FrameSku.length>0)
    		{
    		   // galleryItems[0].Item.ItemURL=this.app.getModel().selectedImageObject.DFEPrintImageUrl;  
    		    galleryItems[0].ItemURL=this.app.getModel().selectedImageObject.DFEPrintImageUrl;    		
    		}
    	}
        var galleryID =response.Library.Galleries[0].GalleryId;        
        this.command.tempNewCreatedGalleryId=response.Library.Galleries[0].ItemKey;
        
        var data = this.app.getModel().getAccessKeyObjectAsString() + "&" + this.app.getModel().getUserProfileObjectAsString() + "&"  + "galleryItems=" + JSON.stringify(galleryItems) + "&" + "galleryID=" + galleryID;        
        this.command.serviceProvider.galleryAPIService.addItemsToGallery({ command: this.command, app: this.app, successHandler: this.command.addItemsToGallerySuccess, errorHandler: this.command.addItemsToGalleryError, beforeSendHandler: function () { } }, data);
    }
    else {    	
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.ADD_ITEM_TO_NEW_GALLERY_SUCCESS, response));
    }     
};

com.art.myGalleries.commands.ApplicationCommand.prototype.addNewItemsToGalleryError = function (response) {
    this.app.sendNotification(new com.art.core.utils.Note(this.app.events.ADD_ITEM_TO_NEW_GALLERY_FAILED,response));
};

/**
* 
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.moveExistingItemsToGallerySuccess = function (response) {
	var eventName;
	if (this.app.getModel().selectedImageObject.Source == "ProductPage") 
		eventName = "Product Page Add - Completed";
	else if(this.app.getModel().selectedImageObject.Source == "GalleryPage")
		eventName = "Gallery Page Add - Completed";
	else if(this.app.getModel().selectedImageObject.Source == "ServicesPage")
		eventName = "Services Page Add - Completed";
	else if(this.app.getModel().selectedImageObject.Source == "FramingStudioPage")
		eventName = "Framing Studio Page Add - Completed";
	mygalleriesGA.trackEventWithCategory(eventName, eventName);
	
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY_SUCCESS));	
};

com.art.myGalleries.commands.ApplicationCommand.prototype.moveExistingItemsToGalleryError = function (response) {	
   this.app.sendNotification(new com.art.core.utils.Note(this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY_FAILED));
};


com.art.myGalleries.commands.ApplicationCommand.prototype.addItemsToGalleryError = function (response) {
    this.app.sendNotification(this.app.events.MOVE_ADD_ITEM_TO_EXISTING_GALLERY_FAILED);
};

/**
* 
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.addItemsToGallerySuccess = function (response) {
	var eventName;
	var catName = "Save to Gallery";
	
	if (this.app.getModel().selectedImageObject.Source == "ProductPage") 
		eventName = "Product Page Add - Completed";
	else if(this.app.getModel().selectedImageObject.Source == "GalleryPage")
		eventName = "Gallery Page Add - Completed";
	else if(this.app.getModel().selectedImageObject.Source == "ServicesPage")
		eventName = "Services Page Add - Completed";
	else if(this.app.getModel().selectedImageObject.Source == "FramingStudioPage")
		eventName = "Framing Studio Page Add - Completed";
	mygalleriesGA.trackEventWithCategory(catName, eventName);
	
    this.app.sendNotification(new com.art.core.utils.Note(this.app.events.ADD_ITEM_TO_EXISTING_GALLERY_SUCCESS,this.command.tempNewCreatedGalleryId));
};

com.art.myGalleries.commands.ApplicationCommand.prototype.addItemsToGalleryError = function (response) {
    this.app.sendNotification(this.app.events.ADD_ITEM_TO_EXISTING_GALLERY_FAILED);
};

/**
* 
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.updateGallerySuccess = function (response) {	
	var galleries = response.Library.Galleries;
	
	//refresh page
	location.href = "http://"+location.host + galleries[0].VanityURL;
	
	this.app.getModel().setSelectedGalleryTitle(this.command.currentNote.body.title);
	this.app.getModel().setSelectedGalleryDesc(this.command.currentNote.body.desc);
    this.app.sendNotification(new com.art.core.utils.Note(this.app.events.UPDATE_GALLERY_TITLE_DESC_SUCCESS, response));
};

com.art.myGalleries.commands.ApplicationCommand.prototype.updateGalleryError = function (response) {
    this.app.sendNotification(this.app.events.UPDATE_GALLERY_TITLE_DESC_FAILED,response);
};

/**
* 
* 
* 
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.addGallerySuccess = function (response) {
	//response.OperationResponse.ResponseMessage
    this.app.sendNotification(new com.art.core.utils.Note(this.app.events.ADD_GALLERY_TITLE_DESC_SUCCESS, response));
};
com.art.myGalleries.commands.ApplicationCommand.prototype.addGalleryError = function (response) {
    this.app.sendNotification(this.app.events.ADD_GALLERY_TITLE_DESC_FAILED);
};

/**
* 
* 
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.getGalleryWithItemsSuccess = function (response) {

	trace("ApplicationCommand.getGalleryWithItemsSuccess >> getGalleryDetailswithResultFilter");
	trace(response);
    var _this = this;
    if (response.Library.Galleries == null) {
        throw new Error("ApplicationCommand.getGalleryWithItemsSuccess failed! response.Library.Galleries is undefined.");
    }
    else {
        trace("GET_ALL_GALLERY_ITEMS_SUCCESS ");
        this.app.getModel().setGalleryItems(response.Library.Galleries[0].Items);
        this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_ALL_GALLERY_ITEMS_SUCCESS, this.command.currentNote.body));
        this.processing = false;
    }
};

com.art.myGalleries.commands.ApplicationCommand.prototype.getGalleryWithItemsError = function (response) {
    trace('JSON Call failed');
    this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_ALL_GALLERY_ITEMS_FAILED, error, 'ajax'));
    this.processing = false;
};

/** 
* @method galleryItemSortSuccess
* @param response
*/
com.art.myGalleries.commands.ApplicationCommand.prototype.galleryItemSortSuccess = function (response) {
    var galleryItems = response.Library.Galleries[0].Items;
    trace("success: " + this.app.events.GALLERY_ITEM_SORT_SUCCESS);
    //invalidate data for roomView and SlideShow
    this.app.getModel().flattenGalleryItemDetails(galleryItems);
    this.app.getModel().galleryItemList = [];
    this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GALLERY_ITEM_SORT_SUCCESS, { items: galleryItems }, ""));
    this.command.processing = false;
};

com.art.myGalleries.commands.ApplicationCommand.prototype.galleryItemSortError = function (response) {
    trace('JSON Call failed');
    this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GALLERY_ITEM_LIST_REQUEST_FAILED, error, 'ajax'));
    this.processing = false;
};

/**
 * @method getSystemLibrarySuccess
 * 
 *
 **/
com.art.myGalleries.commands.ApplicationCommand.prototype.getSystemLibrarySuccess = function(response)
{
	trace("ApplicationCommand.getSystemLibrarySuccess");
	trace(response);
	if(response.Library != null)
	{
		this.app.getUserLibraryProxy().setSystemLibrary(response.Library);
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_SYSTEM_LIBRARY_SUCCESS, {}, 'ajax'));	
	}
	else
	{
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_SYSTEM_LIBRARY_FAILED, {}, 'ajax'));	
	}
	
};
com.art.myGalleries.commands.ApplicationCommand.prototype.getSystemLibraryError = function(response)
{
	trace('getUserLibraryError Call Failed!');
	trace(response);
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_SYSTEM_LIBRARY_FAILED, {}, 'ajax'));
};

com.art.myGalleries.commands.ApplicationCommand.prototype.getUserGalleriesSuccess = function(response)
{
	trace("getUserGallerySuccess");
	trace(response);
	var _this = this;
    if (response.Library == null || response.Library.Galleries.length == 0) {
        trace("error code " + response.Library.Galleries);
    	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_ALL_GALLERIES_FAILED));
    }
    else {
        trace("GET_ALL_GALLERY_SUCCESS ");
        this.app.getModel().setGalleryList(response.Library.Galleries);
    	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_ALL_GALLERIES_SUCCESS));
        this.processing = false;
    }
};
com.art.myGalleries.commands.ApplicationCommand.prototype.getUserGalleriesError = function(response)
{
	 this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_ALL_GALLERIES_FAILED, error, 'ajax'));
	 this.processing = false;	
};
/**
 * 
 */
com.art.myGalleries.commands.ApplicationCommand.prototype.createWallSuccess = function(response)
{
	trace("createWallSuccess");
	trace(response);
	if(response.Library)
	{
		var wall = response.Library.Galleries[0].Walls[0];
		//check for empty rooms
		var n =  this.app.getUserLibraryProxy().selectedWallName.indexOf("hex") > -1 ?this.app.getUserLibraryProxy().selectedWallGalleryName : this.app.getUserLibraryProxy().selectedWallName;
		trace("NAME: "+n);
		wall.WallDetails.Name = n; //the reponse doesn't have Name
		this.app.getUserLibraryProxy().wallsObject.push(wall);
		this.app.getUserLibraryProxy().flatten(this.app.getUserLibraryProxy().wallsObject);
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.CREATE_WALL_SUCCESS));
	}
	else
		throw new Error("ApplicationCommand createWallSuccess Error! Response does not have wallid.");
};
/**
 * 
 */
com.art.myGalleries.commands.ApplicationCommand.prototype.createWallError = function(response)
{
	this.sendNotification(new com.art.core.utils.Note(this.app.events.CREATE_WALL_FAILED));
};
/**
 * Refresh Library when complete
 */
com.art.myGalleries.commands.ApplicationCommand.prototype.updateWallItemsSuccess = function(response)
{
	trace("ApplicationCommand.updateWallItemsSuccess()");
	trace(response);
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.UPDATE_WALL_ITEMS_SUCCESS));
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_WALLS));
};
/**
 * 
 */
com.art.myGalleries.commands.ApplicationCommand.prototype.updateWallItemsError = function(response)
{
	this.sendNotification(new com.art.core.utils.Note(this.app.events.UPDATE_WALL_FAILED));
};

com.art.myGalleries.commands.ApplicationCommand.prototype.searchSimilarArtistSuccess = function(response)
{
	trace("ApplicationCommand.searchSimilarArtistSuccess()");
	trace(response);
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.ADD_SIMILAR_ARTIST_ITEM_SUCCESS, response));
    this.processing = false;
};
com.art.myGalleries.commands.ApplicationCommand.prototype.searchSimilarArtistError = function(response)
{
	trace("ApplicationCommand.searchSimilarArtistError");
	trace(response);
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.ADD_SIMILAR_ARTIST_ITEM_FAILED, 'ajax'));
	this.processing = false;	
};
com.art.myGalleries.commands.ApplicationCommand.prototype.getWallsSuccess = function(response)
{
	trace("getWallSuccess");
	trace(response);
	if(response.Library)
	{
		this.app.getUserLibraryProxy().setLastUpdatedWall(response.Library.Walls);
		this.app.getUserLibraryProxy().wallsObject = response.Library.Walls;
		this.app.getUserLibraryProxy().flatten(response.Library.Walls); //for quick lookup to updateWalls
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_WALLS_SUCCESS, {}, 'ajax'));
	}
	else
	{
		//temporary if no walls exist
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_WALLS_SUCCESS, {}, 'ajax'));
		//throw new Error("ApplicationCommand.getWallSuccess failed! Service call error");
	}
};
com.art.myGalleries.commands.ApplicationCommand.prototype.getWallsError = function(response)
{
	 this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_WALLS_FAILED, {}, 'ajax'));
};

/**
 * Response will return entire BareWallGalleries object; we'll use the entire object on initial load
 * because by default it is empty [] array
 * @param response
 */
com.art.myGalleries.commands.ApplicationCommand.prototype.addBareWallSuccess = function(response)
{
	trace("ApplicationCaommand.addBareWallsSuccess");
	trace(response);
	if(response.Library)
	{
		if(response.Library.BareWallGalleries.length > 0)
		{
			this.command.setBareWallNamesLibrary(response.Library);
		}
			
		this.app.getUserLibraryProxy().refreshUserBareWalls(response.Library.BareWallGalleries[0]);
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.ADD_BARE_WALLS_SUCCESS, {}, 'ajax'));
	}
};
com.art.myGalleries.commands.ApplicationCommand.prototype.addBareWallError = function(response)
{
	trace("ApplicationCaommand.addBareWallsError");
	trace(response);
	//this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_WALLS_FAILED, {}, 'ajax'));
};
com.art.myGalleries.commands.ApplicationCommand.prototype.getUserLibrarySuccess = function(response)
{
	if(response.Library)
	{
		trace("response.Library == true");
		
		//only execute if we have bareWalls
		if(response.Library.BareWallGalleries.length > 0)
			this.command.setBareWallNamesLibrary(response.Library);
		
		this.app.getUserLibraryProxy().userLibraryObject = response.Library;
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_USER_LIBRARY_SUCCESS, {}, 'ajax'));
	}
	else
		throw new Error("ApplicationCommand.getUserLibrary failed! UserLibrary is null.");
};
com.art.myGalleries.commands.ApplicationCommand.prototype.getUserLibraryError = function(response)
{
	trace("ApplicationCaommand.getUserLibraryError");
	trace(response);
	//this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_WALLS_FAILED, {}, 'ajax'));
};

com.art.myGalleries.commands.ApplicationCommand.prototype.updateBareWallSuccess = function(response)
{
	trace("updateBareWallSuccess");
	if(response != undefined)
	{
		for(var i=0; i < this.app.getUserLibraryProxy().userLibraryObject.BareWallGalleries[0].BareWalls.length;i++)
		{
			var w = this.app.getUserLibraryProxy().userLibraryObject.BareWallGalleries[0].BareWalls[i];
			if(w.BareWallId == response.Library.BareWalls[0].BareWallId)
			{
				this.command.setBareWallName(response.Library.BareWalls[0])
				this.app.getUserLibraryProxy().userLibraryObject.BareWallGalleries[0].BareWalls[i] = response.Library.BareWalls[0];
				return;
			}
			
		}
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.UPDATE_BARE_WALL_SUCCESS));
	}
	else
	{
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.UPDATE_BARE_WALL_ERROR));
	}

};
com.art.myGalleries.commands.ApplicationCommand.prototype.updateBareWallError = function(response)
{
	
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.UPDATE_BARE_WALL_ERROR));
};
com.art.myGalleries.commands.ApplicationCommand.prototype.shareWallSuccess = function(response)
{
	if(response.Library.Galleries[0] == undefined)
		throw new Error("ApplicationCommand.shareWallSuccess failed! Galleries is undefined.");
	trace("ApplicationCommand.shareWallSuccess response: ");
	trace(response);
	var selectedGallery = this.app.getModel().environment.selectedGalleryID;
	var rvo = new com.art.myGalleries.vos.ShareRequestVO();
	rvo.viewMode 		= this.app.constants.ROOM_VIEW;
	//rvo.shareType		= _this.shareType == "shareEmail" ? _this.app.constants.EMAIL : _this.app.constants.FACEBOOK;
	rvo.title			= this.app.getModel().cacheByGalleryList[selectedGallery].Name;
	rvo.additionalArgs  = this.app.getModel().cacheByGalleryList[selectedGallery].ItemCount;
  
	rvo.imageURL		= response.SharedItemImageURL.MediumImage.HttpImageURL;
	var hexColor		= this.app.getUserLibraryProxy().selectedWallName.indexOf("hex") > -1 ? "/" + this.app.getUserLibraryProxy().selectedWallName : "";
	rvo.galleryURL 		= "http://" + window.location.host + response.Library.Galleries[0].VanityURL+"?viewmode="+this.app.constants.ROOM_VIEW+"/"+response.Library.Galleries[0].Walls[0].WallId+hexColor;
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.SHARE_ACTION_SUCCESS,{rvo:rvo}));
};
com.art.myGalleries.commands.ApplicationCommand.prototype.getWallByIdSuccess = function(response)
{
	trace("getWallByIdSuccess initialLoadComplete:"+this.app.getUserLibraryProxy().initialLoadComplete);
	trace(response);
	if(response.Library)
	{
		this.app.getUserLibraryProxy().wallsObject = response.Library.Galleries[0].Walls;
		this.app.getUserLibraryProxy().flatten(response.Library.Galleries[0].Walls); //for quick lookup to updateWalls
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_WALL_BY_ID_SUCCESS, {}, 'ajax'));
	}
};
com.art.myGalleries.commands.ApplicationCommand.prototype.getWallByIdError = function(response)
{
	throw new Error("ApplicationCommand.getWallByIdError bad response.");
};
com.art.myGalleries.commands.ApplicationCommand.prototype.getUserLibraryByProfileKeySuccess = function(response)
{
	trace("getUserLibraryByProfileKeySuccess");
	trace(response);
	if(response.Library)
	{
		//only execute if we have bareWalls
		if(response.Library.BareWallGalleries.length > 0)
			this.command.setBareWallNamesLibrary(response.Library);
		
		this.command.setBareWallNames(response.Library);
		
		this.app.getUserLibraryProxy().userLibraryObject = response.Library;
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_USER_LIBRARY_BY_PROFILE_SUCCESS, {}, 'ajax'));
	}
};
com.art.myGalleries.commands.ApplicationCommand.prototype.getUserLibraryByProfileKeyError = function(response)
{
	throw new Error("ApplicationCommand.getUserLibraryByProfileKeyError bad response.");
};
//fixing iphone issue
com.art.myGalleries.commands.ApplicationCommand.prototype.setBareWallNamesLibrary = function(library)
{
	trace("setBareWallNamesLibrary");
	if(library.BareWallGalleries == undefined || library.BareWallGalleries[0] == undefined || library.BareWallGalleries[0].BareWalls == undefined )
		throw new Error("ApplicationCommand.setBareWallNames failed! BareWallGalleries is undefined.");
	var bareWalls = library.BareWallGalleries[0].BareWalls;
	this.setBareWallNames(bareWalls);
};

/**
 * Input Array of user bareWalls (upload walls)
 * @param bareWalls
 */
com.art.myGalleries.commands.ApplicationCommand.prototype.setBareWallNames = function(bareWalls)
{
	trace("--setBareWallNames");
	for(var i=0; i < bareWalls.length; i++)
	{
		this.setBareWallName(bareWalls[i]);
	}
};
/**
 * update single bareWall object
 * @param bareWall
 */
com.art.myGalleries.commands.ApplicationCommand.prototype.setBareWallName = function(bareWall)
{
	trace("----setBareWallName");
	trace(bareWall);
	if(bareWall.Name == undefined)
		throw new Error("ApplicationCommand.setBareWallName failed! Name property is undefined.");
	
	//preserve older walls that are NOT IPhone uploaded; they'll have prefix, otherwise replace
	if(bareWall.Name.indexOf(this.app.getUserLibraryProxy().userBareWallNamePrefix) == -1)
		bareWall.Name = this.app.getUserLibraryProxy().userBareWallNamePrefix+bareWall.BareWallId;
	trace("-----bareWall.Name: "+bareWall.Name)
};

com.art.myGalleries.commands.ApplicationCommand.prototype.getFrameIdForDFESuccess = function(response)
{
	//Send the notification as success.	
	//Checking response lenght to be > 1 for cases where response is 0
	if(response != null && response.trim().length > 1)
	{
		var apNum = this.app.getModel().cacheByGalleryItemList[this.app.getModel().selectedItemId].APNum;
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_FRAME_ID_SUCCESS,{frameid:response, apNum:apNum}));
	}
	else
	{
		this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_FRAME_ID_FAILED, {}));
	}
};

com.art.myGalleries.commands.ApplicationCommand.prototype.getFrameIdForDFEError = function(response)
{
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_FRAME_ID_FAILED, {}));
};