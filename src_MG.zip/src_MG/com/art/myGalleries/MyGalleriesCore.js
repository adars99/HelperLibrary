/**
 * @author Angelo Calub
 * @version 1.0f
 * @classDescription Central Application Core
 * @class MyGalleriesCore
 */
var MyGalleriesCore = (function()
{
	var model			= {};
	var userLibrary		= {};
	var serviceProvider = {};
	var templateEngine 	= {};
	var subscribers		= {};
	var environment 	= {};
	var ga				= {};
	var ec				= {};	
	var version			= "@VERSION@";
	var intervalID;
	

	var events = {
			STARTUP:'startup',
            UPDATE_BACKGROUND_COLOR:'updateBackgroundColor',
            CHANGE_VIEWMODE:'changeViewMode',
            GET_ALL_GALLERY_ITEMS:'getAllGalleryItems',
            GET_ALL_GALLERY_ITEMS_SUCCESS:'getAllGalleryItemsSuccess',
            GET_ALL_GALLERY_ITEMS_FAILED:'getAllGalleryItemsFailed',
            UPDATE_GALLERY_TITLE_DESC:'updateTitleDesc',
            UPDATE_GALLERY_TITLE_DESC_SUCCESS:'updateTitleDescSuccess',
            UPDATE_GALLERY_TITLE_DESC_FAILED:'updateTitleDescFailure',
            ADD_GALLERY_TITLE_DESC:'addTitleDesc',
            ADD_GALLERY_TITLE_DESC_SUCCESS:'addTitleDescSuccess',
            ADD_GALLERY_TITLE_DESC_FAILED:'addTitleDescFailure',            
            GALLERY_ITEM_SORT:"galleryItemsSort",
            GALLERY_ITEM_SORT_SUCCESS:"galleryItemsSortSuccess",
            GALLERY_ITEM_SORT_FAILED:"galleryItemsSortFailed",
            GET_SYSTEM_LIBRARY:"getSystemLibrary",
            GET_SYSTEM_LIBRARY_SUCCESS:"getSystemLibrarySuccess",
            GET_SYSTEM_LIBRARY_FAILED:"getSystemLibraryFailed",
            GET_USER_LIBRARY:"getUserLibrary",
            GET_USER_LIBRARY_SUCCESS:"getUserLibrarySuccess",
            GET_USER_LIBRARY_FAILED:"getUserLibraryFailed",
            ADD_ITEM_TO_EXISTING_GALLERY:"addItemToExistingGallery",
            ADD_ITEM_TO_EXISTING_GALLERY_SUCCESS:"addItemToExistingGallerySuccess",
            ADD_ITEM_TO_EXISTING_GALLERY_FALIED:"addItemToExistingGalleryFailed",
            MOVE_ADD_ITEM_TO_EXISTING_GALLERY:"moveAddItemToExistingGallery",
            MOVE_ADD_ITEM_TO_EXISTING_GALLERY_SUCCESS:"moveAddItemToExistingGallerySuccess",
            MOVE_ADD_ITEM_TO_EXISTING_GALLERY_FALIED: "moveAddItemToExistingGalleryFailed",
            MOVE_ADD_ITEM_TO_NEW_GALLERY: "moveAddItemToNewGallery",
            MOVE_ADD_ITEM_TO_NEW_GALLERY_SUCCESS: "moveAddItemToNewGallerySuccess",
            MOVE_ADD_ITEM_TO_NEW_GALLERY_FALIED: "moveAddItemToNewGalleryFailed",
            ADD_ITEM_TO_EXISTING_GALLERY_EXT:"addItemToExistingGalleryExt",
            GET_ALL_GALLERIES:'getAllGalleries',
            GET_ALL_GALLERIES_SUCCESS:'getAllGalleriesSuccess',
            GET_ALL_GALLERIES_FAILED:'getAllGalleriesFailed',
            ADD_ITEM_TO_NEW_GALLERY: "AddItemToNewGallery",
            ADD_ITEM_TO_NEW_GALLERY_SUCCESS: "AddItemToNewGallerySuccess",
            ADD_ITEM_TO_NEW_GALLERY_FALIED: "AddItemToNewGalleryFailed",
            SHOW_LOGINMODAL:"showLoginModal",
            REGISTER_ACCOUNT : "registerMyGalleriesAccount",
            REGISTER_ACCOUNT_SUCCESS : "registerMyGalleriesAccountSuccess",
            REGISTER_ACCOUNT_FAILED : "registerMyGalleriesAccountFailed",
            LOGIN_ACCOUNT : "loginMyGalleriesAccount",
            LOGIN_ACCOUNT_SUCCESS : "loginMyGalleriesAccountSuccess",
            LOGIN_ACCOUNT_FAILED : "loginMyGalleriesAccountFailed",
            LOGOUT_MYGALLERY :"logoutMyGalleriesAccount",
            LOGOUT_MYGALLERY_SUCCESS : "logoutMyGalleriesAccountSuccess",
            LOGOUT_MYGALLERY_FAILED : "logoutMyGalleriesAccountFailed",
            UPDATE_DLE:"updateDLE",
            UPDATE_WALL_ITEMS: "updateWallItems",
            UPDATE_WALL_ITEMS_SUCCESS: "updateWallItemsSuccess",
            UPDATE_WALL_ITEMS_FAILED: "updateWallItemsFailed",
            CREATE_WALL: "createWall",
            CREATE_WALL_SUCCESS: "createWallSuccess",
            CREATE_WALL_FAILED: "createWallFailed",
            GET_WALLS:"getWalls",
            GET_WALLS_SUCCESS:"getWallsSuccess",
            GET_WALLS_FAILED:"getWallsFailed",
            ADD_SIMILAR_ARTIST_ITEM : "addSimilarArtistItem",
            ADD_SIMILAR_ARTIST_ITEM_SUCCESS : "addSimilarArtistItemSuccess",
            ADD_SIMILAR_ARTIST_ITEM_FAILED : "addSimilarArtistItemFailed",
            SHORTEN_ROOM_VIEW_URL:"shortenRoomViewURL",
            SHORTEN_ROOM_VIEW_URL_SUCCESS:"shortenRoomViewURLSuccess",
            SHORTEN_ROOM_VIEW_URL_FAILED:"shortenRoomViewURLFailed",
            INITIAL_LOAD:"initialLoad",
            SHARE_REQUEST:"shareRequest",
            SHARE_REQUEST_SUCCESS:"shareRequestSuccess",
            SHARE_REQUEST_FAILED:"shareRequestFailed",
            DELETE_GALLERY_ITEM:"deleteGalleryItem",
            DELETE_GALLERY_ITEM_FAILED:"deleteGalleryItemFailed",
            DELETE_GALLERY_ITEM_SUCCESS:"deleteGalleryItemSuccess",            
            ADD_BARE_WALLS:"addBareWalls",
            ADD_BARE_WALLS_SUCCESS:"addBareWallsSuccess",
            ADD_BARE_WALLS_ERROR:"addBareWallsError",
            SHARE_WALL:"shareWall",
            SHARE_ACTION_SUCCESS:"shareActionSuccess",
            UPDATE_BARE_WALL:"updateBareWall",
            UPDATE_BARE_WALL_SUCCESS:"updateBareWallSuccess",
            UPDATE_BARE_WALL_ERROR:"updateBareWallError",
            ADD_BARE_WALLS_ERROR:"addBareWallsError",
            SHOW_CREATE_GALLERY_MODAL:"SHOW_CREATE_GALLERY_MODAL",
            DELETE_GALLERY_ITEM_DP:"detailPageDeleteGalleryItem",
            DELETE_GALLERY_ITEM_DP_FAILED:"detailPageDeleteGalleryItemFailed",
            DELETE_GALLERY_ITEM_DP_SUCCESS:"detailPageDeleteGalleryItemSuccess",
            SHOW_LOGIN_OR_JOIN:"showloginorjoin",
            UPDATE_PRIVACY_SETTINGS:"updateprivacysettings",
            GET_FRAME_SKU:"getFrameSku",
            GET_FRAME_SKU_SUCCESS:"getFrameSkuSuccess",
            GET_FRAME_SKU_FAILED:"getFrameSkuError",
            GET_WALL_BY_ID:"getWallById",
            GET_WALL_BY_ID_SUCCESS:"getWallByIdSuccess",
            GET_WALL_BY_ID_ERROR:"getWallByIdError",
            GET_USER_LIBRARY_BY_PROFILE:"getUserLibraryByProfile",
            GET_USER_LIBRARY_BY_PROFILE_SUCCESS:"getUserLibraryByProfileSuccess",
            GET_USER_LIBRARY_BY_PROFILE_ERROR:"getUserLibraryByProfileError",
            LOGIN_FACEBOOK_MYGALLERY:"loginWithFacebook",
            LOGIN_FACEBOOK_MYGALLERY_SUCCESS:"loginWithFacebookSuccess",
            LOGIN_FACEBOOK_MYGALLERY_FAILED:"loginWithFacebookFailed",
            ROOM_VIEW_SWF_LOADED:"roomViewSWFLoaded",
            MYACCOUNT_WISHLIST:"myAccountWishList",
            GET_FRAME_ID:"getFrameID",
            GET_FRAME_ID_SUCCESS:"getFrameIDSuccess",
            GET_FRAME_ID_FAILED:"getFrameIDFailed"
			};
	var constants 		= {
			GALLERY_HOME:'galleryHome',
			GRID_VIEW:'gridView',
			DETAIL_VIEW:'detailView',
			SLIDESHOW:'slideshow',
			ROOM_VIEW:'roomView',
			DEFAULT:'default',
			FACEBOOK:'facebook',
			EMAIL:'email',			
			ANONYMOUS:"1",
			OWNER:"200",
			VIEW:"50",
			EDIT:"100",
			SIGNUP:"SignUp",
			PRODUCT_PAGE:"productPage",
			GALLERY_PAGE:"galleryPage",
			LOGIN:"Login",
			DFEIMAGEMAXW:"200",
			DFEIMAGEMAXH:"200",
			DFEUNITOFMEASUREINCH:"in",
			DFEUNITOFMEASURECM:"cm"
	};
	/*
	 * Public API to Application
	 */
	var interestedSubscribers = {};
	return {
		"getVersion":function(){return version;},
		"events":events,
		"constants":constants,
		"getUseCaseResultsByName":function(name)
		{
			return applicationFlowDebugger.getUseCase(name);
		},
		"registerModule":function(module)
		{
			this.registerSubscriber(module);
		},
		"registerSubscriber":function(observer)
		{
			if(observer.NAME == undefined)
				throw new Error("MyGalleries.registerSubscriber failed! observer.NAME is undefined.");
			
			var arr = observer.listNotificationInterests();
			for(var i=0; i < arr.length; i++)
			{
				var noteName = arr[i];
				if(interestedSubscribers[noteName] == undefined)
					interestedSubscribers[noteName] = {};
					
				interestedSubscribers[noteName][observer.NAME] = true;
			}
			subscribers[observer.NAME] = observer;
		},
		"getInterestedSubscribers":function(){ return interestedSubscribers; },
		"removeModule":function(name)
		{
			var tmp = {};
			for(var m in subscribers)
			{
				if(m != name)
					tmp[m] = subscribers[m];
			}
			subscribers = tmp;
		},
		"sendNotification":function(note)
		{
			trace("note.name: "+note.name);
			for(var m in interestedSubscribers[note.name])
			{
				if(subscribers[m] != undefined)
					subscribers[m].handleNotification(note);
			}
		},
		"clearAll":function()
		{
			subscribers = {};
			interestedSubscribers = {};
		},
		"startAll":function()
		{
			for(var subscriber in subscribers)
			{
				trace("module.init: "+subscriber);
				subscribers[subscriber].init();
			}
		},
		"startAllByViewMode":function(viewmode)
		{
			for(var subscriber in subscribers)
			{
				subscribers[subscriber].init(viewmode);
			}
		},
		"startModule":function(name,obj)
		{
			if(obj == undefined)
			{
				subscribers[name].init();
			}
			else
			{
				subscribers[name].init(obj);
			}
		},
		"getSubscriber":function(name)
		{
			return subscribers[name];
		},
		"getSubscribers":function(name)
		{
			return subscribers;
		},
		"getModule":function(name)
		{
			return subscribers[name];
		},
		"setEnvironment":function(obj)
		{
			environment = obj;
		},
		"getEnvironment":function()
		{
			return environment;
		},
		"addToEnvironment":function(key,value)
		{
			environment[key] = value;
		},
		"getModel":function(){ return model; },
		"getUserLibraryProxy":function(){ return userLibrary; },
		"getServiceProvider":function(){ return serviceProvider; },
		"init":function(envObj,viewMode)
		{
			environment = envObj;
			model		= new com.art.myGalleries.proxies.ApplicationProxy(envObj,viewMode);
			userLibrary	= new com.art.myGalleries.proxies.UserLibraryProxy(envObj);
			
		},
		"updateWallFromDLE":function(wallItemInfo)
		{
			trace("MyGalleriesCore.updateWallFromDLE");
			trace(wallItemInfo);
			
			/*
			 * FROM FLASH on add or move
			 *  {itemGalleryItemID:n,centerXPos:centerXPos,centerYPos:centerYPos,scaleValueOfImage:scaleValue}
			 */
			
			//add to wallItemsMap
			//if(this.getUserLibraryProxy().initialLoadComplete)
			trace("--wallItemInfo.initialLoad: "+wallItemInfo.initialLoad);
			if(!wallItemInfo.initialLoad)
			{
				trace(wallItemInfo.itemGalleryItemID);
				trace(wallItemInfo);
				trace("--wallItemsMap: "+wallItemInfo.itemGalleryItemID);
				
				
				//if not already added
				this.getUserLibraryProxy().wallItemsMap[wallItemInfo.itemGalleryItemID] = wallItemInfo;
				
				//shared Room views will NOT have write permissions
				trace("hasWritePermissions: "+this.getModel().hasWritePermissions());
				if(!this.getModel().hasWritePermissions())
				{
					this.getUserLibraryProxy().tempWallItems[wallItemInfo.itemGalleryItemID] = wallItemInfo;
					com.art.core.utils.Flash.getMovie("roomViewFlashTarget").stopCursor();
					return;
				}
				else
				{
					var items = this.getUserLibraryProxy().getItemsForUpdate();
					this.getModel().updateFromDLE = true;
					this.sendNotification(new com.art.core.utils.Note(this.events.UPDATE_WALL_ITEMS,items));
				}
			}
			else
			{
				//reset initialLoad to false
				this.getUserLibraryProxy().getCheckBoxByItemGalleryItemID(wallItemInfo.itemGalleryItemID).value.initialLoad = false;
			}
			
		},
		"createWallFromDLE":function(wallName)
		{
			/*
			 * this is called everytime a room is changed
			 * 
			 * */
			this.getModel().updateFromDLE = true;
			
			trace("MyGalleriesCore.createWallFromDLE "+wallName);
			//FOR EMPTY WALLS: do not create new walls per color only size(Extra Large,Large,etc.)
			var wallName = wallName.indexOf('hex') > -1 ? this.getUserLibraryProxy().selectedWallGalleryName : wallName;
			trace("wallName: "+wallName);
			
			
			/**
			 * if this is NOT the first time the application started
			 */
			if(!this.getUserLibraryProxy().initialLoadComplete)
			{
				trace("initialLoad");
				this.getUserLibraryProxy().initialLoadComplete = true;
				
				if(!this.getUserLibraryProxy().wallExists())
				{
					trace("createWall this.getModel().hasWritePermissions():"+this.getModel().hasWritePermissions());
					if(!this.getModel().hasWritePermissions())
						return;
					else
					{
						trace("has permissions");
						this.sendNotification(new com.art.core.utils.Note(this.events.CREATE_WALL));
					}
				}
				else
				{
					//proceed to load items for existing wall
					this.sendNotification(new com.art.core.utils.Note(this.events.INITIAL_LOAD));
				}
			}
			else
			{
				//create a new wall if it doesn't exist; async not to block return
				if(!this.getUserLibraryProxy().wallExists())
				{
					trace("createWall");
					if(!this.getModel().hasWritePermissions())
						return;
					
					this.sendNotification(new com.art.core.utils.Note(this.events.CREATE_WALL));
				}
				else
				{
					trace("update wall with items currently on wall");
					trace("-only if this.getModel().hasWritePermissions()==true "+this.getModel().hasWritePermissions());
					if(this.getModel().hasWritePermissions())
					{
						items = this.getUserLibraryProxy().getItemsForUpdate();
						this.sendNotification(new com.art.core.utils.Note(this.events.UPDATE_WALL_ITEMS,items));
					}
				}
			}
		},
		"gaTrackFromDLE":function(wallName)
		{
			//if wallName == undefined coming from bottom thumbnail clicks;
			//if wallName != undefined coming from lefthand menu click
			//GA track breaks ExternalInterface SYNC call; ensure it's at END of your ASYNC call
			if(this.getUserLibraryProxy().initialLoadComplete)
			{
				mygalleriesGA.trackEventWithCategory("Room", this.getUserLibraryProxy().getSelectedWallGAEventName(wallName));
			}
		},
		"allWallItemsResizeComplete":function()
		{
			//if wall already exists we can call updateImagePositions
			//else let "CREATE_WALL" flow handle the updateImagePositions call
			if(this.getUserLibraryProxy().wallExists())
			{
				var items = this.getUserLibraryProxy().getItemsForUpdate();
				com.art.core.utils.Flash.getMovie("roomViewFlashTarget").updateImagePositions(items);
			}
		},
		"swfReadyFromDLE":function()
		{
			//sent from dle
			this.getModel().dleIsLoaded = true;
			trace("swfReadlyFromDLE dleIsLoaded:"+this.getModel().dleIsLoaded);
			trace("galleryItemsLoaded: "+this.getModel().galleryItemsLoaded);
			//if righthand tray loads BEFORE swf (see RoomView if tray loads AFTER swf)
			if(this.getModel().galleryItemsLoaded)
				this.sendNotification(new com.art.core.utils.Note(this.events.ROOM_VIEW_SWF_LOADED));
		},
		"getImageObjectFromDLE":function(wallName)
		{
			//large background image in RoomView
			trace("MyGalleriesCore.getImageObjectFromDLE: "+wallName);
			this.getUserLibraryProxy().selectedWallName = wallName;
			var obj = this.getUserLibraryProxy().getImageObject(wallName);
			trace(obj);
			trace("initialLoadComplete: "+this.getUserLibraryProxy().initialLoadComplete);
			
			return obj;
		},
		"setSelectedWallGalleryIndexAndNameFromDLE":function(wallGalleryName)
		{
			trace("MyGalleriesCore.setSelectedWallGalleryIndexAndNameFromDLE: "+wallGalleryName);
			
			
			
			trace("HERE");
			this.getUserLibraryProxy().selectedWallGalleryName = wallGalleryName.indexOf(com.art.myGalleries.proxies.UserLibraryProxy.EMPTY_WALL_DELIMITER) > -1 ? wallGalleryName.split(com.art.myGalleries.proxies.UserLibraryProxy.EMPTY_WALL_DELIMITER)[1] : wallGalleryName;
			trace("-this.getUserLibraryProxy().selectedWallGalleryName: "+this.getUserLibraryProxy().selectedWallGalleryName);
			
			//Check for emptyRooms; split Roomsbysize@@@Medium search on Roomsbysize
			var name = wallGalleryName.indexOf(com.art.myGalleries.proxies.UserLibraryProxy.EMPTY_WALL_DELIMITER) > -1 ? wallGalleryName.split(com.art.myGalleries.proxies.UserLibraryProxy.EMPTY_WALL_DELIMITER)[0] : wallGalleryName;
			trace("name: "+name);
			//skip if user walls
			if(this.getUserLibraryProxy().selectedWallGalleryName != "myWallsBrowseBtn")
			{
				var wallGalleries = this.getUserLibraryProxy().systemLibraryObject.BareWallGalleries;
				for(var i = 0; i < wallGalleries.length; i++)
				{
					trace("--wallGalleries[i].Name: "+wallGalleries[i].Name+":"+name);
					if(wallGalleries[i].Name == name)
					{
						this.getUserLibraryProxy().selectedWallGalleryIndex = i;
						return;
					}
				}
			}
			else
			{
				//Personal Walls
				//else search Personal on startup only
				trace("search Personal walls");
				var personalWallGalleries =  this.getUserLibraryProxy().userLibraryObject.BareWallGalleries;
				for(var z=0; z < personalWallGalleries.length; z++)
				{
					trace("--personalWallGalleries[z].Name:  "+personalWallGalleries[z].Name);
					if(personalWallGalleries[z].Name == this.getUserLibraryProxy().selectedWallGalleryName)
					{
						this.getUserLibraryProxy().selectedWallGalleryIndex = z;
						
						trace("this.getUserLibraryProxy().selectedWallGalleryIndex: "+this.getUserLibraryProxy().selectedWallGalleryIndex);
						return;
					}
				}
			}

		},
		"handleSignInFromDLE":function(key)
		{
			trace("handleSignInFromDLE: "+key);
			if(key != "upload" && key != "ruler")
				this.sendNotification(new com.art.core.utils.Note(this.events.SHOW_LOGINMODAL,{'signInMode':key}));
		},
		"handleCallibrationFromDLE":function(obj)
		{
			trace('handleCallibrationFromDLE ');
			this.sendNotification(new com.art.core.utils.Note(this.events.UPDATE_BARE_WALL,obj));
		},
		"createBareWallFromDLE":function(obj)
		{
			//triggered when user uploads personal wall in DLE
			trace("createBareWallFromDLE obj: canUpdate: "+this.getModel().hasWritePermissions());
			trace(obj);
			if(this.getModel().hasWritePermissions())
				this.sendNotification(new com.art.core.utils.Note(this.events.ADD_BARE_WALLS,obj));
		},
		"externalAddToGallery":function(page)
		{
			var _this = this;
			//prevent rapid clicking from breaking
			clearTimeout(intervalID);
			intervalID = setTimeout(function(){
				if(_this.getModel().selectedImageObject != null)
				{
					trace("-this.events:"+_this.events.ADD_ITEM_TO_EXISTING_GALLERY_EXT);
					switch(page)
					{
					case _this.constants.PRODUCT_PAGE:
						mygalleriesGA.trackEventWithCategory('Save to Gallery','Product Page Add - Clicked');
						break;
					case _this.constants.GALLERY_PAGE:
						mygalleriesGA.trackEventWithCategory('Save to Gallery','Gallery Page Add - Clicked');
						break;
					}
					_this.sendNotification(new com.art.core.utils.Note(_this.events.ADD_ITEM_TO_EXISTING_GALLERY_EXT));
				}
			},300);
			
		}
		
	};
})();