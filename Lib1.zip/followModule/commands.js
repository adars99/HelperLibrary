followModule.addFollow = function(accountId) {
	// check anonymous
	var c = new com.art.core.cookie.Cookie();
	var anonymous = c.getCookieDictionary('ap','accounttype') == MyGalleriesCore.constants.ANONYMOUS;
	
	if (anonymous) {
		followModule.login();
		return;
	}
	
	DAL.profileAddFollow({
		accountId:accountId,
		onComplete:function() {
			alreadyFollowed.push(accountId);
			art.view('followModuleDR').update();
			$(document.body).removeClass('wait');
		}
	});
	$(document.body).addClass('wait');
}
followModule.removeFollow = function(accountId) {
	DAL.profileAddFollow({
		accountId:accountId,
		unfollow:true,
		onComplete:function() {
			alreadyFollowed.splice( alreadyFollowed.indexOf(accountId) , 1 );
			art.view('followModuleDR').update();
			$(document.body).removeClass('wait');
		}
	});
	$(document.body).addClass('wait');
}



followModule.login = function(options,tabOption) {
	if (!options) options = {};
	var message = options.message || ''; // message shown in login modal
	var onLogin = options.onLogin || ''; // function to be run after login success, after postback. Provide the text of the function, not an actual function.
	var redirect = options.redirect || null;
	var loginoption;
	var msg;
	if (redirect) localStorage.setItem('runOnce_redirect',redirect);
	if(tabOption=='reg'){
		loginoption = com.art.core.components.LoginModal.REGISTER;
		msg = "Please sign up to use this feature";
	}
	else
	{
		loginoption = com.art.core.components.LoginModal.LOGIN;
		msg = "Please log in to use this feature";
	}
	msg = "Please log in or sign up to use this feature";
	
	var note = new com.art.core.utils.Note(
		MyGalleriesCore.events.SHOW_GLOBAL_LOGINMODAL,
		{
		    loginOption: loginoption, message: msg
		}, { modulename: "GlobalHeader" });
	MyGalleriesCore.sendNotification(note);
    
   
};