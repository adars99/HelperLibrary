if (!utils) var utils = {};
	
utils.followBtnDisplay = function(accid) {
	return;
	if (isNullOrEmpty(accid)) {
		error('gigya > followBtnDisplay > error: account id not provided.');
		return 'none !important';
	}
	var t = "block";
	
	if(SocialCore.isLoggedIn()) {
		if (isNullOrEmpty(art.model.socialFeed.profileInfo)) return 'block';
		var data = art.model.socialFeed.profileInfo.following;
		if (!data||!data.push) {
			warn('gigya > utils > followingBtnDisplay > profile info not ready; cannot determine status of following button. (when profileInfo comes in, feed should update)');
			return 'none !important';
		}
		for (var i = 0; i < data.length; i++){
			if (!data[i].account||!data[i].account.accountId) {
				error('gigya > utils > followBtnDisplay > data error; followed user missing account ID. data item to follow.');
				info(data[i]);
			}
			if (data[i].account.accountId==accid) {
				t = "none !important;";
			}
		}
	}
	
	var cookieobject = new com.art.core.cookie.Cookie();
	if(cookieobject.getCookieDictionary('ap','accountid') == accid)
		t = "none !important;";
	
	return t;
	
};
generateUniqueId = function() {
	return guid();
	
	function s4() {
	  return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
	};

	function guid() {
	  //return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
		return s4()+'-'+s4();
	};
};

followModule.renderProductLink = function(obj) {
	if(obj != null){
		//this.trackOnclickEventWithCategory('SocialFeed-Click through the featured image', 'Click through the featured image');
		var fcsKey = "";
		if(MyGalleriesEnvironmentVariables!=undefined && MyGalleriesEnvironmentVariables.UrlPatternArray!=undefined){	
			fcsKey = MyGalleriesEnvironmentVariables.UrlPatternArray; 
		}
		if(obj.serviceInfo && obj.serviceInfo.ServiceID > 1 && !MyGalleriesCore.isa3sProductServiceUrlsUse()){
			var sku= obj.sku;         
	        var pd = sku.substring(0, sku.length - 1);
	        var sp = sku.substring(sku.length - 1, sku.length).toLowerCase();
	        var mt = "", redirecturl = "";
			if(obj.serviceInfo.ServiceID == "2"){
				mt = 1;
			}
			else if(obj.serviceInfo.ServiceID == "7") {
				mt = 2;
			}
			else if(obj.serviceInfo.ServiceID == "4") {
				mt = 3;
			}			
			url = "http://" + location.host + "/asp/mountshop/default.asp/_/mt--" + mt + "/pd--" + pd + "/sp--" + sp + "/posters.htm?PODConfigID="+obj.podConfigId;			
		}
		else {
			url = obj.itemAttributes.productPageUrl;
		}		
		url = url.replace( /&/g , '&amp;' );				
		if(!MyGalleriesCore.isa3sProductServiceUrlsUse()) {
			if(com.art.core.utils.StringUtil.isValidDomainUrl(url, fcsKey))
				return false;
			else
				return url;
		}
		else if(MyGalleriesCore.isa3sProductServiceUrlsUse()) {
			if(com.art.core.utils.StringUtil.isValidDomainUrl(url, fcsKey))
				return url;
		}
	}
}


if (!Array.prototype.indexOf) {
	Array.prototype.indexOf = function(obj, start) {
	     for (var i = (start || 0), j = this.length; i < j; i++) {
		 if (this[i] === obj) { return i; }
	     }
	     return -1;
	}
}