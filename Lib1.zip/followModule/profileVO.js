// corresponds to FeedItem.cs from API 


var ProfileVO = function(args) {
	if (!args) args = {};
	
	this.account = args.account || {};
	this.bookmarks = args.bookmarks;
	this.followedBy = args.followedBy;
	this.following = args.following;
	this.galleries = args.galleries;
	this.recentActivity = args.recentActivity;

	this.guid = generateUniqueId();
		
};

// var $c = ProfileVO;
var $c = ProfileVO;

$c.parseFromAPI = function(apiReturn) {
	if (!apiReturn||typeof(apiReturn)!='object') { error('FeedItemVO > apiReturn must be an object'); return; }
	if (!apiReturn.push) apiReturn = [ apiReturn ];
	
	// to-do: some basic smoke testing of return set
	
	
	// loop through all feed items, parse each type individually (slightly different parsing each time), add to collection
	var items = [];
	
	for (var i = 0; i < apiReturn.length; i++) {
		var obj = apiReturn[i];
		// insert basic smoke testing on obj here
				
		var args = {};
		var accountObj = obj.Account || obj.Accounts[0];
		args.account = UserVO.parseFromAPI(accountObj)[0];
		args.account.guid = generateUniqueId();

		args.galleries = {};
		if (obj.RecentActivity&&obj.RecentActivity.length>0&&obj.RecentActivity[0].GalleryItems) {
			args.galleries = {
				preview: {
					items: GalleryItemVO.parseGalleryItems(obj.RecentActivity[0].GalleryItems)
				}
			};
		} else {
			args.galleries = {
				preview: {
					items: []
				}
			};
		}

		if (obj.Following&&obj.Following.length>0) {
			args.following = ProfileVO.parseFromAPI(obj.Following);
		} else {
			args.following = [];
		}

		if (obj.Followers&&obj.Followers.length>0) {
			args.followedBy = ProfileVO.parseFromAPI(obj.Followers);
		} else {
			args.followedBy = [];
		}

		var profile = new ProfileVO(args);
		profile.guid = generateUniqueId();
		items.push(profile);
	}
	
	return items;
};
