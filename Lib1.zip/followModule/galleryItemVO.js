GalleryItemVO = function(obj) {
	if (!obj) obj = {};

    // properties
    this.galleryItemId = obj.galleryItemId || 0;
    this.type = obj.type || 1; // gallery item type, i.e. product, room, etc
    this.compositeSKU = obj.compositeSKU || '';
    this.itemNumber = obj.itemNumber || '';
    this.sku = obj.sku || '';
    this.apNum = obj.apNum || '';
    this.podConfigId = obj.podConfigId || '';
    
    if (!obj.itemAttributes) obj.itemAttributes = {}; var ia = obj.itemAttributes;
    if (!obj.itemAttributes.artist) obj.itemAttributes.artist = {}; var iaa = obj.itemAttributes.artist;
    if (!obj.itemAttributes.dimensions) obj.itemAttributes.dimensions = {}; var iad = obj.itemAttributes.dimensions;
    this.itemAttributes = {
        title: ia.title || '',
        productPageUrl: ia.productPageUrl || '',
        artist: {
            id: iaa.id || 0,
            firstName: iaa.firstName || '',
            lastName: iaa.lastName || '',
            fullName: function() {
                return this.firstName + ' ' + this.lastName;
            }
        },
        type: ia.type || '', /* product type, i.e. art print */
        canFrame: ia.canFrame || false,
        dimensions: {
            unitOfMeasure: iad.unitOfMeasure || 1, /* some sort of enum, 1 = inch */
            width: iad.width || 0,
            height: iad.height || 0,
            depth: iad.depth || 0
        },
        description: ia.description || '',
        timeToShip: ia.timeToShip || ''
    }

    if (!obj.imageInformation) obj.imageInformation = {}; var ii = obj.imageInformation;
    if (!ii.smallImage) ii.smallImage = {};
    if (!ii.mediumImage) ii.mediumImage = {};
    if (!ii.largeImage) ii.largeImage = {};
    if (!ii.zoomImage) ii.zoomImage = {};
    this.images = {
        small: {
            url: ii.smallImage.url || '',
            width: ii.smallImage.width || 0,
            height: ii.smallImage.height || 0
        },
        medium: {
            url: ii.mediumImage.url || '',
            width: ii.mediumImage.width || 0,
            height: ii.mediumImage.height || 0
        },
        large: {
            url: ii.largeImage.url || '',
            width: ii.largeImage.width || 0,
            height: ii.largeImage.height || 0
        },
        zoom: {
            url: ii.zoomImage.url || '',
            width: ii.zoomImage.width || 0,
            height: ii.zoomImage.height || 0
        }
    };
    
    if (!obj.serviceInfo) obj.serviceInfo = {};
	this.serviceInfo = {
			ServiceID:obj.serviceInfo.ServiceID || 0,
			Frame:obj.serviceInfo.Frame || '',
			CanvasMuseum:obj.serviceInfo.CanvasMuseum || '',
			CanvasGallery:obj.serviceInfo.CanvasGallery || '',
			Mounting:obj.serviceInfo.Mounting || '',
			Acrylic:obj.serviceInfo.Acrylic || '',
			PrintOnly:obj.serviceInfo.PrintOnly || '',
			PosterCalendar:obj.serviceInfo.PosterCalendar || '',
			Laminate:obj.serviceInfo.Laminate || '',
			LaminaFrame:obj.serviceInfo.LaminaFrame  || ''
	};

	this.guid = generateUniqueId();

    return;
/*
    // properties (wrong format)
    try {
        this.ItemId                     = obj.ItemGalleryItemID;
        this.ItemStatus                 = obj.ItemDetails.ItemStatus || 0;
        this.AvailableInOtherSizes      = obj.AvailableInOtherSizes || false;
        this.APNum                      = obj.ItemDetails.APNum || "";
        this.ItemDisplayedType          = obj.ItemDetails.ItemDisplayType || "";
        this.Imageid                    = obj.ItemDetails.ImageId || "";
        
        if(obj.FrameSku && obj.FrameSku!="")
        this.FrameSku                   = obj.FrameSku || "";
        
        this.Sku                        = obj.ItemDetails.Sku || "";        
       
        this.Title                      = obj.ItemDetails.Title || "";
        this.ArtistName                 = obj.ItemDetails.Artist.FirstName || "";
        this.ArtistUrl                  = "";
        this.ImageUrl                   = obj.ItemDetails.ImageInformation.LargeImage.HttpImageURL;
        this.Height                     = obj.ItemDetails.ImageInformation.LargeImage.Dimensions.Height;
        this.Width                      = obj.ItemDetails.ImageInformation.LargeImage.Dimensions.Width;
        this.PhysicalDimensionHeight    = obj.ItemDetails.PhysicalDimensions.Height;
        this.PhysicalDimensionWidth     = obj.ItemDetails.PhysicalDimensions.Width;
        this.Price                      = obj.ItemDetails.ItemPrice.DisplayPrice;
        this.DisplayMSRP                = obj.ItemDetails.ItemPrice.DisplayMSRP;
        this.MarkDownPrice              = obj.ItemDetails.ItemPrice.MarkDownPrice;
        this.ShowMarkDownPrice          = obj.ItemDetails.ItemPrice.ShowMarkDownPrice;
        this.CanFrame                   = obj.ItemDetails.ServiceFlags.CanFrame || false;
        this.AppendShadow               = obj.ItemDetails.AppendShadow;
        this.DateCreated                = obj.DateCreated;
        this.DateCreated                = obj.DateUpdated;
        this.ZoomUrl                    = "";
        this.CropperUrl                 = "";
        this.AddToCartUrl               = "";//obj.ItemDetails.AdditionalUrls.AddtoCartUrl || "";
        this.ProductPageUrl             = "";//obj.ItemDetails.AdditionalUrls.ProductPageUrl || "";
        this.PODConfigID                = obj.PODConfigID || 0;
        this.VanityURL                  = obj.VanityURL || "";
        this.ItemDetails                = obj.ItemDetails || null;
        if(obj.SpecialHandlingID!=null && obj.SpecialHandlingID != undefined)
        this.SpecialHandlingID          = obj.SpecialHandlingID;
        

    } catch(e) {
        error('gigya > GalleryItemVO > an error occurred while instantiating a GalleryItemVO using the *old* method. The old method is deprecated and should not be used.');
    }
	*/
	
};


GalleryItemVO.parseFromAPI = function(apiReturn) {
	// returns a GalleryVO from the JSON return set from the Gallery Service
	// to be implemented
	var items = [];
	if(apiReturn != null)
	{
		if (!apiReturn.push) apiReturn = [ apiReturn ];
		
		
		for (var i = 0; i < apiReturn.length; i++) {
			var obj = apiReturn[i];
			items.push( new GalleryItemVO(obj) );
		}
	}	
	return items;
};

GalleryItemVO.parseGalleryItems = function(arr) {
    // parses one or more Art.Data.Contract.API.GalleryItem objects
    if (!arr) return [];
    if (!arr.push) arr = [ arr ];
    var ret = [];

    for (var i = 0; i < arr.length; i++){
        var obj = arr[i];
        var args = {};

        args.galleryItemId = obj.GalleryItemId;
        if (obj.Item) {
            var item = obj.Item;
            args.type = item.ItemType;
            args.compositeSKU = item.CompositeSKU;
            args.itemNumber = item.ItemNumber;
            
        	var apnum = '', podConfigId = 0;
    		if(!item.ItemNumber){
    			//warn('apNum > parse error > APNUM not found in service return set.');
    		}
    		else {
    			var temp = item.ItemNumber;
    			if(temp.indexOf("-") > -1){
    				temp = temp.split("-");
    				apnum = temp[0];
    				podConfigId = temp[1];
    			}
    		}
    		
    		args.apNum = apnum;
    		args.podConfigId = podConfigId;
    		
            var sku = '';
    		if(!item.Sku){
    			//warn('Sku > parse error > Sku not found in service return set.');
    		}
    		else {
    			var temp = item.Sku;
    			temp = temp.split("-");
    			sku = temp[0];
    		}
    		args.sku =sku;
            
            
            
            if (item.ItemAttributes) {
                var a = item.ItemAttributes;
                var ar = a.Artist || {};
                var pd = a.PhysicalDimensions || {};

                var pUrl = a.ProductPageUrl;
                
                if(pUrl.indexOf("http://")> -1){
                	var tUrlDomain =  com.art.core.utils.BrowserUtil.getHostName(pUrl);
                	pUrl = pUrl.replace(tUrlDomain, "http://"+location.host);
                }
                
                args.itemAttributes = {
                    title: a.Title,
                    productPageUrl: pUrl,
                    artist: {
                        id: ar.ArtistId,
                        firstName: ar.FirstName,
                        lastName: ar.LastName
                    },
                    type: a.Type,
                    canFrame: a.CanFrame,
                    dimensions: {
                        unitOfMeasure: pd.UnitOfMeasure,
                        width: pd.Width,
                        height: pd.Height,
                        depth: pd.Depth
                    },
                    description: a.Description,
                    timeToShip: a.TimeToShip
                };                
            }
            if (item.ImageInformation) {
                var ii = item.ImageInformation;
                var iis = ii.SmallImage || {}; var iisd = iis.Dimensions || {};
                var iim = ii.MediumImage || {}; var iimd = iim.Dimensions || {};
                var iil = ii.LargeImage || {}; var iild = iil.Dimensions || {};
                var iiz = ii.ZoomImage || {}; var iizd = iiz.Dimensions || {};
                args.imageInformation = {
                     smallImage: {
                        url: iis.HttpImageURL,
                        width: iisd.Width,
                        height: iisd.Height
                    },
                    mediumImage: {
                        url: iim.HttpImageURL,
                        width: iimd.Width,
                        height: iimd.Height
                    },
                    largeImage: {
                        url: iil.HttpImageURL,
                        width: iild.Width,
                        height: iild.Height
                    },
                    zoomImage: {
                        url: iiz.HttpImageURL,
                        width: iizd.Width,
                        height: iizd.Height
                    }
                };
            }
            
            var serviceId = 0;
    		if(!item.Service || !item.Service.ServiceID){
    			//warn('ProductVo > parse error > Service Id not found in service return set.');
    		}	
    		else {	
    			serviceId = item.Service.ServiceID;
    		}
    		
    		var Frame = '', CanvasMuseum='', CanvasGallery = '', Mounting='', Acrylic='', PrintOnly= '', PosterCalendar= '', Lamination = '';
    		
    		
    		if(serviceId == 1 && item.Service.Frame !=null && item.Service.Frame.Image != null){
    			Frame = item.Service.Frame.Image.HttpImageURL;
    		}
    		if(serviceId == 4 && item.Service.CanvasMuseum !=null && item.Service.CanvasMuseum.Image != null) {
    			CanvasMuseum = item.Service.CanvasMuseum.Image.HttpImageURL;
    		}
    		if(serviceId == 5 && item.Service.CanvasGallery !=null && item.Service.CanvasGallery.Image != null) {
    			CanvasGallery = item.Service.CanvasGallery.Image.HttpImageURL;
    		}
    		if(serviceId == 2 && item.Service.Mounting !=null && item.Service.Mounting.Image != null) {
    			Mounting = item.Service.Mounting.Image.HttpImageURL;
    		}
    		if(serviceId == 3 && item.Service.Acrylic !=null && item.Service.Acrylic.Image != null) {
    			Acrylic = item.Service.Acrylic.Image.HttpImageURL;
    		}
    		if(serviceId == 6 && item.Service.PrintOnly !=null && item.Service.PrintOnly.Image != null) {
    			PrintOnly = item.Service.PrintOnly.Image.HttpImageURL;
    		}
    		if(serviceId == 9 && item.Service.PosterCalendar !=null && item.Service.PosterCalendar.Image != null) {
    			PosterCalendar = item.Service.PosterCalendar.Image.HttpImageURL;
    		}
    		if(serviceId == 7 && item.Service.Lamination !=null && item.Service.Lamination.Image != null) {
    			Lamination = item.Service.Lamination.Image.HttpImageURL;
    		}
    		
    		args.serviceInfo =  {
				ServiceID:serviceId,
				Frame:Frame,
				CanvasMuseum:CanvasMuseum,
				CanvasGallery:CanvasGallery,
				Mounting:Mounting,
				Acrylic:Acrylic,
				PrintOnly:PrintOnly,
				PosterCalendar:PosterCalendar,
				Lamination:Lamination
			};
        }

        var galleryItem = new GalleryItemVO(args);

        ret.push(galleryItem);
    }
    return ret;
};
