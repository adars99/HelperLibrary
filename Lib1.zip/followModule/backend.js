var followModule = {};

function getProfile(args,doScroll) {
	if (!args) args = {};
	
	var targetY;
	var append = false;
	
		var targetY = $('#scrollTarget').offset().top;
		
	if (args=='nextPage') { 
		followsPage++; append = true;
		if (followModule._noMorePages) return;
	}
	if (args=='prevPage') followsPage--;
	DAL.profileGet({append:append,onComplete:function() {
		//if (!append) $('.mg-menuExpanded').append('<li class="style1" onclick="getProfile(\'nextPage\')">see more...</li>');
		if (doScroll) {
		}
	}});		
	if (doScroll) {
		$('html,body').animate({
		    scrollTop: targetY,
		    scrollLeft: 0
		});
		info('followModule app > backend.js > scrolling to: '+targetY);
	}
}

var followsPage = 1;

var isFollowing = window.location.href.indexOf('/follows') > -1;
var isFollowers = window.location.href.indexOf('/followers') > -1;
var showModule = isFollowing || isFollowers;
if ( !showModule ) {
	$('#followsModule').hide();
}

window.onscroll = function() {
	var target = $art.g('nextPageButton');
	if (!target) return;
	var coords = UIUtil.getWindowOffset(target);
	if (coords.y > $(window).height()) {
		info('followModule > onscroll > coords.y='+coords.y+', window height='+$(window).height());
		clearTimeout( window['timeout_1'] );
		window['timeout_1'] = setTimeout(function() {
			getProfile('nextPage');
		},250);
	}
}

var alreadyFollowed = JSON.parse($('#graphData').html());
if (alreadyFollowed && alreadyFollowed.Follows) {
	try {
		var arr = alreadyFollowed.Follows.UserNetworkRelationshipActivities.results;
		var arr2 = [];
		for (var i = 0; i < arr.length; i++) {
			arr2.push( arr[i].UserId );
		}
		alreadyFollowed = arr2;
	} catch(e) {
		error('could not parse list of already followed users.');
	}
}

function wait(waiting) {
	if (waiting) {
		$('#waiting').show();
		$('#nextPageButton').hide();
	} else {
		$('#waiting').hide();
		$('#nextPageButton').show();
	}
}


$('#see_more a').attr('href','#').html('SEE MORE &gt;').click(function(e) { e.preventDefault(); getProfile('nextPage',true); });


function getFollowButtonStyle(accountId,isFollowing) {
	var data = alreadyFollowed;
	for (var i = 0; i < data.length; i++) {
		if (data[i].toString()==accountId.toString()) {
			if (isFollowing) return 'display: block;';
			else return 'display: none;'		
		}
	}
}
function doFollowButtons() {
	var nodes = document.getElementsByClassName('feedIR_userFollowButton');
	for (var i = 0; i < nodes.length; i++) {
		var node = nodes[i];
		var accountId = node.getAttribute('accountId');
		if (alreadyFollowed.indexOf(accountId)>-1) node.style.display = 'none';
	}
}