
var env = {
	apiUrl: 'http://api.art.com/ECommerceAPI.svc/jsonp/',
	apiKey: 'A555B7EF46B941C3A13B21537E03427D' /* borrowed from ArtMatch */,
	appId: '82B1C62CB16146FDB01AF9FB34B8B5E2' /* also borrowed from ArtMatch */
}
if (typeof($serverSideConfig)!='undefined')
	env.apiUrl = $serverSideConfig.environment.serviceUrl_eCommerceApi + '/jsonp/';

if (typeof(MyGalleriesEnvironmentVariables)!='undefined')
	env.apiUrl = MyGalleriesEnvironmentVariables.serviceUrlEcommerceApi + '/jsonp/';

var DAL = function(args) {
};


//var $c = com.art.site.model.DAL;
//var $p = $c.prototype;
var $p = DAL;

DAL.services = {
	base: new com.art.core.services.ServiceProvider( { 
		serviceUrlEcommerceApi: MyGalleriesEnvironmentVariables.ApiEcommerceServiceUrl
	} )
};
DAL.api = DAL.services.base.ecommerceAPIService;

$p.constructURL = function(method,parms) {
	//var url = art.site.config.environment.apiUrl;
	var url = env.apiUrl;
	url += method;

	if (parms) {
		var c = 0;
		for (var i in parms) {
			url += (c++==0?'?':'&');
			url += i + '=';
			url += parms[i];
		}
	}

	return url;
}

$p.profileGet = function(args) {
	if (!args) args = {};
	
	var accountId = mygalPageInfo.FollowingUserId;
	if (!accountId || accountId == '') {
		var c = new com.art.core.cookie.Cookie()
		accountId = c.getCookieDictionary('ap','accountid');
	}
		
	var e = env;
	var parms = {
		apiKey: MyGalleriesEnvironmentVariables.apiKey,
		authToken: MyGalleriesEnvironmentVariables.authToken,
		sessionId: MyGalleriesEnvironmentVariables.sessionId,
		accountIdentifier: accountId,
		lookupType: 2,
		includeGalleries: false,
		includeBookmarks: false,
		includeFollowing: isFollowing,
		includeFollowedBy: isFollowers,
		includeRecentActivity: false,
		includeFollowersRecentActivity: isFollowers,
		includeFollowingRecentActivity: isFollowing,
		followPageNumber: followsPage,
		followItemsPerPage: 10
	}
	
	var callbacks = {
		successHandler: function(response) {
			window['_profileGetResponse'] = response;
			//var vo = com.art.social.model.ProfileVO.parseFromAPI(response.Profiles);
			
			var vo;
			var data = null;
			var dataError = '';
			
			// parse the data into a ProfileVO
			if (!response.Profiles) dataError += 'no Profile object in API result. ';
			else vo = ProfileVO.parseFromAPI(response.Profiles);
					
			if (!vo || !vo.length || vo.length<1) dataError += 'failed to parse VO. ';
			else {
				if (isFollowing) data = vo[0].following;
				if (isFollowers) data = vo[0].followedBy;
			}
			
			// sanity check 2		
			if (!data || !data.length || data.length < 1) dataError += 'follow data is empty. ';
			if (!data || !data.length || data.length < 10) { dataError += 'fewer than ten users; there are no more pages. '; followModule._noMorePages = true; }
			
			// if no data, hide "see more" button and stop infinite scroll
			if (dataError!='') {
				info('followModule > END OF DATA. dataError='+dataError);
				//document.getElementById('nextPageButton').style.display = 'none';
				document.getElementById('nextPageButton').className += ' hidden';
				document.getElementById('waiting').className += ' hidden';
				$('#waiting').hide();
			}

			// scrub data
			for (var i = 0; i < data.length; i++) {
				try {
					var items = data[i].galleries.preview.items;
					for (var j = 0; j < items.length; j++) {
						items[j].images.small.url = items[j].images.small.url.replace( /&/g , '&quot;' );
					}
				} catch(e) {}
			}
			
			// append data
			if (args.append && data)
				window['followsData'] = window['followsData'].concat(data);
			else
				window['followsData'] = data;

			// if original server-side data is visible, hide it
			//$('#mg_followsModule').hide();
			$('.mg-section.followsModule').hide();
			
			// update components (i.e. the DataRepeater)
			art.view.update();
			
			wait(false);
			
			if (typeof(args.onComplete)=='function') args.onComplete.call(null,data,args);		
				
		},
		beforeSendHandler: function() {},
		errorHandler: function() {}
	}
	/*
	DAL.api.ProfileGet( callbacks, parms.apiKey, parms.authToken, 
				  parms.sessionId, parms.accountIdentifier, parms.lookupType, 
				  parms.includeGalleries, parms.includeBookmarks, parms.includeFollowing, 
				  parms.includeFollowedBy, parms.includeRecentActivity, parms.includeFollowersRecentActivity, 
				  parms.includeFollowingRecentActivity, parms.followPageNumber, parms.followItemsPerPage ); 
	*/
	var url = this.constructURL('ProfileGet',parms);
	DAL.doJsonpRequest({
		successHandler: callbacks.successHandler,
		url:url
	});
	wait(true);
/*
	var url = this.constructURL('ProfileGet',parms);
	wait(true);
	$art.get(url, null, function(responseText) {	
		wait(false);
		var json = JSON.parse(responseText);
		info(json);
	});
*/
	
}

$p.profileAddFollow = function(args) {
	if (!args) args = {};
	
	if (!args.accountId) {
		error('followModule > profileAddFollow > must provide accountId');
		return;
	}
	
	var method = 'ProfileAddFollow';
	if (args.unfollow) method = 'ProfileRemoveFollow';
		
	var e = env;
	var parms = {
		apiKey: MyGalleriesEnvironmentVariables.apiKey,
		authToken: MyGalleriesEnvironmentVariables.authToken,
		sessionId: MyGalleriesEnvironmentVariables.sessionId,
		accountIdentifier: args.accountId,
		lookupType: 2,
		returnBareResponse: true
	}

	var url = this.constructURL(method,parms);
	/*$art.get(url, null, function(responseText) {	
		var json = JSON.parse(responseText);
		window['_profileAddFollowResponse'] = json;
		
		if (typeof(args.onComplete)=='function') args.onComplete.call(null,json,args);		
	});*/
	
	function successHandler(response) {		
		window['_profileAddFollowResponse'] = response;
		
		if (typeof(args.onComplete)=='function') args.onComplete.call(null,response,args);		
	}
	
	var url = this.constructURL(method,parms);
	DAL.doJsonpRequest({
		successHandler: successHandler,
		url:url
	});
	wait(true);
	
}

$p.initializeAPI = function(args) {
	if (!args) args = {};

	var e = art.site.config.environment;
	var parms = {
		apiKey: e.apiKey,
		appId: e.appId,
		applicationId: e.appId,
		twoDigitISOCountryCode: 'US',
		twoDigitISOLanguageCode: 'en'
	}

	var url = this.constructURL('InitializeAPI',parms);
	art.site.state.wait(true);

	$art.get(url, null, function(responseText) {				
		try {
			var json = JSON.parse(responseText);
		} catch(e) {
			error('siteApp > DAL > initializeAPI > could not initialize API.');
			error(e);
			return;
		}
		if (typeof(args.onComplete)=='function') args.onComplete.call(null,json,args);
		art.site.state.wait(false);
	});
}


$p.getAPIResults = function(args) {
	if (!args) { error('site > DAL.js > getAPIResults() > args not provided.'); return; }

	// parse response as JSON
	var errors = [], json = null;
	try {
		json = JSON.parse(args.responseText);
		this.validateAPIResponse(json,errors);
	} catch(e) {
		errors.push('unable to parse JSON');
	}

	// determine response status
	var responseCode = json.d && json.d.OperationResponse && json.d.OperationResponse.ResponseCode || 'unknown';
	if (responseCode!=200) errors.push('site > DAL.js > invalid or erroneous API response code "'+responseCode+'"');

	var responseMessage = json.d && json.d.OperationResponse && json.d.OperationResponse.ResponseMessage || 'unknown';
	// unreliable // if (responseMessage!='success') errors.push('site > DAL.js > invalid or erroneous API response message "'+responseMessage+'"');

	// create detailed result object
	var ret = {
		method: args.method,
		valid: !errors.length,
		responseCode: responseCode,
		responseMessage: responseMessage,
		errors: errors,
		json: json,
		responseText: args.responseText,
		url: args.url
	}

	// log result in global variable
	if (!window['_apiCalls']) window['_apiCalls'] = [];
	window['_apiCalls'].push(ret);

	// alert on failure
	if (errors.length>0) {
		error(['site > DAL.js > failure in API call. method='+ret.method+', responseMessage='+ret.responseMessage.left(50)+'. result follows.',ret]);
	}

	return ret;
}

$p.validateAPIResponse = function(json,err) {
	var errors = err || [];

	return errors;
}

$p.doJsonpRequest = function(args) {


	var r = {};
	r.url = args.url;

	r.dataType = 'jsonp';
	r.jsonp = 'callback';
	r.jsonpCallback = 'jsonpCallback';

	//r.beforeSend = function () { callbacks['beforeSendHandler'](); };
	r.success = function (response) { args.successHandler(response); };
	//r.error = function (response) { callbacks['errorHandler'](response); };

	if (args.data != undefined)
		r.data = args.data;

	//X-Request-Id parameter is being passed to all the ajax calls so that we can correlate the cascading errors in splunk for the given id. 
	if (args.data != undefined){
		r.data = args.data + "&X-Art-Request-Id=" + com.art.core.utils.StringUtil.generateRandomNumber();
	} else {
		r.url = r.url + com.art.core.utils.StringUtil.queryStringChr(r.url) + "X-Art-Request-Id=" + com.art.core.utils.StringUtil.generateRandomNumber();
	}
	$.ajax(r);
}