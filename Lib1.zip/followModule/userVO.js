UserVO = function(args) {
	if (!args) args = {};
	
	this.id = args.id || '';
	this.accountId = args.accountId || '';
	this.Featured = args.Featured || false;
	if (!args.name) args.name = {};
	this.name = {
			firstName: args.name.firstName || '',
			lastName: args.name.lastName || '',
			fullName: function() { return this.firstName+' '+this.lastName; },
			userName:args.name.userName,
			IsNicknameSystemGenerated:args.name.IsNicknameSystemGenerated,
			PublicAlias: args.name.PublicAlias,
			HideNameFromPublicProfile:args.name.HideNameFromPublicProfile,
			displayName: function (){ 
			    if (this.firstName != '' && this.firstName != null && this.lastName != '' && this.lastName != null) {
			        if (!this.HideNameFromPublicProfile) {
			            return this.firstName + " " + this.lastName;
			        }
			        else if (!this.IsNicknameSystemGenerated && this.PublicAlias != null) {
			            return this.PublicAlias;
			        }
			    }
			    else {
			        if (!this.IsNicknameSystemGenerated && this.PublicAlias != null) {
			            return this.PublicAlias;
			        }
			        else {
			            return MyGalleriesCore.getString("Art Lover");
			        }
			    }
			}
	};
	
	if (!args.social) args.social = {};
	this.social = {
			followersCount: args.social.followersCount || 0,
			followingCount: args.social.followingCount || 0,
			likesCount: args.social.likesCount || 0,
			profileUrl: args.social.profileUrl || '#'
	};
	
	if (!args.images) args.images = {};
	this.images = {
			thumbnail: args.images.thumbnail || 'http://cache1.artprintimages.com/images/youart/blank_avatar.jpg',
			small: args.images.small || '',
			medium: args.images.medium || '',
			large: args.images.large || ''
	};
	
	if (!args.galleries) args.galleries = {};
	this.galleries = {
			bareWalls: args.galleries.bareWalls || [],
			preview: args.galleries.preview || []
	};

	this.guid = generateUniqueId();
	
};


UserVO.parseFromAPI = function(apiReturn) {
	// returns a UserVO from the JSON return set from the API representing a user
	
	if (!apiReturn.push) apiReturn = [ apiReturn ];
	
	var users = [];
	
	for (var i = 0; i < apiReturn.length; i++) {
		
		var obj = apiReturn[i];

		//if (!obj.ProfileInfo) { error('UserVO > parse error > ProfileInfo not found.'); return; } // Art.Data.Contract.API.UserAccount.UserAccount
		//if (!obj.CuratorInfo) { error('UserVO > parse error > CuratorInfo not found.'); return; } // type Art.Data.Contract.API.UserAccount.GalleryOwner

		// sanity checks
		if (!obj.ProfileInfo) { warn('gigya > UserVO > parse error > ProfileInfo not found.'); obj.ProfileInfo = {}; };
		if (!obj.CuratorInfo) { warn('gigya > UserVO > parse error > CuratorInfo not found.'); obj.CuratorInfo = {}; };
		
		var args = {};
		
		args.name = {
				firstName: obj.ProfileInfo.FirstName,
				lastName: obj.ProfileInfo.LastName,
				userName:obj.ProfileInfo.UserName,
				IsNicknameSystemGenerated: obj.ProfileInfo.IsNicknameSystemGenerated,
				HideNameFromPublicProfile: obj.ProfileInfo.HideNameFromPublicProfile,
				PublicAlias:obj.ProfileInfo.PublicAlias
		};
		
		if(obj.CuratorInfo.Featured)
		args.Featured = obj.CuratorInfo.Featured || false;
		
		/*
		if (!obj.CuratorInfo.ProfileImage||!obj.CuratorInfo.ProfileImage.ThumbnailImage||!obj.CuratorInfo.ProfileImage.ThumbnailImage.HttpImageURL) { 
			warn('UserVO > parse error > thumbnail image not found in service return set.');  
		} else {
			args.images = {
					thumbnail: obj.CuratorInfo.ProfileImage.ThumbnailImage.HttpImageURL
			};	
		}*/

		if (!obj.CuratorInfo.ProfileImage) { 
			warn('UserVO > parse error > profile images not found in service return set.');  
		} else {
			var p = obj.CuratorInfo.ProfileImage;
			var t = p.ThumbnailImage || {};
			var s = p.SmallImage || {};
			args.images = {
					thumbnail: t.HttpImageURL,
					small: s.HttpImageURL
			};	
			if (args.images.small&&!args.images.thumbnail) args.images.thumbnail = args.images.small;
		}
		
		
		if (!obj.ProfileInfo){
			warn('UserVO > parse error > Profile URL or key not found in service return set.');
		}
		else 
		{
			
			var scnt = 0, followcnt = 0, followerscnt = 0; 
			if(obj.ProfileInfo.Statistics != null && obj.ProfileInfo.Statistics.length > 0){
				for(var i=0; i<obj.ProfileInfo.Statistics.length; i++){
					var stat = obj.ProfileInfo.Statistics[i];
					if(stat.Name == "galleryItems")
						scnt = stat.Value || 0;
					else if(stat.Name == "followers")
						followerscnt = stat.Value || 0;
					else if(stat.Name == "following")
						followcnt = stat.Value || 0;
				}
				 
			}
			
			args.social = {
					profileUrl: obj.ProfileInfo.ProfileKey || '#',
					followersCount: followerscnt,
					likesCount: scnt,
					followingCount: followcnt
			};
			args.accountId = obj.ProfileInfo.AccountId;
		}
		users.push( new UserVO(args) );
		
		
	}
	
	return users;
};
