/**
 * Notification interface, used to validate Note object
 * @class INotification
 * @constructor
 */
com.art.core.interfaces.INotification 					= function(){};
com.art.core.interfaces.INotification.prototype.name	= "";
com.art.core.interfaces.INotification.prototype.body	= {};
com.art.core.interfaces.INotification.prototype.type	= "";
