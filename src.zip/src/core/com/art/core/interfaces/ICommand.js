com.art.core.interfaces.ICommand 								= function(){};
com.art.core.interfaces.ICommand.prototype.successHandler 		= function(){};
com.art.core.interfaces.ICommand.prototype.errorHandler			= function(){};
com.art.core.interfaces.ICommand.prototype.beforeSendHandler	= function(){};	
