com.art.core.interfaces.IExtension 							= function(){};
com.art.core.interfaces.prototype.init						= function(){};
com.art.core.interfaces.prototype.notify					= function(){};
com.art.core.interfaces.prototype.handleNotification		= function(){};
com.art.core.interfaces.prototype.listNotificationInterests	= function(){};
