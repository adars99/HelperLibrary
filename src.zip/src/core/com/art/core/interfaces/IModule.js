/**
 * @class IModule
 */
com.art.core.interfaces.IModule 									= function(){};
com.art.core.interfaces.IModule.prototype.init 						= function(){};
com.art.core.interfaces.IModule.prototype.destroy					= function(){};
com.art.core.interfaces.IModule.prototype.notify					= function(){};
com.art.core.interfaces.IModule.prototype.handleNotification		= function(){};
com.art.core.interfaces.IModule.prototype.getTemplate				= function(){};
com.art.core.interfaces.IModule.prototype.getTarget					= function(){};
com.art.core.interfaces.IModule.prototype.listNotificationInterests	= function(){};