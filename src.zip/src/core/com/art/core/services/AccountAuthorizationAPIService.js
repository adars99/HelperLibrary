/**
 * Top level core object, common JS core library for art.com
 * @module services
 * @title art.com common components
 */

/**
 * Account Services JS API
 * @class AccountAuthorizationAPIService
 * @namespace com.art.core.services
 * @constructor
 */
com.art.core.services.AccountAuthorizationAPIService = function(base)
{
	this.base = base;
    this.serviceUrl = this.base.environment.serviceUrlAccountAuthenticationApi;
};
/**
 * 
 * <AccountAuthenticate xmlns="http://api.art.com">
 *   <apiKey i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
 *   <sessionId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
 *   <emailAddress i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
 *   <password i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
 * </AccountAuthenticate>
 * @method accountAuthenticate
 * @constructor
 * @param callbacks
 * @param apiKey
 * @param sessionId
 * @param emailAddress
 * @param password
 */
com.art.core.services.AccountAuthorizationAPIService.prototype.accountAuthenticate = function(callbacks, apiKey, sessionId, emailAddress, password)
{

    var url;
    var operation = "AccountAuthenticate"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId', sessionId];
    properties[2] = ['emailAddress', emailAddress];
    properties[3] = ['password', password];
    
    url = this.base.getUrl(this.base.environment.serviceUrlAccountAuthenticationApi, operation, properties);
    this.base.doRequest(url,callbacks);
};

com.art.core.services.AccountAuthorizationAPIService.prototype.accountAuthenticateWithFacebookUid = function(callbacks, apiKey)
{
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.base.environment.serviceUrlAccountAuthenticationApi, operation, properties);
    this.base.doRequest(url,callbacks);
};
/**
 * Create a new art.com account
 * <AccountCreate xmlns="http://api.art.com">
      <apiKey i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <sessionId i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <emailAddress i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
      <password i:nil="true" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" />
    </AccountCreate>
 * @method accountCreate
 * @param callbacks
 * @param apiKey
 * @param sessionId
 * @param emailAddress
 * @param password
 */
com.art.core.services.AccountAuthorizationAPIService.prototype.accountCreate = function(callbacks, apiKey, sessionId, emailAddress, password)
{
    
    var url;
    var operation = "AccountCreate"; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['emailAddress',emailAddress];
    properties[3] = ['password',password];
    
    url = this.base.getUrl(this.base.environment.serviceUrlAccountAuthenticationApi, operation, properties);
    this.base.doRequest(url,callbacks);

};

com.art.core.services.AccountAuthorizationAPIService.prototype.accountRetrievePassword = function(callbacks, apiKey)
{
    var url;
    var operation = ""; 
    var properties = [];
    
    properties[0] = ['apiKey',apiKey];
    
    url = this.base.getUrl(this.base.environment.serviceUrlAccountAuthenticationApi, operation, properties);
    this.base.doRequest(url,callbacks);

};

