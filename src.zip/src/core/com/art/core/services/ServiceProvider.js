/**
 * Global common service provider class to access entire art.com service API
 * @class ServiceProvider
 * @constructor
 * @namespace com.art.core.services
 * 
 * @param {Object} env Environmental object set from server; see com.art.core.vos.Environment for more details
 */
 com.art.core.services.ServiceProvider = function(env)
{
	this.name ="ServiceProvider";
	this.environment = env;

	this.ecommerceAPIService 				= new com.art.core.services.EcommerceAPIService(this);
	this.galleryAPIService					= new com.art.core.services.GalleryAPIService(this);
	this.accountAuthorizationAPIService		= new com.art.core.services.AccountAuthorizationAPIService(this);
	this.adcNetService						= new com.art.core.services.AdcNetService(this);
	this.loggingAPIService					= new com.art.core.services.LoggingAPIService(this);
	this.searchAPIService					= new com.art.core.services.SearchAPIService(this);
	this.dfeAPIService						= new com.art.core.services.DFEAPIService(this);
	this.framingServiceAPI					= new com.art.core.services.FramingServiceAPI(this);
	//constants
	this.contentType = com.art.core.services.ServiceProvider.JSON_CONTENT_TYPE;
	this.TEXT_CONTENT_TYPE = com.art.core.services.ServiceProvider.TEXT_CONTENT_TYPE;
	this.dataType			= com.art.core.services.ServiceProvider.JSONP;
	this.type				= com.art.core.services.ServiceProvider.GET;

};

com.art.core.services.ServiceProvider.XML_CONTENT_TYPE 		= 'application/xml; charset=utf-8';
com.art.core.services.ServiceProvider.XML					= 'xml';
com.art.core.services.ServiceProvider.JSON_CONTENT_TYPE 	= 'application/json; charset=utf-8';
com.art.core.services.ServiceProvider.JSON					= 'json';
com.art.core.services.ServiceProvider.JSONP                 = 'jsonp';
com.art.core.services.ServiceProvider.TEXT_CONTENT_TYPE     = 'text/plain; charset=utf-8';
com.art.core.services.ServiceProvider.GET					= 'get';
com.art.core.services.ServiceProvider.POST 					= 'post';
com.art.core.services.ServiceProvider.HTML 					= 'html';


com.art.core.services.ServiceProvider.prototype.ecommerceAPIService;
com.art.core.services.ServiceProvider.prototype.galleryAPIService;
com.art.core.services.ServiceProvider.prototype.accountAuthorizationAPIService;
com.art.core.services.ServiceProvider.prototype.adcNetService;
com.art.core.services.ServiceProvider.prototype.loggingAPIService;
com.art.core.services.ServiceProvider.prototype.FramingServiceAPI;

/**
 * @method doRequest
 * @param {String} url the full url of the service call
 * @param {Object} callbacks the callbacks object will be executed via ajax; see com.art.core.vos.Callbacks for more details
 * @param (String) (optional) denotes the return type expected from the service.  Should be set from the static vars in this class.
 * @param (data) (optional) data parameter that, when provided, will fill the requestObj .data property
 */
com.art.core.services.ServiceProvider.prototype.doRequest = function (url, callbacks, methodType, data) {
    //STEP: Set the Content type if it was passed, otherwise it was the default set in the contructor
    if (methodType)//NOTE: Makes it optional by first checking if it is undefined
    {
    	//NOTE: This switch is necessary to ensure the passed in value is a legit content type
    	switch(methodType)
    	{
    		case com.art.core.services.ServiceProvider.XML:
    		case com.art.core.services.ServiceProvider.JSON:
    		case com.art.core.services.ServiceProvider.TEXT_CONTENT_TYPE:            
    		case com.art.core.services.ServiceProvider.JSONP:
    		case com.art.core.services.ServiceProvider.HTML:
    			this.dataType = methodType;
    			break;
    	}
    }
    else
    {
        //STEP: Reset JSONP as the default if the method is not passed in
        this.dataType = com.art.core.services.ServiceProvider.JSONP;
    }
    //trace(this.name + ": DataType will be: " + this.dataType);
    
    var requestObj = {};
    requestObj.url = url;

    //requestObj.cache = true;
    //requestObj.contentType = this.contentType;
    requestObj.dataType = this.dataType;
    
    if (this.dataType == this.JSON || this.dataType == this.JSONP)
    {
    	requestObj.jsonp = 'callback';
        requestObj.jsonpCallback = 'jsonpCallback';
    }
    requestObj.beforeSend = function () { callbacks['beforeSendHandler'](); };
    requestObj.success = function (response) { callbacks['successHandler'](response); };
    requestObj.error = function (response) { callbacks['errorHandler'](response); };
    if (data != undefined)
        requestObj.data = data;

    $.ajax(requestObj);
};


/**
 * Some comments, general description
 * @method createHandlers
 * @param handlerSuccessFunction
 * @param handlerErrorFunction
 * @param handlerBeforeSendFunction
 * @returns {___anonymous2301_2417}
 * 
 * Below comments
 */
com.art.core.services.ServiceProvider.prototype.createHandlers = function(handlerSuccessFunction,handlerErrorFunction,handlerBeforeSendFunction)
{
	return {successHandler:handlerSuccessFunction,errorHandler:handlerErrorFunction,beforeSendHandler:handlerBeforeSendFunction};
};
/**
 * This method will return a properly formatted Url for a service call
 * @method getUrl
 * @param serviceUrl
 * @param operation
 * @param parameterKeyValueArray
 * @param serviceProviderContentType (optional) Parameter will default to JSONP if not provided
 * @returns string formattedUrl
 */
com.art.core.services.ServiceProvider.prototype.getUrl = function(serviceUrl, operation, parameterKeyValueArray, serviceProviderContentType)
{
    var url = serviceUrl;
    
    //STEP: add content type specific needs to the URL 
    if (serviceProviderContentType)
    {
    	if (serviceProviderContentType == this.JSON)
    		url += "/jsonp";
    }
    else
    {
    	url += "/jsonp";
    }
    	
    //STEP: Add the operation name to the URL if it was passed in
    if (operation.length)
    	url += "/" + operation;
    
    //STEP: Add the Question Mark to the URL 
    url += "?";
    
    for (var i = 0; i < parameterKeyValueArray.length; i++)
    {
        if (i>0)
        {
            url += "&";
        }
        url += parameterKeyValueArray[i][0] + "=" + parameterKeyValueArray[i][1];
    }
    return url;
};
com.art.core.services.ServiceProvider.prototype.getUrlSimple = function(url, queryString)
{
	return url + "?" + queryString;
};

com.art.core.services.ServiceProvider.prototype.getJSONUrl = function(serviceUrl, operation, jsonpString)
{
    var url = serviceUrl;
    url += "/json";
    url += "/" + operation;
    return url;
};

com.art.core.services.ServiceProvider.prototype.getAJAXUrl = function(serviceUrl, operation, jsonpString)
{
    var url = serviceUrl;
    url += "/ajax";
    url += "/" + operation;
    return url;
};

com.art.core.services.ServiceProvider.prototype.doSyncRequest = function (url, callbacks) {

	var requestObj = {};
    requestObj.url = url;
    
    requestObj.processData = false;
    requestObj.cache = false;
    
    //requestObj.beforeSend = function () {callbacks['beforeSendHandler'](); };
    requestObj.success = function (response) {callbacks['successHandler'](response); };
    requestObj.error = function (response) {callbacks['errorHandler'](response); };
    
    $.ajax(requestObj);
};




