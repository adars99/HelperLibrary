com.art.core.services.FramingServiceAPI = function(base)
{
	this.base = base;
	this.serviceUrl = this.base.environment.framingWebServiceURL;
	
};

com.art.core.services.FramingServiceAPI.prototype.getFrameIdForDFE = function(callbacks,properties)
{
	this.serviceUrl = "/asp/DFEHelper.asp"; 
    var url = this.base.getUrlSimple(this.serviceUrl, properties);
    this.base.doSyncRequest(url,callbacks);
};

