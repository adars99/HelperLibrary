com.art.core.services.DFEAPIService = function(base,apiKey,authToken)
{
	this.base = base;
	this.serviceUrl = this.base.environment.dfeAPIServiceUrl; 
    this.domainUrl = this.base.environment.domain;
};

com.art.core.services.DFEAPIService.prototype.GetFrameSkuForFrameConfiguration = function(callbacks,data)
{
	var operation = "GetFrameSkuForFrameConfiguration";
	var url = this.base.getAJAXUrl(this.serviceUrl,operation);
	trace(url);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};