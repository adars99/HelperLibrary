com.art.core.services.GalleryAPIService = function(base,apiKey,authToken)
{
	this.base = base;
	this.serviceUrl = this.base.environment.galleryServiceUrl; //"http://loc-ws-account2.art.com/GalleryService.svc"
    this.domainUrl = this.base.environment.domain;
};

com.art.core.services.GalleryAPIService.prototype.getUserGalleries = function(callbacks,data)
{
	var operation = "getUserGalleries";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};

com.art.core.services.GalleryAPIService.prototype.getGalleryWithItems = function(callbacks,data)
{
	trace("getGalleryWithItems");
	var operation = "getGalleryWithItems";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};

com.art.core.services.GalleryAPIService.prototype.getUserDefaultGallery = function(callbacks,data)
{
	trace("getUserDefaultGallery");
	var operation = "getUserDefaultGallery";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};

com.art.core.services.GalleryAPIService.prototype.getGalleryDetailswithResultFilter = function(callbacks,data)
{
	trace("getGalleryDetailswithResultFilter");
	var operation = "getGalleryDetailswithResultFilter";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};

com.art.core.services.GalleryAPIService.prototype.updateGallery = function(callbacks,data)
{
	var operation = "updateGallery";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};

com.art.core.services.GalleryAPIService.prototype.createGallery = function (callbacks, data) {
    var operation = "createGallery";
    var url = this.base.getJSONUrl(this.serviceUrl, operation);
    this.base.doRequest(url, callbacks,com.art.core.services.ServiceProvider.JSONP, data);
};


com.art.core.services.GalleryAPIService.prototype.getUserLibrary = function(callbacks,data)
{
	var operation = "getUserLibrary";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};

com.art.core.services.GalleryAPIService.prototype.getSystemLibrary = function(callbacks,data)
{
	var operation = "getSystemLibrary";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};
com.art.core.services.GalleryAPIService.prototype.getUserLibrary = function(callbacks,data)
{
	var operation = "getUserLibrary";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};

com.art.core.services.GalleryAPIService.prototype.addItemsToGallery = function(callbacks,data)
{
	var operation = "addItemsToGallery";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};

com.art.core.services.GalleryAPIService.prototype.moveGalleryItem = function(callbacks,data)
{
	var operation = "moveGalleryItem";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};
com.art.core.services.GalleryAPIService.prototype.addBareWalls = function(callbacks,data)
{
	var operation = "addBareWalls";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};
com.art.core.services.GalleryAPIService.prototype.updateBareWall = function(callbacks,data)
{
	var operation = "updateBareWall";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};

com.art.core.services.GalleryAPIService.prototype.deleteGalleryItem = function(callbacks,data)
{
	var operation = "removeGalleryItem";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};
/**
 * Create new Wall for DLE Room View appliation
 * @method createWall
 * @param callbacks
 * @param data
 */
com.art.core.services.GalleryAPIService.prototype.createWall = function(callbacks,data)
{
	var operation = "createWall";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};
com.art.core.services.GalleryAPIService.prototype.updateWall = function(callbacks,data)
{
	var operation = "updateWall";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};
com.art.core.services.GalleryAPIService.prototype.getWalls = function(callbacks,data)
{
	var operation = "getWalls";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};
com.art.core.services.GalleryAPIService.prototype.shareWall = function(callbacks,data)
{
	var operation = "shareaWall";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};
com.art.core.services.GalleryAPIService.prototype.getWallByWallId = function(callbacks,data)
{
	var operation = "getWallByWallId";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};
com.art.core.services.GalleryAPIService.prototype.getUserLibraryByProfileKey = function(callbacks,data)
{
	var operation = "getUserLibraryByProfileKey";
	var url = this.base.getJSONUrl(this.serviceUrl,operation);
	this.base.doRequest(url,callbacks,com.art.core.services.ServiceProvider.JSONP,data);
};



/*
* This method is used to register user account by calling account service through account proxy
*/
com.art.core.services.GalleryAPIService.prototype.callAccountProxy = function (callbacks, data) {    
    this.AccountProxyUrl = "http://"+this.domainUrl + "/ADC.NET/Root/Pages/MyGalleries/AccountProxy.aspx";
    this.base.doRequest(this.AccountProxyUrl, callbacks, 'text/html', data);
};

/*
* 
*/
com.art.core.services.GalleryAPIService.prototype.callMyAccountProxy = function (callbacks, data) {
    var myAccountProxyUrl = "http://" + this.domainUrl + "/asp/functions/myAccountProxy.asp";
    
    this.base.doRequest(myAccountProxyUrl, callbacks, 'text/html', data);
};

com.art.core.services.GalleryAPIService.SORT_BY_DATE_ADDED = 1;
com.art.core.services.GalleryAPIService.SORT_BY_ARTIST_NAME = 2;
com.art.core.services.GalleryAPIService.SORT_BY_PRICE = 3;
com.art.core.services.GalleryAPIService.SORT_BY_TITLE = 4;
com.art.core.services.GalleryAPIService.SORT_DIRECTION_DESC = 1;
com.art.core.services.GalleryAPIService.SORT_DIRECTION_ASC = 0;


//pagingNumber
//pageNumber
//itemsPerPage
//AllItems true|false

