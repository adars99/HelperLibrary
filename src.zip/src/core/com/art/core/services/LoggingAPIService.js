/**
 * Top level core object, common JS core library for art.com
 * @module services
 * @title art.com common components
 */

/**
 * LoggingAPI Services JS API
 * This connects to the LoggingAPI endpoint of the api.art.com services 
 * @class LoggingAPIService
 * @namespace com.art.core.services
 * @constructor
 */
com.art.core.services.LoggingAPIService = function(base)
{
	this.base = base;
    this.serviceUrl = this.base.environment.serviceUrlLoggingApi;
};

com.art.core.services.LoggingAPIService.prototype.logError = function(callbacks, apiKey, sessionId, errorMessage, errorSource, errorName, errorLocation, errorObjectAsString)
{
    var url;
    var operation = "LogError"; 
    var properties = [];

    properties[0] = ['apiKey',apiKey];
    properties[1] = ['sessionId',sessionId];
    properties[2] = ['errorMessage',errorMessage];
    properties[3] = ['errorSource',errorSource];
    properties[4] = ['errorName',errorName];
    properties[5] = ['errorLocation',errorLocation];
    properties[6] = ['errorObjectAsString',errorObjectAsString];
    
    url = this.base.getUrl(this.serviceUrl, operation, properties);
    this.base.doRequest(url,callbacks);
};
