/**
 * Common value object classes
 * @module vos
 */

/**
 * Moulding Value Object, standardized object for Moulding object
 * @class MouldingVO
 * @namespace com.art.core.vos
 * @param title
 */
com.art.core.vos.MouldingVO = function(sourceMoulding,imagePath)
{
	this.NAME = com.art.core.vos.MouldingVO.NAME;
	this.apNum = sourceMoulding.ApNum;
	this.mouldingId = sourceMoulding.MouldingId;
	this.Name = sourceMoulding.Name;
	this.color = sourceMoulding.Color;
	this.style = sourceMoulding.Style;
	this.finish = sourceMoulding.Finish;
	this.material = sourceMoulding.Material;
	this.width = sourceMoulding.Width;
	this.height = sourceMoulding.Height;
	this.isPopular = sourceMoulding.IsPopular;
	this.description = sourceMoulding.Description;
	this.baseThumbImageUrl = imagePath+'/images/framing/hires/$ID/thumb/$ID.jpg';
	this.getThumbImageUrl = function(){ return this.baseThumbImageUrl.replace(/\$ID/g,this.apNum); };
};
com.art.core.vos.MouldingVO.NAME = "MouldingVO"; //static

// How many of these s do I really need?
com.art.core.vos.MouldingVO.prototype.apNum= ''; // Makes it an "Item"
com.art.core.vos.MouldingVO.prototype.mouldingId= '';
com.art.core.vos.MouldingVO.prototype.name= '';
com.art.core.vos.MouldingVO.prototype.color= '';
com.art.core.vos.MouldingVO.prototype.style= '';
com.art.core.vos.MouldingVO.prototype.finish= '';
com.art.core.vos.MouldingVO.prototype.material= '';
com.art.core.vos.MouldingVO.prototype.width= '';
com.art.core.vos.MouldingVO.prototype.height= '';
com.art.core.vos.MouldingVO.prototype.isPopular= '';
com.art.core.vos.MouldingVO.prototype.description= '';

// customerZoneId;  languageId;  apNum;  mouldingId;  name;  frameType;  color;  style;  finish;  material;  
// width;  height;  rabbetWidth;  rabbetHeight;  itemDisplayedTypeID;  siteStatusId;  dBDateUpdated;  isPopular;  canFrameCanvas;  description;  isP2AMoulding;
com.art.core.vos.MouldingVO.ConvertToMouldingVOArray = function(serviceSideMouldingsArray,imagePath)
{
	trace("ConvertToMouldingVOArray");
	
	var outputMouldings = [];
	for(var index in serviceSideMouldingsArray)
	{
		for(var innerIndex in serviceSideMouldingsArray[index].Mouldings)
		{
			outputMouldings.push(new com.art.core.vos.MouldingVO(serviceSideMouldingsArray[index].Mouldings[innerIndex],imagePath));
		}
	}
	return outputMouldings;
};
