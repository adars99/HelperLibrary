/**
 * Common value object classes
 * @module vos
 */

/**
 * Image Value Object, standardized object for image object
 * @class ImageVO
 * @namespace com.art.core.vos
 * @param title
 */
com.art.core.vos.ImageVO = function(title)
{
	this.NAME = com.art.core.vos.ImageVO.NAME;
	this.Title = title;
};
com.art.core.vos.ImageVO.NAME = "ImageVO"; //static
com.art.core.vos.ImageVO.prototype.Title = '';
com.art.core.vos.ImageVO.prototype.ImageUrl = '';
com.art.core.vos.ImageVO.prototype.ZoomImageUrl = '';
com.art.core.vos.ImageVO.prototype.NoWatermarkImageUrl = '';
com.art.core.vos.ImageVO.prototype.FileName = '';
com.art.core.vos.ImageVO.prototype.UploadedImageUrl = '';
com.art.core.vos.ImageVO.prototype.ArtistName = '';
com.art.core.vos.ImageVO.prototype.Price = '';
com.art.core.vos.ImageVO.prototype.MasterDisplayPrice = '';
com.art.core.vos.ImageVO.prototype.LargeImageWidth = '';
com.art.core.vos.ImageVO.prototype.LargeImageHeight = '';
com.art.core.vos.ImageVO.prototype.Position = '';
com.art.core.vos.ImageVO.prototype.ImageId = 0;
com.art.core.vos.ImageVO.prototype.ImageGuid = '';
com.art.core.vos.ImageVO.prototype.ArtistCategoryId = 0;
com.art.core.vos.ImageVO.prototype.CategoryID = 0;
com.art.core.vos.ImageVO.prototype.ProductPageUrl = '';
com.art.core.vos.ImageVO.prototype.MasterProductID = 0;
com.art.core.vos.ImageVO.prototype.MasterSpecID = '';
com.art.core.vos.ImageVO.prototype.Apnum = 0;
com.art.core.vos.ImageVO.prototype.OtherSizes = '';
com.art.core.vos.ImageVO.prototype.ImageMedWidth = '';
com.art.core.vos.ImageVO.prototype.ImageMedHeight = '';
com.art.core.vos.ImageVO.prototype.ArtistUrl = '';
com.art.core.vos.ImageVO.prototype.ShowMarkDown = '';
com.art.core.vos.ImageVO.prototype.MarkDownPrice = '';
com.art.core.vos.ImageVO.prototype.ItemGroupTypeID = '';
com.art.core.vos.ImageVO.prototype.Type = "";
com.art.core.vos.ImageVO.prototype.MasterZoneProductId = '';
com.art.core.vos.ImageVO.prototype.IsCustomerUpload = false;
com.art.core.vos.ImageVO.prototype.ItemDisplayedType = '';
com.art.core.vos.ImageVO.prototype.PhysicalInchWidth = '';
com.art.core.vos.ImageVO.prototype.PhysicalInchHeight = '';
com.art.core.vos.ImageVO.prototype.TimeToShipDisplayText = '';
com.art.core.vos.ImageVO.prototype.AppendDropShadow = true;
com.art.core.vos.ImageVO.prototype.MasterPodConfigId = '';

com.art.core.vos.ImageVO.imageType = {CATALOG:'catalog',UPLOADED:'uploaded',SEARCH:'search',WALL:'wall'};
com.art.core.vos.ImageVO.itemLookupTypeFromDomain = {ItemNumber :'ItemNumber',Sku:'Sku',CustomFramedItem:'CustomFramedItem',UserUploadedItem : 'UserUploadedItem', FramedRecommendationItem:'FramedRecommendationItem'};
com.art.core.vos.ImageVO.itemTypeFromDomain = {CatalogItem : 'CatalogItem', CustomFramedItem : 'CustomFramedItem', FramedItemRecommendation : 'FramedItemRecommendation', UserUploadedItem : 'UserUploadedItem'};

com.art.core.vos.ImageVO.prototype.getTestImage = function(obj)
{
 	this.Title = "Customer Photo";
	this.ImageUrl = "http://cache2.artprintimages.com/p/MED/21/2190/U4GAD00Z/art-print/ron-burns-i-wanna-go.jpg";
	this.Type = com.art.core.vos.ImageVO.imageType.UPLOADED;
	this.Price = '';
	this.MasterDisplayPrice = '';
	this.Apnum = '';
	this.IsCustomerUpload = true;
	this.ItemDisplayedType = "Customer Photo";
	this.PhysicalInchWidth = 0;
	this.PhysicalInchHeight = 0;
	this.TimeToShipDisplayText = "";
};

com.art.core.vos.ImageVO.prototype.getTestCatalogImage = function()
{
	this.parseCatalogImageDetail("323186"
			,"Keep Calm and Carry On"
			, "796808"
			, 16
			, "http://qa-imagesource5.art.com/MED/7/796/RCJI000Z.jpg"
			, "http://qa-imagesource5.art.com/MED/7/796/RCJI000Z.jpg"
			, "9.99"
			, "19.99"
			, "ArtistName"
			, "10286380"
			, "A"
			, "10286380A"
			, "10"
			, "16"
			, "11"
			, "17"
			, "/gallery/id--a15897/philip-rugel-posters.htm"
			, "12"
			, "18"
			, "1-2 days"
			, "http://www.art.com/products/p13936089-sa-i2784740/vincent-van-gogh-irises-saint-remy-c1889.htm");
	
};


com.art.core.vos.ImageVO.prototype.parseCatalogImageDetail = function(apnum, title, imageId, artistCategoryId, imageUrl, largeImageUrl, price, masterDisplayPrice, artistName, masterProductID, masterSpecID, masterZoneProductId, largeImageWidth, largeImageHeight, imageMedWidth, imageMedHeight, artistUrl, physicalInchWidth, physicalInchHeight, timeToShipDisplayText, productPageUrl)
{
	this.LrgImageUrl = String(largeImageUrl).replace('/MED','/MED');
	this.ImageUrl = imageUrl;
	this.ArtistCategoryId = artistCategoryId;
	this.ImageId = imageId;
	this.Apnum = apnum;
	this.Title = title;
	this.Type = com.art.core.vos.ImageVO.imageType.CATALOG;
	this.Price = price;
	this.MasterDisplayPrice = masterDisplayPrice;
	this.ArtistName = artistName;
	this.MasterProductID = masterProductID;
	this.MasterSpecID = masterSpecID;
	this.MasterZoneProductId = masterZoneProductId;
	this.LargeImageWidth = largeImageWidth;
	this.LargeImageHeight = largeImageHeight;
	this.ImageMedWidth = imageMedWidth;
	this.ImageMedHeight = imageMedHeight;
	this.ArtistUrl = artistUrl;
	this.PhysicalInchWidth = physicalInchWidth;
	this.PhysicalInchHeight = physicalInchHeight;
	this.TimeToShipDisplayText = timeToShipDisplayText;
	this.ProductPageUrl = productPageUrl;
};

com.art.core.vos.ImageVO.prototype.parseUploadCustomerPhotoData = function(obj)
{
	/*
	<ImageUploadResponse xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="http://tempuri.org/">
	<ResponseCode>0</ResponseCode>
	<ResponseText>Success</ResponseText>
	<Image>
		<ImageID>0</ImageID>
		<ImageGUID>E6F28C62-C066-4CC9-A5F1-B60C066ACA93</ImageGUID>
		<ImageUrl>\1001\100138\E6F28C62C0664CC9A5F1B60C066ACA93.jpg</ImageUrl>
		<UploadedImageUrl>Posted Image Data</UploadedImageUrl>
		<ZoomImageUrl>http://imagecache5d.art.com/watermarker/1001-100138-39ACA660C06B1F5A9CC4660C26C82F6E.jpg</ZoomImageUrl>
		<FrameImageUrl>http://frameimage.art.com/FrameImageHandler/universal/frameimage.jpg?frame=[FAP:0+PRT:[PAP=0|PRW=22.5|PRH=30|PIP=\1001\100138\E6F28C62C0664CC9A5F1B60C066ACA93.jpg|LFL=MCG|PWL=354|PHL=450|PWO=1572|PHO=2000]+MLD:[MID=46|MIP=|MDW=1.125|MDH=0.875]+GLS:0+NMM:1+MT1:[MTD=336|MTP=B71.gif|MTC=F4EDDB|MTL=4.3125|MTT=4.3125|MTR=4.3125|MTB=4.3125|MDP=0.2|MBV=0.08]+MT2:[MTD=0|MTP=|MTC=|MTL=0|MTT=0|MTR=0|MTB=0|MDP=0.2|MBV=0.08]+MT3:[MTD=0|MTP=|MTC=|MTL=0|MTT=0|MTR=0|MTB=0|MDP=0.2|MBV=0.08]+CRP:[CID=0|CRX=0|CRY=0|CRW=354|CRH=450]+LIN:[LID=0|LFN=|LNW=0|LND=0]+CAN:[CVD=0|CVC=|CVF=|CVS=0]+MLF:[FLD=0|FLW=0|FFP=]+LNF:[FLD=0|FLW=0|FFP=]+TMF:[FLD=0|FLW=0|FFP=]+MMF:[FLD=0|FLW=0|FFP=]+BMF:[FLD=0|FLW=0|FFP=]+FDP:0+MXD:500+MXW:0+MXH:0+SHI:5+QLT:101+OVH:[TOH=0|ROH=0|BOH=0|LOH=0]+CRZ:[CZT=0|CRI=4|LPC=0|TPC=0|WPC=0|HPC=0|CMD=0]]</FrameImageUrl>
		<LrgImageUrl>http://imagecache5.art.com/LRG/1001/100138/E6F28C62C0664CC9A5F1B60C066ACA93.jpg</LrgImageUrl>
		<MedImageUrl>http://imagecache5.art.com/MED/1001/100138/E6F28C62C0664CC9A5F1B60C066ACA93.jpg</MedImageUrl>
		<SmlImageUrl>http://imagecache5.art.com/SML/1001/100138/E6F28C62C0664CC9A5F1B60C066ACA93.jpg</SmlImageUrl>
		<PersistentID></PersistentID>
		<AccountID>0</AccountID>
		<ImageSourceTypeID>0</ImageSourceTypeID>
		<OriginalFileSize>2012817</OriginalFileSize>
		<Title></Title>
		<OrigW>1944</OrigW>
		<OrigH>2592</OrigH>
		<XLGW>562</XLGW>
		<XLGH>750</XLGH>
		<ZOOW>670</ZOOW>
		<ZOOH>894</ZOOH>
		<LRGW>337</LRGW>
		<LRGH>450</LRGH>
		<MEDW>120</MEDW>
		<MEDH>160</MEDH>
		<SMLW>86</SMLW>
		<SMLH>115</SMLH>
		<ParentImageID>0</ParentImageID>
		<CropXOriginal>0</CropXOriginal>
		<CropYOriginal>0</CropYOriginal>
		<SharedImageID>0</SharedImageID>
	</Image>
	<ImageXml></ImageXml>
	</ImageUploadResponse>
	 */
	this.ImageId = obj.ImageID;
	this.ImageGuid = obj.ImageGUID;
	
	this.Title = "Customer Photo";
	this.ImageUrl = obj.MedImageUrl;
	this.LrgImageUrl = obj.LrgImageUrl;
	this.ZoomImageUrl = obj.ZoomImageUrl;
	
	this.FileName = obj.fileName;
	this.UploadedImageUrl = obj.UploadedImageUrl;
	this.Type = com.art.core.vos.ImageVO.imageType.UPLOADED;
	this.Price = '';
	this.MasterDisplayPrice = '';
	this.Apnum = 0;
	this.ArtistCategoryId = 0;			
	this.MasterZoneProductId='';
	this.IsCustomerUpload = true;
	this.ItemDisplayedType = "Customer Photo";
	this.PhysicalInchWidth = 0;
	this.PhysicalInchHeight = 0;
	this.TimeToShipDisplayText = "";
};

com.art.core.vos.ImageVO.prototype.parseImageUploadData = function(obj)
{
	/*
	 * from flash
	 <?xml version="1.0" encoding="utf-8"?>
			<SearchImageUploadResponse xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="http://tempuri.org/">
			  <ResponseCode>0</ResponseCode>
			  <ResponseText>Success</ResponseText>
			  <Image>
				<ImageID>100072408</ImageID>
				<ImageGUID>4838DD4B-EC1E-458E-8FF0-AD3020787E34</ImageGUID>
				<ImageUrl>\1000\100072\4838DD4BEC1E458E8FF0AD3020787E34.jpg</ImageUrl>
				<UploadedImageUrl>Posted Image Data</UploadedImageUrl>
				<SrchImageUrl>http://imagecache5.art.com/SRCH/1000/100072/4838DD4BEC1E458E8FF0AD3020787E34.jpg</SrchImageUrl>
				<SrchMedImageUrl>http://imagecache5.art.com/SRCHMED/1000/100072/4838DD4BEC1E458E8FF0AD3020787E34.jpg</SrchMedImageUrl>
				<OrigW>871</OrigW>
				<OrigH>690</OrigH>
				<SRCHW>500</SRCHW>
				<SRCHH>396</SRCHH>
				<SRCHMEDW>160</SRCHMEDW>
				<SRCHMEDH>127</SRCHMEDH>
			  </Image>
			  <ImageXml />
			</SearchImageUploadResponse>
	 */
	this.Title = "Customer Photo";
	this.ImageUrl = obj.SrchMedImageUrl;
	this.LrgImageUrl = obj.SrchImageUrl;
	this.FileName = obj.fileName;
	this.UploadedImageUrl = obj.UploadedImageUrl;
	this.Type = com.art.core.vos.ImageVO.imageType.UPLOADED;
	this.Price = '';
	this.MasterDisplayPrice = '';
	this.Apnum = 0;
	this.ArtistCategoryId = 0;			
	this.MasterZoneProductId='';
	this.IsCustomerUpload = true;
	this.ItemDisplayedType = "Customer Photo";
	this.PhysicalInchWidth = 0;
	this.PhysicalInchHeight = 0;
	this.TimeToShipDisplayText = "";
};
com.art.core.vos.ImageVO.prototype.parseSearchServiceImageDetail = function(imageDetail)
{
	/*
	 * from Search Service
	ImageDetails: [
      {
          o ImageId: 2784742
          o APNum: 3623135
          o Title: "Starry Night, c.1889"
          o ZoneProductID: "1542629765A"
           Artist: {
                + FirstName: "Vincent"
                + LastName: " Van Gogh"
                + ArtistCategoryId: 84
                + ArtistUrl: "/gallery/id--a84/vincent-van-gogh-posters.htm"
            }
             PhysicalDimensions: {
                + Height: 24
                + Width: 32
            }
           ItemPrice: {
                + PriceListName: null
                + Price: 14.99
                + MSRP: 14.99
                + DisplayPrice: "$12.99 - $499.99"
                + MarkDownPrice: "$14.99"
                + ShowMarkDownPrice: false
                + DisplayPriceMaster: "$14.99"
            }
            FulfillmentInformation: {
                  TimeToShip: {
                      # Days: 0
                      # DisplayText: "24 Hours"
                  }
                + ShippingPackageItemId: 0
            }
          o ItemDisplayedType: "Art Print"
          o NumberOfSizes: 18
          o Tags: null
            UrlInfo: {
                + ProductPageUrl: "/products/p1542629765-sa-i2784742/vincent-van-gogh-starry-night-c1889.htm"
                + ImageUrl: http://cache2.artprintimages.com/MED/27/2709/IS5ND00Z.jpg
                + CroppedSquareImageUrl: http://imagecache5d.art.com/CropHandler/crop.jpg?img=27-2709-IS5ND00Z&x=0&y=0&w=400&h=300&size=2&maxw=100&maxh=100&mode=sq&q=100
                + ZoomUrl: http://imagecache5d.art.com/watermarker/27-2709-Z00DN5SI.jpg
                + SuperZoomUrl: http://cache1.artprintimages.com/images/superzoom/27/2709/IS5ND00Z.jpg
             ApnumVariations: [
                + 1113866
                + 1517056
                + 2834316
                + 2834337
                + 3623135
                + 6216702
            ]
          o Score: 0.22
          o AppendShadow: 1
      }
	]	 
*/
	this.Title = imageDetail.Title;
	this.ImageUrl = imageDetail.UrlInfo.ImageUrl;
	this.LrgImageUrl = String(imageDetail.UrlInfo.ImageUrl).replace('/MED','/LRG');
	this.ZoomImageUrl = imageDetail.UrlInfo.ZoomUrl;
	this.NoWatermarkImageUrl = imageDetail.UrlInfo.ZoomUrlWithoutWatermark;
	this.FileName = "";
	this.Type = com.art.core.vos.ImageVO.imageType.CATALOG;
	this.Price = imageDetail.ItemPrice.Price;
	this.MasterDisplayPrice = imageDetail.ItemPrice.DisplayPriceMaster;
	this.Apnum = imageDetail.APNum;
	if (imageDetail.Artist != null)
	{
		if (imageDetail.Artist.FirstName || imageDetail.Artist.LastName)
			this.ArtistName = imageDetail.Artist.FirstName + imageDetail.Artist.LastName;
		else
			this.ArtistName = "";
		this.ArtistCategoryId = imageDetail.Artist.ArtistCategoryId;
		this.ArtistUrl = imageDetail.Artist.ArtistUrl;
	}
	this.MasterZoneProductId = imageDetail.ZoneProductID;
	this.ImageId = imageDetail.ImageId;
	this.IsCustomerUpload = false;
	this.ItemDisplayedType = imageDetail.ItemDisplayedType;
	this.PhysicalInchWidth = imageDetail.PhysicalDimensions.Width;
	this.PhysicalInchHeight = imageDetail.PhysicalDimensions.Height;
	if (imageDetail.FulfillmentInformation)
		this.TimeToShipDisplayText = imageDetail.FulfillmentInformation.TimeToShip.DisplayText;
	this.ProductPageUrl = imageDetail.UrlInfo.ProductPageUrl;
	this.AppendDropShadow = imageDetail.AppendShadow == 1;
	this.CroppedSquareImageUrl = imageDetail.UrlInfo.CroppedSquareImageUrl;
	if (imageDetail.PodInfo !== null && imageDetail.PodInfo !== undefined && imageDetail.PodInfo.MasterPodConfigId !== null && imageDetail.PodInfo.MasterPodConfigId !== undefined)
		this.MasterPodConfigId = imageDetail.PodInfo.MasterPodConfigId;
};

com.art.core.vos.ImageVO.prototype.isSameAs = function(incomingImageVo)
{
	if (this.Apnum == incomingImageVo.Apnum && this.ImageId == incomingImageVo.ImageId)
		return true;
	else
		return false;
};