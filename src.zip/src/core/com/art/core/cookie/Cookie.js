/**
 * Cookie functionality
 * @module cookie
 * @title art.com cookie functionality
 */

/**
 * Convenience class to art.com cookie API
 * @class Cookie
 * @namespace com.art.core.cookie
 * @constructor
 */
com.art.core.cookie.Cookie = function()
{
	
};

/**
 * @method getCookieDomain
 * @param brand
 * @returns {String}
 */
com.art.core.cookie.Cookie.prototype.getCookieDomain = function(brand)
{
    //brand will be passed as "art" or "allposters".
	
	var cookieDomain= "." + brand + ".com"; 
    var  hostName;
    hostName=location.host;
    
    if(hostName.indexOf('www') >= 0)
    	cookieDomain = hostName.indexOf('.', 0) > 0 ? hostName.substring(hostName.indexOf('.', 0)) : hostName;
    
    /*NOTE: In case of http://eu.art.com, it will return .art.com */		
    return cookieDomain;
};

/**
 * @method getCookieDictionary
 * @param dictName
 * @param dictKey
 * @returns {String}
 */
com.art.core.cookie.Cookie.prototype.getCookieDictionary = function(dictName,dictKey)
{
	
	//trace("getCookieDictionary");
	
	   var retval = "";
	   var cookieBase = String(this.getCookieBase(dictName));
	   var arrCookies;
	   var cookieVal;
	   if (cookieBase != null){
		   arrCookies = cookieBase.split("&");
	      for (var i=0; i < arrCookies.length; i++){
	    	  cookieVal = arrCookies[i].split("=");
	         if (cookieVal[0] == dictKey){
	            retval = cookieVal[1];
	            return retval;
	         }
	      }
	   }
	   return retval;
};
/**
 * @method getCookieBase
 * @param name
 * @returns {null}
 */
com.art.core.cookie.Cookie.prototype.getCookieBase = function(name)
{
	   var arg = name + "=";
	   var alen = arg.length;
	   var clen = document.cookie.length;
	   var i = 0;
	   while (i < clen) {
	      var j = i + alen;
	      if (document.cookie.substring(i, j) == arg){
	         return this.getCookieVal (j);
	      }
	      i = document.cookie.indexOf(" ", i) + 1;
	      if (i == 0) {
	         break;
	      }
	   }
	   return null;
};

/**
 * @method getCookieVal
 * @param offset
 * @returns {String}
 */
com.art.core.cookie.Cookie.prototype.getCookieVal = function(offset)
{
	var endstr = document.cookie.indexOf (";", offset);
	if (endstr == -1)
	endstr = document.cookie.length;
	return unescape(document.cookie.substring(offset, endstr));
};

/**
 * @method setCookieDictionary
 * @param dictName
 * @param dictKey
 * @param dictValue
 * @param expires
 * @param path
 * @param domain
 * @param secure
 */
com.art.core.cookie.Cookie.prototype.setCookieDictionary = function(dictName,dictKey,dictValue,path,domain,expires,secure)
{
	   var Dictionary = String(this.getCookieBase(dictName));
	   var newValue = new String();
	   if (Dictionary != "null"){
	      //Then this key exists...but is it a dictionary?
	      if (Dictionary.indexOf("=") > 0){
	         //This value has an equal sign in it, so most likely a dictionary
	         //Now see if this value has the key in that we want
	         if (Dictionary.indexOf(dictKey + "=") >= 0){
	            //Yes this key is already in here, now change its value
	            var arParts = Dictionary.split("&");
	            var arVals = new Array();
	            var indexOfEqual;
	            for (var i = 0; i < arParts.length; i++){
	               indexOfEqual = String(arParts[i]).indexOf("=");
	               //arVals = String(arParts[i]).split("=",1);
	               arVals[0] = String(arParts[i]).substring(0,indexOfEqual);
	               arVals[1] = String(arParts[i]).substring(indexOfEqual+1);
	               //alert('Length: ' + arVals.length + '\n\nName: ' + arVals[0] + '\n\nValue: ' + arVals[1]);

	               if (newValue.length != 0){
	                  newValue += "&";
	               }
	               if (arVals[0] == dictKey){
	                  newValue += arVals[0] + "=" + escape(dictValue);
	               }else{
	                  newValue += arVals[0] + "=" + escape(arVals[1]);
	               }   
	            }
	            this.setCookie(dictName,newValue,path,domain,expires,secure);
	         }else{
	            //No, this key does not exist so add it
	            newValue = Dictionary + "&" + dictKey + "=" + dictValue;
	            this.setCookie(dictName,newValue,path,domain,expires,secure);
	         }
	      }else{
	         //This value is not a dictionary...how to handle?
	      }
	      
	   }else{
	      //This Dictionary has never been created, so create it
	      newValue = dictKey + "=" + dictValue;
	      this.setCookie(dictName,newValue,path,domain,expires,secure);
	   }
};

/**
 * @method setCookie
 * @param name
 * @param value
 * @param expires
 * @param path
 * @param domain
 * @param secure
 */
com.art.core.cookie.Cookie.prototype.setCookie = function(name,value,path,domain,expires,secure)
{
	   var cookieValue = name + "=" + (value) +	   
	   ((path) ? "; path=" + path : "") +
	   ((domain) ? "; domain=" + domain : "") +
	   ((expires) ? "; expires=" + expires.toGMTString() : "") +
	   ((secure) ? "; secure" : "");
	   //trace("cookieValue: "+cookieValue);
	   document.cookie = cookieValue;
};



/**
* Delete a specific cookie from cookie dictionary
* @method delete_cookie
* @param name
*/
com.art.core.cookie.Cookie.prototype.deleteCookie = function(name)
{
    var cookie_date = new Date();  // current date & time
    cookie_date.setTime(cookie_date.getTime() - 1);
    document.cookie = name += "=; expires=" + cookie_date.toGMTString();
};

/**
 * @method getCookie
 * @param name
 * @returns {String}
 */
com.art.core.cookie.Cookie.prototype.getCookie = function(name)
{
	var c_start,c_end;
	if (document.cookie.length>0)
	  {
	  c_start=document.cookie.indexOf(name + "=");
	  if (c_start!=-1)
		{ 
		c_start=c_start + name.length+1; 
		c_end=document.cookie.indexOf(";",c_start);
		if (c_end==-1) c_end=document.cookie.length;
		return unescape(document.cookie.substring(c_start,c_end));
		} 
	  }
	return "";
};