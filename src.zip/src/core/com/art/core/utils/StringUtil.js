com.art.core.utils.StringUtil = function()
{
	
};
/**
 * @param base
 * @param arr
 * 
 * This function will take base string and replace tokens with array elements from arr
 * 
 * example usage
 * var myParams	= ['dev','someOperation',12345,'someSessionID'
 * var url = com.art.core.utils.StringUtil.substitute("http://$0-www.art.com/someService/$1/accountid/$2/sessionid/$3",myParams);
 * returns string http://dev-www.art.com/someService/someOperation/accountid/12345/sessionid/someSessionID
 */
com.art.core.utils.StringUtil.substitute = function(base,arr)
{
	for(var i=0; i < arr.length; i++)
	{
		base = base.replace("$"+i,arr[i]);
	}
	return base;
};

com.art.core.utils.StringUtil.formatDimensions = function(width,height,convertToCm)
{
	var constant = 2.54;
	var printWidth = width;
	var printHeight = height;
	if (convertToCm)
	{
		printWidth = Math.round(width * constant, 2);
		printHeight = Math.round(height * constant, 2);
		return printWidth + " x " + printHeight + " cm";
	}
	return Math.round(printWidth*2)/2 + '" x ' + Math.round(printHeight*2)/2 + '"';
};
com.art.core.utils.StringUtil.formatDimension = function(dimension,convertToCm)
{
	var constant = 2.54;
	var printSide = dimension;
	if (convertToCm)
	{
		printSide = Math.round(dimension * constant, 2);
		return printSide + " cm";
	}
	return Math.round(dimension*2)/2 + '"';
};

/**
 * Generate alpha-numeric key
 * @method
 * @static
 */
com.art.core.utils.StringUtil.generateUID = function(length)
{
	var alpha = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]; //needs to be an array for IE
	var alphaLen = alpha.length-1;
	var nums = ["1","2","3","4","5","6","7","8","9","0"];
	var numsLength = nums.length-1;
	var len = (length != undefined && length >=10) ? length : 10;
	var str = "";
	for(var i=0; i < len; i++)
	{
		var s = Math.round(Math.random() * 1);
		var rand = Math.random();
		if(s == 1)
		{
			
			var k = Math.floor( rand * alphaLen);
			if(alpha[k]==undefined)
				trace("undefined alpha: "+k);
			str += alpha[k];
		}
		else
		{
			var k = Math.floor(rand * numsLength);
			if(nums[k]==undefined)
				trace("undefined num: "+k);
			str += nums[k];
		}
		str = i % 5 == 0 && i > 0? str+="-" : str;
	}
	return str;
};

/**
 * Create ellipse for text longer that specified limit
 * @method autoEllipseText
 * @static
 */
com.art.core.utils.StringUtil.autoEllipseText = function(text, limit)
{
	if(!text)
		throw Error("art.core.Core.autoEllipseText(text,limit) text is undefined");
    var temp;
    if (text.length - 1 > limit)
    {
        temp = text.substring(0, limit) + '...';
    }
    else
    {
        temp = text;
    }
    return temp;
};

/**
 * For a Hash variable input (var hash = {key1:value1,key2:value2,etc...}), 
 * this will return a string formatted as a QueryString (key1=value1&key2=value2&etc...)
 * @method getQueryStringFromHash
 * @param hash
 * @static
 */
com.art.core.utils.StringUtil.getQueryStringFromHash = function(hash)
{
	var returnValue = '';
	var firstLoop = true;
	for (property in hash)
	{
		if(!firstLoop)
			returnValue += "&";
		else
			firstLoop = false;
		returnValue += property + "=" + hash[property];
	}
	return returnValue;
};