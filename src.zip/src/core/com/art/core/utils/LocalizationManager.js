/**
 * The LocalizationManager is the class that will perform language translations.  It is modeled after the 
 * .NET framework for translating.  It exposes a "GetString" method which will be used to translate phrases.
 * It also expects the availability of a language dictionary from which to look up the translation, but will always
 * return the phrase "as-is" (with underscores replaced with spaces) if it does not find a translation.
 * @param environment
 * @param suffix optional to append to all keys at getString call
 */
com.art.core.utils.LocalizationManager = function(environment,suffix)
{
	this.init();
	this.suffix = suffix != undefined ? suffix : "";
    this.environment = environment;
    this.serviceProvider = new com.art.core.services.ServiceProvider(this.environment);
    this.apiKey = "" ;
    this.sessionId = "";
    this.localizationAppId = "";
    this.dictionary = {};
    this.culture = this.environment.languageIso;
    this.defaultPattern = "[LANG]";
    this.isLoaded = false;
    this.LOADED = com.art.core.utils.LocalizationManager.LOADED;
    this.ERROR = com.art.core.utils.LocalizationManager.ERROR;

};
com.art.core.utils.LocalizationManager.LOADED = "loaded";
com.art.core.utils.LocalizationManager.ERROR = "error";


com.art.core.utils.LocalizationManager.prototype.setLanguageDictionary = function(apiKey, sessionId, appId)
{
	this.apiKey = apiKey ;
    this.sessionId = sessionId;
    this.localizationAppId = (appId == undefined) ? "16" : appId;
};

com.art.core.utils.LocalizationManager.prototype.load = function()
{
    //STEP: This needs to fill the dictionary based on the language
	this.getDictionaryData(this.apiKey, this.sessionId, this.localizationAppId);

};

/**
 * This is the main function of the LocalizationManager.  This will take in a base string and will return a string
 * which will be the translation or will be the input string with underscores replaced by spaces.
 */
com.art.core.utils.LocalizationManager.prototype.getString = function (baseString)
{
    var testString = baseString.replace(/ /gi, "_");
    
    var returnValue = this.dictionary[testString+this.suffix];
    
   if (returnValue === undefined)
        returnValue = this.dictionary[testString];
    
    if (returnValue === undefined)
        returnValue = baseString.replace(/_/gi, " ");
    
    //trace('{ LANGUAGE : ' + this.culture + ", baseString : " + baseString + ", testString : " + testString + ", returnValue : " + returnValue);    
    return returnValue;
};
com.art.core.utils.LocalizationManager.prototype.getImageSrcByPattern = function(imagePath,pattern)
{
    return imagePath.replace(pattern,this.culture);
};
com.art.core.utils.LocalizationManager.prototype.getImageSrc = function(imagePath)
{
    return this.getImageSrcByPattern(imagePath, this.defaultPattern);
};
com.art.core.utils.LocalizationManager.prototype.getDictionaryDataOld = function(culture)
{
	/* switch(culture)
    {
        
        case "fr":
            strings['hello_world'] = 'allo monde';
            strings['Canvas'] = 'La Canvasse';
            strings['canvas'] = 'la canvasse';
            strings['choose your options'] = 'choissez vous optiones';
        default:
            strings['hello_world'] = 'hello world';
            strings['Canvas'] = 'Canvas';
            strings['canvas'] = 'canvas';
            strings['choose your options'] = 'choose your options';
        
        case "fr":
            return {'Hello_World':'allo monde',
                    'Canvas' : 'La Canvasse',
                    'canvas' : 'la canvasse',
                    'Framing' : '[French]Framing',
                    'Wood_Mounting' : '[French]Wood Mounting',
                    'Acrylic' : '[French]Acrylic',
                    'Print_Only' : '[French]Print Only',
                    'choose_your_options' : 'choissez vous optiones'};
        default:
            return {'Hello_World':'Hello_World',
            'Canvas' : 'Canvas',
            'Framing' : 'Framing',
            'Wood_Mounting' : 'Wood Mounting',
            'Acrylic' : 'Acrylic',
            'Print_Only' : 'Print Only',
            'canvas' : 'canvas',
            'choose_your_options' : 'choose your options'};
   }*/
   
};

/**
 * This function will take in a languageIso parameter and return the mapped languageId which is unique to art.com system
 * @static
 * @method convertLanguageIsoToLanguageId
 * @param languageIso
 * @returns {String}
 */
com.art.core.utils.LocalizationManager.convertLanguageIsoToLanguageId = function(languageIso)
{
	var n = "1";
	switch(languageIso.toLowerCase())
	{
	    case 'en': n = '1'; break; 
	    case 'fr': n = '2'; break; 
	    case 'de': n = '3'; break; 
	    case 'es': n = '4'; break; 
	    case 'it': n = '5'; break; 
	    case 'ja': n = '6'; break; 
	    case 'nl': n = '7'; break; 
	    case 'se': n = '8'; break; 
	    case 'da': n = '9'; break; 
	    case 'no': n = '10'; break; 
	    case 'fi': n = '11'; break; 
	    case 'pt': n = '12'; break; 
	    case 'pl': n = '13'; break; 
	    case 'zh': n = '14'; break; 
	    case 'tr': n = '15'; break; 
	    case 'cs': n = '16'; break; 
	}
	return n;
};
/**
 * This function will return a time to ship from a dictionary for a given english version.
 * @param timeToShipEnglish
 */
com.art.core.utils.LocalizationManager.getTimeToShipString = function(timeToShipEnglish, languageIso)
{
    timeToShipEnglish = timeToShipEnglish.toLowerCase();
    languageIso = languageIso.toLowerCase();
    var returnValue = timeToShipEnglish;
    // NOTE &#224; means an accented a in french
    if (languageIso.length > 0 && languageIso != 'en')
    {
        var dict = 
        {
                '10-12 days' : {'fr':'10 &#224; 12 jours','de':'10 bis 12 tage'}
        , '10-14 days' : {'fr':'10 &#224; 14 jours','de':'10 bis 14 tage'}
        , '1-2 days' : {'fr':'1 &#224; 2 ours','de':'1 bis 2 tage'}
        , '12-17 days' : {'fr':'12 &#224; 17 jours','de':'12 bis 17 tage'}
        , '14-19 days' : {'fr':'14 &#224; 19 jours','de':'14 bis 19 tage'}
        , '2-3 days' : {'fr':'2 &#224; 3 jours','de':'2 bis 3 tage'}
        , '2-3 weeks' : {'fr':'2 &#224; 3 semaines','de':'2 bis 3 wochen'}
        , '24 hours' : {'fr':'24 heures','de':'24 stunden'}
        , '3-4 weeks' : {'fr':'3 &#224; 4 semaines','de':'3 bis 4 wochen'}
        , '3-5 days' : {'fr':'3 &#224; 5 jours','de':'3 bis 5 werktage'}
        , '4-5 weeks' : {'fr':'4 &#224; 5 semaines','de':'4 bis 5 wochen'}
        , '4-6 days' : {'fr':'4 &#224; 6 jours','de':'4 bis 6 tage'}
        , '5+ weeks' : {'fr':'plus de 5 semaines','de':'ca. 5 wochen'}
        , '5-10 days' : {'fr':'5 &#224; 10 jours','de':'5 bis 10 tage'}
        , '5-6 days' : {'fr':'5 &#224; 6 jours','de':'5 bis 6 tage'}
        , '5-7 days' : {'fr':'5 &#224; 7 jours','de':'5 bis 7 tage'}
        , '7-9 days' : {'fr':'7 &#224; 9 jours','de':'7 bis 9 tage'}
        };
        var phraseRow = dict[timeToShipEnglish];
        if (phraseRow != undefined)
        {
            var phrase = phraseRow[languageIso];
            if (phrase != undefined)
                returnValue = phrase;
        }
    }
    return returnValue;
};

/**
 * This function will take in the A2 Iso Code for a country and return the equivalent Iso Number for that country
 */
com.art.core.utils.LocalizationManager.convertCountryIsoA2ToCountryIsoNumber = function(countryIsoA2)
{
    var n = "840";
    switch(countryIsoA2.toUpperCase())
    {
        case 'AD': n = '20'; break; 
        case 'AE': n = '784'; break; 
        case 'AF': n = '4'; break; 
        case 'AG': n = '28'; break; 
        case 'AI': n = '660'; break; 
        case 'AL': n = '8'; break; 
        case 'AM': n = '51'; break; 
        case 'AN': n = '530'; break; 
        case 'AO': n = '24'; break; 
        case 'AQ': n = '10'; break; 
        case 'AR': n = '32'; break; 
        case 'AS': n = '16'; break; 
        case 'AT': n = '40'; break; 
        case 'AU': n = '36'; break; 
        case 'AW': n = '533'; break; 
        case 'AZ': n = '31'; break; 
        case 'BA': n = '70'; break; 
        case 'BB': n = '52'; break; 
        case 'BD': n = '50'; break; 
        case 'BE': n = '56'; break; 
        case 'BF': n = '854'; break; 
        case 'BG': n = '100'; break; 
        case 'BH': n = '48'; break; 
        case 'BI': n = '108'; break; 
        case 'BJ': n = '204'; break; 
        case 'BM': n = '60'; break; 
        case 'BN': n = '96'; break; 
        case 'BO': n = '68'; break; 
        case 'BR': n = '76'; break; 
        case 'BS': n = '44'; break; 
        case 'BT': n = '64'; break; 
        case 'BV': n = '74'; break; 
        case 'BW': n = '72'; break; 
        case 'BY': n = '112'; break; 
        case 'BZ': n = '84'; break; 
        case 'CA': n = '124'; break; 
        case 'CC': n = '166'; break; 
        case 'CD': n = '180'; break; 
        case 'CF': n = '140'; break; 
        case 'CG': n = '178'; break; 
        case 'CH': n = '756'; break; 
        case 'CI': n = '384'; break; 
        case 'CK': n = '184'; break; 
        case 'CL': n = '152'; break; 
        case 'CM': n = '120'; break; 
        case 'CN': n = '156'; break; 
        case 'CO': n = '170'; break; 
        case 'CR': n = '188'; break; 
        case 'CS': n = '891'; break; 
        case 'CU': n = '192'; break; 
        case 'CV': n = '132'; break; 
        case 'CX': n = '162'; break; 
        case 'CY': n = '196'; break; 
        case 'CZ': n = '203'; break; 
        case 'DE': n = '276'; break; 
        case 'DJ': n = '262'; break; 
        case 'DK': n = '208'; break; 
        case 'DM': n = '212'; break; 
        case 'DO': n = '214'; break; 
        case 'DZ': n = '12'; break; 
        case 'EC': n = '218'; break; 
        case 'EE': n = '233'; break; 
        case 'EG': n = '818'; break; 
        case 'EH': n = '732'; break; 
        case 'ER': n = '232'; break; 
        case 'ES': n = '724'; break; 
        case 'ET': n = '231'; break; 
        case 'EU': n = '*'; break; 
        case 'FI': n = '246'; break; 
        case 'FJ': n = '242'; break; 
        case 'FK': n = '238'; break; 
        case 'FM': n = '583'; break; 
        case 'FO': n = '234'; break; 
        case 'FR': n = '250'; break; 
        case 'FX': n = '249'; break; 
        case 'GA': n = '266'; break; 
        case 'GB': n = '826'; break; 
        case 'GD': n = '308'; break; 
        case 'GE': n = '268'; break; 
        case 'GF': n = '254'; break; 
        case 'GH': n = '288'; break; 
        case 'GI': n = '292'; break; 
        case 'GL': n = '304'; break; 
        case 'GM': n = '270'; break; 
        case 'GN': n = '324'; break; 
        case 'GP': n = '312'; break; 
        case 'GQ': n = '226'; break; 
        case 'GR': n = '300'; break; 
        case 'GS': n = '239'; break; 
        case 'GT': n = '320'; break; 
        case 'GU': n = '316'; break; 
        case 'GW': n = '624'; break; 
        case 'GY': n = '328'; break; 
        case 'HK': n = '344'; break; 
        case 'HM': n = '334'; break; 
        case 'HN': n = '340'; break; 
        case 'HR': n = '191'; break; 
        case 'HT': n = '332'; break; 
        case 'HU': n = '348'; break; 
        case 'ID': n = '360'; break; 
        case 'IE': n = '372'; break; 
        case 'IL': n = '376'; break; 
        case 'IN': n = '356'; break; 
        case 'IO': n = '86'; break; 
        case 'IQ': n = '368'; break; 
        case 'IR': n = '364'; break; 
        case 'IS': n = '352'; break; 
        case 'IT': n = '380'; break; 
        case 'JM': n = '388'; break; 
        case 'JO': n = '400'; break; 
        case 'JP': n = '392'; break; 
        case 'KE': n = '404'; break; 
        case 'KG': n = '417'; break; 
        case 'KH': n = '116'; break; 
        case 'KI': n = '296'; break; 
        case 'KM': n = '174'; break; 
        case 'KN': n = '659'; break; 
        case 'KP': n = '408'; break; 
        case 'KR': n = '410'; break; 
        case 'KW': n = '414'; break; 
        case 'KY': n = '136'; break; 
        case 'KZ': n = '398'; break; 
        case 'LA': n = '418'; break; 
        case 'LB': n = '422'; break; 
        case 'LC': n = '662'; break; 
        case 'LI': n = '438'; break; 
        case 'LK': n = '144'; break; 
        case 'LR': n = '430'; break; 
        case 'LS': n = '426'; break; 
        case 'LT': n = '440'; break; 
        case 'LU': n = '442'; break; 
        case 'LV': n = '428'; break; 
        case 'LY': n = '434'; break; 
        case 'MA': n = '504'; break; 
        case 'MC': n = '492'; break; 
        case 'MD': n = '498'; break; 
        case 'MG': n = '450'; break; 
        case 'MH': n = '584'; break; 
        case 'MK': n = '807'; break; 
        case 'ML': n = '466'; break; 
        case 'MM': n = '104'; break; 
        case 'MN': n = '496'; break; 
        case 'MO': n = '446'; break; 
        case 'MP': n = '580'; break; 
        case 'MQ': n = '474'; break; 
        case 'MR': n = '478'; break; 
        case 'MS': n = '500'; break; 
        case 'MT': n = '470'; break; 
        case 'MU': n = '480'; break; 
        case 'MV': n = '462'; break; 
        case 'MW': n = '454'; break; 
        case 'MX': n = '484'; break; 
        case 'MY': n = '458'; break; 
        case 'MZ': n = '508'; break; 
        case 'NA': n = '516'; break; 
        case 'NC': n = '540'; break; 
        case 'NE': n = '562'; break; 
        case 'NF': n = '574'; break; 
        case 'NG': n = '566'; break; 
        case 'NI': n = '558'; break; 
        case 'NL': n = '528'; break; 
        case 'NO': n = '578'; break; 
        case 'NP': n = '524'; break; 
        case 'NR': n = '520'; break; 
        case 'NU': n = '570'; break; 
        case 'NZ': n = '554'; break; 
        case 'OM': n = '512'; break; 
        case 'PA': n = '591'; break; 
        case 'PE': n = '604'; break; 
        case 'PF': n = '258'; break; 
        case 'PG': n = '598'; break; 
        case 'PH': n = '608'; break; 
        case 'PK': n = '586'; break; 
        case 'PL': n = '616'; break; 
        case 'PM': n = '666'; break; 
        case 'PN': n = '612'; break; 
        case 'PR': n = '630'; break; 
        case 'PT': n = '620'; break; 
        case 'PW': n = '585'; break; 
        case 'PY': n = '600'; break; 
        case 'QA': n = '634'; break; 
        case 'RE': n = '638'; break; 
        case 'RO': n = '642'; break; 
        case 'RU': n = '643'; break; 
        case 'RW': n = '646'; break; 
        case 'SA': n = '682'; break; 
        case 'SB': n = '90'; break; 
        case 'SC': n = '690'; break; 
        case 'SD': n = '736'; break; 
        case 'SE': n = '752'; break; 
        case 'SG': n = '702'; break; 
        case 'SH': n = '654'; break; 
        case 'SI': n = '705'; break; 
        case 'SJ': n = '744'; break; 
        case 'SK': n = '703'; break; 
        case 'SL': n = '694'; break; 
        case 'SM': n = '674'; break; 
        case 'SN': n = '686'; break; 
        case 'SO': n = '706'; break; 
        case 'SR': n = '740'; break; 
        case 'ST': n = '678'; break; 
        case 'SV': n = '222'; break; 
        case 'SY': n = '760'; break; 
        case 'SZ': n = '748'; break; 
        case 'TC': n = '796'; break; 
        case 'TD': n = '148'; break; 
        case 'TF': n = '260'; break; 
        case 'TG': n = '768'; break; 
        case 'TH': n = '764'; break; 
        case 'TJ': n = '762'; break; 
        case 'TK': n = '772'; break; 
        case 'TM': n = '795'; break; 
        case 'TN': n = '788'; break; 
        case 'TO': n = '776'; break; 
        case 'TP': n = '626'; break; 
        case 'TR': n = '792'; break; 
        case 'TT': n = '780'; break; 
        case 'TV': n = '798'; break; 
        case 'TW': n = '158'; break; 
        case 'TZ': n = '834'; break; 
        case 'UA': n = '804'; break; 
        case 'UG': n = '800'; break; 
        case 'UM': n = '581'; break; 
        case 'US': n = '840'; break; 
        case 'UY': n = '858'; break; 
        case 'UZ': n = '860'; break; 
        case 'VA': n = '336'; break; 
        case 'VC': n = '670'; break; 
        case 'VE': n = '862'; break; 
        case 'VG': n = '92'; break; 
        case 'VI': n = '850'; break; 
        case 'VN': n = '704'; break; 
        case 'VU': n = '548'; break; 
        case 'WF': n = '876'; break; 
        case 'WS': n = '882'; break; 
        case 'YE': n = '887'; break; 
        case 'YT': n = '175'; break; 
        case 'ZA': n = '710'; break; 
        case 'ZM': n = '894'; break; 
        case 'ZW': n = '716'; break; 
    }
    return n;
};
/**
 * A static function that will house the business rule for the client application in order determine if an Inch value needs to be converted to a
 * centimeter value.
 * @param userCountry
 * @param userCurrency
 * @param userLanguage
 * @returns {Boolean}
 */
com.art.core.utils.LocalizationManager.determineConvertToCm = function(userCountry, userCurrency, userLanguage)
{
	//STEP: This is the current business rule: if the currency != USD, then doConvert
	var returnValue = true;
	if (userCurrency.toLowerCase() == 'usd')
		returnValue = false;
	return returnValue;
};

com.art.core.utils.LocalizationManager.prototype.getDictionaryData = function(apiKey, sessionId, appId)
{
	var handlers = this.serviceProvider.createHandlers(
			this.getLanguageTranslationsSuccess
			,
			this.getLanguageTranslationsFailure
			,
			function(){}
	);
	
	//add reference to LocalizationManager object
	handlers.localizationManager = this;
	
	this.serviceProvider.ecommerceAPIService.getLanguageTranslations(
            handlers
            ,apiKey
	        ,sessionId
            ,appId
	);
	//trace(this.errorObjToString(errObj));
};

com.art.core.utils.LocalizationManager.prototype.getLanguageTranslationsFailure = function(response)
{           
    if(this.localizationManager.callbacks[this.localizationManager.ERROR] != undefined)
        this.localizationManager.callbacks[this.localizationManager.ERROR](err);
};
com.art.core.utils.LocalizationManager.prototype.getLanguageTranslationsSuccess = function(response)
{
	this.dictionaryNew = {};
	//if(response.LanguageKeyValuePairs.length == 0)
		//throw new Error("LocalizationManager.getLanguageTranslationsSuccess failed! Translations are empty.");
    	
    	//NOTE: Application Configuration - Caching the Environment Variable
        try
        {
            for (var i=0; i<response.LanguageKeyValuePairs.length; i++)
            {
            	var tmp = response.LanguageKeyValuePairs[i];
            	this.localizationManager.dictionary[tmp.Key] = tmp.Value;
            	//trace(tmp.Key + '  '+ tmp.Value);
            }
            
            if(this.localizationManager.callbacks[this.localizationManager.LOADED] != undefined)
            {
            	this.localizationManager.callbacks[this.localizationManager.LOADED]();
            }
        }
        catch(err){
        	if(this.localizationManager.callbacks[this.localizationManager.ERROR] != undefined)
        		this.localizationManager.callbacks[this.localizationManager.ERROR](err);
        }
             	
};
com.art.core.components.BaseComponent.extend(com.art.core.utils.LocalizationManager.prototype);
