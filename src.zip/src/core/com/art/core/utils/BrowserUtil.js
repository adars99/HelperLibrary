/**
 * Browser utility to access common browser related information
 * @class BrowserUtil
 * @static
 * 
 */
com.art.core.utils.BrowserUtil = function () { };
com.art.core.utils.BrowserUtil.cropperModes = {};
com.art.core.utils.BrowserUtil.cropperModes.NONE = "none";
com.art.core.utils.BrowserUtil.cropperModes.SQUARE = "square";

/**
 * pass in key for desired value from url query string
 * @method getQueryString
 * @static
 */
com.art.core.utils.BrowserUtil.getQueryString = function(name)
{
	name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
	var regexS = "[\\?&]"+name+"=([^&#]*)";
	var regex = new RegExp( regexS );
	var url = location.href;
	var results = regex.exec( url );
	if( results == null )
	   return "";
	else
	   return decodeURIComponent(results[1].replace(/\+/g, " "));
};


/**
 * Valid url:
 * ex: http://qa-frameimage.art.com/FrameImageHandler/universal/frameimage.jpg?frame=[FAP:0+PRT:[PAP=0|PRW=17.78|PRH=8|PIP=\1007\100787\D03FAE25CAD7426C975D5E24F7534C21.jpg|PWL=400|PHL=180]+NMM:0+CAN:[ECR=423934|ECB=1D1714|BKC=FFFFFF|EDW=1.5|GWP=0]+MXW:1024+MXH:1024+CRP:[CID=1|CRX=0|CRY=23|CRW=400|CRH=133]]
 * 
 */
com.art.core.utils.BrowserUtil.getCroppedImageUrl = function(url,maxW,maxH,mode,width,height)
{
	var w = width == undefined ? 1000 : width;
	var h = height == undefined ? 1000 : height;
	var aspectRatio = w/h;	
    
    if(url.indexOf('frameimage')>-1)
    {
	    var finalUrl =url.replace(/MXW:[0-9]+/,"MXW:"+maxW).replace(/MXH:[0-9]+/,"MXH:"+maxH);	
    }
    else
    {
    	var mode =  mode == com.art.core.utils.BrowserUtil.cropperModes.NONE ? "" : "mode=sq&";
    	//var finalUrl = url.replace(/x=[0-9]+/,"x=0").replace(/y=[0-9]+/,"y=0").replace(/w=[0-9]+/,"w="+w).replace(/h=[0-9]+/,"h="+h).replace(/maxw=[0-9]+/,"maxw="+(maxW-20)).replace(/maxh=[0-9]+/,"maxh="+(maxH-20)).replace("mode=sq&",mode);
    	var finalUrl = url.replace(/x=[0-9]+/,"x=0").replace(/y=[0-9]+/,"y=0").replace(/w=[0-9]+/,"w="+w).replace(/h=[0-9]+/,"h="+h).replace(/maxw=[0-9]+/,"maxw="+(maxW)).replace(/maxh=[0-9]+/,"maxh="+(maxH)).replace("mode=sq&",mode);
    }
	return finalUrl;
};
/**
 * Find the next highest z-index value in DOM on page
 * @method getNextHighestZIndex
 * @static
 */
com.art.core.utils.BrowserUtil.getNextHighestZIndex = function()
{
	var z = 1;
	var count = 0;
	$("*").each(function(){
		var zindex = parseInt($(this).css("z-index"));
		if(zindex >= z && zindex != Number.NaN)
				z = zindex + 1; //zindex my skip random number of values, so we can't simpy increment
			
	});
	return z;
};
/**
*Check if remote image exists
*handy for calling fallback images
*static call
* passThruObject Object that get's passed directly to success/failure handlers
* url String
* successCallback String
* 	example
*	MyClass.prototype.successCallback = function(uniqueID,url){
*		//do something;
*	}
* failureCallback String
* 	example
*   MyClass.prototype.failureCallback = function(uniqueID,url){
*   	//do something
*  	}
* context calling object reference
* 	example
* 	MyClass.prototype.run = function(id,url){
* 		com.art.core.utils.BrowserUtil.checkIfRemoteImageExists(id,url,'successCallback','failureCallback',this);
* 	}
* 	...
* 	var myKlass = new MyClass();
* 	//check if image exists
* 	myKlass.run('abc123','http://someImageUrl/images/test1.jpg');
**/
com.art.core.utils.BrowserUtil.checkIfRemoteImageExists = function(passThruObject,url,successCallback,failureCallback, context)
{
	var uid = com.art.core.utils.StringUtil.generateUID(32);
	var key = "_"+uid;
	trace("key: "+key);
	$("body").append("<img id='"+key+"'/>");
	var o = $("#"+key);
	o.css("opacity","0");
	o.css({width:"0px",height:"0px"});
	o.imagesLoaded(function(){
		o.remove(); //cleanup
		context[successCallback](passThruObject,url);
	}).error(function(){
		o.remove(); //cleanup
		context[failureCallback](passThruObject,url);
	});
	o.attr("src",url); //"http://www.google.com/intl/en_com/images/srpr/logo3w.png");
};