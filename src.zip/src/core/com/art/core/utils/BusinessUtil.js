com.art.core.utils.BusinessUtil = function () { };

com.art.core.utils.BusinessUtil.getFramedItemAddToCartUrl = function(frameid, apNum, sessionId)
{
	return "/asp/place_order.asp/_/posters.htm?CREATE_BSK=Y&MasterNum="+apNum+"&ui="+sessionId+"&FrameID="+frameid;
};

com.art.core.utils.BusinessUtil.getSimpleAddToCartUrl = function(sku,podconfigid, specialHandlingID, sessionId)
{

   var podQueryString="";
   if(podconfigid!=undefined && podconfigid > 0 )
   {
     podQueryString="&PODConfigID="+podconfigid;
   }
   else
   {
     podQueryString="&PODConfigID=0";
   }

   var serviceType = "";
   
   switch(specialHandlingID)
   {   
	case 2:
		serviceType = "M";
	   break;
	case 6 :
		serviceType = "L";
		break;
	}
   if(sku != null && sku.trim().length >0)
   {
		var pdta = sku.substring(0, sku.length - 1);
	    var specID = sku.substring(sku.length - 1, sku.length);
		var url = "/asp/place_order.asp/_/pdta--" + pdta + "/sp--"+ specID +"/posters.htm?add_to_cart=Y&ui="+sessionId+"&IID=" + podQueryString;
		if(serviceType.trim().length > 0)
		{
			url += "&ServiceType="+serviceType+"";
		}
		return url;
	}
   else
   {
	   return "/asp/place_order.asp";
   }
};
com.art.core.utils.BusinessUtil.GetApnumFromFrameSku = function(FrameSku){     
    
    var apnum;
    if (FrameSku.length>0)
    {
        var frameSkuArr = FrameSku.split('-');          
        var framSkuArrFirstVal=frameSkuArr[0];
        if (framSkuArrFirstVal.indexOf("_")>-1)
        {
            var apnumArr = framSkuArrFirstVal.split('_');
            apnum = apnumArr[0];
        }
        else
            apnum = frameSkuArr[0];
    }
    return apnum;
};
