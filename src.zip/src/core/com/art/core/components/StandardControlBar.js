com.art.core.components.StandardControlBar = function(id,usePlayControls,leftButtonLabel,rightButtonLabel)
{
	this.init();
	this.id = id;
	this.usePlayControls = usePlayControls;
	this.leftActionButton = new com.art.core.components.ArtButton(id + "_leftButton", com.art.core.components.ArtButton.ART_ORANGE, leftButtonLabel);
    this.rightActionButton = new com.art.core.components.ArtButton(id + "_RightButton", com.art.core.components.ArtButton.ART_BLUE, rightButtonLabel);
	this.centerToParentFlag = false;
	this.externalComponent = "";
	this.price="";
	this.salePrice="";

};
com.art.core.components.StandardControlBar.prototype.render = function(centerToParentFlag)
{
	this.centerToParentFlag = centerToParentFlag;
	var playControls = this.usePlayControls ? this.playControlsTemplate : "";
	var width = this.usePlayControls ? 567 : 400;
	var ec = this.externalComponent == "" ? "" : this.externalComponent;
	var str = this.template.replace("$PLAY_CONTROLS",playControls).replace(/\$ID/g,this.id).replace("$RIGHT_ACTION_BTN", this.rightActionButton.render()).replace("$LEFT_ACTION_BTN",this.leftActionButton.render()).replace("$W",width).replace("$EXT_BTN",ec).replace("$ZINDEX", this.zindex).replace("$PRICE",this.price).replace("$SALE_PRICE",this.salePrice).replace(/\$IMAGE_HOST/g, this.getImageHost());
	return str;
};
com.art.core.components.StandardControlBar.prototype.centerToParent = function()
{
	$("#"+this.id+"_CONTROL_BAR").centerNoDropShadow();
};
com.art.core.components.StandardControlBar.prototype.position = function(p)
{
	$("#"+this.id+"_CONTROL_BAR").css("position",p);
};
com.art.core.components.StandardControlBar.prototype.height = function()
{
	return $("#"+this.id+"_CONTROL_BAR").height();
};
com.art.core.components.StandardControlBar.prototype.width = function()
{
	return $("#"+this.id+"_CONTROL_BAR").width();
};
com.art.core.components.StandardControlBar.prototype.isHidden = function()
{
	return $("#"+this.id+"_CONTROL_BAR").is(':hidden');
};
com.art.core.components.StandardControlBar.prototype.top = function(t)
{
	$("#"+this.id+"_CONTROL_BAR").css("top",t+"px");
};
com.art.core.components.StandardControlBar.prototype.fadeIn = function(t)
{
	$("#"+this.id+"_CONTROL_BAR").fadeIn();
};
com.art.core.components.StandardControlBar.prototype.fadeOut = function(t)
{
	$("#"+this.id+"_CONTROL_BAR").fadeOut();
};
com.art.core.components.StandardControlBar.prototype.left = function(l)
{
	$("#"+this.id+"_CONTROL_BAR").css("left",l+"px");
};
com.art.core.components.StandardControlBar.prototype.setPrice = function(value)
{
	var id = $("#"+this.id+"_price").attr("id");
	this.price = value;
	if(id != null)
		$("#"+id).html(value);
};
com.art.core.components.StandardControlBar.prototype.setSalePrice = function(value)
{
	var id = $("#"+this.id+"_salePrice").attr("id");
	this.salePrice = value;
	if(id != null)
		$("#"+id).html(value);
};
com.art.core.components.StandardControlBar.prototype.attachExternalComponent = function(str)
{
	var w = $("#"+this.id+"_externalButtonContainer").width();
	trace("StandardControlBar.attachExternalComponent w:"+w);
	if(w == null)
		this.externalComponent = str;
	else
		$("#"+this.id+"_externalButtonContainer").html(str);
};
com.art.core.components.StandardControlBar.prototype.close = function()
{
	this.leftActionButton.destroy();
	this.rightActionButton.destroy();
	$("#"+this.id+"_CONTROL_BAR").remove();
};
com.art.core.components.StandardControlBar.prototype.registerEvents = function()
{
	this.leftActionButton.registerEvents();
	this.rightActionButton.registerEvents();
	if(this.centerToParentFlag)
		this.centerToParent();
};
com.art.core.components.StandardControlBar.prototype.playControlsTemplate =
	"<div id='$ID_previousButton' style='cursor:pointer;float:left;margin-top:26px;width:26px; height:25px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:-90px -606px;background-repeat:no-repeat;'></div>"+
	"<div id='$ID_playPauseButton' style='cursor:pointer;float:left;margin-top:20px;margin-left:3px;width:38px; height:38px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:0px -606px;background-repeat:no-repeat;'></div>"+
	"<div id='$ID_nextButton' style='cursor:pointer;float:left;margin-top:26px;margin-left:3px;width:26px; height:25px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:-120px -606px;background-repeat:no-repeat;'></div>"+
	"<div style='margin-top:20px;width:1px;height:38px;display:inline-block;float:left;margin-left:5px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:-637px 0px;background-repeat:no-repeat;'></div>";
com.art.core.components.StandardControlBar.prototype.template =
	"<div id='$ID_CONTROL_BAR' style='background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:0px -493px;z-index:$ZINDEX;background-repeat:no-repeat;width:$Wpx;height:73px;padding-left:20px;'>"+
	"$PLAY_CONTROLS"+
	"<div id='$ID_externalButtonContainer' style='margin-top:12px; margin-left:2px; float:left;display:inline-block;'>$EXT_BTN</div>"+
	"<div style='background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:-599px -493px;height:73px; width:9px;display:inline-block;float:right;margin-right:-9px;'/>"+
	"<div id='controlButtonLeft' style='margin-top:23px;margin-right:15px;float:right;display:inline-block;'>$RIGHT_ACTION_BTN</div>"+
	"<div id='controlButtonRight' style='margin-top:23px;float:right;display:inline-block;'>$LEFT_ACTION_BTN</div>"+
	"<div id='$ID_salePrice' style='text-shadow:0 1px #FFFFFF;font-family: Verdana,Arial,sans-serif;font-size: 11px;font-style: italic;font-weight: bold;color: #EC2127;display:inline-block;margin-top:29px;margin-right:10px;float:right;'>$SALE_PRICE</div>"+
	"<div id='$ID_price' style='text-shadow:0 1px #FFFFFF;color: #666;font-family: Verdana,Arial,sans-serif;text-decoration: line-through;font-size: 11px;display:inline-block;margin-top:29px;margin-right:10px;float:right;'>$PRICE</div>"+
	"<div style='clear:both;'></div>"+
"</div>";
com.art.core.components.BaseComponent.extend(com.art.core.components.StandardControlBar.prototype);