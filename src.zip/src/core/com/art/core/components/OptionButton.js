com.art.core.components.OptionButton = function (id, label,w,h,options,icon) {
   this.init();
   this.id = id;
   this.label = label;
   this.width = w;
   this.height = h;
   this.options = options;
   this.icon = icon;
   this.menuIsOpen = false;
   this.hovers = {tl:{position:"-340px -88px"},tm:{position:"-341px -88px"}, tr:{position:"-556px -88px"},ml:{position:"-340px -90px"},mm:{position:"-341px -90px"},mr:{position:"-556px -90px"},bl:{position:"-340px -214px"},bm:{position:"-341px -214px"},br:{position:"-556px -214px"}};
   this.generateUIDs();
   this.offsetObject;
   this.menuWidth = 100; //default
   this.optionsSelectedMap = {};
   this.closeTimer;
   this.MENU_OPENED = com.art.core.components.OptionButton.MENU_OPENED;
   this.MENU_CLOSED = com.art.core.components.OptionButton.MENU_CLOSED;
};
com.art.core.components.OptionButton.NAME = "OptionButton";
com.art.core.components.OptionButton.MENU_OPENED = "optionButtonOpened";
com.art.core.components.OptionButton.MENU_CLOSED = "optionButtonClosed";
com.art.core.components.OptionButton.HOVER = "hover";
com.art.core.components.OptionButton.FLYOUT_ITEM_CLICK = "flyoutItemClicked";
com.art.core.components.OptionButton.COLOR_PICKER_CLICK = "colorPickerItemClicked";
com.art.core.components.OptionButton.prototype.render = function () {
    return this.getTemplate();
};

com.art.core.components.OptionButton.prototype.generateUIDs = function()
{
	for(var key in this.hovers)
	{
		this.hovers[key]["uid"] = com.art.core.utils.StringUtil.generateUID();
	}
};
com.art.core.components.OptionButton.prototype.registerEvents = function () {
    
	
	
    var _this = this;
    $("#" + this.id).live("click", function () {

        if (this.id != null && this.id != undefined) {

            $("#" + this.id + "_toggle").show();
        }
    });

    $("#" + this.id).mouseleave(function () {
        if (this.id != null && this.id != undefined) {
            switch (this.id) {
                case "background": case "sortby": case "privacy": case "share":

                    $("#" + this.id).removeClass("dynamicRightMenuContainer");
                    $("#" + this.id + "_toggle").hide();
                    break;
                default:
                    trace("others");
            }
        }
    });

    $("#" + this.id).mouseenter(function () {
        if (this.id != null && this.id != undefined) {
            switch (this.id) {
                case "background": case "sortby": case "privacy": case "share":

                    $("#" + this.id).addClass("dynamicRightMenuContainer");
                    break;
                default:
                    trace("others");
            }
        }
        var obj = { typeOfData: "FlyoutLinkClicked" };
        if (_this.callbacks[com.art.core.components.OptionButton.CLICK] != undefined) {
            _this.callbacks[com.art.core.components.OptionButton.CLICK](obj);
        }
    });
    var old = "";
    var flag = false;
    $("#" + this.id + "_toggle li").live("click", function () {
        if (_this.callbacks[com.art.core.components.OptionButton.COLOR_PICKER_CLICK] != null && _this.callbacks[com.art.core.components.OptionButton.COLOR_PICKER_CLICK] != undefined) {

            if (flag == true) {
                $("#" + old).add(document.getElementById("a")).css("border", "1px solid White");
                $("#" + this.id).add(document.getElementById("a")).css("border", "1px solid Red");
                old = this.id;
                flag = true;
            }
            if (flag == false) {
                old = this.id;
                $("#" + old).add(document.getElementById("a")).css("border", "1px solid Red");
                flag = true;
            }

            _this.callbacks[com.art.core.components.OptionButton.COLOR_PICKER_CLICK](this);
        }
    });

    $("#" + this.id + "_toggle a").live("click", function () {

        if (_this.callbacks[com.art.core.components.OptionButton.FLYOUT_ITEM_CLICK] != null && _this.callbacks[com.art.core.components.OptionButton.FLYOUT_ITEM_CLICK] != undefined) {
            $(".imgTick").css("visibility", "hidden");
            $("#img" + this.id).css("visibility", "visible");
            _this.callbacks[com.art.core.components.OptionButton.FLYOUT_ITEM_CLICK](this);
        }
    });
};
com.art.core.components.OptionButton.prototype.registerEvents = function ()
{
	trace("OptionButton.registerEvents");
	var _this = this;
	$("#"+this.id).mouseenter(function(){
		trace("mouseenter menuIsOpen: "+_this.menuIsOpen);
		if(_this.menuIsOpen)
		{
			trace("OptionButton.mouseenter clearTimeout");
			clearTimeout(_this.closeTimer); //don't close when mouse over button
		}
		else
		{
			$(this).css("cursor","pointer");
			for(var key in _this.hovers)
			{
				$("#"+_this.hovers[key].uid).css("background-position",_this.hovers[key].position);
			}
		}
	});
	
	$("#"+this.id).mouseleave(function(){
		if(!_this.menuIsOpen)
		{
			$(this).css("cursor","default");
			$(this).find("td").css("background-position","1000px 1000px");
		}
	});
	
	$("#"+this.id).unbind("click");
	$("#"+this.id).click(function(e){
		trace("OptionButton clicked");
		_this.menuIsOpen = !_this.menuIsOpen;
		
		if(_this.menuIsOpen)
		{
			_this.offsetObject = $(this).offset();
			var tmpl = _this.getMenuContainerTemplate();
			trace("optionButton opened: "+tmpl);
			$("body").append(tmpl);
			_this.positionMenu();
			_this.registerOptionEvents();
			if(_this.callbacks[_this.MENU_OPENED])
				_this.callbacks[_this.MENU_OPENED]();
		}
		else
		{
			trace("close optionButton");
			$("#"+this.id+"_menuContainer").remove();
			if(_this.callbacks[_this.MENU_CLOSED])
				_this.callbacks[_this.MENU_CLOSED]();
		}
		
	});
   
};
com.art.core.components.OptionButton.prototype.positionMenu = function()
{
	var _this = this;
	$("#"+this.id+"_menuContainer").mouseleave(function(){
		_this.initiateClose();
	});
	var t = Math.round(this.offsetObject.top)+this.height;
	var l = Math.round(this.offsetObject.left);
	trace("positionMenu top: "+t);
	trace("positionMenu left: "+l);
	$("#"+this.id+"_menuContainer").css("top",t);
	$("#"+this.id+"_menuContainer").css("left",l);
};
com.art.core.components.OptionButton.prototype.initiateClose = function()
{
	var _this = this;
	this.closeTimer = setTimeout(function(){
		trace("OptionButton.initiateClose called");
		_this.closeMenu();
	},100);
};
com.art.core.components.OptionButton.prototype.closeMenu = function()
{
	if(this.menuIsOpen)
	{
		this.menuIsOpen = false;
		$("#"+this.id).find("td").css("background-position","1000px 1000px");
		$("#"+this.id).css("cursor","default");
		$("#"+this.id+"_menuContainer").remove();
		if(this.callbacks[this.MENU_CLOSED])
			this.callbacks[this.MENU_CLOSED]();
	}
};
com.art.core.components.OptionButton.prototype.registerOptionEvents = function()
{
	
	var menu = $("#"+this.id+"_menuContainer");
	menu.addDropShadow();
	this.bindAllEvents(menu);
};
com.art.core.components.OptionButton.prototype.onMouseEnter = function(obj)
{
	obj.css("cursor","pointer");
	obj.css("background-color","#DDDDDD");
};
com.art.core.components.OptionButton.prototype.onMouseLeave = function(obj)
{
	obj.css("background-color","#FFFFFF");
};
com.art.core.components.OptionButton.prototype.onMouseDown = function(obj)
{
	obj.parent().find('li').css("background-color","#FFFFFF");
	obj.parent().find('li').css("text-shadow","0px 0px #FFFFFF");
	obj.parent().find('li>div').css("background-position","1000px 1000px");
	obj.parent().find('li').css("font-weight","normal");
	
	obj.css("background-color","#5E5F5F");
	obj.find("div").css("background-position","-58px -76px");
	obj.css("color","#FFFFFF");
	var id = obj.attr("id");
	this.markAsSelected(id);
	
};
com.art.core.components.OptionButton.prototype.onMouseUp = function(obj)
{
	this.bindAllEvents(obj.parent());
	this.unbindAllEvents(obj);
	this.setSelectedIcon(obj);
	this.closeMenu();
};

com.art.core.components.OptionButton.prototype.setSelectedIcon = function(obj)
{
	
	if(obj != undefined)
	{
		obj.css("background-color","#FFFFFF");
		obj.css("color","#333333");
		obj.css("font-weight","bold");
		obj.css("cursor","default");
		obj.css("text-shadow","0px 1px #FFFFFF");
		obj.find("div").css("background-position","-58px -92px");
	}
};
com.art.core.components.OptionButton.prototype.bindAllEvents = function(obj)
{
	var _this = this;
	obj.find('li').unbind("mouseenter");
	obj.find('li').unbind("mouseleave");
	obj.find('li').unbind("mousedown");
	obj.find('li').unbind("mouseup");
	obj.find('li').mouseenter(	function(){		_this.onMouseEnter($(this));	});
	obj.find('li').mouseleave(	function(){		_this.onMouseLeave($(this));	});
	obj.find('li').mousedown(	function(){		_this.onMouseDown($(this));		});
	obj.find('li').mouseup(		function(){		_this.onMouseUp($(this));		});
};
com.art.core.components.OptionButton.prototype.unbindAllEvents = function(obj)
{
	obj.unbind("mouseenter");
	obj.unbind("mouseleave");
	obj.unbind("mousedown");
	obj.unbind("mouseup");
};
com.art.core.components.OptionButton.prototype.markAsSelected = function(selectedKey)
{
	if(this.optionsSelectedMap[selectedKey] == undefined)
		throw new Error("OptionButton failed! Selected item has invalid value!");
	for(var key in this.optionsSelectedMap)
	{
		this.optionsSelectedMap[key] = false;
	}
	this.optionsSelectedMap[selectedKey] = true;
};
com.art.core.components.OptionButton.prototype.getMenuContainerTemplate = function ()
{
	var str = "<ul style='margin-top:1px;'>";
	for(var i=0; i < this.options.length;i++)
	{
		var opt = this.options[i];
		if(opt.uid == undefined)
		{
			opt.uid = com.art.core.utils.StringUtil.generateUID(10);
			trace("option selected: "+opt.selected);
			this.optionsSelectedMap[opt.uid] = opt.selected;
		}
		this.menuWidth = opt.label.length > 10 ? opt.label.length * 10 : this.menuWidth;
		var fontWeight = this.optionsSelectedMap[opt.uid] ? "bold;" : "normal;";
		var bgPos		= this.optionsSelectedMap[opt.uid] ? "-58px -92px;" : "1000px 1000px;";
		str += "<li id='"+opt.uid+"' style='font-weight:"+fontWeight+"px;list-style: none outside none;background-color:#FFFFFF;padding-top:2px;padding-bottom:3px;margin-bottom:1px;margin-left:-39px;padding-left:3px;'>"+
			"<div style='margin-right:8px;display:inline-block;background-image: url($IMAGE_HOST/images/MyGallery/my_galleries_sprite.png);background-position:"+bgPos+"background-repeat: no-repeat;height:16px;width:16px;'/>"+
			opt.label+"</li>";
	}
	str += "</ul>";
	var mh = this.options.length * 26;
	
	return this.menuContainer.replace("$ID",this.id).replace("$MENU",str).replace("$MW",this.menuWidth).replace("$MH",mh).replace("$ZINDEX", this.zindex);
};
com.art.core.components.OptionButton.prototype.getTemplate = function ()
{
	var adjWidth = this.width - 4;
	var adjHeight = this.height - 4;
	var str = this.template.replace("$ID",this.id).replace("$W", this.width).replace("$H",this.height).replace("$LABEL",this.label).replace(/\$ADJ_W/g, adjWidth).replace(/\$ADJ_H/g,adjHeight).replace(/\$IMAGE_HOST/g, this.getImageHost());
	for(var key in this.hovers)
	{
		str = str.replace("$"+key,this.hovers[key].uid);
	}
	return str;
};
com.art.core.components.OptionButton.prototype.menuContainer = "<div id='$ID_menuContainer' style='position:absolute; background-color:#FFFFFF;border:1px solid #999999; width:$MWpx;height:$MHpx;z-index:$ZINDEX;top:100px;left:100px;padding-right:1px;'>$MENU</div>";
com.art.core.components.OptionButton.prototype.template =
	"<table id='$ID' style='width:$Wpx;height:$Hpx;padding:0px;margin:0px;' cellspacing='0'>"+
		"<tr><td id='$tl' style='padding:0px;width:2px;height:2px; background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-repeat:no-repeat;background-position:-340px 1000px;'></td>"+
			"<td id='$tm' style='padding:0px;width:$ADJ_Wpx;height:2px; background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-repeat:no-repeat;background-position:-341px 1000px;'></td>"+
			"<td id='$tr' style='padding:0px;width:2px;height:2px; background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-repeat:no-repeat;background-position:-556px 1000px;'></td>"+
		"</tr><tr>"+
			"<td id='$ml' style='padding:0px;width:2px;height:$ADJ_Hpx; background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-repeat:no-repeat;background-position:-340px 1000px;'></td>"+
			"<td id='$mm' style='padding:0px;width:$ADJ_Wpx;height:$ADJ_Hpx; background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-repeat:no-repeat;background-position:-341px 1000px;text-align:center;'>$LABEL</td>"+
			"<td id='$mr' style='padding:0px;width:2px;height:$ADJ_Hpx; background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-repeat:no-repeat;background-position:-556px 1000px;'></td>"+
		"</tr><tr>"+
			"<td id='$bl' style='padding:0px;width:2px;height:2px; background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-repeat:no-repeat;background-position:-340px 1000px;'></td>"+
			"<td id='$bm' style='padding:0px;width:$ADJ_Wpx;height:2px; background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-repeat:no-repeat;background-position:-341px 1000px;'></td>"+
			"<td id='$br' style='padding:0px;width:2px;height:2px; background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-repeat:no-repeat;background-position:-556px 1000px;'></td>"+
		"</tr></table>";
com.art.core.components.BaseComponent.extend(com.art.core.components.OptionButton.prototype);