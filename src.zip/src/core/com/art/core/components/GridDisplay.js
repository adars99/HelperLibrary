com.art.core.components.GridDisplay = function(id,width,numberOfColumns)
{
	this.init();
	this.id 				= id;
	this.width 				= width;
	this.numberOfColumns 	= numberOfColumns;
	this.PADDING			= 5;

};
com.art.core.components.GridDisplay.prototype.render = function(){
	
	return this.template.replace(/\$ID/g,this.id).replace("$W", this.width);
};
com.art.core.components.GridDisplay.prototype.template = "<div id='$ID' style='width:$Wpx;'>$TABLE</div>";
com.art.core.components.GridDisplay.prototype.getRowTemplate = function(rowBackgroundColor,useEllipse)
{
	var str = "";
	var rs = "margin-bottom:1px;";
	var rowBGC = (rowBackgroundColor != undefined) ? rowBackgroundColor : "";
	rs+="background-color:"+rowBGC+";";
	
	for(var i=0; i < this.numberOfColumns;i++)
	{
		str+="<div style='$STYLE_"+i+"'><span style='background-color:"+rowBGC+"'>$VALUE_"+i+"</span></div>";
	}
	str+="<div style='clear:both;'></div>";
	if(useEllipse)
	{
		rs += "background-image: url(http://cache1.artprintimages.com/images/pub/pid/UI_elipse.gif);";
		rs += "background-repeat:repeat-x;";
		rs += "background-position:0px 4px;";
	}
	
	return "<div style='"+rs+"'>"+str+"</div>";
};
com.art.core.components.GridDisplay.prototype.addRow = function(args)
{
	if(args.columns == undefined)
		throw new Error("GridDisplay.getRowTemplate failed! Required values and/or styles property is undefined.");
	if($("#"+this.id).width() == 0)
		throw new Error("GridDisplay.getRowTemplate failed! GridDisplay.render() has not yet been called.");
	if(args.columns.length != this.numberOfColumns)
		throw new Error("GridDisplay.getRowTemplate failed! GridDisplay.addRow() has incorrect number of column objects.");
	
	var rowTemplate = this.getRowTemplate(args.rowBackgroundColor,args.useEllipse);
	//build row
	for(var i=0; i < args.columns.length; i++)
	{
		var obj = args.columns[i];
		var s = this.getColumnStyle(obj);
		rowTemplate = rowTemplate.replace("$STYLE_"+i,s).replace("$VALUE_"+i,obj.value);
		
	}
	$("#"+this.id).append(rowTemplate);
};
com.art.core.components.GridDisplay.prototype.getColumnStyle = function(obj)
{
	var style = "";
	style += "text-align:" + ((obj.textAlign == "right") ? "right;" :"left;");
	style += "font-weight:" + ((obj.bold) ? "bold;" : "normal;");
	style += "float:" + ((obj.float == "right") ? "right;" : "left;");
	style += "color:" + ((obj.color == undefined) ? "#000000;" : obj.color+";");
	style += "width:"+(Math.round(this.width/this.numberOfColumns))+"px;";
	style += "padding-left:0px;padding-top:5px;padding-bottom:5px;padding-right:0px;";
	//add other styles here
	trace("style: "+style);
	return style;
		
};

com.art.core.components.GridDisplay.prototype.getTemplate = function()
{
	return this.template.replace("$TABLE", "").replace("$W", this.width).replace("$ID",this.id);
};

com.art.core.components.GridDisplay.prototype.render = function()
{
	return this.getTemplate();
};


com.art.core.components.BaseComponent.extend(com.art.core.components.GridDisplay.prototype);