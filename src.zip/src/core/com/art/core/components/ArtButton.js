
/**
 * Top level core object, common JS core library for art.com
 * @module components
 * @title art.com common components
 */

/**
 * Common art.com button
 * @class ArtButton
 * @namespace com.art.core.components
 * @constructor
 * @param id
 * @param site
 * @param label
 */

com.art.core.components.ArtButton = function(id,buttonColor,label,arrowStyle)
{
	if(typeof id != "string")
		throw new Error("ArtButton Failed! id param is NOT a string.");
	
	if( (buttonColor != com.art.core.components.ArtButton.ART_ORANGE) && (buttonColor != com.art.core.components.ArtButton.ART_BLUE) && (buttonColor != com.art.core.components.ArtButton.APC_RED) && (buttonColor != com.art.core.components.ArtButton.APC_BLUE))
		throw new Error("ArtButton Failed! buttonColor specified is not supported.");
	
	this.init();
	
	//http://pwl-vm-ria01d.art.com:8088/componentLibrary/
	this.id 	= id;
	this.color 	= buttonColor;
	this.label	= label;
	this.NAME	= com.art.core.components.ArtButton.NAME;
	//this.CLICK = com.art.core.components.ArtButton.CLICK;
	this.states = {};
	this.ARROW_DOWN 	= com.art.core.components.ArtButton.ARROW_DOWN;
	this.ARROW_LEFT 	= com.art.core.components.ArtButton.ARROW_LEFT;
	this.ARROW_RIGHT 	= com.art.core.components.ArtButton.ARROW_RIGHT;
	this.ARROW_NONE		= "none";
	this.ART_ORANGE 	= com.art.core.components.ArtButton.ART_ORANGE;
	this.ART_BLUE 		= com.art.core.components.ArtButton.ART_BLUE;
	this.APC_RED 		= com.art.core.components.ArtButton.APC_RED;
	this.APC_BLUE 		= com.art.core.components.ArtButton.APC_BLUE;
	
	//sprite background positions
	this.states[this.ART_ORANGE] 	= {"default":"0px 0px",hover:"0px -32px",down:"0px -64px",disabled:"0px -96px", disabled_END:"-305px -96px"};
	this.states[this.ART_BLUE]		= {"default":"0px -128px",hover:"0px -160px",down:"0px -192px",disabled:"0px -224px", disabled_END:"-305px -224px"};
	this.states[this.APC_RED] 		= {"default":"0px 0px",hover:"0px -32px",down:"0px -64px",disabled:"0px -96px", disabled_END:"-307px -96px"};
	this.states[this.APC_BLUE]		= {"default":"0px -128px",hover:"0px -160px",down:"0px -192px",disabled:"0px -224px", disabled_END:"-307px -224px"};
	
	this.arrowStyle = this.ARROW_NONE;
	if(arrowStyle != undefined)
	{
		this.arrowStyle = arrowStyle;
	}
	this.arrowTemplates = {};// 
	this.arrowTemplates[this.ARROW_LEFT] 	= "<div style='float:left;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png); background-position:-319px -39px; background-repeat:no-repeat;width:20px; height:25px;'></div><div style='float:left'>$L</div><div style='clear:both'></div>";
	this.arrowTemplates[this.ARROW_RIGHT] 	= "<div style='float:left'>$L</div><div style='float:left;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png); background-position:-309px -8px; background-repeat:no-repeat;width:20px; height:25px;'></div><div style='clear:both'></div>";
	this.arrowTemplates[this.ARROW_DOWN] 	= "<div style='float:left'>$L</div><div style='float:left;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png); background-position:-310px -71px; background-repeat:no-repeat;width:23px; height:25px;'></div><div style='clear:both'></div>";
	this.arrowTemplates[this.ARROW_NONE]	= "$L";
};

com.art.core.components.ArtButton.ARROW_DOWN 			= 'art_button_arrow_down';
com.art.core.components.ArtButton.ARROW_LEFT 			= 'art_button_arrow_left';
com.art.core.components.ArtButton.ARROW_RIGHT 			= 'art_button_arrow_right';
com.art.core.components.ArtButton.ART_ORANGE 			= 'art_orange';
com.art.core.components.ArtButton.ART_BLUE 				= 'art_blue';
com.art.core.components.ArtButton.APC_RED 				= 'apc_red';
com.art.core.components.ArtButton.APC_BLUE 				= 'apc_blue';
com.art.core.components.ArtButton.ALLPOSTERS 			= 'allposters';
com.art.core.components.ArtButton.NAME 					= 'ArtButton';
com.art.core.components.ArtButton.prototype.template = "";
com.art.core.components.ArtButton.prototype.render = function(zindex)
{
	return this.getTemplate(zindex);
};

com.art.core.components.ArtButton.prototype.disable = function()
{
	$("#"+this.id).css("cursor","default");
	$("#"+this.id).unbind("mouseover");
	$("#"+this.id).unbind("mouseleave");
	$("#"+this.id).unbind("mousedown");
	$("#"+this.id).unbind("mouseup");
	$("#"+this.id).die("click");
	var pos = this.getPosition(this.DISABLED);
	var pos2 = this.getPosition(this.DISABLED+"_END");
	
	$("#"+this.id+">div:first-child").css("background-position",pos);
	$("#"+this.id+">div:nth-child(2)").css("background-position",pos2);
};

com.art.core.components.ArtButton.prototype.getPosition = function(state)
{
	var s = this.states[this.color][state];
	return s;
};

com.art.core.components.ArtButton.prototype.getTemplate = function(zindex)
{
	var label = "";
	var z = zindex != undefined ? "z-index:"+zindex+";" : "";
	var pos = this.getPosition(this.HOVER);
	label = this.arrowTemplates[this.arrowStyle].replace("$L",this.label);
	var domain = this.color.indexOf(com.art.core.constants.ART) > -1 ? com.art.core.constants.ART : com.art.core.constants.APC;
	var rpos = domain == com.art.core.constants.APC ? "-307" : "-305"; //default to ART
	rpos = rpos+pos.substring(pos.indexOf("px"));
	return this.template.replace(/\$ID/g,this.id).replace("$LABEL",label).replace(/\$ZNDX/g,z).replace("$POS",pos).replace("$RCAP_POS",rpos).replace(/\$IMAGE_HOST/g, this.getImageHost(domain)).replace(/\$IMAGE_SPRITE/g,this.getImageFile());
};
com.art.core.components.ArtButton.prototype.getImageFile = function()
{
	var f = this.color.indexOf("art") > -1 ? this.ART_SPRITE : this.APC_SPRITE;
	return f;
};
com.art.core.components.ArtButton.prototype.template = '<div id="$ID" style="display:inline-block;cursor:pointer;$ZNDX;position:relative;height:32px;">'+
	'<div style="display:inline-block;float:left;height:24px;padding-left:18px;padding-top:7px;padding-right:11px;color:#FFFFFF;font-size:11px;font-family:verdana,arial,sans-serif;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png); background-position:$POS;background-repeat:no-repeat;" id="$ID_label">$LABEL</div>'+
	'<div style="display:inline-block;float:left;height:26px; padding-top:6px;width:4px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:$RCAP_POS;background-repeat:no-repeat;" id="$ID_rightcap"></div>'+
	'<div style="display:inline-block;clear:both"></div>'+
'</div>';


com.art.core.components.ArtButton.prototype.registerEvents = function()
{
	var _this = this;
	$("#"+this.id).mouseover(function(){
		var pos = _this.getPosition(_this.HOVER);
		$("#"+this.id+">div:first-child").css("background-position",pos);
	});
	$("#"+this.id).mouseleave(function(){
		var pos = _this.getPosition(_this.MOUSEUP);
		$("#"+this.id+">div:first-child").css("background-position",pos);
	});
	$("#"+this.id).mousedown(function(){
		var pos = _this.getPosition(_this.MOUSEDOWN);
		$("#"+this.id+">div:first-child").css("background-position",pos);
	});
	$("#"+this.id).mouseup(function(){
		var pos = _this.getPosition(_this.MOUSEUP);
		$("#"+this.id+">div:first-child").css("background-position",pos);
		if(_this["callbacks"][_this.CLICK] != undefined)
		{
			_this["callbacks"][_this.CLICK]();
		}
	});
	$("#"+this.id).live("click",function(e){
		e.stopPropagation();
		e.preventDefault();
	});
};
com.art.core.components.ArtButton.prototype.destroy = function()
{
	$("#"+this.id).die();
	$("#"+this.id).remove();
};
com.art.core.components.BaseButton.extend(com.art.core.components.ArtButton.prototype);
