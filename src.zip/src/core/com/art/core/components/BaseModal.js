/**
 * Base modal dialog box. Width is specified by not height, the contents injected to setContents() will
 * implicitly set height of modal. This is necessary to keep button bar at bottom of dialog
 * @class BaseModal
 * @constructor
 * @param id
 * @param width
 * @param bgcolor
 * @param useButtonBar
 */
com.art.core.components.BaseModal = function (id, width, bgcolor, useButtonBar, disableDropShadow) {
	this.init();
    this.id = id;
    this.width = width;
    this.bgcolor = bgcolor;
    this.useButtonBar = useButtonBar;
    this.disableDropShadow = disableDropShadow != undefined ? disableDropShadow : false;    
    this.CLOSE_CLICKED = com.art.core.components.BaseModal.CLOSE_CLICKED;
    this.BODY_CLICKED = com.art.core.components.BaseModal.BODY_CLICKED;
    com.art.core.components.BaseComponent.extend(this);
    this.zindex = -1;
    this.skin = com.art.core.components.BaseModal.ART_SKIN;
    this.ART_SKIN = com.art.core.components.BaseModal.ART_SKIN;
    this.APC_SKIN = com.art.core.components.BaseModal.APC_SKIN;
};
com.art.core.components.BaseModal.APC_SKIN		= "apc_skin";
com.art.core.components.BaseModal.ART_SKIN		= "art_skin";

com.art.core.components.BaseModal.CLOSE_CLICKED = 'BaseModalCloseClicked';
com.art.core.components.BaseModal.BODY_CLICKED = 'BaseModalBodyClicked';
com.art.core.components.BaseModal.extend = function(obj)
{
	var m = new com.art.core.components.BaseModal(obj.id,obj.width);
	for(var n in obj)
	{
		trace(n+": "+obj[n]);
		if(n == 'template')
		{
			obj[n] = m.getTemplate().replace("$EXTEND",obj[n]);
		}
	}
	for(var i in m)
	{
		if(i != 'render' && i != 'getTemplate' && i != 'template')
		{
			trace('replace: '+i);
			obj[i] = m[i]; //trace(i+" :"+typeof m[i]);
		}
	}
};

com.art.core.components.BaseModal.prototype.setContents = function(str)
{
	this.template = this.template.replace("$EXTEND",str);
};
com.art.core.components.BaseModal.prototype.render = function(zindex)
{
	var str = this.getTemplate(zindex);
	return str;
};
com.art.core.components.BaseModal.prototype.registerEvents = function () {
    var _this = this;
    //setup close button
    $('#baseModalCloseBtn_' + this.id).mouseenter(function () {
        $(this).css("background-position", "-357px -15px");
    });
    $('#baseModalCloseBtn_' + this.id).mouseleave(function () {
        $(this).css("background-position", "-340px -15px");
    });
    $('#baseModalCloseBtn_' + this.id).mousedown(function () {
        $(this).css("background-position", "-374px -15px");
    });
    $('#baseModalCloseBtn_' + this.id).mouseup(function () {
        $(this).css("background-position", "-340px -15px");

        if (_this.callbacks[_this.CLOSE_CLICKED] != undefined)
            _this.callbacks[_this.CLOSE_CLICKED]();
        		
        if(this.id == "baseModalCloseBtn_myModalMoveToGallery" && $('#MoveToGalleryConfirm').css("visibility") != 'hidden') {
        	window.location.href = window.location.href = "http://"+window.location.hostname+MyGalleriesCore.getModel().environment.profileURL +MyGalleriesCore.getModel().environment.galleryKey +"/";
        }
        _this.close();
    });
    
    $("#"+_this.id).live("click",function(e){
    	if(_this.callbacks[_this.BODY_CLICKED] != undefined)
    	{
    		e.stopPropagation();
    		_this.callbacks[_this.BODY_CLICKED]();
    	}
    });
    trace("disableDropShadow");
    trace(this.disableDropShadow);
    
  if (this.disableDropShadow) {
        var obj = $("#" + this.id).centerNoDropShadow(true);
    }
    else {
        var obj = $("#" + this.id).addDropShadow().center(true);
   }
    
};

com.art.core.components.BaseModal.prototype.removeCloseButton = function()
{
	$("#baseModalCloseBtn_"+this.id).css("display", "none");
	
};


com.art.core.components.BaseModal.prototype.close = function () {
    $("#" + this.id).die();
    $("#" + this.id).unbind("click");
    $("#" + this.id).remove();
};
/**
 * Add button(s) to statndard modal box
 * @param id
 * @param style
 * @param label
 * @param callback
 */
com.art.core.components.BaseModal.prototype.registerButton = function(id,style,label,callback,arrowStyle)
{
	var as = (arrowStyle != undefined) ? arrowStyle :undefined;
		
	var b = new com.art.core.components.ArtButton(id,style,label,as);
	$("#btnBarClear").before("<div style='float:right'>"+b.render()+"</div>");
	b.registerEvents();
	b.registerCallback(com.art.core.components.BaseButton.CLICK,function(){
		callback(b);
	});
	
	//set some spacing for buttons
	$("#baseModalButtonBarRight_"+this.id+" > div").css("margin-left","5px");
};
com.art.core.components.BaseModal.prototype.setDefaultButtons = function()
{
	var b = new com.art.core.components.ArtButton('someID',com.art.core.components.ArtButton.ART_BLUE,'Submit');
	$("#baseModalButtonBarRight_"+this.id).html(b.render());
};
com.art.core.components.BaseModal.prototype.setLeftButtonBarContent = function(str)
{
	$("#baseModalButtonBarLeft_"+this.id).html(str);
};
com.art.core.components.BaseModal.prototype.getTemplate = function(zindex) {
    
	var z = zindex != undefined ? "z-index:"+zindex+";" : "z-index:1000";
	var domain = this.skin == this.ART_SKIN ? com.art.core.constants.ART : com.art.core.constants.APC;
	var btnStr = this.useButtonBar ? this.buttonBarTemplate.replace(/\$ID/g,this.id) : "";
	var str = this.template.replace(/\$ID/g,this.id).replace("$W", this.width).replace("$WW", this.width-28).replace("$BGC",this.bgcolor).replace("$BTN_BAR",btnStr).replace("$ZNDX",z).replace(/\$IMAGE_HOST/g,this.getImageHost(domain));
	return str;
};
com.art.core.components.BaseModal.prototype.buttonBarTemplate =
"<div class='buttonBarTemplate'>" +
	"<div id='baseModalButtonBarLeft_$ID' style='float:left;margin-top: 7px;'></div>" +
	"<div id='baseModalButtonBarRight_$ID' style='float:right;width:50%'><div id='btnBarClear' style='clear:both'></div></div>"+
	"<div style='clear:both;font-size:0px;'></div>"+
"</div>";
com.art.core.components.BaseModal.prototype.template =
"<div id='$ID'style='width:$Wpx;background-color:$BGC;position:absolute;$ZNDX'>" +
	"<div id='baseModalCloseBtn_$ID' class='baseModalCloseBtn' style='margin-right:10px;margin-top:10px;float:right;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png); background-repeat:no-repeat; background-position:-340px -15px;height:17px;width:17px;cursor:pointer;'></div>" +
	//"<div style='clear:both; font-size:0px;'></div>"+
	"<div id='baseExtend' style='width:100%;#width:100%;height:100%;'>$EXTEND</div>" +
	"<div style='clear:both;font-size:0px;'></div>"+
	"$BTN_BAR" +
"</div>";
com.art.core.components.BaseComponent.extend(com.art.core.components.BaseModal.prototype);
