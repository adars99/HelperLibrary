/**
 * FixedContainer component; is a container that will stay in view port; used primary to keep menu options visible on-screen
 * @class FixedContainer
 * @constructor
 * @param id
 * @param xAlignment
 * @param bottomBoundaryElementID
 * @param width
 * @param height
 * @param sideMargin
 */
com.art.core.components.FixedContainer = function(id,xAlignment,bottomBoundaryElementID,width,height,sideMargin)
{
	this.init();
	
	this.id 						= id;
	this.xAlignment 				= xAlignment;
	this.bottomBoundaryElementID 	= bottomBoundaryElementID;
	this.sideMargin					= sideMargin;
	this.width						= width;
	this.height						= height;
	this.scrollTop 					= 0;
	this.ypos						= 0;
	this.bottomBoundary				= -1; //default no boundary
	this.boundaryOffset;
	this.timeoutID;
	this.scrollDirection;
	this.content = "";
	this.fixedXPos = -1;
	this.fixedYPos = -1;
	this.scrollTop;
	this.xBoundary = false;
	this.LEFT = com.art.core.components.FixedContainer.LEFT;
};
com.art.core.components.FixedContainer.RIGHT	= 'fixedContainerRight';
com.art.core.components.FixedContainer.LEFT		= 'fixedContainerLeft';
com.art.core.components.FixedContainer.UP		= 'scrollDirectionUp';
com.art.core.components.FixedContainer.DOWN		= 'scrollDirectionDown';

com.art.core.components.FixedContainer.prototype.registerEvents = function()
{
	this.setBottomBoundary();
	var _this = this;
	this.setXPos();
	this.checkYPos($(window).scrollTop());
	$(window).scroll(function(){
		_this.checkYPos();
		_this.checkXPos();
		_this.checkXPos($(window).scrollLeft());
	});
};

com.art.core.components.FixedContainer.prototype.setContent = function(str)
{
	this.content = str;
};
//com.art.core.components.FixedContainer.prototype.checkXPos = function()
//{
//	var scrollLeft = $(window).scrollLeft();
//	var pos = $("#"+this.id).css("position");
//	if(this.xAlignment == this.LEFT)
//	{
//		var xpos = scrollLeft > 0 && pos == "fixed" ? this.sideMargin - scrollLeft : this.sideMargin;
//		$("#"+this.id).css("left", xpos+"px");
//	}
//};
com.art.core.components.FixedContainer.prototype.checkYPos = function()
{
	var scrollTop = $(window).scrollTop();
	if(this.boundaryOffset != null) 
	{
		if(this.bottomBoundary !=  Math.round(this.boundaryOffset.top) + parseInt($("#"+this.bottomBoundaryElementID).height()))
		{
			this.setBottomBoundary();
		}
	
		var _this = this;
		this.scrollTop = Math.round(scrollTop);
		this.ypos = parseInt( this.scrollTop + $(window).height())- (this.height);
		if(this.fixedYPos == -1) this.fixedYPos = $(window).height() - (this.height-5);
		if(this.ypos >= (this.bottomBoundary - (this.height + 5) ))
		{
			$("#"+this.id).css("position","absolute");
			$("#"+this.id).css("top",(this.bottomBoundary-this.height-5)+"px");
			$("#"+this.id).css("bottom","5px");
			
		}
		else
		{
			$("#"+this.id).css("position","fixed");
			$("#"+this.id).css("top",this.fixedYPos+"px");
			
		}
	}	
};

com.art.core.components.FixedContainer.prototype.checkXPos = function(scrollLeft)
{
	//trace("scrollLeft "+scrollLeft);
	/*if(this.boundaryOffset != null) 
	{
		if(this.bottomBoundary !=  Math.round(this.boundaryOffset.top) + parseInt($("#"+this.bottomBoundaryElementID).height()))
		{
			this.setBottomBoundary();
		}
	
		var _this = this;
		this.scrollTop = Math.round(scrollTop);
		this.ypos = parseInt( this.scrollTop + $(window).height())- (this.height);
		if(this.fixedYPos == -1) this.fixedYPos = $(window).height() - (this.height-5);
		if(this.ypos >= (this.bottomBoundary - (this.height + 5) ))
		{
			$("#"+this.id).css("position","absolute");
			$("#"+this.id).css("top",(this.bottomBoundary-this.height-5)+"px");
			$("#"+this.id).css("bottom","5px");
			
		}
		else
		{
			$("#"+this.id).css("position","fixed");
			$("#"+this.id).css("top",this.fixedYPos+"px");
			
		}
	}	

	if(scrollLeft > 0)
	{
		$("#"+this.id).css("position","absolute");
		$("#"+this.id).css("left",this.fixedXPos+"px");
	}
	else
	{
		$("#"+this.id).css("position","fixed");
		$("#"+this.id).css("top",this.fixedYPos+"px");
	}*/
};
com.art.core.components.FixedContainer.prototype.setBoundaryOffset = function()
{
	this.boundaryOffset = $("#"+this.bottomBoundaryElementID).offset();
	//trace("boundaryOffset: "+this.boundaryOffset);
};
/**
 * Set container which fixedContainer should not move beyond
 * @method setBottomBoundary
 */
com.art.core.components.FixedContainer.prototype.setBottomBoundary = function()
{
	this.setBoundaryOffset();
	if(this.boundaryOffset != null)
		this.bottomBoundary =  Math.round(this.boundaryOffset.top) + parseInt($("#"+this.bottomBoundaryElementID).height());
};

com.art.core.components.FixedContainer.prototype.setXPos = function()
{
	var xpos = this.xAlignment == com.art.core.components.FixedContainer.LEFT ? this.sideMargin : parseInt($(window).width()) - (this.width+this.sideMargin);
	$("#"+this.id).css("left",xpos+"px");
	this.fixedXPos = xpos;
};
com.art.core.components.FixedContainer.prototype.render = function()
{
	return this.template.replace("$ID",this.id).replace("$W",this.width).replace("$H", this.height).replace("$C",this.content).replace(/\$IMAGE_HOST/g, this.getImageHost());;
};
com.art.core.components.FixedContainer.prototype.template = "<div id='$ID' style='position:absolute;width:$Wpx;height:$Hpx;border:1px solid #999999;background-color:#DDDDDD;'>$C</div>";


com.art.core.components.BaseComponent.extend(com.art.core.components.FixedContainer.prototype);






//var str="<div id='panel' style='background-color:#999999;width:200px; height:100px; border:1px solid #000000; color:#FFFFFF; position:absolute;z-index:1000;top:100px; left:100px;'>Hello World</div>";

//set up optional boundry












