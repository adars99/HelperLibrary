/**
 * CheckBox component will dim the contents of target element, useful for displaying modal content on top of target parameter
 * @class CheckBox
 * @namespace com.art.core.components
 * @constructor
 * @param id
 * @param value
 */
com.art.core.components.CheckBox = function (id,value,label, isSelected) {
	this.init();
    this.id = id;
    this.value = value;
    this.label = label;
    this.NAME = com.art.core.components.CheckBox.NAME;
    this.selected = isSelected == true;
    this.CHECKED = com.art.core.components.CheckBox.CHECKED;
    this.enabled = true;
};
com.art.core.components.CheckBox.NAME = "CheckBox";
com.art.core.components.CheckBox.CHECKED = "CheckBoxChecked";
com.art.core.components.CheckBox.prototype.registerEvents = function()
{
	if(!this.enabled)
		return;
	
	var _this = this;
	$("#"+this.id).mouseover(function(){
		var pos = _this.selected ? '-412px -44px': '-358px -44px';
		$(this).css('background-position',pos);
	});
	$("#"+this.id).mouseout(function(){
		var pos = _this.selected ? '-394px -44px': '-340px -44px';
		$(this).css('background-position',pos);
	});
	$("#"+this.id).mousedown(function(){
		var pos = _this.selected ? '-430px -44px': '-376px -44px';
		$(this).css('background-position',pos);
	});
	$("#"+this.id).mouseup(function(e){
		_this.toggle();
	});
	$("#"+this.id).live("click",function(e){
		e.stopPropagation();
		e.preventDefault();
	});
};

/**
 * 
 * To selecte/deselect checkbox programatically
 * Will also execute the CHECKED callback
 */
com.art.core.components.CheckBox.prototype.toggle = function()
{
	this.selected = !this.selected;
	var pos = this.selected ? '-394px -44px': '-340px -44px';
	$("#"+this.id).css('background-position',pos);
	if(this.callbacks[this.CHECKED] != undefined)
		this.callbacks[this.CHECKED](this);
};
com.art.core.components.CheckBox.prototype.enable = function(bool)
{
	this.enabled = bool;
	var opacity = bool ? 1 : .3;
	
	$("#"+this.id).css("opacity",opacity);
	$("#"+this.id).unbind("mouseup");
	$("#"+this.id).unbind("mousedown");
	$("#"+this.id).unbind("mouseout");
	$("#"+this.id).unbind("mouseover");
	$("#"+this.id).unbind("click");
	this.registerEvents();
};
/**
 * @method getTemplate
 * 
 */
com.art.core.components.CheckBox.prototype.getTemplate = function()
{
	var pos = this.selected ? '-394px -44px': '-340px -44px';
	return this.template.replace('$ID',this.id).replace("$POS",pos).replace(/\$IMAGE_HOST/g,this.getImageHost());
};
/**
 * Outputs markup for component
 * @method render
 * @returns {String}
 */
com.art.core.components.CheckBox.prototype.render = function () {
    return this.getTemplate();
};
/**
* @method registerCallback
* @param eventName
* @param callback
*/
com.art.core.components.CheckBox.prototype.registerCallback = function (eventName, callback) {
    this.callbacks[eventName] = callback;
};

com.art.core.components.CheckBox.prototype.template = '<div id="$ID" style="width:18px;height:19px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png); background-repeat:no-repeat;background-position:$POS"></div>';
	
com.art.core.components.BaseComponent.extend(com.art.core.components.CheckBox.prototype);
