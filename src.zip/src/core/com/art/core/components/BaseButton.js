com.art.core.components.BaseButton = function()
{
	this.init();
	this.CLICK 		= com.art.core.components.BaseButton.CLICK;
	this.HOVER 		= com.art.core.components.BaseButton.HOVER;
	this.MOUSEDOWN 	= com.art.core.components.BaseButton.MOUSEDOWN;
	this.MOUSEUP 	= com.art.core.components.BaseButton.MOUSEUP;
	this.DISABLED	= com.art.core.components.BaseButton.DISABLED;	
};



com.art.core.components.BaseButton.extend = function(subclass)
{
	var bb = new com.art.core.components.BaseButton();
	for(var k in bb)
	{
		subclass[k] = bb[k];
	};
};

com.art.core.components.BaseButton.CLICK = "click";
com.art.core.components.BaseButton.HOVER = "hover";
com.art.core.components.BaseButton.MOUSEDOWN = "down";
com.art.core.components.BaseButton.MOUSEUP = "default";
com.art.core.components.BaseButton.DISABLED = "disabled";


com.art.core.components.BaseComponent.extend(com.art.core.components.BaseButton.prototype);
