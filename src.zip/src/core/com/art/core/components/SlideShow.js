/**
* @class SlideShow
* @param id
* @param w
* @param h
* @param images
* @param totalImagesInCollection
* 
* @param pageNumber optional
* @param imagesPerPage optional
*/
com.art.core.components.SlideShow = function (id, w, h, images, startingImageIndex) {
    this.init();
    this.id = id;
    this.width = w;
    this.height = h;
    this.margin = 40;
    this.backgroundColor = "#FFFFFF";
    this.bottomControlsPadding = 30;
    this.ADD_TO_CART_CLICKED = com.art.core.components.SlideShow.ADD_TO_CART_CLICKED;
    this.CLOSE_BUTTON_CLICKED = com.art.core.components.SlideShow.CLOSE_BUTTON_CLICKED;
    this.ESC_KEY_CLICKED = com.art.core.components.SlideShow.ESC_KEY_CLICKED;
    this.delayTimerID;
    this.requestTimeoutDuration = 10 * 1000; //10sec
    this.shareBtn;
    this.controlsTimer;
    this.slideShowTimerID;
    this.mouseX = 0; //controls hide/show for ie
    this.mouseY = 0; //controls hide/show for ie


    /**
    * @property images support paginated collection
    */
    this.images = images;

    this.imageDomain = 'http://pwl-vm-uapp01/ue/galleries_v2/assets/'; //imageDomain;

    /**
    * Boolean flag to control play/pause toggle
    * @property slideShowToggle
    **/
    this.slideShowToggle = true;
    //play/pause share same div see slideShowStartupMainControls() method
    this.slideShowControlsIsPaused = false;

    this.slideShowControls = {
        play: { enabled: "-45px -606px", disabled: "-45px -565px", width: "38px", height: "38px" },
        pause: { enabled: "0px -606px", disabled: "0px -565px", width: "38px", height: "38px" },
        previous: { enabled: "-90px -604px", disabled: "-90px -565px", width: "25px", height: "25px" },
        next: { enabled: "-120px -604px", disabled: "-120px -565px", width: "25px", height: "25px" }
    };

    //support pagination
    this.slideShowCursor = startingImageIndex == undefined ? -1 : startingImageIndex -1; //position of slideshow
    this.ssScrollDirectionOptions = { LEFT: 'left', RIGHT: 'right' };
    this.ssScrollDirection = this.ssScrollDirectionOptions.LEFT;
    this.controlsInit = false;
    this.ssCurrentCursor = 0;
    this.ssIsPaused = false;
    this.ssProcessing = false;
    this.ssCurrent;
    this.SlideShowNext;
    this.playPause = false;
    this.ssContainerWidth;
    this.ssContainerHeight;
    this.ssW = 58;
    this.ssH = 70;
    this.newImages;
    
    //button
    this.addToCartBtn;
    this.closeBtn;
    this.imageInfo;

};
com.art.core.components.SlideShow.ADD_TO_CART_CLICKED = "slideShowAddToCart";
com.art.core.components.SlideShow.CLOSE_BUTTON_CLICKED = "slideShowCloseButtonClicked";
com.art.core.components.SlideShow.ESC_KEY_CLICKED = "escKeyClicked";


com.art.core.components.SlideShow.prototype.getTotalImages = function () {
    return this.images.length;
};
/**
 * Removed standard close button at top
 * 
 */


/**
* registerEvents method is used to fire the event 
* @method registerEvents
*
**/
com.art.core.components.SlideShow.prototype.registerEvents = function () {
    var x = setTimeout("");
    for (var i = 0; i <= x; i++) {
        clearTimeout(i);
    }

    var _this = this;
    //Hide the modal close button

    //register jquery callback for controls...

    //Preventing right click event on slideshow
    $("#" + this.id).bind("contextmenu", function (e) {
        e.preventDefault();
    });

    this.centerControls();

    //hide/show the controls on mousemove
    $("body").mousemove(function (e) {
    	if(e.pageX != _this.mouseX && e.pageY != _this.mouseY)
    	{
    		_this.mouseX = e.pageX;
    		_this.mouseY = e.pageY;
    		_this.hideShowMainControl();
    	}
    });

    //prevent closing when control bar clicked
    $("#" + this.id + "_CONTROL_BAR").live("click", function (e) {
        e.preventDefault();
        e.stopPropagation();
        trace("controlBar clicked");
    });


    $(window).resize(function () {
        if (typeof window.innerWidth != 'undefined') {
            _this.width = window.innerWidth - _this.ssW;
            _this.height = window.innerHeight - _this.ssH;
        }
        else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {

            //IE 6+ in 'standards compliant mode'             
            _this.width = document.documentElement.clientWidth - _this.ssW;
            _this.height = document.documentElement.clientHeight - _this.ssH;
        }

        $('#' + _this.id).css("width", _this.width);
        $('#' + _this.id).css("height", _this.height);
        _this.centerControls();
    });

    $("#ssCloseSlideshow").live("click", function () {
        _this.close();
    });


    $('.imgClip').live("click", function (event) {
        event.stopPropagation();
    });


    $(document).bind('keydown', function (escapeKey) {
        if (escapeKey.which == 27 || escapeKey.keyCode == 27) {
            _this.close();
            if(_this.callbacks[_this.ESC_KEY_CLICKED]!=null)
            	_this.callbacks[_this.ESC_KEY_CLICKED]();
        }
    });

    this.slideShowStartupMainControls();

    this.addToCartBtn.registerEvents();
    this.addToCartBtn.registerCallback(com.art.core.components.BaseButton.CLICK, function () {
        _this.callbacks[_this.ADD_TO_CART_CLICKED]();
    });
    this.closeBtn.registerEvents();
    this.closeBtn.registerCallback(com.art.core.components.BaseButton.CLICK, function () {
        _this.callbacks[_this.CLOSE_BUTTON_CLICKED]();
    });
};

/**
* Close slideshow
* @method close
*/
com.art.core.components.SlideShow.prototype.close = function ()
{
	clearTimeout(this.slideShowTimerID);
	$("body").unbind("mousemove");
	$("#"+this.id+"_CONTROL_BAR").die("click");
	$("#ssCloseSlideshow").die("click");
    $("#"+this.id).die();  
    $("#"+this.id+"_CONTROL_BAR").remove();
    $("#"+this.id).remove();
    var x = setTimeout("");
    for(var i=0; i <= x; i++)
    {
    	clearTimeout(i);
    }
};

/**
* Start slideshow, if no images loaded, throw error
* @method start
*/
com.art.core.components.SlideShow.prototype.start = function () {
    this.loadImage();
};
/**
* appendImages method is used to append the images,call the service after rendering the last image
* @method appendImages
*
**/
com.art.core.components.SlideShow.prototype.appendImages = function (arr) {    
    this.newImages = arr;   
};

com.art.core.components.SlideShow.prototype.loadImage = function () {
    clearTimeout(this.slideShowTimerID);
    var _this = this;

    if (this.ssProcessing)
        return;

    this.ssProcessing = true;
    var _this = this;
    var randid = "id_" + Math.round(Math.random() * 10000);
    this.SlideShowNext = randid;


    if (this.ssScrollDirection == this.ssScrollDirectionOptions.LEFT) {
        this.slideShowCursor = this.slideShowCursor == this.images.length - 1 ? 0 : this.slideShowCursor + 1;
    }
    else {
        this.slideShowCursor = (this.slideShowCursor <= 0) ? this.images.length - 1 : this.slideShowCursor - 1;
    }

    //To do - Change the width and height once service will provide
    $("#" + this.id + "_CLIP").append('<img id="' + randid + '" class="imgClip" src="' + this.images[this.slideShowCursor].url + '" style="position:absolute;left:0px"/>');

    //$("#ssDiscountImagePrice").text(this.images[this.slideShowCursor].price);
    var initPos = this.ssScrollDirection == this.ssScrollDirectionOptions.LEFT ? $("#" + this.id + "_CLIP").width() + 10 : -($("#" + this.id + "_CLIP").width() + 10);

    if (this.ssScrollDirection == this.ssScrollDirectionOptions.LEFT) {
        if ($("#" + randid).width() > initPos)
            initPos = $("#" + randid).width();
    }
    else {
        if (-$("#" + randid).width() < initPos)
            initPos = -$("#" + randid).width();
    }

    $("#" + randid).css("left", initPos + "px");

    //pause when clicked
    $("#" + randid).live('click', function () {

        _this.playPauseToggle();
    });
    $("#" + randid).imagesLoaded(function (img) {

        //center vertically
        var newTop = Math.round(($("#" + _this.id + "_CLIP").height() - $("#" + randid).height()) / 2);
        $(this).unbind('load');

        $("#" + randid).css("top", newTop + "px");

        $(_this).addCenterOuterShadow();

        if (_this.controlsInit == false) {
            _this.slideShowStartupMainControls('mySlideShow_CONTROL_BAR');
            _this.controlsInit = true;
        }
        //Set the image price
        if (_this.images[_this.slideShowCursor].showMarkDownPrice == false || _this.images[_this.slideShowCursor].showMarkDownPrice == undefined) {        	
            $("#ssImagePrice").css("margin-right", "45px");
            $("#ssImagePrice").css("color", "#666");
            
            var strPrice=_this.images[_this.slideShowCursor].price;
            
            $("#ssImagePrice").html(strPrice); //text(strPrice.replace(/\&amp;/g,'&'));
            $("#ssDiscountImagePrice").text('');
        }
        else {  
        	
            //$("#ssDiscountImagePrice").css("margin-right", "25px");
        	
        	$("#ssDiscountImagePrice").css("margin-right", "87px");
        	$("#ssDiscountImagePrice").css("margin-top", "-12px");
            $("#ssImagePrice").css("margin-right", "15px");
            $("#ssImagePrice").css("font-style", "italic");
            $("#ssImagePrice").css("font-weight", "bold");
            
            var strDiscountPrice=_this.images[_this.slideShowCursor].DisplayMSRP;
            $("#ssDiscountImagePrice").html(strDiscountPrice);
            
            var strMarkDownPrice=_this.images[_this.slideShowCursor].price;
            $("#ssImagePrice").css("color","red");
            $("#ssImagePrice").html(strMarkDownPrice);
           
        }

        //TODO
        var tmp = _this.ssCurrent;
        if (_this.ssCurrent != undefined && !_this.ssIsPaused) {
            var left = _this.ssScrollDirection == _this.ssScrollDirectionOptions.LEFT ? -$("#" + _this.id + "_CLIP").width() : $("#" + _this.id + "_CLIP").width();
            $("#" + tmp).animate({ "left": left + "px" }, 2000, function () {
                $("#" + tmp).die();
                $("#" + tmp).remove();
            });

        }
        if (!_this.ssIsPaused) {

            var newLeft = Math.round(($("#" + _this.id + "_CLIP").width() - $("#" + randid).width()) / 2);
            $("#" + _this.SlideShowNext).animate({ "left": newLeft }, 2000, function () {
                $("#" + _this.ssCurrent).remove();
                _this.ssCurrent = _this.SlideShowNext;
                _this.SlideShowNext = '';
                _this.ssScrollDirection = _this.ssScrollDirectionOptions.LEFT;
                _this.continueSlideShow();
            });
        }
    });
};


/**
* Get the slideshow image detail while it is moving for add to card
* @method continueSlideShow
*
**/
com.art.core.components.SlideShow.prototype.getCurrentImageIndex = function () {
	
	return this.slideShowCursor;
};
/**
* continueSlideShow method is used to continue the slide show
* @method continueSlideShow
*
**/
com.art.core.components.SlideShow.prototype.continueSlideShow = function () {

    this.ssProcessing = false;
    var _this = this;
    //only continue if user has not closed slideshow AND is not paused
    if (this.slideShowToggle && !this.ssIsPaused) {
        this.slideShowTimerID = setTimeout(function () {
            _this.loadImage();
        }, 4000);
    }
};

/**
* render method is used to render the getTemplate method
* @method render
*
**/
com.art.core.components.SlideShow.prototype.render = function () {
    
    return this.getTemplate();
};


/**
* centerControls method is used to center the control bar e.g. play,pause etc
* @method centerControls
*
**/
com.art.core.components.SlideShow.prototype.centerControls = function () {

    //left
    var cbw = $("#" + this.id + "_CONTROL_BAR").width();
    //var ssw = $("#" + this.id).width() + 74;
    var ssw = $("#" + this.id).width() -10;

    var newLeft = Math.round((ssw - cbw) / 2);
    $("#" + this.id + "_CONTROL_BAR").css("left", newLeft);

    //top
    var cbh = $("#" + this.id + "_CONTROL_BAR").height();
    var ssh = $("#" + this.id).height();
    
    var newTop = Math.round(ssh - (cbh + this.bottomControlsPadding));
    $("#" + this.id + "_CONTROL_BAR").css("top", newTop);
};

/**
* hideShowMainControl method is used to hide/show the main control bar e.g. play,pause etc
* @method hideShowMainControl
*
**/
com.art.core.components.SlideShow.prototype.hideShowMainControl = function ()
{
	var _this = this;
	clearTimeout(this.controlsTimer);
	if ($('#'+_this.id+'_CONTROL_BAR').is(':hidden'))
		$('#'+_this.id+'_CONTROL_BAR').fadeIn();
    this.controlsTimer = setTimeout(function (){
    	$('#'+_this.id+"_CONTROL_BAR").fadeOut();
    }, 1500);
	//}, 5000);
};

/**
* getTemplate method is used to get the HTML template
* @method getTemplate
*
**/
com.art.core.components.SlideShow.prototype.getTemplate = function () {

	this.addToCartBtn = new com.art.core.components.ArtButton(this.id + "_AddToCartBtn", com.art.core.components.ArtButton.ART_ORANGE, 'Add To Cart');
    this.closeBtn = new com.art.core.components.ArtButton(this.id + "_CloseBtn", com.art.core.components.ArtButton.ART_BLUE, 'Close Slideshow');
    var tmp = this.shellTemplate.replace("$CLIP", this.clipTemplate) + this.controlsTemplate;
    var str = tmp.replace("$SSW", this.width).replace("$SSH", this.height).replace(/\$ID/g, this.id).replace("$ADD_BTN", this.addToCartBtn.render()).replace("$CLOSE_BTN",this.closeBtn.render()).replace(/\$IMAGE_HOST/g, this.getImageHost());
    return str;
};

/**
* slideShowStartupMainControls Pass the div Id where we want to keep our slideshow controls e.g. Next,Prev, pause.
* @method slideShowStartupMainControls
*
**/
com.art.core.components.SlideShow.prototype.slideShowStartupMainControls = function () {
	trace("slideShowStartupMainControls");
    var _this = this;

    //previous ~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~
    var p = $('#SlideShowPrev');
    this.setSlideShowHover(p, 'previous');
    p.live('click', function () {
        _this.resetPlayPause();
        clearTimeout(_this.slideShowTimerID); //stop
        _this.ssScrollDirection = _this.ssScrollDirectionOptions.RIGHT;
        _this.loadImage();
    });

    //pause~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~
    var pl = $('#SlideShowPlayPause');
    this.setSlideShowHover(pl, 'pause');
    pl.live('click', function () {

        _this.playPauseToggle();
    });

    //next~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~
    var n = $('#SlideShowNext');
    this.setSlideShowHover(n, 'next');
    n.live('click', function () {
        _this.resetPlayPause();
        clearTimeout(_this.slideShowTimerID); //stop
        _this.ssScrollDirection = _this.ssScrollDirectionOptions.LEFT;
        _this.loadImage();
    });

    
};
com.art.core.components.SlideShow.prototype.attachExternalComponent = function(str)
{
	
	$("#externalButtonContainer").html(str);
};

/**
* resetPlayPause method is used to reset the play/pause functionality
* @method resetPlayPause
*
**/
com.art.core.components.SlideShow.prototype.resetPlayPause = function () {
    if (this.ssIsPaused) {
        this.ssIsPaused = false;
        this.setSlideShowHover($('#SlideShowPlayPause'), 'pause');
        var _this = this;
        $('#SlideShowPlayPause').die();
        $('#SlideShowPlayPause').live('click', function () {
            _this.playPauseToggle();
        });
        _this.resetPlayPause();
    }
};

/**
* playPauseToggle method is used to toggle into play/pause button
* @method playPauseToggle
*
**/
com.art.core.components.SlideShow.prototype.playPauseToggle = function () {

    trace("playPausToggle clicked");
    this.ssIsPaused = !this.ssIsPaused;
    if (this.ssIsPaused) {
        clearTimeout(this.slideShowTimerID); //stop timer
    }
    else {
        this.loadImage();
    }

    //toggle button play or pause
    var key = this.ssIsPaused ? 'play' : 'pause';
    var _this = this;
    this.setSlideShowHover($('#SlideShowPlayPause'), key);    
    $('#SlideShowPlayPause').live('click', function () {
        _this.playPauseToggle();
    });
};

/**
* setSlideShowHover method is used to set the events e.g. hover,mouse enter on the image and buttons
* @method setSlideShowHover
*
**/
com.art.core.components.SlideShow.prototype.setSlideShowHover = function (obj, key) {

    var _this = this;
    obj.css("backgroundPosition", this.slideShowControls[key].enabled);
    obj.unbind('mousedown');
    obj.unbind('mouseup');

    obj.die();
    obj.mousedown(
			function () {
			    obj.css("backgroundPosition", _this.slideShowControls[key].disabled);
			});

    obj.mouseup(
			function () {
			    obj.css("backgroundPosition", _this.slideShowControls[key].enabled);
			});

};

/**
* @property shellTemplate main container for slideshow
*/
com.art.core.components.SlideShow.prototype.shellTemplate = "<div id='$ID' style='height:$SSHpx;'>$CLIP</div>";

/**
* @property clipTemplate container that will display scrolling images, overflow is hidden
*/
com.art.core.components.SlideShow.prototype.clipTemplate = "<div id='$ID_CLIP' style='height:100%;overflow:hidden;position:relative;'></div>";

/**
* @property controlsTemplate slideShow control container
*/
com.art.core.components.SlideShow.prototype.controlsTemplate =
	"<div id='$ID_CONTROL_BAR' style='position:absolute;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:0px -493px;background-repeat:no-repeat;zindex:2000;width:510px;height:73px'>" +
		"<div id='SlideShowPrev' style='cursor:pointer;float:left;margin-top:24px;margin-left:20px;width:26px; height:27px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:-90px -604px;background-repeat:no-repeat;'></div>"+
		"<div id='SlideShowPlayPause' style='cursor:pointer;float:left;margin-top:20px;margin-left:3px;width:38px; height:38px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:0px -604px;background-repeat:no-repeat;'></div>"+
		"<div id='SlideShowNext' style='cursor:pointer;float:left;margin-top:24px;margin-left:3px;width:26px; height:27px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:-120px -604px;background-repeat:no-repeat;'></div>"+
		"<div style='margin-top:20px;width:1px;height:38px;display:inline-block;float:left;margin-left:5px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:-637px 0px;background-repeat:no-repeat;'></div>"+
        "<div id='externalButtonContainer' style='margin-top:10px;'></div>" +        
		"<div style='background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:-599px -493px;height:73px; width:9px;display:inline-block;position:absolute;right:-7px;top:0px;'/>"+
		"<div id='closeSlideShow' style='margin-top:12px;margin-right:15px;float:right;display:inline-block;'>$CLOSE_BTN</div>"+
		"<div id='addToCart' style='margin-top:12px;float:right;display:inline-block;'>$ADD_BTN</div>"+
		"<div id='ssImagePrice' style='text-shadow:0 1px #FFFFFF;font-family: Verdana,Arial,sans-serif;font-size: 11px;color: #EC2127;display:inline-block;margin-top:20px;margin-right:10px;float:right;'></div>"+
		"<div id='ssDiscountImagePrice' style='text-shadow:0 1px #FFFFFF;color: #666;font-family: Verdana,Arial,sans-serif;text-decoration: line-through;font-size: 11px;display:inline-block;margin-top:20px;margin-right:60px;float:right;'></div>"+
		"<div style='clear:both;'></div>"+
	"</div>";
com.art.core.components.BaseComponent.extend(com.art.core.components.SlideShow.prototype);

