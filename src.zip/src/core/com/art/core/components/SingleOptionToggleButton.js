com.art.core.components.SingleOptionToggleButton = function (id,label,value,color) {
    this.id = id;
    this.label = label;
    this.value = value;
    this.callbacks = {};
    this.CLICK = com.art.core.components.SingleOptionToggleButton.CLICK;
    this.color = color == undefined || color == com.art.core.components.SingleOptionToggleButton.DARK ? com.art.core.components.SingleOptionToggleButton.DARK : com.art.core.components.SingleOptionToggleButton.LIGHT;
    this.DARK = com.art.core.components.SingleOptionToggleButton.DARK;
    this.LIGHT = com.art.core.components.SingleOptionToggleButton.LIGHT;
    this.NAME = com.art.core.components.SingleOptionToggleButton.NAME;
    this.states = {};
    this.states[this.DARK] = {selected:'0px -322px',active:'0px -264px',over:'0px -293px',down:'0px -322px'};
    this.states[this.LIGHT] = {selected:'0px -438px',active:'0px -380px',over:'0px -409px',down:'0px -438px'};
    
    com.art.core.components.BaseComponent.extend(this);
};
com.art.core.components.SingleOptionToggleButton.NAME = "SingleOptionToggleButton";
com.art.core.components.SingleOptionToggleButton.CLICK = "SingleOptionToggleButtonCLICK";
com.art.core.components.SingleOptionToggleButton.DARK = "SingleOptionToggleButtonDark";
com.art.core.components.SingleOptionToggleButton.LIGHT = "SingleOptionToggleButtonLight";


com.art.core.components.SingleOptionToggleButton.prototype.getState = function(state)
{
	return this.states[this.color][state];
};

com.art.core.components.SingleOptionToggleButton.prototype.resetButtons = function()
{
	$("#singleOptionToggleButton_"+this.id).unbind("mouseover");
	$("#singleOptionToggleButton_"+this.id).unbind("mouseout");
	$("#singleOptionToggleButton_"+this.id).unbind("mousedown");
	$("#singleOptionToggleButton_"+this.id).unbind("mouseup");
	$("#singleOptionToggleButton_"+this.id).die();
};
com.art.core.components.SingleOptionToggleButton.prototype.getColor = function()
{
	return this.color == this.DARK ? "#FFFFFF" : "#000000";
};	
com.art.core.components.SingleOptionToggleButton.prototype.registerEvents = function()
{
	this.resetButtons();
	var _this = this;
	var obj = $("#singleOptionToggleButton_"+this.id+">div:first-child");
	
	obj.css("border:1px solid red");
	obj.mouseover(function(){
		obj.css('background-position',_this.getState('over'));
	});
	obj.mouseout(function(){
		obj.css('background-position',_this.getState('active'));
	});
	obj.mousedown(function(){
		obj.css('background-position',_this.getState('down'));
	});
	obj.mouseup(function(){
		obj.css('background-position',_this.getState('active'));
		if(_this.callbacks[_this.CLICK] != undefined)
			_this.callbacks[_this.CLICK](_this.value);
	});
};
/**
 * @method getTemplate
 * 
 */
com.art.core.components.SingleOptionToggleButton.prototype.getTemplate = function()
{
	var pos = this.states[this.color]['active'];
	return this.template.replace(/\$ID/g,this.id).replace("$LABEL",this.label).replace("$COLOR", this.getColor()).replace("$POS",pos).replace(/\$IMAGE_HOST/g, this.getImageHost());
};
/**
 * Outputs markup for component
 * @method render
 * @returns {String}
 */
com.art.core.components.SingleOptionToggleButton.prototype.render = function () {
    return this.getTemplate();
};
/**
* @method registerCallback
* @param eventName
* @param callback
*/
com.art.core.components.SingleOptionToggleButton.prototype.registerCallback = function (eventName, callback) {
    this.callbacks[eventName] = callback;
};

com.art.core.components.SingleOptionToggleButton.prototype.template =
"<div id='singleOptionToggleButton_$ID' style='display:inline-block'>"+
	"<div style='cursor:pointer;padding-left:15px; padding-top:5px; padding-right:10px;float:left;height:24px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:$POS;background-repeat:no-repeat; color:$COLOR;'>$LABEL</div>"+
	"<div style='float:left;width:1px;height:24px;padding-top:5px;background-image:url($IMAGE_HOST/images/coreimages/core-components-sprites.png);background-position:-306px -264px;background-repeat:no-repeat;'></div>"+
"<div style='clear:both'></div>";
	
com.art.core.components.BaseButton.extend(com.art.core.components.SingleOptionToggleButton.prototype);