com.art.core.components.SuperZoom = function(id,zindex,useControlBar)
{
	this.init();
	this.useControlBar = useControlBar != undefined ? useControlBar : false;
	this.id 			= id;
	this.controlBar 	= new com.art.core.components.StandardControlBar('szCB',false,"Buy Now","Add To My Gallery");
	this.optionButton;
	this.uid 			= com.art.core.utils.StringUtil.generateUID(12);
	this.lightbox 		= new com.art.core.components.LightBox(id+"_LightBox","body",.7);
	this.windowWidth 	= $(window).width();
	this.windowHeight 	= $(window).height();
	this.loadFired		= false; //prevent multi firing of imagesloaded function
	this.zoomWidth 		= Math.floor(this.windowWidth * .9);
	this.zoomHeight 	= Math.floor(this.windowHeight * .9);
	this.zindex			= zindex;
	this.controlBar.zindex = zindex + 1;
	this.IMAGE_LOADED 	= com.art.core.components.SuperZoom.IMAGE_LOADED;
	this.controlsTimer;
	this._disableAutoClose = false; //mechanism to delay auto close after 5 sec
	this.ESC_KEY_CLICKED = com.art.core.components.SuperZoom.ESC_KEY_CLICKED;
};
com.art.core.components.SuperZoom.IMAGE_LOADED = "superZoomImageLoaded";
com.art.core.components.SuperZoom.ESC_KEY_CLICKED = "escKeyClicked";

com.art.core.components.SuperZoom.prototype.disableAutoClose = function()
{
	clearTimeout(this.controlsTimer);
	this._disableAutoClose = true;
};
com.art.core.components.SuperZoom.prototype.enableAutoClose = function()
{
	this._disableAutoClose = false;
};
com.art.core.components.SuperZoom.prototype.show = function(zoomUrl)
{
	trace("SuperZoom.show");
	this.loadFired = false;
	this.lightbox.setLightBoxZIndex(this.zindex);
	this.lightbox.show();
	trace($("#"+this.uid).width() );
	if( $("#"+this.uid).width() == null )
	{
		trace("SuperZoom not yet created");
		$("body").append('<img id="' + this.uid + '" src="' + zoomUrl+ '"/>');
	}
	else
	{
		trace("SuperZoom created, reuse");
		$("#"+this.uid).attr("src",zoomUrl);
	}
	
	var _this = this;
	$("#"+this.uid).imagesLoaded(function(){
		trace("load fired");
		if(!_this.loadFired)
		{
			_this.loadFired = true;
			var newValue = $(this).scaleObjectToFitOrFill.Calculate({
				srcWidth : $(this).width(),
				srcHeight : $(this).height(),
				destWidth : _this.zoomWidth,
				destHeight : _this.zoomHeight,
				method : "fit"
			});
			$(this).css({
				'position' : 'absolute',
				'z-index' : _this.zindex + 1,
				'width' : newValue.width,
				'height' : newValue.height
			});
		
			//show image
			$(this).center(true);
		
			//position close button
			_this.attachCloseButton();
			_this.positionCloseButton();
		
			//position controls
			if(_this.useControlBar)
			{
				_this.attachControls();
				_this.positionControls();
			}
		
			//register events
			_this.registerEvents();
		
			//notify image is loaded
			if(_this.callbacks[_this.IMAGE_LOADED] != null)
				_this.callbacks[_this.IMAGE_LOADED]();
		}
	});
};
com.art.core.components.SuperZoom.prototype.attachCloseButton = function()
{
	var str = this.closeButtonTemplate.replace("$ID",this.id).replace("$ZINDEX",this.zindex+2).replace(/\$IMAGE_HOST/g, this.getImageHost());
	$("body").append(str);
};
com.art.core.components.SuperZoom.prototype.positionCloseButton = function()
{
	var i = $('#'+this.uid); //image
	var _this = this;
	setTimeout(function(){
		_this.checkSuperZoomSize(i.width(),i.height());
	},250);
	
};
com.art.core.components.SuperZoom.prototype.attachControls = function()
{
	$("body").append(this.controlBar.render());
};
com.art.core.components.SuperZoom.prototype.setPrice = function(value)
{
	this.controlBar.setPrice(value);
};
com.art.core.components.SuperZoom.prototype.setSalePrice = function(value)
{
	this.controlBar.setSalePrice(value);
};
com.art.core.components.SuperZoom.prototype.attachExternalComponent = function(ob)
{
	this.optionButton = ob;
	this.controlBar.attachExternalComponent(this.optionButton.render());
};
com.art.core.components.SuperZoom.prototype.positionControls = function()
{
	trace("superzoom uid: "+this.uid);
	var i = $("#"+this.uid); //image
	var c = this.controlBar; //controls
	
	c.registerEvents();
	c.position("absolute");
	
	var top 	= (Math.round(i.offset().top) + i.height() )- (c.height()+50);
	var left 	= (Math.round(i.offset().left) + Math.round(i.width() - c.width())/2);
	
	c.top(top);
	c.left(left);
};
com.art.core.components.SuperZoom.prototype.checkSuperZoomSize = function(width,height)
{
	var i = $('#'+this.uid); //image
	if(i.width() == width && i.height()==height)
	{
		trace("both match, set close button");
		var c = $("#closeButton"+this.id);
		var w = $(window); //window
		
		var top 	= Math.ceil((( w.height() - c.height() ) / 2+w.scrollTop() ) - (i.height()/2));
		var left 	= Math.ceil((( w.width()  - c.width()  ) / 2+w.scrollLeft()) + (i.width()/2));
		
		$('#closeButton'+this.id).css({'position':'absolute','top':top,'left':left});
	}
	else
	{
		trace("position close button w:"+width);
		var _this = this;
		setTimeout(function(){
			_this.checkSuperZoomSize(i, i.width(), i.height());
		},150);
	}
		
};
com.art.core.components.SuperZoom.prototype.closeButtonTemplate = '<img id="closeButton$ID" src="$IMAGE_HOST/images/photostoart/closebox.png" style="z-index:$ZINDEX;cursor:pointer;"/>';
com.art.core.components.SuperZoom.prototype.registerEvents = function()
{
	var _this = this;
	
	//Preventing right click event on superzoom
    $(document).bind("contextmenu", function (e) {
        e.preventDefault();
    });
	
    if(this.useControlBar)
    {
		$('#'+this.uid).mousemove(function () {
			//trace("mousemove: "+_this._disableAutoClose);
			if(!_this._disableAutoClose)
				_this.hideShowControl();
		});
    }
	$(window).bind('resize',function(){
		if(_this.useControlBar)
			_this.positionControls();
		
		_this.positionCloseButton();
	});
	$('#closeButton'+_this.id).bind('click', function() {
		_this.close();
	});
	this.lightbox.registerCallback(com.art.core.components.LightBox.CLICK,function(){
		_this.close();
	});
	
	$(document).bind('keydown', function (escapeKey) {
	        if (escapeKey.which == 27 || escapeKey.keyCode == 27) {
	            _this.close();
	        }
	    });
	
	this.controlBar.registerEvents();
	if(this.optionButton != undefined)
		this.optionButton.registerEvents();
};
com.art.core.components.SuperZoom.prototype.close = function()
{
	trace("SuperZoom.close");
	
	//clean up image
	$("#"+this.uid).unbind('load');
	$("#"+this.uid).die('load');
	$('#' + this.uid).unbind('click');
	$('#'+ this.uid).remove();
	$("#" + this.uid).empty();
	
	//clean up close button
	$('#closeButton' + this.id).unbind('click');
	$('#closeButton'+this.id).remove();
	$('#closeButton'+this.id).empty();
	
	//clean up lightbox
	this.lightbox.close();
	
	if(this.useControlBar)
		this.controlBar.close();
	
};
com.art.core.components.SuperZoom.prototype.getNextHighestZIndex = function()
{
	return this.controlBar.zindex + 1;
};
com.art.core.components.SuperZoom.prototype.hideShowControl = function ()
{
	var _this = this;
	clearTimeout(this.controlsTimer);
	if (this.controlBar.isHidden())
		this.controlBar.fadeIn();

    this.controlsTimer = setTimeout(function (){
    	_this.controlBar.fadeOut();
	}, 5000);
};
com.art.core.components.BaseComponent.extend(com.art.core.components.SuperZoom.prototype);