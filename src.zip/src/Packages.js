com.art.photosToArt = {};
com.art.photosToArt.modules = {};
com.art.photosToArt.proxies = {};
com.art.photosToArt.components = {};
com.art.photosToArt.commands = {};
com.art.photosToArt.vos = {};