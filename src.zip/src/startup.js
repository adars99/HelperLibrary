

var photosToArtCoreEnvironment = {};

$(document).ready(function(){
	//NOTE: This is the environment variable to pass into the app...here right now but will come from Service call eventually
	photosToArtCoreEnvironment = 
	{
            //alert('in doc ready');

            //NOTE: This is the environment variable to pass into the app...here right now but will come from Service call eventually
        //SECTION: These are HOSTED on partner page
        //'apiKey':'A9D386E7371144AEA4FCEDABB181F593' //Pottery Barn
        'apiKey': 'A555B7EF46B941C3A13B21537E03427D' //APC.com
        , 'serviceUrlEcommerceApi': 'http://dev-api.art.com/ecommerceapi.svc'
        , 'serviceUrlLoggingApi': 'http://dev-api.art.com/Log.svc'
        , 'countryCode': 'US'
        , 'languageIso': 'en'

        //SECTION: OPTIONAL - These are HOSTED on partner page
        //, 'applicationId' : 'DDA1692E2EF94DE5B5FC92BA8CA86E4C'  //Pottery Barn
        //, 'applicationId': 'A51583B8564F48FF898013AA539DEE4E'  //APC.com
        //, 'applicationId': '7C5401EF239741018FBDA48D76520FA8'  //APC.de
        , 'applicationId': 'EE363FE53CAD46249C724FB2680F799F'  //ART.COM
        , 'applicationRootUrl': ''

        //SECTION: These are DATABASE values that come from InitializeAPI
        , 'virtualPath': ''
        , 'serviceList': //CONFIGURATION: What is in this list will be what is used for services.
            [
                  PhotosToArtCore.constants.SERVICE_TYPE_CANVASGALLERY
                , PhotosToArtCore.constants.SERVICE_TYPE_CANVASMUSEUM
                , PhotosToArtCore.constants.SERVICE_TYPE_FRAMING
                , PhotosToArtCore.constants.SERVICE_TYPE_WOODMOUNTING
                , PhotosToArtCore.constants.SERVICE_TYPE_ACRYLIC
                , PhotosToArtCore.constants.SERVICE_TYPE_PRINTONLY
            ]
        , 'serviceDefault': PhotosToArtCore.constants.SERVICE_TYPE_CANVASMUSEUM
        , 'startMode': 'homepage'
        , 'startAuto': false
        , 'contentBlocks': {
            homepage: 'on'
            , header: {
                overview: 'off'
                    , application: 'off'
            }
            , footer: {
                overview: 'off'
                    , application: 'off'

            }
            , valueBox01: 'on'
            , valueBox02: 'on'
            , valueBox03: 'on'
        }
    };


            //if (window.location.host.indexOf('.potterybarn-photos.') > 0)
            PhotosToArtCore.init(photosToArtCoreEnvironment);
            PhotosToArtCore.registerModule(new com.art.photosToArt.modules.ModuleShell({ "target": "#photostoartcontainer", "inline": "true" }, PhotosToArtCore));
            PhotosToArtCore.startModule("ModuleShell");

            //SECTION: Help and Faq - removed from ModuleShell.getUi()
            PhotosToArtCore.registerModule(new com.art.photosToArt.modules.ModuleHelp({}, PhotosToArtCore));
            PhotosToArtCore.startModule("ModuleHelp");


            $('#id-button-home-dynamic').live('click', function () {
                if (PhotosToArtCore != undefined && PhotosToArtCore.getModel() != undefined && PhotosToArtCore.getModel().initializeGet() == false)
                {
                    var itemCount = PhotosToArtCore.getModel().getGalleryItemCount();

                    trace("itemCount is: " + itemCount);

                    if (itemCount == 0)
                        PhotosToArtCore.getModule("ModuleShell").openUploader();
                    else
                        PhotosToArtCore.getModule("ModuleShell").getUi(itemCount);
                }
                else
                {
                    alert("App is still loading.  Try again in a few seconds.  This warning will be removed for production.");
                }
            });
});
