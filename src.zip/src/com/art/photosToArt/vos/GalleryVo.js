com.art.photosToArt.vos.GalleryVo = function()
{
    this.galleryId = '';
    this.title = '';
    this.visibility = '';
    this.shortDescription = '';
    this.longDescription = '';
    
    this.galleryItems = [];
    this.walls = [];
    
    
    this.isLoaded = false;
};

com.art.photosToArt.vos.GalleryVo.prototype.parseGalleryFromServiceResponse = function(data)
{
    if (data.GalleryAttributes)
    {
        this.galleryId          = data.GalleryAttributes.GalleryId;
        this.title              = data.GalleryAttributes.Title;
        this.visibility         = data.GalleryAttributes.GalleryVisibility;
        this.shortDescription   = data.GalleryAttributes.ShortDescription;
        this.longDescription    = data.GalleryAttributes.LongDescription;
        
        this.isLoaded = true;
    }
    if (data.GalleryItems)
        this.galleryItems = data.GalleryItems;
    
    if (data.Walls)
        this.walls = data.Walls;
    
};

com.art.photosToArt.vos.GalleryVo.prototype.getGalleryFromServiceResponseByTitle = function(galleries,titleToFind)
{
    if (galleries)
    {
        for (var i = 0; i < galleries.length; i++)
        {
            if (galleries[i].Title.toLowerCase() == titleToFind.toLowerCase())
            {
                this.parseGalleryFromServiceResponse({'GalleryAttributes':galleries[i]});
                break;
            }
        }
    }
};
