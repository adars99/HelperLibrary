/**
 * This class is meant to aid in the communication with the ImageUpdateAndGetResults operation.
 * 
 * The constructor will get the data from the Proxy (Model) and then the caller can fill out specific aspects, 
 * depending on what needs updating.
 */
com.art.photosToArt.vos.UserImageChangeRequestVo = function(model)
{
	try
	{
	    this.apiKey = model.application.apiKey;
	    this.sessionId = model.user.sessionId;
	    this.imageId = model.SelectedImageIdGet(); //We will use the imageGuid for the reference.
	    this.imageGuid = model.SelectedImageGuidGet();
	    
	    var cropInformation = model.SelectedItemServiceImageCropGet();
	    this.ImageCropId = cropInformation.CustomCropInformation.ImageCropId == 0 ? model.StateImageCropIdOverrideGet() : cropInformation.CustomCropInformation.ImageCropId;
	    this.cropX = cropInformation.Coordinates.CoordinateX;
	    this.cropY = cropInformation.Coordinates.CoordinateY;
	    this.cropW = cropInformation.Dimensions.Width;
	    this.cropH = cropInformation.Dimensions.Height;
	    this.action = '';
	    
	    this.podConfigId = model.SelectedItemPodConfigIdGet();
	    this.selectedService = model.SelectedItemServiceGet().labelForServiceCall;
	    this.selectedServiceSubType = model.SelectedItemServiceGet().subType;
	    this.maxImageAreaWidth = 400; //TODO: Configurable on a application level once UI changes size
	    this.maxImageAreaHeight = 700; //TODO: Configurable on a application level once UI changes size
	}
	catch(err)
	{
		//trace('Error in UserImageChangeRequestVo constructor ' + err.message + ', ' + err.fileName + ' Line ' + err.lineNumber);
	}
};
com.art.photosToArt.vos.UserImageChangeRequestVo.action = {CROP:'crop', SIZECROP:'sizecrop'};

com.art.photosToArt.vos.UserImageChangeRequestVo.prototype.updateCropInformation = function(cropX,cropY)
{
    this.cropX = cropX;
    this.cropY = cropY;
    this.action = com.art.photosToArt.vos.UserImageChangeRequestVo.action.CROP;
};

com.art.photosToArt.vos.UserImageChangeRequestVo.prototype.updateItemService = function(itemService)
{
    this.selectedService = itemService.labelForServiceCall;
    this.selectedServiceSubType = itemService.SubType;
    
    //TODO: Now we must also switch Crops...which will be either the crop stored for this, or a blank crop
    
};