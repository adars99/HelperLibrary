com.art.photosToArt.vos.AvailableSizeData = function(sizeData)
{
	this.sizeData;
};

/**
= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
returns [{index:VALUE,display:'w X h "|cm'},...];
index as number
display is dimensions in inches(") or cm
**/

com.art.photosToArt.vos.AvailableSizeData.prototype.getImageSizeData = function(imageSizePerService)
{
    var sizes = imageSizePerService;
    var hash = {};
    //var hash = [];
    var arr = [];   
    
    //getSelectedImageSizesTotal
    for (var m in sizes)
    {
        var w = sizes[m].Small;
        var h = sizes[m].Large;
        var podConfigId = sizes[m].PodConfigId;
        var so = Number(w) * Number(h);
        //filter to only use best fit (group 1)
        var g = sizes[m].Group;
        
    	if (g.indexOf('1') > -1)
        {
            //no longer using indices, using podconfigids now
            hash[m] = { order: so, small: w, large: h, id: m, label: w + " x " + h, groups: g , podConfigId: podConfigId};
            arr.push(hash[m]);
        }
    
    }
    
    return arr.sort(this.sortSizes);
};

com.art.photosToArt.vos.AvailableSizeData.prototype.sortSizes = function(a, b)
{
    var returnValue = 0;
    return ((Number(a.small) < Number(b.small)) ? -1 
            : ((Number(a.small) > Number(b.small)) ? 1 
                    : ((Number(a.large) < Number(b.large)) ? -1 : 1)));
};

