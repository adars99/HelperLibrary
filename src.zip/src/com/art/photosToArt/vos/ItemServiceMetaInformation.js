com.art.photosToArt.vos.ItemServiceMetaInformation = function(name,
        labelForData, labelForServiceCall, labelForObjectProperty, itemServiceCode, subType)
{

    this.name = name;
    this.labelForData = labelForData;
    this.labelForServiceCall = labelForServiceCall;
    this.labelForObjectProperty = labelForObjectProperty;
    this.itemServiceCode = itemServiceCode;
    this.subType = subType;
    this.labelForButtonGeneric = '';
    this.labelForButtonSpecific = '';
};

com.art.photosToArt.vos.ItemServicesMetaInformation = function(availableServices)
{
	if (availableServices === undefined || (/canvasmw|canvasmuseum/gi.test(availableServices)))
		this.canvasMuseum = new com.art.photosToArt.vos.ItemServiceMetaInformation('CanvasMuseum', 'CanvasMuseum', 'canvasmw', 'CanvasMuseum', 'C', 'mw');
	if (availableServices === undefined || (/canvasgw|canvasgallery/gi.test(availableServices)))
		this.canvasGallery = new com.art.photosToArt.vos.ItemServiceMetaInformation('CanvasGallery', 'CanvasGallery', 'canvasgw', 'CanvasGallery', 'C', 'gw');
	if (availableServices === undefined || (/framing/gi.test(availableServices)))
		this.framing = new com.art.photosToArt.vos.ItemServiceMetaInformation('Framing', 'Framing', 'framing', 'Frame', 'F', '');
	if (availableServices === undefined || (/mounting/gi.test(availableServices)))
		this.mounting = new com.art.photosToArt.vos.ItemServiceMetaInformation('Mounting', 'Mounting', 'mounting', 'Mounting', 'M', '');
	if (availableServices === undefined || (/acrylic/gi.test(availableServices)))
		this.acrylic = new com.art.photosToArt.vos.ItemServiceMetaInformation('Acrylic', 'Acrylic', 'acrylic', 'Acrylic', 'A', '');
	if (availableServices === undefined || (/printonly/gi.test(availableServices)))
		this.printOnly = new com.art.photosToArt.vos.ItemServiceMetaInformation('PrintOnly', 'PrintOnly', 'printonly', 'PrintOnly', 'P', '');

};