var _gaq = _gaq || []; 

/**
 * Global Singleton core application
 * 
 * @returns
 */
var PhotosToArtCore = (function()
{
    var model               = {};
    var serviceProvider     = {};
    var templateEngine      = {};    
    var subscribers         = {};
    var environment         = {};
    var ga                  = {};
    var requestBaseVO       = {};
    var version             = "@SVN@";
    
    var markupUtil          = {};
    var loggingManager      = {};
    var appName             = "PhotosToArt";
    var appNameShort        = "p2a";
    var localizationManager = {};
    
    var events = 
        {
              INITIALIZE_API:'INITIALIZE_API'
            , INITIALIZE_API_FAILURE:'INITIALIZE_API_FAILURE'
            , INITIALIZE_API_SUCCESS:'INITIALIZE_API_SUCCESS'
            , APP_INIT_IMAGES:'APP_INIT_IMAGES'
            , CANCEL:'CANCEL'
            , CLOSE_APP:'CLOSE_APP'
            , LOAD_USER_INTERFACE : 'LOAD_USER_INTERFACE'
            , RELOAD_USER_INTERFACE : 'RELOAD_USER_INTERFACE'
            , SERVICE_TAB_CLICKED:'SERVICE_TAB_CLICKED'
            , GALLERY_REMOVE_ITEM:'GALLERY_REMOVE_ITEM'
            , GALLERY_REMOVE_ITEM_SUCCESS:'GALLERY_REMOVE_ITEM_SUCCESS'
            , GALLERY_REMOVE_ITEM_FAILURE:'GALLERY_REMOVE_ITEM_FAILURE'
            , PHOTO_DELETED: 'PHOTO_DELETED'
            , USERIMAGE_CLICKED : 'USERIMAGE_CLICKED'
            , RELOAD_USER_INTERFACE : 'RELOAD_USER_INTERFACE'
            , DISABLE_UPLOAD_BUTTON : 'DISABLE_UPLOAD_BUTTON'
            , ENABLE_UPLOAD_BUTTON : 'ENABLE_UPLOAD_BUTTON'
            , UPLOAD_COMPLETE : 'UPLOAD_COMPLETE'
            , UPLOAD_PROCESS_COMPLETE : 'UPLOAD_PROCESS_COMPLETE'
            , CONTINUE_TO_UPLOAD : 'CONTINUE_TO_UPLOAD'
            , DO_UPLOAD : "DO_UPLOAD"
            , UPLOAD_CANCEL : 'UPLOAD_CANCEL'
            , USER_IMAGE_CHANGE : 'USER_IMAGE_CHANGE'
            , ADDTOCART_GOTOCART : 'ADDTOCART_GOTOCART'
            , ADDTOCART_GOTOCART_SUCCESS : 'ADDTOCART_GOTOCART_SUCCESS'
            , ADDTOCART_GOTOCART_FAILURE : 'ADDTOCART_GOTOCART_FAILURE'
            , ADDTOCART_STAY : 'ADDTOCART_STAY'
            , ADDTOCART_STAY_SUCCESS : 'ADDTOCART_STAY_SUCCESS'
            , ADDTOCART_STAY_FAILURE : 'ADDTOCART_STAY_FAILURE'
            
            , AUTHENTICATE_ACCOUNT : 'AUTHENTICATE_ACCOUNT' 
            , AUTHENTICATE_ACCOUNT_SUCCESS : 'AUTHENTICATE_ACCOUNT_SUCCESS' 
            , AUTHENTICATE_ACCOUNT_FAILURE : 'AUTHENTICATE_ACCOUNT_FAILURE' 
            , CREATE_ACCOUNT : 'CREATE_ACCOUNT'
            , CREATE_ACCOUNT_SUCCESS : 'CREATE_ACCOUNT_SUCCESS'
            , CREATE_ACCOUNT_FAILURE : 'CREATE_ACCOUNT_FAILURE'
            , FRAME_CREATE : 'FRAME_CREATE'
            , FRAME_CREATE_SUCCESS : 'FRAME_CREATE_SUCCESS'
            , FRAME_CREATE_FAILURE : 'FRAME_CREATE_FAILURE'
            , FRAME_GET_COMPONENTS: 'FRAME_GET_COMPONENTS'
            , FRAME_GET_COMPONENTS_SUCCESS: 'FRAME_GET_COMPONENTS_SUCCESS'
            , FRAME_GET_COMPONENTS_FAILURE: 'FRAME_GET_COMPONENTS_FAILURE'
            , FRAME_GET_MOULDING_PRICE : 'FRAME_GET_MOULDING_PRICE'
            , FRAME_GET_MOULDING_PRICE_SUCCESS : 'FRAME_GET_MOULDING_PRICE_SUCCESS'
            , FRAME_GET_MOULDING_PRICE_FAILURE : 'FRAME_GET_MOULDING_PRICE_FAILURE'
            , FRAME_UPDATE_MOULDING : 'FRAME_UPDATE_MOULDING'
            , FRAME_UPDATE_MAT : 'FRAME_UPDATE_MAT'
            , FRAME_UPDATE_MAT_COUNT : 'FRAME_UPDATE_MAT_COUNT'
            , GALLERY_GET_BY_USER : 'GALLERY_GET_BY_USER'
            , GALLERY_GET_BY_USER_SUCCESS : 'GALLERY_GET_BY_USER_SUCCESS'
            , GALLERY_GET_BY_USER_FAILURE : 'GALLERY_GET_BY_USER_FAILURE'
            , GALLERY_ADD_FOR_USER : 'GALLERY_ADD_FOR_USER'
            , GALLERY_ADD_FOR_USER_SUCCESS : 'GALLERY_ADD_FOR_USER_SUCCESS'
            , GALLERY_ADD_FOR_USER_FAILURE : 'GALLERY_ADD_FOR_USER_FAILURE'
            , GALLERY_GET : 'GALLERY_GET'
            , GALLERY_GET_SUCCESS : 'GALLERY_GET_SUCCESS'
            , GALLERY_GET_FAILURE : 'GALLERY_GET_FAILURE'
            , GALLERY_ADD_ITEM : 'GALLERY_ADD_ITEM'
            , GALLERY_ADD_ITEM_SUCCESS : 'GALLERY_ADD_ITEM_SUCCESS'
            , GALLERY_ADD_ITEM_FAILURE : 'GALLERY_ADD_ITEM_FAILURE'
            , CATALOG_ITEM_GET : "CATALOG_ITEM_GET"
            , CATALOG_ITEM_GET_SUCCESS : 'CATALOG_ITEM_GET_SUCCESS'
            , CATALOG_ITEM_GET_FAILURE : 'CATALOG_ITEM_GET_FAILURE'

            , CATALOG_ITEM_GET_VARIATIONS : 'CATALOG_ITEM_GET_VARIATIONS'
            , CATALOG_ITEM_GET_VARIATIONS_SUCCESS : 'CATALOG_ITEM_GET_VARIATIONS_SUCCESS'
            , CATALOG_ITEM_GET_VARIATIONS_FAILURE : 'CATALOG_ITEM_GET_VARIATIONS_FAILURE'
            , CATALOG_ITEM_VARIATIONS_GET_MASTER : 'CATALOG_ITEM_VARIATIONS_GET_MASTER'
            , CATALOG_ITEM_VARIATIONS_GET_MASTER_SUCCESS : 'CATALOG_ITEM_VARIATIONS_GET_MASTER_SUCCESS'
            , CATALOG_ITEM_VARIATIONS_GET_MASTER_FAILURE : 'CATALOG_ITEM_VARIATIONS_GET_MASTER_FAILURE'
            , CATALOG_GET_CONTENT : 'CATALOG_GET_CONTENT'
            , CATALOG_GET_CONTENT_SUCCESS : 'CATALOG_GET_CONTENT_SUCCESS'
            , CATALOG_GET_CONTENT_FAILURE : 'CATALOG_GET_CONTENT_FAILURE'
            , IMAGE_UPDATE_AND_GET_RESULTS : 'IMAGE_UPDATE_AND_GET_RESULTS'
            , IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS : 'IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS'
            , IMAGE_UPDATE_AND_GET_RESULTS_FAILURE : 'IMAGE_UPDATE_AND_GET_RESULTS_FAILURE'
            , DUPLICATE_FRAME_FOR_CART : 'DUPLICATE_FRAME_FOR_CART'
            , DUPLICATE_FRAME_FOR_CART_SUCCESS : 'DUPLICATE_FRAME_FOR_CART_SUCCESS'
            , DUPLICATE_FRAME_FOR_CART_FAILURE : 'DUPLICATE_FRAME_FOR_CART_FAILURE'
            , CLOSE_POPUP:    'CLOSE_POPUP'
            , SUBTYPE_CLICKED:  'SUBTYPE_CLICKED'
            , SHOW_MORE_SIZES: 'SHOW_MORE_SIZES'
            , CLOSE_LIGHTBOX: 'CLOSE_LIGHTBOX'    
            , SHOW_HOMEPAGE: 'SHOW_HOMEPAGE'
            , FRAME_CREATE: 'FRAME_CREATE'
            , SHOW_PRICE_DETAILS_MODAL: 'SHOW_PRICE_DETAILS_MODAL'
            , GET_SALES_EVENT_MESSAGE_FOR_PRODUCT : 'GET_SALES_EVENT_MESSAGE_FOR_PRODUCT'
            , GET_SALES_EVENT_MESSAGE_FOR_PRODUCT_SUCCESS : 'GET_SALES_EVENT_MESSAGE_FOR_PRODUCT_SUCCESS'
            , GET_SALES_EVENT_MESSAGE_FOR_PRODUCT_FAILURE : 'GET_SALES_EVENT_MESSAGE_FOR_PRODUCT_FAILURE'
            , SHOW_SUPER_ZOOM: "SHOW_SUPER_ZOOM"
        };
    var interestedSubscribers = {};
    
    // Some of these "SERVICE_" values are all deprecated = use model.data.serviceTypes.framing.name
    var constants = 
    {
        P2A_COOKIE_DICTIONARY_PERSISTENT: 'p2a'
        ,ART_COOKIE_DICTIONARY_PERSISTENT: 'ap'
        ,COOKIE_NAME_P2AKEY: 'p2akey'
        ,COOKIE_NAME_CARTKEY: 'cartkey'
        ,COOKIE_NAME_ACCEPTS_TERMS: 'acceptsterms'
        ,SERVICE_TYPE_CANVAS: 'canvasmuseum'
        ,SERVICE_TYPE_CANVASMUSEUM: 'canvasmuseum'
        ,SERVICE_TYPE_CANVASGALLERY: 'canvasgallery'
        ,SERVICE_TYPE_FRAMING: 'framing'
        ,SERVICE_TYPE_WOODMOUNTING: 'mounting'
        ,SERVICE_TYPE_ACRYLIC: 'acrylic'
        ,SERVICE_TYPE_PRINTONLY: 'printonly'
        ,GALLERY_PHOTOSTOART_DEFAULT_NAME: 'photostoart'
        ,GALLERY_PHOTOSTOART_DEFAULT_VISIBILITY: 'Public'
        ,UI_MODE_APPLICATION:'UI_MODE_APPLICATION'
        ,UI_MODE_LANDING:'UI_MODE_LANDING'
        ,COOKIE_NAME_SESSIONID:'sessionid'
        ,FRAMING_COMPONENT_MOULDING : 'FRAMING_COMPONENT_MOULDING'
        ,FRAMING_COMPONENT_MAT : 'FRAMING_COMPONENT_MAT'
        ,FRAMING : 'framing'
        ,TOP_MAT : 'topMat'
        ,MIDDLE_MAT : 'middleMat'
        ,BOTTOM_MAT : 'bottomMat'
        ,FRAME: 'frame'
        ,MAT:'mat'
        ,MAX_MAT_COUNT:3
    };

    //public members
    return {
        "getVersion":function(){return version;},
        "events":events,
        "constants":constants,
        "registerModule":function(module)
        {
            this.registerSubscriber(module);
        },
        "registerSubscriber":function(observer)
        {
            //trace('P2A Core - registering subscriber ' + observer.NAME);
            if(observer.NAME == undefined)
                throw new Error("PhotosToArtCore.registerSubscriber failed! observer.NAME is undefined.");
            
            var arr = observer.listNotificationInterests();
            for(var i=0; i < arr.length; i++)
            {
                var noteName = arr[i];
                if(interestedSubscribers[noteName] == undefined)
                    interestedSubscribers[noteName] = {};
                    
                interestedSubscribers[noteName][observer.NAME] = true;
            }
            subscribers[observer.NAME] = observer;
        },
        "getInterestedSubscribers":function(){ return interestedSubscribers; },
        "removeModule":function(name)
        {
            var tmp = {};
            for(var m in subscribers)
            {
                if(m != name)
                    tmp[m] = subscribers[m];
            }
            subscribers = tmp;
        },
        "sendNotification":function(note)
        {
            try
            {
                //trace("EVENT: " + note.name);
                for(var m in interestedSubscribers[note.name])
                {
                    if(subscribers[m] != undefined)
                    {
                        try
                        {
                        	// trace('P2ACORE: handle ' + note.name + ': ' + subscribers[m].NAME);
                            subscribers[m].handleNotification(note);
                        }
                        catch(err)
                        {
                            //trace('Error handling notification : ' + subscribers[m].NAME);
                            this.logError(err);
                        }
                    }
                }
            }
            catch(err)
            {
                //trace('Error handling notification : ' + subscribers[m].NAME);
                this.logError(err);
            }
        },
        "clearAll":function()
        {
            subscribers = {};
            interestedSubscribers = {};
        },
        "startAll":function()
        {
            for(var module in modules)
            {
                subscribers[module].init();
            }
        },
        "startModule":function(name,obj)
        {
            if(obj == undefined)
            {
                subscribers[name].init();
            }
            else
            {
                subscribers[name].init(obj);
            }
        },
        "getSubscriber":function(name)
        {
            return subscribers[name];
        },
        "getSubscribers":function(name)
        {
            return subscribers;
        },
        "getModule":function(name)
        {
            return subscribers[name];
        },
        "setEnvironment":function(obj)
        {
            environment = obj;
        },
        "getEnvironment":function()
        {
            return environment;
        },
        "addToEnvironment":function(key,value)
        {
            environment[key] = value;
        },
        "getModel":function(){ return model; },
        "initModel":function(environment){model = new com.art.photosToArt.proxies.ApplicationProxy(this.getEnvironment());},
        "getServiceProvider":function(){ return serviceProvider; },
        "getLocalizationManager":function(){ return localizationManager; },
        "getLoggingManager":function(){ return loggingManager; },
        "getMarkupUtil":function(){ return markupUtil; },
        "getString" : function(baseString) { return localizationManager.getString(baseString);},
        "init":function(_environment)
        {
            //setup Environment
            this.setEnvironment(_environment);
            var _this = this;
            //setup application level objects
            serviceProvider = new com.art.core.services.ServiceProvider(this.getEnvironment()); //new com.art.photosToArt.commands.ServiceProvider();
            markupUtil = new com.art.core.utils.MarkupUtil(appNameShort);
            localizationManager = new com.art.core.utils.LocalizationManager(this.getEnvironment(),"_p2ai");
            loggingManager = new com.art.core.utils.LoggingManager(this.getEnvironment());
            this.getLocalizationManager().registerCallback(com.art.core.utils.LocalizationManager.ERROR,function(error){
            	_this.getLoggingManager().logError(error);
            });
            
            //NOTE:  set up the "command" object for the app, which will make all service calls
            this.registerSubscriber(new com.art.photosToArt.commands.ApplicationCommand(this));
            
            //setup GA
            this.initTracking();
            
            //IE7 bug fix search button
            if($.browser.msie && $.browser.version == "7.0")
            	$("#headerSearchButton").css("border","0px solid");
        },
        "resetModel":function()
        {
            model = new com.art.photosToArt.proxies.ApplicationProxy();
        },
        "initTracking":function()
        {
            ga = new com.art.core.tracking.GoogleAnalytics("P2A");
            ga.init();
        },
        "logError":function(err)
        {
            loggingManager.logError(err);
        },
        "GATrackPageView":function(pageViewName)
        {
            return ga.trackPageView(pageViewName);
        },
        "getGoogleAnalytics":function(){return ga;}
    };
})();
