/**
 * This is the Help module.
 * It deals with the both FAQ and Help content.
 * @module ModuleHelp
 * @param data
 * @param app
 */
com.art.photosToArt.modules.ModuleHelp = function(data, app)
{
	this.NAME		= com.art.photosToArt.modules.ModuleHelp.Name;
	this.moduleData = data;
	this.app 		= app;
	this.instance	= this;
	this.IMAGE_BASEURL = this.app.getEnvironment().imagePath;
	this.markupUtil = this.app.getMarkupUtil().getInstance(this);
	this.IMAGE_LIGHTBOX_CLOSE = this.app.getEnvironment().imagePath + '/images/photostoart/close.png';
	
};
com.art.photosToArt.modules.ModuleHelp.Name = 'ModuleHelp';

com.art.photosToArt.modules.ModuleHelp.prototype.getTemplate = function()
{
	return this.template.replace('$NAME',this.NAME);
};

/**
 * Gets the location in the container to insert this module's rendered markup
 * @method getTarget
 * @returns
 */
com.art.photosToArt.modules.ModuleHelp.prototype.getTarget = function()
{
	return this.moduleData.target;
	return returnValue.replace('$NAME', this.NAME.toLowerCase());
};

/**
 * Initializes the module
 * @method init
 */
com.art.photosToArt.modules.ModuleHelp.prototype.init = function()
{
	//alert(this.getTemplate);
	//trace("ModuleHelp INIT");
	$(this.getTarget()).html(this.getTemplate());
	this.registerEvents();

};

/**
 * @method render
 */
com.art.photosToArt.modules.ModuleHelp.prototype.render = function(startContent)
{
    var _this =this;
	if(startContent == "photocanvases")
	{
	   $(document).ready(function()
	   {
		   //trace('ModuleHelp.render photocanvases');
		   _this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/photocanvasfaq'},'vo'));
	   });
	}  
	else if(startContent == "ordering")
	{
		$(document).ready(function()
		{
			_this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/orderingfaq'},'vo'));
		});
	}
	else if(startContent == "shipping")
	{
		$(document).ready(function()
		{
			_this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/shippingfaq'},'vo'));
		});
	}	
	
};

/**
 * Attaches event handlers to html elements
 * @method registerEvents
 * @param 
 */
com.art.photosToArt.modules.ModuleHelp.prototype.registerEvents = function()
{
	var _this = this;

	// footer links starts here
	function listItemSelected(tab)
    {
    	$('.footerlinkhdr li').each(function(tab){
    		if($(this).hasClass('selected'))
    		{
    			$(this).removeClass('selected');
    		}
    	});
    	$(tab).addClass('selected');
    }	
	$('#p2a-aboutus').live('click', function()
	{
		listItemSelected(this);
		_this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/aboutusfaq'},'vo'));
	});
	
	$('#p2a-terms').live('click', function()
	{
		listItemSelected(this);
		_this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/termsofusefaq'},'vo'));
	});
	
	$('#p2a-termsofsale').live('click', function()
	{
		listItemSelected(this);
		_this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/termsofsalefaq'},'vo'));
	});
	
	$('#p2a-privacy').live('click', function()
	{
		listItemSelected(this);
		_this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/privacypolicyfaq'},'vo'));
	});
	
	$('#p2a-program').live('click', function()
	{
		listItemSelected(this);
		_this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/photocanvasfaq'},'vo'));
	});
	
	$('#p2a-orderingr').live('click', function()
	{
		listItemSelected(this);
		_this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/orderingfaq'},'vo'));
	});
	
	$('#p2a-shipping').live('click', function()
	{
		listItemSelected(this);
		_this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/shippingfaq'},'vo'));
	});
	
	$('#p2a-cs').live('click', function()
	{
		listItemSelected(this);
		_this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/customerservicefaq'},'vo'));
	}); 
			
};	
com.art.photosToArt.modules.ModuleHelp.prototype.renderContent = function(cmsContent)
{
	var _this = this;
	var popupTarget = $('#p2ahelpmodule');
	if(popupTarget.length === 0)
	{
		// Create a place to put the content in case we don't have the div in this context.
		$('body').append('<div style="width:725px" id="p2atemphelp"></div>');
		popupTarget = $('#p2atemphelp');
	}
	//trace('=====renderContent - html.length = ' + popupTarget.html().length);
	if(popupTarget.html().length === 0)
	{
		popupTarget.html(this.getTemplate());
	
		this.lightBox = new com.art.core.components.LightBox('PhotoCanvases','body','0.4');
		this.lightBox.show();
	
		var PhotoCanvasesZIndex = this.lightBox.getLightBoxZIndex()+1;		
		popupTarget.css({'z-index':PhotoCanvasesZIndex, 'background-color':'white'});
		$('#lightboxclosebtn').bind('click', function()
		{         
		   	_this.lightBox.close();
		   	_this.destroy();
		});
	}
	$('#displaytext').html(cmsContent);
	
	
	setTimeout(function(){popupTarget.center(true);}, 250);
	//$('body').append(popupTarget);
};
/**
 * @method destroy
 */
com.art.photosToArt.modules.ModuleHelp.prototype.destroy = function()
{
	//com.art.core.utils.destroyChildEvents($("#"+this.NAME));
	$("#"+this.NAME).die();
	$("#"+this.NAME).unbind();
	$("#"+this.NAME).empty();
	$("#"+this.NAME).remove(); 
};

/**
 * Sends notifications through event messaging system
 * @method notify
 * @param note
 */
com.art.photosToArt.modules.ModuleHelp.prototype.notify = function(note)
{
	this.app.sendNotification(note);
};

/**
 * Informs Core of events it will handle
 * @method listNotificationInterests
 * @returns {Array}
 */
com.art.photosToArt.modules.ModuleHelp.prototype.listNotificationInterests = function()
{
	return [
	        this.app.events.CATALOG_GET_CONTENT_SUCCESS
	        ];
};


/**
 * Handlers for events
 * @method handleNotification
 * @param note
 */
com.art.photosToArt.modules.ModuleHelp.prototype.handleNotification = function(note)
{
	//trace('MH.handleNotfication: ' + note.name);
	//trace('ModuleHelp.Handle CATALOG_GET_CONTENT_SUCCESS for content ' + note.body.contentBlockName);
	switch(note.name)
	{
		case this.app.events.CANCEL:
		case this.app.events.CLOSE_APP:
			this.destroy();
			break;
		default:
			throw Error('unhandled note.name: '+note.name);
			break;
		case this.app.events.CATALOG_GET_CONTENT_SUCCESS:
        	switch(note.body.contentBlockName.toLowerCase())
        	{
        	    case "p2a/aboutusfaq":
        	    case "p2a/privacypolicyfaq":
        		case "p2a/shippingfaq":
        		case "p2a/orderingfaq":
        		case "p2a/customerservicefaq":	
	        	case "p2a/photocanvasfaq":
	        	case "p2a/termsofusefaq":
	        	case "p2a/termsofsalefaq":
	        		this.renderContent(note.body.ResponseValue);
	        		break;

	        		
        	}
        	if (note.body.anchor != undefined && note.body.anchor != "")
        	{
        		window.location = '#' + note.body.anchor;
        	}
        	break;
	};
};

com.art.photosToArt.modules.ModuleHelp.prototype.template = '<div id="$NAME" style="width:725px">'
+      		  '<div id="header" class="floatright" style="background-color:#FFFFFF; width:100%; height:40px; ">'
+      			    '<div class="floatright" style="padding-right:10px; padding-top:10px; cursor:pointer;">'
+            		      '<img id="lightboxclosebtn" alt="close" src="http://cache1.allpostersimages.com/images/photostoart/close.png">'
+      			    '</div>'
+      		 '</div>'
+       	 '<div id="helpdivcontent" style="clear:both;">' 
+               	  '<div id="displaytext"> </div>'
+      		 '</div>'
+'</div>';




