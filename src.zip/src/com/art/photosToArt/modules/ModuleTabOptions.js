/**
 * This module is the main control container object for the Working Area.
 * It supports print size selection, cropping, and the canvas wrap selector type (Museum vs. Gallery)
 * @module ModuleTabOptions
 * @param data
 * @param app
 */
com.art.photosToArt.modules.ModuleTabOptions = function(data,app)
{
    this.app         = app;
    this.moduleData = data;
    this.NAME        = com.art.photosToArt.modules.ModuleTabOptions.NAME;
    this.instance    = this;
    this.IMAGE_BASEURL = this.app.getEnvironment().imagePath;
    this.imagesDir = this.IMAGE_BASEURL + com.art.photosToArt.modules.ModuleTabOptions.IMAGE_SUBFOLDER;
    this.markupUtil = this.app.getMarkupUtil().getInstance(this);

    this.IMAGE_INFO_OFF = this.app.getEnvironment().imagePath + '/images/photostoart/info_off.png';
    this.IMAGE_ARROW = this.app.getEnvironment().imagePath + '/images/photostoart/arrow.png';
    this.IMAGE_MUSEUM_WRAP = this.app.getEnvironment().imagePath + '/images/photostoart/museumwrap.gif';
    this.IMAGE_GALLERY_WRAP = this.app.getEnvironment().imagePath + '/images/photostoart/gallerywrap.gif';
    this.isInitialized  = false;
    this.baseMouldingImageUrl = com.art.photosToArt.modules.ModuleTabOptions.baseMouldingImageUrl;
    this.baseMatImageUrl = com.art.photosToArt.modules.ModuleTabOptions.baseMatImageUrl;
};

//Must be accessible statically by cropping popup
com.art.photosToArt.modules.ModuleTabOptions.tmpCropX = 0;
com.art.photosToArt.modules.ModuleTabOptions.tmpCropY = 0;

com.art.photosToArt.modules.ModuleTabOptions.NAME                 = "ModuleTabOptions";
com.art.photosToArt.modules.ModuleTabOptions.IMAGE_SUBFOLDER      = "/images/photostoart/";
com.art.photosToArt.modules.ModuleTabOptions.IMAGE_SIZE_CONTAINER = "warning.gif";
com.art.photosToArt.modules.ModuleTabOptions.IMAGE_DROP_DOWN_OVER = "print_size_over.png";
com.art.photosToArt.modules.ModuleTabOptions.IMAGE_DROP_DOWN      = "print_size.png";
com.art.photosToArt.modules.ModuleTabOptions.IMAGE_INFO_OFF                      = "info_off.png";
com.art.photosToArt.modules.ModuleTabOptions.IMAGE_CHANGE_PRINT_AREA             = "change_print_area[LANG_FOR_IMG].gif";
com.art.photosToArt.modules.ModuleTabOptions.IMAGE_CHANGE_PRINT_AREA_ROLLOVER    = "change_print_area_rollover[LANG_FOR_IMG].gif";
com.art.photosToArt.modules.ModuleTabOptions.IMAGE_INACTIVE_PRINT_AREA           = "inactiveprintarea[LANG_FOR_IMG].gif";
com.art.photosToArt.modules.ModuleTabOptions.baseMouldingImageUrl = '/images/framing/hires/[ID]/thumb/[ID].jpg';
com.art.photosToArt.modules.ModuleTabOptions.baseMatImageUrl = '/images/framing/mats/hires/[ID]/swatch/[ID]_b.jpg';

/**
 * Gets the location in the container to insert this module's rendered markup
 * @method getTarget
 * @returns
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.getTarget = function ()
{
    // NOTE: Init is where you initialize the handlers for this module and any variables, etc instantiated object will need
    return this.moduleData.target;
};
/**
 * Initializes the module
 * @method init
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.init = function ()
{
    var _this = this;
    var model = this.app.getModel();
    
    $(this.getTarget()).html(this.getTemplate());
    
    this.configureCanvasOptions();
    this.createToolTip();
    this.registerEvents();
    this.enablePrintArea(); 
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.configureCanvasOptions = function()
{
    var model = this.app.getModel();
    
    // 1 - See if more than one canvas option is supported
    // 2 -    if so, get the model.state for the selected subtype
    var canvasOptionsDiv = $('#' + this.markupUtil.getName('canvaswrapcontainer'));
    
    // This code only executes once, to initialze the state of the radio buttons
    if(!this.isInitialized && this.supportCanvasWrapOptions())
    {
        // We need to display the radio buttons
        if(       model.state.selectedItemServiceSubType === undefined 
                ||model.state.selectedItemServiceSubType.canvas === undefined
                ||model.state.selectedItemServiceSubType.canvas.name === undefined)
        {
            throw new Error("In Model, state.selectedItemServiceSubType or child has not been properly initialized, and is undefined.");
        }
        else
        {
            var canvasDefault = model.state.selectedItemServiceSubType.canvas.name.toLowerCase();
            // radio-1 is Museum, radio-2 is Gallery
            var musBtn = $('input#radio-1');
            var galBtn = $('input#radio-2');
            if(canvasDefault.indexOf('museum') > -1)
            {
                musBtn.attr('checked', 'checked');
                galBtn.removeAttr('checked');
            }
            else
            {
                galBtn.attr('checked', 'checked');
                musBtn.removeAttr('checked');
            }
        }
        this.isInitialized = true;
    }
    
    //STEP: Show the Canvas Options Section only if:
    //    1) Current service is a canvas type
    //    2) We have museum and gallery
    if(!model.isServiceACanvasService(model.SelectedItemServiceGet()) || !this.supportCanvasWrapOptions())
    {
    	canvasOptionsDiv.hide();
        return;
    }
    else
    {
    	canvasOptionsDiv.show();
    }
};

/**
 * Populates the print size dropdown
 * @method fillDropDown
 * @param imageSizeDataPerService
 * @param showMoreSizes
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.fillDropDown = function(imageSizeDataPerService, showMoreSizes)
{
    $('.p2a_mto_ulsizeoptions').html("");
    $('.p2a_mto_sizetextbox').text("");
    var htm = "";
    var tmp;
    var obj = new com.art.photosToArt.vos.AvailableSizeData();
    var sizeData = obj.getImageSizeData(imageSizeDataPerService);
         
        //property is the PODConfigID (SizeID)
    var user = this.app.getModel().user;
    var doConvertToCm = com.art.core.utils.LocalizationManager.determineConvertToCm(user.countryIso, user.currencyIso, user.languageIso);
    for (var property in sizeData)
    {
        var dimensions = com.art.core.utils.StringUtil.formatDimensions(sizeData[property].small, sizeData[property].large, doConvertToCm);   // sizeData[property].small + ' x ' + sizeData[property].large;
        var li = '<li class="lisizeoptions" sizeid="' + sizeData[property].podConfigId + '">' + dimensions + '</li>';
        $('.p2a_mto_ulsizeoptions').append(li);
        if (this.app.getModel().SelectedItemPodConfigIdGet() == sizeData[property].podConfigId)
            $('.p2a_mto_sizetextbox').text(dimensions);
        if ($('.p2a_mto_sizetextbox').text() == "")
        {
            var size = this.app.getModel().getMasterSizeByPodConfigId(this.app.getModel().SelectedItemPodConfigIdGet());
            dimensions = com.art.core.utils.StringUtil.formatDimensions(size.Small, size.Large, doConvertToCm);   // sizeData[property].small + ' x ' + sizeData[property].large;
            $('.p2a_mto_sizetextbox').text(dimensions);
        }
    }
    
    // Needs language support
    if (showMoreSizes)
        $('.p2a_mto_ulsizeoptions').append('<li class="lisizeoptions lisizeoptions_seemore" sizeid="seemore">' + this.app.getString("See More Sizes").replace(/ /gi,"&nbsp;") + '<span style="padding-left:1px;">&gt;</span></li>');
        var _this = this;
        var podConfigId;
        $('.p2a_mto_ulsizeoptions').find('li').each(function(index)          
           {
                $(this).bind('click', function()
                    {
                		_this.app.GATrackPageView('/p2a/create/select-size');
                       podConfigId = $(this).attr('sizeid');
                       var liDimension = $(this).text();
                       $('.p2a_mto_sizeoptions').slideUp("slow");              
                       if (podConfigId == 'seemore')
                        {
                           //STEP: Fire off notify with event name of "OPEN_SEE_MORE_SIZES"
                           _this.notify(new com.art.core.utils.Note(_this.app.events.SHOW_MORE_SIZES,{'podConfigId':podConfigId,'liDimension':liDimension},'vo'));
                        }
                      else
                        {
                          $('.p2a_mto_sizetextbox').text(liDimension);    
                          _this.app.getModel().SelectedItemPodConfigIdSet( podConfigId );
                          var requestParameters = new com.art.photosToArt.vos.UserImageChangeRequestVo(_this.app.getModel());
                          requestParameters.action = com.art.photosToArt.vos.UserImageChangeRequestVo.action.SIZECROP;
                          _this.notify(new com.art.core.utils.Note(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS, requestParameters, 'vo'));
                        }
                   });
         });
  
    $(this).bind('mouseover', function()
    {
        $(this).toggleClass('lisizeoptions_selected');
    });
   
    $(this).bind('mouseout', function()
    {
        $(this).toggleClass('lisizeoptions_selected');
    });
};   
/**
 * Creates the tooltip for the canvaswrap
 * @method createToolTip
 */
//tool tip code starts here
com.art.photosToArt.modules.ModuleTabOptions.prototype.createToolTip = function()
{
    var _this = this; 
    var toolTipContent; 
    var toolTipObj;
    var relativeX;
    var relativeY;
    //tool tip for canvaswrap  
    $('#p2a_mto_canvaswrapmoreinfo').bind('mouseover', function(e)
    {
        toolTipContent = _this.getCanvasWrapToolTip();
        toolTipObj = new com.art.core.components.ToolTip('uniquestring');
        var offset = $(this).offset();
        relativeX = offset.left + 35;
        relativeY = offset.top - 15;    
        toolTipObj.setToolTip(toolTipContent.title, toolTipContent.message); 
        toolTipObj.render(relativeX, relativeY);
    });
    $('#p2a_mto_canvaswrapmoreinfo').bind('mouseout', function(e)
    {
       toolTipObj.destroy();
    });
    //tool tip for printarea
    $('.p2a_mto_printinfo').bind('mouseover', function(e)
    {
         toolTipContent = _this.getPrintAreaToolTip();
         toolTipObj = new com.art.core.components.ToolTip('uniquestring');
         var offset = $(this).offset();
         relativeX = offset.left +35;
         relativeY = offset.top -15;    
         toolTipObj.setToolTip(toolTipContent.title, toolTipContent.message); 
         toolTipObj.render(relativeX, relativeY);
    });
    $('.p2a_mto_printinfo').bind('mouseout', function(e)
    {
       toolTipObj.destroy();
    });   
};    
com.art.photosToArt.modules.ModuleTabOptions.prototype.getCanvasWrapToolTip = function()
{
    var returnValue = {title:' ', message:' '};
    returnValue.title =" ";
    returnValue.message =  '<div id="p2a_tooltip_container" style="display: block;" src="' + this.IMAGE_INFO_OFF + '">' 
    +               '<img class="p2a_tooltip_leftarrow" src="' + this.IMAGE_ARROW + '" />'
    +              '<div class="tooltipcontent">'
    +                      '<div style="margin-bottom:10px;">' +this.app.getString("We offer two styles of canvas wrap. Museum wrap stops the image at the front edge, has hand painted black sides, and is ideal for portraits or when you want to emphasize the photo. Gallery wrap extends the image around the sides and is more informal. Choose the style that suits your d&egrave;cor.")+ '</div>'
    +                     '<div style="font-weight:bold; margin-bottom:10px; cursor:pointer;">' +this.app.getString("Museum Wrap")+ '</div>'
    +                     '<div class="clear"></div>'
    +                      '<img width="205" src="' + this.IMAGE_MUSEUM_WRAP + '" />'
    +                     '<div class="clear"></div>'
    +                     '<div style="font-weight:bold; margin-bottom:10px;">' +this.app.getString("Gallery Wrap")+ '</div>'
    +                     '<div class="clear"></div>'
    +                     '<div><img width="205" src="' + this.IMAGE_GALLERY_WRAP + '" alt="" title="" /></div>' 
    +                     '<div class="clear"></div>'
    +                     '<div class="tooltipcontent addmoreinactivemoreinfo hidden" style="display: none;">'
    +                     '</div>'
    +              '</div>' 
    + '</div>'; 
    return returnValue;
               
};    
com.art.photosToArt.modules.ModuleTabOptions.prototype.getPrintAreaToolTip = function()
{
    var returnValue = {title:' ', message:' '};
    returnValue.title =" ";
    returnValue.message =  '<div id="p2a_tooltip_container" style="display: block;" src="' + this.IMAGE_INFO_OFF + '">' 
       +         '<img class="p2a_tooltip_leftarrow" src="' + this.IMAGE_ARROW + '" />'                
       +              '<div class="tooltipcontent paperTypeMoreInfo hidden" style="display: none;">'
       +                    '<div style="font-weight:bold; margin-bottom:10px; cursor:pointer;">' +this.app.getString("Photographic Paper")+ ' </div>'
       +                    '<div class="clear"></div>'
       +                    '<div>' +this.app.getString("Printing on archival photographic paper results in vivid, pure color and exceptional detail.")+ '</div>'
       +                    '<div class="clear"></div>'
       +              '</div>'
       +              '<div class="tooltipcontent printMoreInfo hidden" style="display: block;">'
       +                  '<div style="font-weight:bold; margin-bottom:10px; cursor:pointer;">' +this.app.getString("Print Area")+ '</div>'
       +                  '<div class="clear"></div>'
       +                  '<div>' +this.app.getString("If your image does not exactly match the aspect ratio of the print size you've chosen, you can adjust the print area in the available space to choose what part of the image will be printed.")+ '</div>'
       +                  '<div class="clear"></div>'
       +             '</div>';
    return returnValue;
    
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.getSizeDataFromCacheAndFillDropDown = function()
{
    var model = this.app.getModel();
    var sizeData = model.getItemAvailableSizesBestFit
    (
            model.SelectedImageGuidGet()
            ,
            model.SelectedItemServiceGet()
    );
    var allSizeData = model.getItemAvailableSizes
    (
            model.SelectedImageGuidGet()
            ,
            model.SelectedItemServiceGet()
    );
    var doShowMoreSizes = model.objectPropertyCount(allSizeData) > model.objectPropertyCount(sizeData);
    this.fillDropDown(sizeData, doShowMoreSizes);
};
/**
 * Attaches event handlers to html elements
 * @method registerEvents
 * @param module
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.registerEvents = function(module)
{

    var _this = this;

    // the drop down menu for the finished size starts here.
    $('.p2a_mto_sizetextbox').bind('click', function(event) {
        if ($('.p2a_mto_sizeoptions li').length > 0) 
        {
            $('.p2a_mto_sizeoptions').slideToggle("slow", function(){});
               event.stopPropagation();
               $('.p2a_mto_ulsizeoptions li').each(function(index){
                   $(this).mouseover(function(){
                        $(this).addClass('lisizeoptions_selected');
                        }).mouseout(function(){
                            $(this).removeClass('lisizeoptions_selected');
                        });
                   });
           }
      });
    
      $('body').live('click',function(event) {
         if ($('.p2a_mto_sizeoptions li').length > 0) {
                  $('.p2a_mto_sizeoptions').slideUp("slow");
             }
         event.stopPropagation();
       });      
       
      $('.'+this.markupUtil.getName('.p2a_mto_sizetextbox',this.markupUtil.buttonStates.ACTIVE)).live('mouseover', function(event) {
           $(this).css('background', "url(" + $(this).attr('dropdownimgover') + ")");
      });
     
      $('.'+this.markupUtil.getName('.p2a_mto_sizetextbox',this.markupUtil.buttonStates.ACTIVE)).live('mouseout', function(event) {
           $(this).css('background', "url(" + $(this).attr('dropdownimg') + ")");
       });

      //cleanup first
      $('#radio-1').die('click');
      $('#radio-1').live('click', function()
      {
             $(this).attr('checked', true);
             $('#radio-2').attr('checked', false);
            _this.canvasServiceRadioClick(true);
      });
     $('#radio-2').die('click');
     $('#radio-2').live('click', function()
       {
             $(this).attr('checked', true);
             $('#radio-1').attr('checked', false);
             _this.canvasServiceRadioClick(false);
       });
     
     //setting the change print area
     var s1 = '#' + _this.markupUtil.getName('printareabutton');
     
     $(s1).live('mouseover', function(event)
     {
         $(this).attr('src', _this.imagesDir + '/change_print_area_rollover_' + String(_this.app.getModel().user.languageIso).toUpperCase() + '.gif');
     });
     
     $(s1).live('mouseout', function()
     {
         $(this).attr('src', _this.imagesDir + 'change_print_area_' + String(_this.app.getModel().user.languageIso).toUpperCase() + '.gif');
     });
     
     // User clicks change print area button p2a_mto_printareabutton
     $(s1).die('click');
     $(s1).live('click', function()
     {
    	 _this.app.GATrackPageView('/p2a/create/change-print-area');
         var currentImage = _this.app.getModel().SelectedImageGet();
         
         var cropperData = {
                                   imageItem : currentImage
                                , getSelectedImageCropData : "PhotosToArtCore.getSubscribers()['ModuleTabOptions'].getConvertedCropData"
                                , jsMethodToUpdateCropData : "com.art.photosToArt.modules.ModuleTabOptions.prototype.updateCropDetails"
                                , jsMethodToGetGalleryWrapData : "com.art.photosToArt.modules.ModuleTabOptions.prototype.getGalleryWrapData"
                                , clickAndDragText : _this.app.getString('Click and Drag to Move')
                             }; 
         var cropComponent = new com.art.photosToArt.components.ComponentPrintAreaSelect(cropperData, _this.app);
         
         //NOTE: "Static" method
         cropComponent.registerCallbacks('applycrop', function(){
               var requestParameters = new com.art.photosToArt.vos.UserImageChangeRequestVo(_this.app.getModel());
               requestParameters.updateCropInformation(com.art.photosToArt.modules.ModuleTabOptions.tmpCropX, com.art.photosToArt.modules.ModuleTabOptions.tmpCropY);
               
           	   
               // Must remove the object directly first for IE null ref error.
               $('#printarea_target').remove();
           	   $('#ComponentMessagingLightbox').remove();
           	   $('#p2a_lightbox').remove();
           	   
           	   // NEW - make sure to remove the popup prior to calling this event - 
           	   _this.notify(new com.art.core.utils.Note(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS, requestParameters, 'vo'));
            });
         
         //NOTE: "Static" method
         cropComponent.registerCallbacks('cropcancel', function(){
     	 	$('#ComponentMessagingLightbox').remove();
    	 	$('#p2a_lightbox').remove();
         });
         
         
         var cropHtml = cropComponent.render();
         cropComponent.registerEvents();

         var data = {
                    html : cropHtml
                    , title : _this.app.getString('select_print_area')
                    , zindex : '1200'
                    , height : _this.getSelectedImageDimensions().height
                    , width : _this.getSelectedImageDimensions().width
               };
         var msgLightbox = new com.art.photosToArt.components.ComponentMessagingLightbox(data, _this.app);
         
         msgLightbox.render();
         $('#ComponentMessagingLightbox').hide();
         
         // Initialize and display the flash cropping popup
         cropComponent.invokeFlash();
         setTimeout(function(){
        	 $('#ComponentMessagingLightbox').center(true);
        	 $('#ComponentMessagingLightbox').show();
         }, 500);

     });
     
     $('#fdmouldingname').click(function(){
    	 _this.displayMouldingPopup();
     });
     
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.canvasServiceRadioClick = function(isMuseum)
{
    // Get a reference to the service object
    var model = this.app.getModel();
    var itemService = isMuseum ? model.data.serviceTypes.canvasMuseum : model.data.serviceTypes.canvasGallery;
    var currentSize = model.getItemAvailableSizeByPodConfigId(model.SelectedImageGuidGet(), model.SelectedItemServiceGet(), model.SelectedItemPodConfigIdGet());
    var small = currentSize.Small;
    var large = currentSize.Large;
    
    // Set the selected service
    model.SelectedItemServiceSet(itemService.name);
    
    // Set the subtype
    model.SelectedItemServiceSubTypeSet(itemService);
    
    //STEP: This controls behavior: capture the PODConfigID that is currently there...we want to set the new service type to the same size
    var podConfigIdOverride = model.getSelectedItemPodConfigIdForGivenSizeAndService(small, large, itemService);
    
    if (podConfigIdOverride > 0 )
    {
        model.SelectedItemPodConfigIdSet(podConfigIdOverride);
    }
    
    var requestParameters = new com.art.photosToArt.vos.UserImageChangeRequestVo(this.app.getModel());
    
    this.notify(new com.art.core.utils.Note(this.app.events.IMAGE_UPDATE_AND_GET_RESULTS, requestParameters, 'vo'));
};
/**
 * Callback function to close out the Crop popup
 * @method cancelCrop
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.cancelCrop = function()
{
    this.notify(new com.art.core.utils.Note(this.app.events.CLOSE_POPUP, {}, 'vo'));
};
/**
 * Upon completion of the crop, sends notification data to update ufig and cropdata
 * @method applyCropData
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.applyCropData = function()
{
    //On the Cropper Popup button click, assign the cropx and cropy values to the cropdata
	var requestParameters = new com.art.photosToArt.vos.UserImageChangeRequestVo(this.app.getModel());
	requestParameters.updateCropInformation(this.tmpCropX, this.tmpCropY);
	this.notify(new com.art.core.utils.Note(this.app.events.IMAGE_UPDATE_AND_GET_RESULTS, requestParameters, 'vo'));
};
/**
 * @method getSelectedImageDimensions
 * @returns {height, width}
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.getSelectedImageDimensions = function(imageItem)
{
    var result = {
                      height : 0
                    , width : 0
                };
    try
    {
        if(imageItem == null || imageItem == undefined)
        {
            imageItem = this.app.getModel().SelectedImageGet();
        }
        var dimensions = imageItem.ImageInformation.LargeImage.Dimensions;
        result.height = dimensions.Height;
        result.width = dimensions.Width;
    }
    catch(err)
    {
        this.app.logError(err);
    }
    
    return result;
};
/**
 *
 * Converts the cropdata to the structure expected by the flash cropper component
 * Needs to work as a STATIC method - no "this" allowed - to allow access to data from swf
 * @method getConvertedCropData
 * @returns {CropH, CropW, CropX, CropY}
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.getConvertedCropData = function()
{
	
    var convertedData = {};
    
    try
    {
        var model = PhotosToArtCore.getModel();
        var podConfigId = model.SelectedItemPodConfigIdGet(); 
        var sourceData = model.SelectedItemServiceImageCropGet();
        var image = model.SelectedImageGet();
        var isLandscape = image.ImageInformation.LargeImage.Dimensions.Width > image.ImageInformation.LargeImage.Dimensions.Height;
        try
        {
        	var dragPlane = com.art.photosToArt.modules.ModuleTabOptions.prototype.getDragPlane(sourceData);
        }catch(err){trace('getConvertedCropData: ' + err.message);}
        var selectedService = model.SelectedItemServiceGet();
        
        var measurements = {
                              CropH : sourceData.Dimensions.Height
                            , CropW : sourceData.Dimensions.Width
                            , CropX : sourceData.Coordinates.CoordinateX
                            , CropY : sourceData.Coordinates.CoordinateY 
        };
        
        // Is it gallery wrap?
        if(selectedService.name === "CanvasGallery")
        {
            // Common data points
            var masterSize = model.getMasterSizeByPodConfigId(podConfigId);
            var stretcherbarwidth = PhotosToArtCore.getEnvironment().stretcherBarWidth;
            
            // CropH
            var shortSidePixels = isLandscape ? measurements.CropH : measurements.CropW ; //Large image, in pixels
            var sm = masterSize.Small + (stretcherbarwidth * 2);
            var lrg = masterSize.Large + (stretcherbarwidth * 2);
            
            // NOTE - this isn't used ever
            var pixelsPerInch = Math.round(shortSidePixels / sm);

            var newAR = sm / lrg;
            // If landscape, newH = CropH, because we don't crop vertically
            // If portrait, newH = CropW/ aspect ratio
            var newH = (measurements.CropW > measurements.CropH) ? measurements.CropH : Math.round(measurements.CropW / newAR);
            
            // CropW
            // If landscape, newW = CropH/aspect ratio
            // If portrait, newW = CropW - we don't crop horizontally
            var newW = (measurements.CropW > measurements.CropH) ? Math.round(measurements.CropH / newAR) : measurements.CropW;
            
            // CropX
            var newX = 0;
            var tarWidth = newW;
            if (measurements.CropX == 0)
            {
            	// Portrait - no x cropping
                newX = measurements.CropX;
            }
            else
            {
                newX = measurements.CropX + Math.round((measurements.CropW - newW) / 2); //move to right
            }
            
            // CropY
            var curHeight = measurements.CropH; //mw
            newY = measurements.CropY + Math.round((measurements.CropH - newH) / 2); //move down
            
            measurements.CropH = newH;
            measurements.CropW = newW;
            measurements.CropX = newX;
            measurements.CropY = newY;
            
            // ASSIGN THESE VALUES TO THE ITEM'S CROPDATA
            var thisCrop = model.getItemImageCropByItemServiceAndPodConfigId(selectedService, podConfigId);
            thisCrop.CoordinateX = newX;
            
            // NEW idea
            thisCrop.Coordinates.CoordinateX = newX;
            
            thisCrop.Coordinates.CoordinateY = newY;
            thisCrop.Dimensions.Height = newH;
            thisCrop.Dimensions.Width = newW;
            
        }

        var convertedData = {
                  CropH : measurements.CropH
                , CropW : measurements.CropW
                , CropX : measurements.CropX 
                , CropY : measurements.CropY
                , DragPlane : dragPlane
                , ImageCropGuid : sourceData.CustomCropInformation.ImageCropGuid
                , ImageCropID : sourceData.CustomCropInformation.ImageCropId
                , ImageID : image.ImageInformation.ImageAttributes.ImageId
                , PODConfigID : podConfigId
                , ServiceTypeCode : selectedService.itemServiceCode
                , UserImageUrl : image.ImageInformation.LargeImage.HttpImageURL
        };
    
        // The flash has been defaulting to hidden despite my efforts
        $('#printarea_target').css('visibility', 'visible');
    }
    catch(err)
    {
        this.app.logError(err);
    }
    return convertedData;
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.getDragPlane = function(cropData)
{
	var result = 'H';
	try
	{
		var largeImage = PhotosToArtCore.getModel().SelectedImageGet();
		var largeImageDimensions = largeImage.ImageInformation.LargeImage.Dimensions;  //Height, Width	
		result = largeImageDimensions.Height === cropData.Dimensions.Height ? 'H' : 'V';
	}
	catch(err){trace('Error in MTO.getDragPlane: ' + err.message);}
	
	return result;
	
};
/**
 * Callback method usedby the Flash cropping component to update the current cropping data
 * MUST function as "STATIC" method
 * @method updateCropDetails
 * @param xpos
 * @param ypos
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.updateCropDetails = function(xpos, ypos)
{    
	com.art.photosToArt.modules.ModuleTabOptions.tmpCropX = xpos < 0 ? 0 : xpos;
	com.art.photosToArt.modules.ModuleTabOptions.tmpCropY = ypos < 0 ? 0 : ypos;
};
/**
 * Callback method passed to Flash cropping component to provide calculations for gallery wrap
 * @method getGalleryWrapData
 * @returns gallery wrap data
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.getGalleryWrapData =  function()
{
    var galleryWrapData = {};
    
    try
    {
        var imageItem = PhotosToArtCore.getModel().SelectedImageGet();
        var service = PhotosToArtCore.getModel().SelectedItemServiceGet();
        var podConfigId = PhotosToArtCore.getModel().SelectedItemPodConfigIdGet(); 
        var stretcherbarwidth = PhotosToArtCore.getEnvironment().stretcherBarWidth;
        var galleryPixelsPerInch = 0;
        var stretcherBarDepthInPixels = 0;
        var masterSize = PhotosToArtCore.getModel().getMasterSizeByPodConfigId(podConfigId);
        var dimensions = imageItem.ImageInformation.LargeImage.Dimensions; 
        var galleryWrapVisibleHeight = 0;
        var galleryWrapVisibleWidth = 0;
        var side = 0;
        var isLandscape = dimensions.Width > dimensions.Height;
        var smallSidePixels =  isLandscape ? dimensions.Height : dimensions.Width; //STEP: Get the small side in pixels
        
        //STEP: In the case of GalleryWrap, the Inch Small side will actually be 2x StretcherBarWidth longer..so add here if necessary
        var smallSideInches = (service.name === "CanvasGallery" ? true:false) ? masterSize.Small + (stretcherbarwidth * 2) : masterSize.Small;
        
        //STEP: now with short side in pixels and short side in inches, we can calculate pixels per inch
        galleryPixelsPerInch = Math.round((smallSidePixels / smallSideInches) * 100) / 100;
        
        //STEP: get the stretcherbar depth in pixels
        stretcherBarDepthInPixels = Math.round((galleryPixelsPerInch * stretcherbarwidth) * 100) / 100;
        
        side = Number(isLandscape ? masterSize.Small : masterSize.Large);
        
        galleryWrapVisibleHeight =  Math.round(side * galleryPixelsPerInch) * 100 / 100;
        
        //NOTE: here side is the opposite of the height calculation
        side = Number(isLandscape ? masterSize.Large : masterSize.Small);
        
        galleryWrapVisibleWidth = Math.round(side * galleryPixelsPerInch) * 100 / 100;
    
        galleryWrapData = {
            pixelsPerInch : galleryPixelsPerInch
            , origH : imageItem.ImageInformation.Original.Dimensions.Height
            , largeH : dimensions.Height
            , isGalleryWrap : (service.name === "CanvasGallery"? true : false)
            , galleryWrapXOffset : stretcherBarDepthInPixels
            , galleryWrapYOffset : stretcherBarDepthInPixels
            , galleryWrapWidth : galleryWrapVisibleWidth
            , galleryWrapHeight : galleryWrapVisibleHeight
        };
    }
    catch(err)
    {
        this.app.logError(err);
    }
    return galleryWrapData;
};
/**
 * @method destroy
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.destroy = function()
{
    //NOTE: Destroy is where you destroy this object and clean up memory
};
/**
 * Sends notifications through event messaging system
 * @method notify
 * @param note
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.notify = function(note)
{
    // NOTE: 
    // //trace('ModuleTabOptions notify: ' + note.name);
    this.app.sendNotification(note);
};
/**
 * Informs Core of events it will handle
 * @method listNotificationInterests
 * @returns {Array}
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.listNotificationInterests = function()
{

    return [         this.app.events.SHOW_MORE_SIZES 
                     , this.app.events.RELOAD_USER_INTERFACE
                     , this.app.events.FRAME_GET_COMPONENTS_SUCCESS
            ];
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.toggleResolutionWarningMessage = function()
{
    var model = this.app.getModel();
    var podConfigId = model.SelectedItemPodConfigIdGet();
    var size = model.getItemAvailableSizeByPodConfigId(model.SelectedImageGuidGet(), model.SelectedItemServiceGet(), podConfigId);
    
    if(size.Warning == "True")
        $('#p2a_mto_sizeerror').show();
    else
        $('#p2a_mto_sizeerror').hide();
};

/**
 * Handlers for events
 * @method handleNotification
 * @param note
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.handleNotification = function(note)
{
    var _this = this;
    switch(note.name)
    {
        case this.app.events.RELOAD_USER_INTERFACE:
            this.getSizeDataFromCacheAndFillDropDown();
            this.enablePrintArea();
            this.configureCanvasOptions();
            this.updateFramingDetails();
            this.toggleResolutionWarningMessage();
            break;
			
        case this.app.events.FRAME_GET_COMPONENTS_SUCCESS:
        	if(this.app.getModel().getFramingComponents() == undefined || this.app.getModel().getFramingComponents()[this.app.getModel().SelectedItemPodConfigIdGet()] == undefined )
        	{
        		//must be getting set in next subscriber, let's wait and try again
        		setTimeout(function(){
        			_this.reload();
        		},500);
        		return;
        	}
        	this.reload();
        	break;
        case this.app.events.SHOW_MORE_SIZES:
            var selectedImage = this.app.getModel().getGalleryItemByImageGuid(this.app.getModel().SelectedImageGuidGet());
            
            var isLandscape = selectedImage.Item.ImageInformation.Original.Dimensions.Width > selectedImage.Item.ImageInformation.Original.Dimensions.Height;
            var sizeData = this.app.getModel().getItemAvailableSizes
            (
                    this.app.getModel().SelectedImageGuidGet()
                    ,
                    this.app.getModel().SelectedItemServiceGet()
            );

            //STEP: Get Inputs for the Available Size Picker
            var user = this.app.getModel().user;
            var doConvertToCm = com.art.core.utils.LocalizationManager.determineConvertToCm(user.countryIso, user.currencyIso, user.languageIso);
            var selectedSizeId = this.app.getModel().SelectedItemPodConfigIdGet();
            var translatableContent = {
                    select_print_size : this.app.getString("select print size")
                    , rectangle: this.app.getString("Rectangle")
                    , square: this.app.getString("Square")
                    , panorama: this.app.getString("Panoramic")
                    };
            //sizeData, isSelectedImageLandscape, selectedSizeId, imagePath, markupNames
            var componentSizePicker = new com.art.photosToArt.components.ComponentAvailableSizePicker(
                    "sizepicker"
                    ,sizeData
                    ,isLandscape
                    ,selectedSizeId
                    ,this.app.getEnvironment().imagePath
                    ,undefined
                    ,doConvertToCm
                    ,translatableContent);
            
            //STEP: Create a lightbox
            this.lightbox = new com.art.core.components.LightBox('sizepickerlightbox','body','0.4');
            this.lightbox.show();
            
            //STEP: Get the z-index of the lightbox so that we can make the popup one higher:
            var sizepickerZIndex = this.lightbox.getLightBoxZIndex()+1;
            componentSizePicker.render(sizepickerZIndex);
            var _this = this;

            componentSizePicker.initAllSizesPanel();
            componentSizePicker.registerCallback('close', function()
            {
                _this.lightbox.close();
            });
            componentSizePicker.registerCallback('sizeclick', function(podConfigId, clickedSizeDisplay){
                $('.p2a_mto_sizetextbox').text(clickedSizeDisplay);    
                _this.app.getModel().SelectedItemPodConfigIdSet( podConfigId );
                var requestParameters = new com.art.photosToArt.vos.UserImageChangeRequestVo(_this.app.getModel());
                requestParameters.action = com.art.photosToArt.vos.UserImageChangeRequestVo.action.SIZECROP;
                _this.notify(new com.art.core.utils.Note(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS, requestParameters, 'vo'));
            });
            componentSizePicker.registerEvents();
            break;
    }
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.reload = function()
{
	this.getSizeDataFromCacheAndFillDropDown();
    this.enablePrintArea();
    this.configureCanvasOptions();
    this.updateFramingDetails();
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.updateFramingDetails = function()
{
	var model = this.app.getModel();
	
	if(model.SelectedItemServiceGet().name == model.data.serviceTypes.framing.name)
	{
		$('#p2a_mto_sizelabel').html(this.app.getString('Print_Size:'));
		// Load the selected Mats
		$('#framingdetails').show();
		var serviceData = model.SelectedGalleryItemGet().Item.Service.Frame;
		
		// Load the selected Moulding
		this.updateMoulding(serviceData);
		this.updateMats(serviceData);
		this.updateFinishedSize(serviceData);
	}
	else
	{
		$('#p2a_mto_sizelabel').html(this.app.getString('Finished_Size:'));
		$('#framingdetails').hide();
	}
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.updateMoulding = function(serviceData)
{
	// show the right moulding
	try
	{
	    var molding = this.app.getModel().getMouldingByMouldingId(serviceData.Moulding.ItemNumber);
		var moldingName = serviceData.Moulding.Name;
	    if (molding != undefined && molding.Name != undefined)
	        moldingName = molding.Name;
	    $('#fdmouldingname').empty().html(moldingName);
		var imgUrl = this.app.getEnvironment().imagePath + this.baseMouldingImageUrl.replace(/\[ID\]/gi, serviceData.Moulding.ItemNumber);
		$('#fdmouldingimg').attr('src', imgUrl);
	}
	catch(err)
	{
		trace('ERROR in MTO.updateMoulding: ' + err.message);
	}
	
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.updateMats = function(serviceData)
{
	var matData = [serviceData.TopMat, serviceData.MiddleMat, serviceData.BottomMat];
	var i = 0;
	var hasMats = false;
	var matDiv = '#MatContainer_';
	var matImg = '#matimg_';
	for( i; i < matData.length; i++)
	{
		if(this.isValidMat(matData[i]))
		{
			hasMats = true;
			$(matDiv + i).show();
			var matImageUrl = this.app.getEnvironment().imagePath + this.baseMatImageUrl.replace(/\[ID]/gi, matData[i].ItemNumber);
			var matObj = this.app.getModel().getMatObjectByMatId(matData[i].ItemNumber);

			
			$('#matname_' + i).html(matData[i].Name);
			
			if(matObj == undefined)
				return;
			com.art.core.utils.BrowserUtil.checkIfRemoteImageExists({index:i,matObj:matObj},matImageUrl,"MatImageLoadedSuccess","MatImageLoadedFailure",this);
		}
		else
		{
			$(matDiv + i).fadeOut();
			$('#matname_' + i).html('');
		}
	}
		
	if(hasMats)
	{
		$('#NoMatContainer').hide();
		if(this.app.getModel().state.current.selectedItemServiceAttributes.areMatsOversizedChanged)
		{
		    //$('#p2a_mats_message').html(this.app.getString("The frame size has changed the mat selection.") + "<br>&nbsp;");
		    //setTimeout(function(){$('#p2a_mats_message').html('');},8000);
		}
	}
	else
	{
		$('#NoMatContainer').show();
	}
	
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.MatImageLoadedSuccess = function(obj,url)
{
	$('#matimg_' + obj.index).attr('src', url);
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.MatImageLoadedFailure = function(obj,url)
{
	try{
		$('#matimg_' + obj.index).parent().css("background-color","#" + obj.matObj.hexColor);
		$('#matimg_' + obj.index).attr('src', obj.matObj.getFallbackImage());
	}catch(err){this.app.logError(err);}
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.updateFinishedSize = function(serviceData)
{
	var user = this.app.getModel().user;
	var doConvertToCm = com.art.core.utils.LocalizationManager.determineConvertToCm(user.countryIso, user.currencyIso, user.languageIso);
	var dimensions = com.art.core.utils.StringUtil.formatDimensions(serviceData.FrameSummary.PhysicalDimensionsRounded.Width, serviceData.FrameSummary.PhysicalDimensionsRounded.Height, doConvertToCm);   
	$('#fdsize').html(dimensions);
};
/**
 * If Mat.ItemNumber AND Mat.Name must be defined
 * @param matItem
 * @returns {Boolean}
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.isValidMat = function(matItem)
{
	return (matItem != undefined && matItem.ItemNumber != undefined && !isNaN(matItem.ItemNumber) && matItem.ItemNumber > 0 && matItem.Name != null);
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.supportCanvasWrapOptions = function()
{
    // Only support canvas options if both types are actually supported.
    return this.app.getModel().data.serviceTypesAvailable.canvasGallery !== undefined && this.app.getModel().data.serviceTypesAvailable.canvasMuseum !== undefined;
};
/**
 * @method getTemplate
 * @returns string
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.getTemplate = function()
{
    
    //STEP: Get the raw string for the template
    var returnValue = this.template;
    
    //STEP: Replace the [IMAGE_DOMAIN] placeholder with the imagePath value
    returnValue = returnValue.replace(/\[IMAGE_DOMAIN\]/gi, this.IMAGE_BASEURL);
    
    //STEP: Replace any strings that require access to separate function calls
    returnValue = returnValue.replace(/\[PREFIX\]/gi,    this.markupUtil.getPrefix());
    returnValue = returnValue.replace(/\[INFO_OFF_IMAGE\]/gi,    this.IMAGE_BASEURL +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_SUBFOLDER    +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_INFO_OFF);

    // in order to replace an id value, no need of the active button state
    returnValue = returnValue.replace(/\[SIZECONTAINERIMG\]/gi,    this.IMAGE_BASEURL +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_SUBFOLDER    +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_SIZE_CONTAINER);
    returnValue = returnValue.replace(/\[DROPDOWNIMAGEOVER\]/gi,    this.IMAGE_BASEURL +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_SUBFOLDER    +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_DROP_DOWN_OVER);
    returnValue = returnValue.replace(/\[DROPDOWNIMAGE\]/gi,    this.IMAGE_BASEURL +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_SUBFOLDER    +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_DROP_DOWN);
    
    //STEP: Replace strings that are phrases for translation
    returnValue = returnValue.replace(/\[SIZELABEL_TEXT\]/gi, this.setSizeLabel());
    returnValue = returnValue.replace(/\[SIZE_ERROR_MSG\]/gi, this.app.getString('This_size_is_not_recommended_for_your_image._Choosing_a_smaller_size_will_result_in_a_higher_quality_print.'));
    returnValue = returnValue.replace(/\[PAPERTYPE\]/gi, this.app.getString('Paper Type:'));
    returnValue = returnValue.replace(/\[PHOTOGRAPHICPAPER\]/gi, this.app.getString('Photographic Paper'));
    
    //print area container
    returnValue = returnValue.replace(/\[PRINTLABEL_TEXT\]/gi, this.app.getString('Options:'));
    returnValue = returnValue.replace(/\[PRINT_ERROR_MSG_TEXT\]/gi, this.app.getString('Work in progress'));
    returnValue = returnValue.replace(/\[CHANGE_PRINT_AREA\]/gi,    this.IMAGE_BASEURL +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_SUBFOLDER    +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_CHANGE_PRINT_AREA);
    returnValue = returnValue.replace(/\[INACTIVE_PRINT_AREA\]/gi,    this.IMAGE_BASEURL +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_SUBFOLDER    +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_INACTIVE_PRINT_AREA);
    returnValue = returnValue.replace(/\[LANG_FOR_IMG\]/gi,    "_" +  String(this.app.getModel().user.languageIso).toUpperCase());
    
    // canvas wrap: museum, gallery
    returnValue = returnValue.replace(/\[PREFIX\]/gi,    this.markupUtil.getPrefix());
    returnValue = returnValue.replace(/\[INFO_OFF_IMAGE\]/gi,    this.IMAGE_BASEURL +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_SUBFOLDER    +  com.art.photosToArt.modules.ModuleTabOptions.IMAGE_INFO_OFF);
    returnValue = returnValue.replace(/\[CANVAS_WRAP_TEXT\]/gi, this.app.getString('Canvas_Wrap:'));
    returnValue = returnValue.replace(/\[MUSEUMWRAP_TEXT\]/gi, this.app.getString('Museum'));
    returnValue = returnValue.replace(/\[GALLERYWRAP_TEXT\]/gi, this.app.getString('Gallery'));
    returnValue = returnValue.replace(/\[FRAME\]/gi, this.app.getString('Frame:'));
    returnValue = returnValue.replace(/\[NO_MATS_SELECTED\]/gi, this.app.getString('none selected'));
    
    returnValue = returnValue.replace(/\[MATS\]/gi, this.app.getString('Mats'));
    returnValue = returnValue.replace(/\[TOP_MAT\]/gi, this.app.getString('Top_Mat'));
    returnValue = returnValue.replace(/\[MIDDLE_MAT\]/gi, this.app.getString('Middle_Mat'));
    returnValue = returnValue.replace(/\[BOTTOM_MAT\]/gi, this.app.getString('Bottom_Mat'));
    returnValue = returnValue.replace(/\[FINISHED_SIZE\]/gi, this.app.getString('Finished_Size:'));
    
    return returnValue.replace('$NAME', this.NAME.toLowerCase());
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.setSizeLabel = function()
{
	var result = this.app.getString('Finished_Size:');
	try
	{
		if(model.SelectedItemServiceGet().name == model.data.serviceTypes.framing.name)
		{
			result = this.app.getString('Print_Size');
		}
	}
	catch(err)
	{
		// go with original result
	}
	return result;
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.displayMouldingPopup = function()
{
	var model = this.app.getModel();
	var serviceData = model.SelectedGalleryItemGet().Item.Service.Frame;
	
	// Get HTML
	var markup = this.getMouldingDetailTemplate(serviceData.Moulding);
	
	var popupData = {
			  html: markup
			, title: this.app.getString("frame details") 
			, zindex:2000
			, height:'525'
			, width:'750'
			, padding:'0px 0px'
		};

	var messageBox = new com.art.photosToArt.components.ComponentMessagingLightbox(popupData,this.app);
	messageBox.render();
	$('#ComponentMessagingLightbox').center(true);
};
com.art.photosToArt.modules.ModuleTabOptions.prototype.template = '<div id="$NAME">'
    // finished size dropdown
    +'<div class="[PREFIX]taboptions">'
    +'<div id="[PREFIX]sizecontainer">'
    +         '<div id="p2a_mto_sizelabel" class="[PREFIX]sizelabel">[SIZELABEL_TEXT]</div>'
    +       '<div class="[PREFIX]sizetextboxcontainer">'
    +         '<div class="[PREFIX]sizetextbox" setwarning="" setitemregularprice="" setitemprice="" setheight="" setwidth="" setpodconfigid="" dropdownimgover="[DROPDOWNIMAGEOVER]" dropdownimg="[DROPDOWNIMAGE]" style="background-image:url(\'[DROPDOWNIMAGE]\'); "></div>'
    +         '<div class="clear"></div>'
    +         '<div class="[PREFIX]sizeoptions hidden">'
    +               '<ul id="[PREFIX]ulsizeoptions" class="[PREFIX]ulsizeoptions">'
    +                   '<li class="[PREFIX]lisizeoptions"></li>'
    +               '</ul>'
    +        '</div>'
    +'</div>'
    +      '<div class="clear"></div>'
    +      '<div id="[PREFIX]sizeerror" class="hidden" style="display:none; margin-top:10px;">'
    +            '<div class="[PREFIX]sizeerrorimg" style="float:left;padding-top:6px;">'
    +                  '<img CLASS="[PREFIX]sizecontainerimage" src="[SIZECONTAINERIMG]">'
    +            '</div>'
    +            '<div class="[PREFIX]sizeerrormsg" style="float:left;width:225px;margin-left:10px;">[SIZE_ERROR_MSG]</div>'
    +      '</div>'
    +'</div>'
    + '<div class="clear"></div>'
    + '<div  id="[PREFIX]canvaswrapcontainer" style="display:none" >'
    + 		'<div class="[PREFIX]canvaswrapcontent" >'
    +             '<div class="[PREFIX]canvaswraplabel">[CANVAS_WRAP_TEXT]</div>'
    +             '<div class="[PREFIX]radiobutton">'
    +                   '<input id="radio-1" type="radio" name="canvaswrap" value="MW" />'
    +                   '<label  for="radio-1" style="#padding-top: 6px; #padding-left: 22px;">[MUSEUMWRAP_TEXT]</label>'
    +             '</div>'
    +             '<div class="[PREFIX]radiobutton">'
    +                   '<input id="radio-2" type="radio" name="canvaswrap" value="GW" />'
    +                   '<label for="radio-2" style="#padding-top: 6px; #padding-left: 22px;">[GALLERYWRAP_TEXT]</label>'
    +             '</div>'
    +             '<div class="[PREFIX]canvaswrapinfo">'
    +                   '<img id="[PREFIX]canvaswrapmoreinfo" class="[PREFIX]moreinfo" src="[INFO_OFF_IMAGE]" />'
    +             '</div>'
    +         '</div>'
    + '</div>'
    + '<div class="clear"></div>'
    + '<div id="[PREFIX]printareacontainer" >'
    +             '<div id="changeprintareaon" class="[PREFIX]printcontent activeprintcontent" style="display: block;">'
    +                   '<div class="[PREFIX]printlabel">[PRINTLABEL_TEXT]</div>'
    +                   '<div class="[PREFIX]print_edit cpointer" >'
    +                         '<img class="floatleft" id="[PREFIX]printareabutton" src="[CHANGE_PRINT_AREA]" />'
    +                   '</div>'
    +                   '<div class="[PREFIX]printinfo">'
    +                         '<img class="[PREFIX]printmoreinfo" src="[INFO_OFF_IMAGE]" />'
    +                   '</div>'
    +            '</div>'
    +            '<div id="changeprintareaoff" class="[PREFIX]printcontent" style="display: none">'
    +                   '<div class="[PREFIX]printlabel inactiveprintcontent floatleft">[PRINTLABEL_TEXT]</div>'
    +                   '<div class="[PREFIX]print_edit">'
    +                        '<img id="[PREFIX]inactiveprintareabutton" src="[INACTIVE_PRINT_AREA]">'
    +                   '</div>'
    +                   '<div class="[PREFIX]printinfo">'
    +                        '<img class="[PREFIX]printmoreinfo" src="[INFO_OFF_IMAGE]" />'
    +                   '</div>'
    +           '</div>'
    +           '<div class="printerror hidden">'
    +                   '<div class="[PREFIX]printerrorimg">'
    +                        '<div class="[PREFIX]printerrormsg">[PRINT_ERROR_MSG_TEXT]</div>'
    +                   '</div>'
    +          '</div>'
    + '</div>'
    + '<div class="clear"></div>'
    + '<div id="framingdetails" class="FramingDetails" style="display: none;margin-top:8px;">'
    + ' 		<div class="FramesContainer">'
    + ' 				<div class="FramesLabel">[FRAME]</div>'
    + ' 				<div id="moldingContainer" class="FramingBackground cPointer">'
    + ' 					<div class="FramesImg">'
	+ '							<img width="28" height="32" src="" id="fdmouldingimg" />'
	+ '						</div>'
    + ' 					<div id="fdmouldingname" class="FramesName" style="text-decoration:underline;cursor:pointer;">Soho Black</div>'
    + ' 				</div>'
    + ' 		</div>'
    + ' 		<div class="clear"></div>'
    + ' 		<div class="MatContainer">'
    + ' 			<div id="NoMatContainer" class="TopMatContainer" style="display: none;">'
    + ' 				<div class="TopMatLabel">[MATS]:</div>'
    + ' 				<div class="framingbackground NoMat">[NO_MATS_SELECTED]</div>'
    + ' 			</div>'
    + '             <div class="clear"></div>'
    + '             <div id="p2a_mats_message"></div>'
    + ' 			<div class="clear"></div>'
    + ' 			<div class="TopMatContainer"  id="MatContainer_0">'
    + ' 				<div class="TopMatLabel">[TOP_MAT]:</div>'
    + ' 				<div class="framingbackground">'
	+ '						 <div style="width:32px;height:32px;float:left;"><img  id="matimg_0" class="fdmatimg" /></div>'
    + ' 					<div id="matname_0" class="fdmatname"></div>'
    + ' 				</div>'
    + ' 			</div>'
    + ' 			<div class="clear"></div>'
    + ' 			<div class="TopMatContainer"  id="MatContainer_1" style="display: none;">'
    + ' 				<div class="MiddleMatLabel">[MIDDLE_MAT]:</div>'
    + ' 				<div class="framingbackground">'
	+ '						 <div style="width:32px;height:32px;float:left;"><img  id="matimg_1" class="fdmatimg" /></div>'
    + ' 					<div id="matname_1" class="fdmatname"></div>'
    + ' 				</div>'
    + ' 			</div>'
    + ' 			<div class="clear"></div>'
    + ' 			<div class="TopMatContainer"  id="MatContainer_2" style="display: none;">'
    + ' 				 <div class="BottomMatLabel">[BOTTOM_MAT]:</div>'
    + ' 				 <div class="framingbackground">'
	+ '						 <div style="width:32px;height:32px;float:left"><img  id="matimg_2" class="fdmatimg" /></div>'
    + ' 					 <div id="matname_2" class="fdmatname"></div>'
    + ' 				 </div>'
    + ' 			</div>'
    + ' 			<div class="clear"></div>'
    + ' 		</div>'
    + ' 		<div class="clear"></div>'
    + ' 		<div class="FramedSize">'
    + ' 			<div class="FramedSizeLabel">[FINISHED_SIZE]</div>'
    + ' 			<div id="fdsize" style="margin-left:10px;float:left">25" X 31"</div>'
    + ' 		</div>'
    + ' 	</div>';

com.art.photosToArt.modules.ModuleTabOptions.prototype.getMouldingDetailTemplate = function(mouldingData)
{
	var template = ''
	+ '     <div class="MoldingContent">'
	+ '             <div style="float:left;margin-bottom: 30px;">'
	+ '                 <div class="cornerImages"><img src="http://artfiles.art.com/images/framing/hires//[MOULDINGID]/corner/[MOULDINGID].jpg"></div>'
	+ '                 <div class="clear"></div>'
	+ '                 <ul class="ulmoldingDetailsLeft">'
	+ '                     <li class="limoldingDetails"><div class="lilabel">[P]:&nbsp;</div><div class="livalue leftValue1">[FRAMENAME]</div><div class="clear"></div></li>'
	+ '                     <li class="limoldingDetails"><div class="lilabel">[M]:&nbsp;</div><div class="livalue leftValue2">[FRAMEMATERIAL]</div><div class="clear"></div></li>'
	+ '                     <li class="limoldingDetails"><div class="lilabel">[S]:&nbsp;</div><div class="livalue leftValue3">[FRAMESTYLE]</div><div class="clear"></div></li>'
	+ '                 </ul>    '
	+ '             </div>'
	+ '             <div style="float:right;margin-bottom: 30px;">'
	+ '                 <div class="profileImages">'
	+ '                     <div class="profileInch">    '
	+ '                         <table><tr><td>' + this.app.getString("Height:") + '</td><td><span style="font-weight:bold;">[FRAMEHEIGHT]</span></td></tr>'
	+ '                         <tr><td>' + this.app.getString("Width:") + '</td><td><span style="font-weight:bold">[FRAMEWIDTH]</span></td></tr></table>'
	+ '                     </div>  '
	+ '                     <img title="" alt="" src="http://artfiles.art.com/images/framing/hires//[MOULDINGID]/profile/[MOULDINGID].jpg">'
	+ '                 </div>'
	+ '                 <div class="clear"></div>'
	+ '                 <ul class="ulmoldingDetailsRight">'
	+ '                     <li class="limoldingDetails"><div class="lilabel">[C]:&nbsp;</div><div class="livalue rightValue1">[COLOR]</div><div class="clear"></div></li>'
	+ '                     <li class="limoldingDetails"><div class="lilabel">[F]:&nbsp;</div><div class="livalue rightValue2">[FINISH]</div><div class="clear"></div></li>'
	+ '                     <li class="limoldingDetails"><div class="lilabel">[P]:&nbsp;</div><div class="livalue rightValue3 bold">[PRICE]</div><div class="clear"></div></li>'
	+ '                 </ul>   '
	+ '             </div>'
	+ '     </div>';
	template = template.replace(/\[P\]/gi, this.app.getString('Profile'));
	template = template.replace(/\[M\]/gi, this.app.getString('Material'));
	template = template.replace(/\[S\]/gi, this.app.getString('Style'));
	template = template.replace(/\[C\]/gi, this.app.getString('Color'));
	template = template.replace(/\[F\]/gi, this.app.getString('Finish'));
	template = template.replace(/\[P\]/gi, this.app.getString('Price'));
	template = template.replace(/\[MOULDINGID\]/gi, mouldingData.ItemNumber );
	
    //STEP: The Molding Item in the Item Object may not be translated, get the name from Molding inventory
    var molding = this.app.getModel().getMouldingByMouldingId(mouldingData.ItemNumber);
    var moldingName = mouldingData.Name;
    if (molding != undefined && molding.Name != undefined)
        moldingName = molding.Name;
 
	template = template.replace(/\[FRAMENAME\]/gi, moldingName );
	template = template.replace(/\[FRAMEMATERIAL\]/gi, mouldingData.Material );
	template = template.replace(/\[FRAMESTYLE\]/gi, mouldingData.Style );
	
	var model = this.app.getModel();
	var user = model.user;
	var doConvertToCm = com.art.core.utils.LocalizationManager.determineConvertToCm(user.countryIso, user.currencyIso, user.languageIso);   
    var mouldingVO = model.getFramingComponent(model.SelectedItemPodConfigIdGet(), mouldingData.ItemNumber,PhotosToArtCore.constants.FRAMING_COMPONENT_MOULDING);
	template = template.replace(/\[FRAMEHEIGHT\]/gi, com.art.core.utils.StringUtil.formatDimension(mouldingVO.height, doConvertToCm) );
	template = template.replace(/\[FRAMEWIDTH\]/gi, com.art.core.utils.StringUtil.formatDimension(mouldingVO.width, doConvertToCm) );
	template = template.replace(/\[COLOR\]/gi, mouldingData.Color );
	template = template.replace(/\[FINISH\]/gi, mouldingData.Finish );
	template = template.replace(/\[PRICE\]/gi, mouldingData.Price.DisplayPrice );
	return template;
};
/**
 * @method 
 */
com.art.photosToArt.modules.ModuleTabOptions.prototype.enablePrintArea =  function()
{
    var model = this.app.getModel();
    var currentImage = model.SelectedImageGet();
    var dimensions = this.getSelectedImageDimensions();
    var currentCropData = model.SelectedItemServiceImageCropGet();
    var printAreaThreshold = this.app.getEnvironment().printAreaCropThreshold;
    //trace('printAreaCropThreshhold: ' + printAreaThreshold);
    var cropWidth = (currentCropData.Dimensions.Width == 0) ? dimensions.width : currentCropData.Dimensions.Width;
    var cropHeight = (currentCropData.Dimensions.Height == 0) ? dimensions.height : currentCropData.Dimensions.Height;
    //trace('-----enablePrintArea: CropW/Width/CropH/Height: ' + cropWidth + '/'  + dimensions.width + '/' + cropHeight + '/' + dimensions.height);
    //trace('width threshold: ' + Math.abs(dimensions.width - cropWidth) + ', height thresh: ' + Math.abs(dimensions.height - cropHeight));
    if ((Math.abs(dimensions.width - cropWidth) > printAreaThreshold) 
     || (Math.abs(dimensions.height - cropHeight) > printAreaThreshold))
    {
    	//trace('enabling print area');
    	$('#changeprintareaon').show();
    	$('#changeprintareaoff').hide();
    }
    else
    {   
    	//trace('disabling print area');
    	$('#changeprintareaon').hide();
    	$('#changeprintareaoff').show();
    }
};
