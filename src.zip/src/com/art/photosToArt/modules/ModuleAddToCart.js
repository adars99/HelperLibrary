/**
 * This is the add to cart module.
 * It deals with the price and shipping details of the selected image.
 * @module ModuleAddToCart
 * @param data
 * @param app
 */
com.art.photosToArt.modules.ModuleAddToCart = function(data,app)
{
	this.app 		= app;
	this.moduleData = data;
	this.NAME		= com.art.photosToArt.modules.ModuleAddToCart.NAME;
	this.instance	= this;
	this.IMAGE_BASEURL = this.app.getEnvironment().imagePath;
	this.markupUtil = this.app.getMarkupUtil().getInstance(this);
	this.lightBox = {};
	this.IMAGE_LIGHTBOX_CLOSE = this.app.getEnvironment().imagePath + '/images/photostoart/close.png';

};

com.art.photosToArt.modules.ModuleAddToCart.NAME = "ModuleAddToCart";
com.art.photosToArt.modules.ModuleAddToCart.IMAGE_SUBFOLDER = "/images/photostoart/";
com.art.photosToArt.modules.ModuleAddToCart.IMAGE_ADD_TO_CART = "add_to_cart_disabled.png";

/**
 * Gets the location in the container to insert this module's rendered markup
 * @method getTarget
 * @returns
 */
com.art.photosToArt.modules.ModuleAddToCart.prototype.getTarget = function()
{
	//NOTE: Init is where you initialize the handlers for this module and any variables, etc instantiated object will need
	return this.moduleData.target;
};

/**
 * Populates the lightBox
 * @method getShippingDetails
 */
com.art.photosToArt.modules.ModuleAddToCart.prototype.getShippingDetails = function() 
{
    var shippingMessage = '<div id="p2a_matc_lightboxmessage" style="text-align:left;width:400px; height:300px; border: 1px solid #727C73;">'
	    +     '<div class="p2a_matc_lightboxtitle" style="height:30px; padding-top:5px; width:100%; background: -moz-linear-gradient(center top , #FFFFFF, #EFEFDE) repeat scroll 0 0 transparent;">'
	    +           '<div class="floatleft" style="padding-left: 10px; color: #647691; font-family: Arial, Helvetica, sans-serif; font-size: 18px;">' +this.app.getString("Ship Time")+ '</div>'
	    +           '<div class="floatright" style="padding-right:9px; padding-top:1px;">'
        +                 '<img id="p2a_matc_lightboxclosebtn" alt="close" src="' +this.IMAGE_LIGHTBOX_CLOSE+ '" />'
        +           '</div>'
	    +     '</div>'
	    +     '<div class="p2a_matc_lightboxcontent" style="padding-left:10px; padding-right:10px; padding-top:10px; font-family:Arial; font-size:12px; line-height:120%;">' +this.app.getString("Ship time indicates the typical number of business days it takes for your item(s) to leave our facilities but does not include transit time from our facilities to the final destination.")+ '</div>'
	    +     '<br></br>' 
	    +     '<div style="padding-left:10px; padding-right:10px; font-family:Arial; font-size:12px; line-height:120%;">' +this.app.getString("Orders that contain multiple items with different ship times will be shipped out based on the item with the longest ship time.")+ '</div>';
    shippingMessage += '<br></br>'
	    +     '<div id="p2a_matc_shippingfaqmsg" style= "padding-left:10px; font-family:Arial; font-size:12px; cursor:pointer; color:#1A5D82;">' +this.app.getString("Shipping FAQ")+ '</div>'
	    +     '<div id="p2a_matc_shippingratesmsg" style="padding-left:10px; font-family:Arial; font-size:12px; cursor:pointer; color:#1A5D82;">' +this.app.getString("Shipping Rates")+ '</div>';
    shippingMessage += '</div>';
	 return shippingMessage;
	 //trace("ShippingMessage: " +shippingMessage); 
};	

/**
 * Initializes the module
 * @method init
 */
com.art.photosToArt.modules.ModuleAddToCart.prototype.init = function ()
{
    $(this.getTarget()).html(this.getTemplate());
    this.registerEvents();
    this.checkImageResolution();
};

/**
 * Attaches event handlers to html elements
 * @method registerEvents
 * @param 
 */
com.art.photosToArt.modules.ModuleAddToCart.prototype.registerEvents = function()
{
	var _this = this; 
	$('#p2a_matc_shippingdetailsmsg').bind('click', function()
	{    	
		//STEP: Create a lightbox
        _this.lightBox = new com.art.core.components.LightBox('usuallyships','body','0.4');
		_this.lightBox.show();
		
		//STEP: Get the z-index of the lightbox so that we can make the popup one higher:
		var usuallyShipsZIndex = _this.lightBox.getLightBoxZIndex()+1;
		$('body').append('<div id="lightboxmessage"></div>');
		
		var lightBoxHtml = _this.getShippingDetails();
		$('#lightboxmessage').hide();
		$('#lightboxmessage').html(lightBoxHtml);
		$('#lightboxmessage').center(true);		
		$('#lightboxmessage').css({'z-index':usuallyShipsZIndex, 'background-color':'white'});
		$('#lightboxmessage').fadeIn();

	    $('#p2a_matc_lightboxclosebtn').bind('click', function()
		{
	    	         _this.lightBox.close();
	    	         $('#lightboxmessage').remove();
		});
      }); 
		
	 $('#p2a_matc_shippingfaqmsg').live('click', function()
	 {   
		 _this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/shippingfaq'},'vo'));
	 });
	 
	
	 $('#p2a_matc_shippingratesmsg').live('click', function()
	 {   
		 _this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/shippingfaq',anchor:'four'},'vo'));
	 }); 
	
	$('#btnaddtocart').bind('click', function()
    {
        //STEP: Determine if this is a complex service (e.g. "framing")
        var isFramedItem = _this.app.getModel().SelectedItemFrameIdGet() > 0;
        
        _this.app.GATrackPageView('/p2a/create/add-to-cart'); 
        _this.showAddToCartLoading();
                    
        //STEP: branch with complex service
        if (isFramedItem)
        {
            _this.notify(new com.art.core.utils.Note(_this.app.events.DUPLICATE_FRAME_FOR_CART,{},'vo'));
        }
        else
        {
            _this.prepareAndCallAddToCart(0);
        }
    });
};

com.art.photosToArt.modules.ModuleAddToCart.prototype.prepareAndCallAddToCart = function(duplicatedFrameId)
{
    var _this = this;
    var cartItemId = '';

    //BEGIN: FUnctionality from place_order.asp

    //STEP: Instantiate the parameter object
    var parameters = [];
    
    //Item attributes
    _this.populateItemAttributes(parameters, duplicatedFrameId);

    //Session Related attributes.
    _this.populateSessionAttributes(parameters);


    //Add the tracking parameter node.
//             call PopulateAffiliateTrackingAttributes(Parameters,MethodParameters)

    //Add the account attributes.
//             call PopulateAccountDetails(Parameters,MethodParameters)

    //STEP: Add the Customer Image attributes.
    _this.populateCustomImageDetails(parameters);
    //END: Functionality from place_order.asp
    
    var requestParameters = {'queryString':com.art.core.utils.StringUtil.getQueryStringFromHash(parameters)};
    //STEP: Call the Add To Cart Event...depending on config value, this could add to cart via ajax, or add to cart via page load.
    if (_this.app.getEnvironment().addToCartMode == "loadcart")
    {
        _this.notify(new com.art.core.utils.Note(_this.app.events.ADDTOCART_GOTOCART,requestParameters,'vo'));
    }
    else
    {
        _this.notify(new com.art.core.utils.Note(_this.app.events.ADDTOCART_STAY,requestParameters,'vo'));
        _this.hideAddToCartLoading();
    }

};

com.art.photosToArt.modules.ModuleAddToCart.prototype.hideAddToCartLoading = function()
{
    var batc =  '#btnaddtocart';
    var iac = '.' + this.markupUtil.getPrefix() + 'loadingaddcart';
    $(batc).show();
    $(iac).hide();
};

com.art.photosToArt.modules.ModuleAddToCart.prototype.showAddToCartLoading = function()
{
    var batc =  '#btnaddtocart';
    var iac = '.' + this.markupUtil.getPrefix() + 'loadingaddcart';
    $(batc).hide();
    $(iac).show();
};

com.art.photosToArt.modules.ModuleAddToCart.prototype.populateItemAttributes = function (parameters, duplicatedFrameId)
{
	//STEP: make a local reference to the cache (model)
	var model = this.app.getModel();
	//'single Parameters .

	
	
	parameters['cartkey'] = model.UserCartKeyGet(this.app.constants.ART_COOKIE_DICTIONARY_PERSISTENT, this.app.constants.COOKIE_NAME_CARTKEY); // model.user.cartKey; //call Parameters.Add("cartkey", CookiePersistentGet("cartkey"))
	parameters['apNum'] = model.application.photosToArtApnum;
	parameters['podconfigid'] = model.SelectedItemPodConfigIdGet(); //call Parameters.Add("podconfigid",PassedPODConfigID)
	parameters['fid'] = duplicatedFrameId > 0 ? duplicatedFrameId : ''; //call Parameters.Add("fid",FRAMEID)
	parameters['quantity'] = 1; //call Parameters.Add("quantity",1)
	parameters['iid'] = model.SelectedImageCartItemIdGet(); //call Parameters.Add("iid",CurrentIID)
	parameters['S'] = model.SelectedItemServiceGet().itemServiceCode; //call Parameters.Add("S",ServiceToBeFetched)
	parameters['ZoneProductID'] = ''; //= model.application.photosToArtApnum; //call Parameters.Add("ZoneProductID",zoneProductId)

	var date = new Date();
	//parameters['UserDate'] = ''; //call Parameters.Add("UserDate", now())
};


com.art.photosToArt.modules.ModuleAddToCart.prototype.populateSessionAttributes = function(parameters)
{
	//STEP: make a local reference to the cache (model)
	var model = this.app.getModel();
	//'XML string parameters.
	var methodParameters = {};
	methodParameters['customerZoneId'] = model.application.customerZoneId; //call MethodParameters.Add("customerZoneId", glbCustomerZoneId)
	methodParameters['languageId'] = com.art.core.utils.LocalizationManager.convertLanguageIsoToLanguageId(model.user.languageIso); //call MethodParameters.Add("languageId", Application("LanguageID"))
	methodParameters['countryIsoA2'] = model.user.countryIso; //call MethodParameters.Add("countryIsoA2", CStr(ipDetectCountryCode))
//NOTE: Hoping that these are deprecated and not needed 	methodParameters['quoteIdentification'] = ''; //call MethodParameters.Add("quoteIdentification", "")
//NOTE: Hoping that these are deprecated and not needed 	methodParameters['exchangeRate'] = ''; //call MethodParameters.Add("exchangeRate", FetchExchangeRateAndRoundingMethod(CStr(selectedCurrency))(0))
	methodParameters['currencyIsoCode'] = model.user.currencyIso; //call MethodParameters.Add("currencyIsoCode", CStr(selectedCurrency))
//NOTE: Hoping that these are deprecated and not needed 	methodParameters['currencyIsoNumber'] = ''; //call MethodParameters.Add("currencyIsoNumber", GetCurrencyID(CStr(selectedCurrency)))
	methodParameters['sessionid'] = model.user.sessionId; //call MethodParameters.Add("sessionid", qs_sessionid)
//NOTE: This may actually get filled in by the service side itself...ccheck to find out...	methodParameters['clientip'] = '';//NOTE: NO way to get this in JS...must get from server at some point //call MethodParameters.Add("clientip", REMOTE_ADDR)   'This variable is populated in page_initialize.asp.
	
	methodParameters['WebServerDomainName'] = location.host; //call MethodParameters.Add("WebServerDomainName", Request.ServerVariables("SERVER_NAME"))
	
	parameters['cartParameters_session'] = escape(com.art.core.utils.StringUtil.getQueryStringFromHash(methodParameters)); //call Parameters.Add("cartParameters_session", Server.URLEncode(MethodParameters.toString()))
};

com.art.photosToArt.modules.ModuleAddToCart.prototype.populateCustomImageDetails = function(parameters)
{   
	//STEP: make a local reference to the cache (model)
	var model = this.app.getModel();
	var cropInformation = model.SelectedItemServiceImageCropGet();
	
	var methodParameters = {};
	//'XML string parameters.
	methodParameters['ImageGuid'] = model.SelectedImageGuidGet(); //call MethodParameters.Add("ImageGuid", CustomImageGuid)
	methodParameters['ServicePriceBucketID'] = model.application.servicePriceBucketId; //call MethodParameters.Add("ServicePriceBucketID",ServicePriceBucketID)
	methodParameters['ImageCropID'] = cropInformation.CustomCropInformation.ImageCropId; //call MethodParameters.Add("ImageCropID",ImageCropID)
	methodParameters['ServiceSubType'] = model.SelectedItemServiceGet().subType; //call MethodParameters.Add("ServiceSubType",ServiceSubType)
	methodParameters['cropX'] = cropInformation.Coordinates.CoordinateX; //call MethodParameters.Add("cropX",cropX)
	methodParameters['cropY'] = cropInformation.Coordinates.CoordinateY; //call MethodParameters.Add("cropY",cropY)
	methodParameters['cropW'] = cropInformation.Dimensions.Width; //call MethodParameters.Add("cropW",cropW)
	methodParameters['cropH'] = cropInformation.Dimensions.Height; //call MethodParameters.Add("cropH",cropH)
	methodParameters['ID'] = model.user.persistentId; //call MethodParameters.Add("ID",ID)
	


	
	
	parameters['itemParameters_CustomImage'] = escape(com.art.core.utils.StringUtil.getQueryStringFromHash(methodParameters)); //call Parameters.Add("itemParameters_CustomImage", Server.URLEncode(MethodParameters.toString()))
};

/*
Sub PopulateAffiliateTrackingAttributes(byref Parameters,byref MethodParameters)
  'XML string parameters.
  call MethodParameters.Clear()
  call MethodParameters.Add("AID",0)
  call MethodParameters.Add("LAID",0)
  call MethodParameters.Add("LastIntRFID", Request.Cookies("RFID")("LastIntRFID"))
  call MethodParameters.Add("CurrentRFID", Request.Cookies("RFID")("CurrentRFID"))
  call MethodParameters.Add("LastExtRFID", Request.Cookies("RFID")("LastExtRFID"))
  call MethodParameters.Add("ExternalVisitCount", Request.Cookies("RFID")("ExternalVisits"))
  call MethodParameters.Add("InternalVisitCount", Request.Cookies("RFID")("InternalVisits"))
  call MethodParameters.Add("AffClickThroughID", Request.Cookies("AffClickThruID"))
  call MethodParameters.Add("OriginalRFID", Request.Cookies("RFID")("OriginalRFID"))
  call MethodParameters.Add("OriginalRFIDDate", Request.Cookies("RFID")("OrigRFIDDate"))
  call MethodParameters.Add("LastExternalRFIDDate", Request.Cookies("RFID")("LastExtRFIDDate"))
  call MethodParameters.Add("LastInternalRFIDDate", Request.Cookies("RFID")("LastIntRFIDDate"))
  call MethodParameters.Add("Compensated", Request.Cookies("RFID")("IsCompensated"))
  call MethodParameters.Add("LastExternalTrackingID", Request.Cookies("RFID")("LastExternalTrackingID"))
  call MethodParameters.Add("LastInternalTrackingID", Request.Cookies("RFID")("LastInternalTrackingID"))
  //PersistentID is a global variable in Page_Initialize.asp.
  call MethodParameters.Add("PersistentID", persistentID)
  'Need the ReferrerURL.Referral URL populated when coming from external links. If coming directly to the site , it is NULL.
  if(not IsNull(http_initial_referer)) then
    call MethodParameters.Add("Referrer", Server.URLEncode(Replace(http_initial_referer,"&","&amp;")))
  end if
  call Parameters.Add("cartParameters_affiliate", Server.URLEncode(MethodParameters.toString()))
end Sub



Sub PopulateAccountDetails(byref Parameters,byref MethodParameters)
Dim UserName,UserId,myuser

if(ACCOUNTLOGINASP_VALIDLOGIN) then
   set myuser = new userobj
   UserId = qs_acct
   myuser.LoadAccount(qs_acct)
   UserName = myuser.Username
end if

 'XML string parameters.
  call MethodParameters.Clear()
  call MethodParameters.Add("UserName",UserName)
  call MethodParameters.Add("UserId", UserId)
  call Parameters.Add("cartParameters_account", Server.URLEncode(MethodParameters.toString()))
end Sub
*/









//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * @method destroy
 */
com.art.photosToArt.modules.ModuleAddToCart.prototype.destroy = function()
{
	//NOTE: Destroy is where you destroy this object and clean up memory
};

/**
 * Sends notifications through event messaging system
 * @method notify
 * @param note
 */
com.art.photosToArt.modules.ModuleAddToCart.prototype.notify = function(note)
{
	//NOTE: 
	this.app.sendNotification(note);
};

/**
 * Informs Core of events it will handle
 * @method listNotificationInterests
 * @returns {Array}
 */
com.art.photosToArt.modules.ModuleAddToCart.prototype.listNotificationInterests = function()
{
	return [
		this.app.events.RELOAD_USER_INTERFACE
		, this.app.events.DUPLICATE_FRAME_FOR_CART_SUCCESS
		, this.app.events.DUPLICATE_FRAME_FOR_CART_FAILURE
		, this.app.events.SHOW_PRICE_DETAILS_MODAL
		, this.app.events.GET_SALES_EVENT_MESSAGE_FOR_PRODUCT_SUCCESS
		, this.app.events.GET_SALES_EVENT_MESSAGE_FOR_PRODUCT_FAILURE
	];
};
/**
 * Handlers for events
 * @method handleNotification
 * @param note
 */
com.art.photosToArt.modules.ModuleAddToCart.prototype.handleNotification = function(note)
{
	////trace('handleNotification');
	var _this = this;
	//trace("MATC - handling " + note.name);
	switch(note.name)
	{
		case this.app.events.RELOAD_USER_INTERFACE:
			$('#' + this.markupUtil.getName('itemdisplayprice')).html(this.app.getModel().SelectedItemDisplayPriceGet());
			this.setShippingMessageDisplay(this.getShippingMessage(this.app.getModel().SelectedItemTimeToShipTextGet(this.app.getModel().SelectedItemPodConfigIdGet())),'');
			if (!this.checkImageResolution())
			{
    			if(this.app.getModel().SelectedItemServiceGet().name != this.app.getModel().data.serviceTypes.framing.name)
    			{
    				this.hidePriceDetailsLink();
    			}
    			else
    			{
    				this.showPriceDetailsLink();
    				var item = this.app.getModel().SelectedImageGet();
    	        	
    	        	//check to see if "TooBigToShip"
    				var enableButton = item.Service.Frame.FrameSummary.IsTooBigToShip.toString() == "true" ? false : true;
    	        	this.enableAddToCartButton(enableButton, this.getTooLargeToShipMessage());
    			}
			}
			break;
		case this.app.events.DUPLICATE_FRAME_FOR_CART_SUCCESS:
		    this.prepareAndCallAddToCart(note.body.ResponseValue);
		    break;
		case this.app.events.DUPLICATE_FRAME_FOR_CART_FAILURE:
		    //alert("Duplicate Frame Failed...don't forget to remove this alert before production.");
		    break;
		case this.app.events.GET_SALES_EVENT_MESSAGE_FOR_PRODUCT_SUCCESS:
		    this.setEventMessage(note);
		    break;
		case this.app.events.GET_SALES_EVENT_MESSAGE_FOR_PRODUCT_FAILURE:
	        this.setShippingMessageDisplay(this.getTimeToShipText(this.app.getModel().SelectedItemTimeToShipTextGet(this.app.getModel().SelectedItemPodConfigIdGet())),'');
		    break;
	}
};
com.art.photosToArt.modules.ModuleAddToCart.prototype.getTooLargeToShipMessage = function()
{
    return "<img src='" + this.app.getEnvironment().imagePath + "/images/photostoart/error.png' style='float:left'/>&nbsp;" + this.app.getString("This will make the item too large to ship");
};
com.art.photosToArt.modules.ModuleAddToCart.prototype.enableAddToCartButton = function(bool, msg)
{
    var _this = this;
    $('#btnaddtocart_msg').html('');
	if(bool == false)
	{
	    //trace('ModuleAddToCart - Image + Service = Low Resolution');
	    $('#btnaddtocart').hide();
        $('#' + this.app.getMarkupUtil().getPrefix() + 'inactiveaddcart').show();	    
        if (msg != undefined)
        {
            $('#btnaddtocart_msg').html(msg);
        }
    }
    else
    {
        //trace('ModuleAddToCart - Image + Service = Resolution OK');
        $('#btnaddtocart').show();
        $('#' + this.app.getMarkupUtil().getPrefix() + 'inactiveaddcart').hide();
	}
	
};

com.art.photosToArt.modules.ModuleAddToCart.prototype.showPriceDetailsLink = function()
{
	var _this = this;
	$("#p2a_price_details").show();
	if($("#p2a_price_details").data("events") == undefined)
	{
		$("#p2a_price_details").bind("click",function(){
			_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.SHOW_PRICE_DETAILS_MODAL,{},""));
			
		});
	}
	else{
		trace("NO NEED TO ADD CLICK EVENT");
	}
	
	
};
com.art.photosToArt.modules.ModuleAddToCart.prototype.hidePriceDetailsLink = function()
{
	$("#p2a_price_details").hide();
};



/**
 * Method to get the value of TimeToShip
 * @method getShippingMessage
 * @param timeToShipText
 */
com.art.photosToArt.modules.ModuleAddToCart.prototype.getShippingMessage = function(timeToShipText)
{
	var eventDateStart = new Date(this.app.getEnvironment().eventMessageDateBegin);
    var eventDateEnd = new Date(this.app.getEnvironment().eventMessageDateEnd);
    var today = new Date();
    
    //today.setMonth(11);
    //trace("eventDateStart: " + eventDateStart);
    //trace("eventDateEnd: " + eventDateEnd);
    //trace("today: " + today);
    
    var cookieHelper = new com.art.core.cookie.Cookie();
    var overrideDate = cookieHelper.getCookieDictionary
    (
            "adbg"
            , "dateToday"
     );
    
    if (overrideDate.length > 0)
        today = new Date(overrideDate);
    if (today > eventDateStart && today < eventDateEnd)
    {
        return this.app.sendNotification(new com.art.core.utils.Note(this.app.events.GET_SALES_EVENT_MESSAGE_FOR_PRODUCT, {dateToday:today.toLocaleString()}, ''));
    }
    else
    {
        return this.getTimeToShipText(timeToShipText);
    }
};

com.art.photosToArt.modules.ModuleAddToCart.prototype.getTimeToShipText = function(timeToShipText)
{
    var timeToShipLabel = this.app.getString("Usually ships in [SAME-DAY]");
    return timeToShipLabel.replace("[SAME-DAY]", com.art.core.utils.LocalizationManager.getTimeToShipString(timeToShipText,this.app.getModel().user.languageIso));
};

com.art.photosToArt.modules.ModuleAddToCart.prototype.setShippingMessageDisplay = function(timeToShip,eventMessage)
{
    $('#' + this.markupUtil.getName('shippingdetailsmsg')).html(timeToShip);
    $('#' + this.markupUtil.getName('eventdetailsmsg')).html(eventMessage);
};

com.art.photosToArt.modules.ModuleAddToCart.prototype.setEventMessage = function(note)
{
    try
    {
    var xmlResponse = note.body;
        
    //Check if there are any errors.
    //var objExceptionNodes = xmlResponse.documentElement.getElementsByTagName("Exception");
    var objExceptionNodes = xmlResponse.toLowerCase().indexOf('<exception') >= 0;
    //var resultsNode       = $(xmlResponse).find("item0").val();
    var resultsNode         = "";
    var beginTag = "<item0>";
    var endTag = "</item0>";
    
    if (xmlResponse.toLowerCase().indexOf("<results") >= 0)
    {
        resultsNode = String(xmlResponse).substring(xmlResponse.toLowerCase().indexOf(beginTag)+beginTag.length, xmlResponse.toLowerCase().indexOf(endTag));
    }
    
    if(objExceptionNodes) 
    {
       this.setShippingMessageDisplay(this.getTimeToShipText(this.app.getModel().SelectedItemTimeToShipTextGet(this.app.getModel().SelectedItemPodConfigIdGet())),'');
    }  
    else
    {
        try
        {
            var parts = resultsNode.split("|");
            var display = "<span style='color:green;font-weight:bold;'>" + parts[1] + "</span>";
            if (parts[0] == "0")
                display = "<span style='color:red;font-weight:bold;'>" + parts[1] + "</span>";
            this.setShippingMessageDisplay('', display);
        }
        catch(err)
        {
            this.setShippingMessageDisplay(this.getTimeToShipText(this.app.getModel().SelectedItemTimeToShipTextGet(this.app.getModel().SelectedItemPodConfigIdGet())),'');
        }
    }
    }
    catch(err)
    {
        this.app.logError(err);
        this.setShippingMessageDisplay(this.getTimeToShipText(this.app.getModel().SelectedItemTimeToShipTextGet(this.app.getModel().SelectedItemPodConfigIdGet())),'');
    }
};


com.art.photosToArt.modules.ModuleAddToCart.prototype.checkImageResolution = function()
{
	//If the selected PODConfig (sizes dropdown) has warning == true attached, suppress the 
	//   add to cart button within an informative div
	var prefix = this.markupUtil.getPrefix();
	var ypc = '.' + prefix + 'yourpricecontainer';
	var ppl = '.' + prefix + 'pricingpopuplink';
	var iac = '.' + prefix + 'inactiveaddcart';
	var us = '.' + prefix + 'usuallyships';
	var lremc = '.' + prefix + 'lowreserrormsgcontainer';
	var batc = 	'#btnaddtocart';
	var isLowResolution = false;
	var isCriticalResolution = false;
	var selectedPod = '';

	var model = this.app.getModel();
	selectedPod = model.SelectedItemPodConfigIdGet();
	
	// LOGIC: if the currently selected image + currently selected service results in only 1 PodConfig option,
	//        and that option has Warning === 'True', disable the add to cart
	//        If there is > 1 PodConfig option, but the currently selected PodConfig has Warning === 'True', 
	//        then display a warning message under the sizes drop down, but do not disable the add to cart button.
	
	
	var sizes = model.getItemAvailableSizes(model.SelectedImageGuidGet(),model.SelectedItemServiceGet());
	for(var i = 0;i < sizes.length; i++)
	{
		if(sizes.length === 1 && sizes[i].Warning === 'True')
		{
			isCriticalResolution = true;
		}
		if(sizes[i].PodConfigId === selectedPod && sizes[i].Warning === 'True')
		{
			isLowResolution = true;
		}
	}
	
	// When user clicks upon an image which has a warning icon, we simply don't allow that to be added to cart
	if(isCriticalResolution)
	{
		////trace('ModuleAddToCart - Image + Service = CRITICAL');
		$(ypc).hide();
		$(ppl).hide();
		$(us).hide();
		$(batc).hide();
		$(lremc).show();
		$(iac).show();
	}
	else
	{
		////trace('ModuleAddToCart - Image + Service = NOT CRITICAL');
		$(ypc).show();
		$(ppl).show();
		$(us).show();
		$(batc).show();
		$(lremc).hide();
		$(iac).hide();
	}
	
	return isCriticalResolution;
	/*
	 * 
	if(!isCriticalResolution && isLowResolution)
	{
		//trace('ModuleAddToCart - Image + Service = Low Resolution');
		this.enableAddToCartButton(false);
	}
	else
	{
		//trace('ModuleAddToCart - Image + Service = Resolution OK');
		this.enableAddToCartButton(true);
	}
	 */
};
/**
 * @method getTemplate
 * @returns string
 */
com.art.photosToArt.modules.ModuleAddToCart.prototype.getTemplate = function()
{
	
	//STEP: Get the raw string for the template
	var returnValue = this.template;
	//STEP: Replace the [IMAGE_DOMAIN] placeholder with the imagePath value
	returnValue = returnValue.replace(/\[IMAGE_DOMAIN\]/gi, this.IMAGE_BASEURL);
	//STEP: Replace any strings that require access to separate function calls
	
	returnValue = returnValue.replace(/\[BTN_GRAY_GRADIENT_PRICE\]/gi, this.markupUtil.getGenericClassName('btn_gray_gradient_price') );
	
	// in order to replace an id value, no need of the active button state
	returnValue = returnValue.replace(/\[ADDTOCARTCONTAINER\]/gi, this.markupUtil.getName('addtocartcontainer'));
	returnValue = returnValue.replace(/\[YOURPRICECONTAINER\]/gi, this.markupUtil.getName('yourpricecontainer',this.markupUtil.buttonStates.ACTIVE));
	returnValue = returnValue.replace(/\[YOURPRICELABEL\]/gi, this.markupUtil.getName('yourpricelabel',this.markupUtil.buttonStates.ACTIVE));
	returnValue = returnValue.replace(/\[YOURPRICE\]/gi, this.markupUtil.getName('yourprice',this.markupUtil.buttonStates.ACTIVE));
	returnValue = returnValue.replace(/\[NORMALPRICE\]/gi, this.markupUtil.getName('normalprice',this.markupUtil.buttonStates.ACTIVE));
	returnValue = returnValue.replace(/\[ADDTOCART\]/gi,this.markupUtil.getName('addtocart',this.markupUtil.buttonStates.ACTIVE));
	returnValue = returnValue.replace(/\[ADDTOCARTIMAGE\]/gi, this.markupUtil.getName('addtocartimage',this.markupUtil.buttonStates.ACTIVE));
	returnValue = returnValue.replace(/\[ADDTOCARTIMG\]/gi,	this.IMAGE_BASEURL +  com.art.photosToArt.modules.ModuleAddToCart.IMAGE_SUBFOLDER	+  com.art.photosToArt.modules.ModuleAddToCart.IMAGE_ADD_TO_CART);
	returnValue = returnValue.replace(/\[USUALLYSHIPS\]/gi, this.markupUtil.getName('usuallyships',this.markupUtil.buttonStates.ACTIVE));
	returnValue = returnValue.replace(/\[ITEM_DISPLAY_PRICE\]/gi, this.markupUtil.getName('itemdisplayprice'));
	returnValue = returnValue.replace(/\[SHIPPING_DETAILS_MSG\]/gi, this.markupUtil.getName('shippingdetailsmsg'));
    returnValue = returnValue.replace(/\[EVENT_DETAILS_MSG\]/gi, this.markupUtil.getName('eventdetailsmsg'));

	returnValue = returnValue.replace(/\[IMAGE_PATH\]/gi, this.IMAGE_BASEURL + com.art.photosToArt.modules.ModuleAddToCart.IMAGE_SUBFOLDER);
	 
	returnValue = returnValue.replace(/\[LOW_RES_TEXT\]/gi, this.app.getString('Sorry, the photo you\'ve selected does not have a high enough resolution to be printed. Please select another photo.'));
	returnValue = returnValue.replace(/\[PREFIX\]/gi, this.markupUtil.getPrefix());
	

	//STEP: Replace strings that are phrases for translation
	returnValue = returnValue.replace(/\[YOUR_PRICE_:\]/gi, this.app.getString('Your Price:'));
	returnValue = returnValue.replace(/\[PRICE\]/gi, this.app.getString('Loading').toLowerCase() + '...');
	returnValue = returnValue.replace(/\[PRICE_DETAILS\]/gi, this.app.getString('Price_details'));

	//STEP: Special cases for add to cart
	var addToCartLabel = this.app.getString(this.app.getModel().EnVarLabelAddToCartButtonEnglishGet());
	var addToCartLabelLength = addToCartLabel.length;
	var addToCartBtnLength = 140;
	//NOTE: Why "11" below, because that is how many chars in "add to cart"
	addToCartBtnLength = addToCartBtnLength + (Math.round((addToCartBtnLength / 11) * (addToCartLabelLength > 11 ? addToCartLabelLength - 11 : 11 - addToCartLabelLength))-20);
    returnValue = returnValue.replace(/\[ADD_TO_CART\]/gi, addToCartLabel);
	returnValue = returnValue.replace(/\[ADD_TO_CART_BTN_WIDTH\]/gi, addToCartBtnLength);

	
	//alert(returnValue);
	return returnValue.replace('$NAME', this.NAME.toLowerCase());

};

com.art.photosToArt.modules.ModuleAddToCart.prototype.template = '<div id="$NAME">'
+ '<div id="[ADDTOCARTCONTAINER]" class="btn_gray_gradient_price">'
+       '<div class="[YOURPRICECONTAINER]">'
+            '<div class="[YOURPRICELABEL]">[YOUR_PRICE_:]</div>'
+            '<div class="[YOURPRICE]">'
+               '<span id="[ITEM_DISPLAY_PRICE]" class="[NORMALPRICE]">[PRICE]</span>'
+            '</div>'
+			 '<div id="p2a_price_details" style="width:130px;text-align:center;margin-top:7px;height:10px;display:none;color: #1A5D82;cursor: pointer;text-transform: capitalize;font-family: Verdana;font-size: 11px;">[PRICE_DETAILS]</div>'
+       '</div>'
+       '<div class="clear"></div>'
//+       '<div class="[PREFIX]pricingpopuplink activeseepricedetails hidden" >[PRICE_DETAILS]</div>'
//+       '<div class="clear"></div>'
+       '<div class="[ADDTOCART]">'
+            '<center>'
+            '<div id="btnaddtocart" class="btn_orange btn_global_doubleline btn_global link"  '
+ '					onmouseout="this.className=\'btn_orange btn_global_doubleline btn_global link\'" '
+ '					onmouseover="this.className=\'btn_over btn_global_doubleline btn_global link\'" style="width: [ADD_TO_CART_BTN_WIDTH]px;">'
+                '<div class="btn_text text-align-center btn_global_rightwhitearrow">[ADD_TO_CART]</div>'
+            '</div>'
+            '<div class="[PREFIX]inactiveaddcart" style="display:none">'
+            '<div id="btnaddtocart_inactive" class="btn_grey btn_global_doubleline btn_global link"  '
+            '    style="width: [ADD_TO_CART_BTN_WIDTH]px;">'
+                '<div class="btn_text text-align-center btn_global_rightwhitearrow">[ADD_TO_CART]</div>'
+            '</div>'
+            '</div>'
+            '<div class="[PREFIX]loadingaddcart hidden" >'
+            '<div id="btnaddtocart_loading" class="btn_grey btn_global_doubleline btn_global link"  '
+            '    style="width: [ADD_TO_CART_BTN_WIDTH]px;">'
+                '<div class="btn_text text-align-center btn_global_rightwhitearrow"><img src="http://cache1.artprintimages.com/images/photostoart/loading.gif" width="15" height="15" style="float:left;margin-left:3px;margin-right:-13px" /><i>[ADD_TO_CART]</i></div>'
+            '</div>'
+            '</div>'
+            '<div id="btnaddtocart_msg"></div>'
+            '</center>'
+      '</div>'
+      '<div class="clear"></div>'
+      '<div class="[USUALLYSHIPS]">'
+           '<span class="usuallyshipsvalue cpointer">&nbsp'
+                '<span id="[SHIPPING_DETAILS_MSG]"></span>'
+           '</span>'
+           '<span id="[EVENT_DETAILS_MSG]"></span>'
+ '		</div>'
+      	'<div class="clear"></div>'
+ '     <div class="[PREFIX]lowreserrormsgcontainer hidden" style="text-align:left;color: #818386;padding-left: 15px;padding-top: 10px;">'
+ '			<div class="[PREFIX]_lowResErrorMsgImg floatleft" style="padding-top:6px;">'
+ ' 			<img src="[IMAGE_PATH]/warning.gif">'
+ '			</div>'
+ '			<div class="[PREFIX]lowResErrorMsgText1 floatleft" style="line-height: 15px;margin-left: 8px;width: 225px;color: #818386;">'
+ '         	[LOW_RES_TEXT]'
+ '			</div> '
+ '		</div> '
+ '</div>'
+'</div>';




	
