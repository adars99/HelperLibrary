/**
 * This module is the home page that contain overview about all the services that are supported by photos to art.
 * @module ModuleTabOptions
 * @module ModuleHomePage
 * @param data
 * @param app
 */
com.art.photosToArt.modules.ModuleHomePage = function(data,app)
{
	this.app 		= app;
	this.moduleData = data;
	this.NAME		= com.art.photosToArt.modules.ModuleHomePage.NAME;
	this.instance	= this;
	this.IMAGE_BASEURL = this.app.getEnvironment().imagePath;
	this.markupUtil = this.app.getMarkupUtil().getInstance(this);
	
};
com.art.photosToArt.modules.ModuleHomePage.NAME = "ModuleHomePage";

/**
 * Gets the location in the container to insert this module's rendered markup
 * @method getTarget
 * @returns
 */
com.art.photosToArt.modules.ModuleHomePage.prototype.getTarget = function ()
{
	return this.moduleData.target;
};

/**
 * Initializes the module
 * @method init
 */
com.art.photosToArt.modules.ModuleHomePage.prototype.init = function ()
{
	//NOTE: Init is where you initialize the handlers for this module and any variables, etc instantiated object will need
	
	//this.app.GATrackEvent(this.app.getEnvironment().gaPartnerCode + ' LANDING ' + com.art.core.tracking.GoogleAnalytics.prototype.getDelimiter() + ' VIEWED');
	
	var _this = this;
	$(this.getTarget()).html(this.getTemplate());

	var contentBlocks = this.app.getEnvironment().contentBlocks;
    if (contentBlocks.homepage == 'on')
        this.notify(new com.art.core.utils.Note(this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/homepage'},'vo'));
    if (contentBlocks.header.overview == 'on')
        this.notify(new com.art.core.utils.Note(this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/header_overview'},'vo'));
    if (contentBlocks.footer.overview == 'on')
        this.notify(new com.art.core.utils.Note(this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/footer_overview'},'vo'));
	
	this.registerEvents();
};

/*
 * Candidate for REMOVAL...implemented now elsewhere
com.art.photosToArt.modules.ModuleHomePage.prototype.postCmsRegisterEvents = function()
{
    // Need to show different buttons depending on whether the user has images or not
    var itemCount = this.app.getModel().getGalleryItemCount();
   	var buttonToShow = itemCount > 0 ? '#id-button-home-loadimage' : '#id-button-home-upload';
   	var buttonToHide = itemCount === 0 ? '#id-button-home-loadimage' : '#id-button-home-upload';
   	//trace('buttonToShow = ' + buttonToShow + ', buttonToHide = ' + buttonToHide);
   	//trace('buttonToShow exists? ' + ($(buttonToShow).length > 0));

   	setTimeout(function() {
   	    $(buttonToShow).show();
   	    $(buttonToHide).hide();
   	    if (loadHomePageButtons !== undefined)
   	        loadHomePageButtons();
   	}, 500);
};
 */


/**
 * Attaches event handlers to html elements
 * @method registerEvents
 * @param module
 */
com.art.photosToArt.modules.ModuleHomePage.prototype.registerEvents = function()
{
    var _this = this;
        
    function makeMeSelected(tab)
    {
    	$('#countrytabs li').each(function(){
    		if($(this).hasClass('selectedtab'))
    		{
    			$(this).removeClass('selectedtab');
    		}
    	});
    	$(tab).addClass('selectedtab');
    }

    $('#tab2').live('click', function()
    {
    	$(this).addClass('selected');
    });	

};

com.art.photosToArt.modules.ModuleHomePage.prototype.destroy = function()
{
	//NOTE: Destroy is where you destroy this object and clean up memory
};
/**
 * Sends notifications through event messaging system
 * @method notify
 * @param note
 */
com.art.photosToArt.modules.ModuleHomePage.prototype.notify = function(note)
{
	//NOTE: 
	this.app.sendNotification(note);
	
};
/**
 * Informs Core of events it will handle
 * @method listNotificationInterests
 * @returns {Array}
 */
com.art.photosToArt.modules.ModuleHomePage.prototype.listNotificationInterests = function()
{
	return [  
	        	this.app.events.CATALOG_GET_CONTENT_SUCCESS
	        ];
};	
	
/**
 * Handlers for events
 * @method handleNotification
 * @param note
 */
com.art.photosToArt.modules.ModuleHomePage.prototype.handleNotification = function(note)
{
	//trace('MHP.handleNotfication (no handlers): ' + note.name);
	
	switch(note.name)
	{
		case this.app.events.CATALOG_GET_CONTENT_SUCCESS:
			//trace('MHP - adding content ' + note.body.contentBlockName.toLowerCase() + '- content length: ' + note.body.ResponseValue.length);
			switch(note.body.contentBlockName.toLowerCase())
			{
				
				case 'p2a/homepage':
				    var responseStr = note.body.ResponseValue;
				    //STEP: If the content is within the model (cached) then use that value as a override
				    if (String(responseStr).length == 0)
				    {
				        responseStr = this.app.getModel().data.homePageHtml;
				        
				        $('#photostoartcontainer').html(responseStr);
				        this.app.getModel().invokeCallToActionButtons();
				        break;
				    }
				    else
				    {
    				    if (String(responseStr).length == 0)
    				        responseStr = '<div id="id-button-home-upload" style="">GET STARTED</div>';
				    }
                    $('#homepagecontainer').html(responseStr);
                    if (initHomePage!==undefined)initHomePage();
				    break;
				case 'p2a/header_overview':
					if (this.app.getModel().StateCurrentUserInterfaceModeGet() !== this.app.constants.UI_MODE_APPLICATION)
                	{
						$('#p2a_ms_header').html(note.body.ResponseValue);
                	}
					break;
				case 'p2a/footer_overview':
					if (this.app.getModel().StateCurrentUserInterfaceModeGet() !== this.app.constants.UI_MODE_APPLICATION)
                	{
						$('#p2a_ms_footer').html(note.body.ResponseValue);
                        //TODO: this is now not needed because of APC Dev, should be compatible with PB too, but check before next PB Deployment
						//this.postCmsRegisterEvents();
						// Marks end of initialize workflow phase of application
						//TODO: this is now not needed because of APC Dev, should be compatible with PB too, but check before next PB Deployment
//						/this.app.getModel().initializeEnd();
                	}
					break;
				default:
					return false;
					break;				
			}
			break;
	}
};

/**
 * @method getTemplate
 * @returns string
 */
com.art.photosToArt.modules.ModuleHomePage.prototype.getTemplate = function()
{
	//STEP: Get the raw string for the template
	var returnValue = this.template;
	return returnValue.replace('$NAME', this.NAME.toLowerCase());
};

com.art.photosToArt.modules.ModuleHomePage.prototype.template = '<div id="$NAME" style="float:left;">'
	+ '<div id="homepagecontainer"></div>'
	+ '</div>';
