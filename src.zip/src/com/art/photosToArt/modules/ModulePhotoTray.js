/**
 * ModulePhotoTray displays the images the user has uploaded and provides delete and zoom functionality
 * @class ModulePhotoTray
 * @namespace com.art.photosToArt.modules
 * @constructor
 * @param target
 * @param app
 */
com.art.photosToArt.modules.ModulePhotoTray = function(target, app)
{
	this.app 		= app;
	this.target 	= target;
	this.NAME		= com.art.photosToArt.modules.ModulePhotoTray.NAME;
	this.IMAGE_BASEURL	= this.app.getEnvironment().imagePath + com.art.photosToArt.modules.ModulePhotoTray.IMAGE_BASEURL;
	this.instance	= this;
	this.initialized = false;
	this.imageVoArray = [];
	this.userImageArray = [];
	this.markupUtil 	= this.app.getMarkupUtil().getInstance(this);
	this.maxImageCount = 0;
	this.debugImageIndex = 0;
	this.gallery = {};
    this.IMAGE_INFO_OFF = this.app.getEnvironment().imagePath + '/images/photostoart/info_off.png';
    this.IMAGE_ARROW = this.app.getEnvironment().imagePath + '/images/photostoart/arrow.png';
    this.imageReturnIndex = 0;
};
com.art.photosToArt.modules.ModulePhotoTray.NAME = "ModulePhotoTray";
com.art.photosToArt.modules.ModulePhotoTray.flashUploader = {};
com.art.photosToArt.modules.ModulePhotoTray.IMAGE_BASEURL = '/images/photostoart/';
com.art.photosToArt.modules.ModulePhotoTray.carousel = {};
/**
 * @method listNotificationInterests
 * @returns {Array}
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.listNotificationInterests = function()
{
	return  [
	         	  this.app.events.GALLERY_ADD_ITEM_SUCCESS
	         	, this.app.events.PHOTO_DELETED
	         	, this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS
	        ];
};
/**
 * @method handleNotification
 * @param note
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.handleNotification = function(note)
{
	switch(note.name)
	{
		case this.app.events.PHOTO_DELETED:
			//trace('MPT - PHOTO DELETED');
			this.unbindEvents();
			this.init();
			this.selectFirstItem();
			break;
			
		case this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS:
			//trace('MPT-IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS');
			this.showImageInCarousel();
			break;
	}
};
com.art.photosToArt.modules.ModulePhotoTray.prototype.selectFirstItem = function()
{
	if(this.app.getModel().getGalleryItemCount() > 0)
	{
		this.notify(new com.art.core.utils.Note(this.app.events.USERIMAGE_CLICKED, { imageGuid: this.app.getModel().SelectedImageGuidGet() },'vo'));
	}
};
com.art.photosToArt.modules.ModulePhotoTray.prototype.unbindEvents = function()
{
	$('#p2a_mpt_container').find('div').unbind();
	$('#p2a_mpt_container').find('img').unbind();
};
/**
 * @method render
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.render = function()
{
	//NOTE: Init is currently the only way this module is being activated by the environment
	//NOTE:  Render is not being called
	if(!this.initialized)
	{
		this.init();
	}
	return getTemplate();
};
/**
 * Init is where you initialize the handlers for this module and any variables, etc instantiated object will need
 * @method init
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.init = function ()
{
	if(this.app.getModel().StateCurrentUserInterfaceModeGet() === this.app.constants.UI_MODE_LANDING)
	{
		//trace('MPT - init() - returning because in UI_MODE_LANDING');
		return;
	}
	try
	{
		//STEP: Get the gallery and retain it
		this.gallery = PhotosToArtCore.getModel().GalleryForPhotosToArtGet();
		trace('MPT INIT - got gallery with ' + this.gallery.galleryItems.length + ' items');
		
		//STEP: Create ComponentUserImage objects from imageVoArray
		this.userImageArray = this.createComponentUserImageArray(this.gallery);
		
		//STEP: For now, assign the template markup here, in the init()
		var markup = this.getTemplate();
		$(this.target.target).html(markup);
		
		//STEP: New - trying to add the UserImages into the jCarousel
		this.loadUserImages();
		
		//STEP: Assign callbacks and register events
		this.assignCallbacksAndEvents(this.userImageArray);
		
		//STEP: Bind events that do not require access to their object for closures
		this.bindOneTimeEvents();
	
		//STEP: Make sure the image is visible in the carousel
		this.showImageInCarousel();
		
		//STEP: Bind my own events
		this.registerEvents();
		
		//TODO: Make changes to existing code to support new data model
		this.checkForLowResolution();
		
		//STEP: Show tooltip and grey out Add Photos if user has max images
		this.enforceMaximumPhotos();
		
		//STEP: Set logic flag
		this.initialized = true;
	}
	catch(err){trace('Error in mpt.init() ' + err.message);}
		
};
com.art.photosToArt.modules.ModulePhotoTray.prototype.carousel_callback = function(carousel, state)
{
	//trace('---------------initializing carousel reference');
	com.art.photosToArt.modules.ModulePhotoTray.carousel = carousel;
};
/**
 * Loads userimages into the carousel
 * @method loadUserImages
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.loadUserImages = function()
{
	var _this = this;
	if(this.userImageArray.length === 0)
	{
		return;
	}
	
	//NOTE: jCarousel expects the first item to have index of 1, not zero.
	$('#p2a_mpt_photos_ul').jcarousel({
		size: this.userImageArray.length
		, scroll:1
		, itemFallbackDimension: 180
		, initCallback: _this.carousel_callback
	  });
	
	var carousel = '#' + this.markupUtil.getPrefix() + 'photos_ul';
	var markup = new String();
	
	for (var i = 0; i < this.userImageArray.length; i++)
	{
		try
		{
			markup = this.userImageArray[i].render();
			var carousel = $(carousel);
			if(carousel.length === 0)
			{
				alert("Carousel is undefined");
			}
			$(carousel).jcarousel('add', i + 1, markup);
		}
		catch(err)
		{
	        this.app.logError(err);
		}
	}
};
/**
 * Processes cases where user image has low resolution
 * @method checkForLowResolution
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.checkForLowResolution = function()
{
	
	
	//TODO: if nothing has low resolution, make sure to return everything to a normal state
	// This maybe needs to be added to a delete image handler 
	var hasLowRes = false;
	var _this = this;
	var prefix = this.markupUtil.getPrefix();
	var lowResRollover = '#' + prefix +  'photoresrollover';
	var lowResNormal =  '.' + prefix +  'lowreserrormsg';
	var learn = '.' + prefix + 'learnmore';
	var lowResOuterDiv = '.' + prefix + 'lowresouter_div'; 
	var showRolloverFlag = prefix + 'showMptRollover';
	
	for(var x = 0; x < this.userImageArray.length; x++)
	{
		if(this.userImageArray[x].imageData.isLowRes)
		{
			//NOTE: show the low res message and its rollover verion in red
			hasLowRes = true;
			break;
		}
	}
	if(hasLowRes)
	{
		// Turn on the PhotoTray level low res message and rollover
		$(lowResOuterDiv).show();
		$(lowResOuterDiv).removeClass('hidden');
		
		// Add module level handler for rollovers
		$('.lowres').live('mouseover', function(){
			$(lowResRollover).show();
			$(lowResNormal).hide();
			$(learn).hide();
		});
		$('.lowres').live('mouseout', function(){
			$(lowResRollover).hide();
			$(lowResNormal).show();
			$(learn).show();
		});
		
		var popupData = {
							  html:_this.getLowResLearnMoreTemplate()
							, title:_this.app.getString("Low_Resolution_Images") 
							, zindex:2000
							, height:'220'
							, width:'500'
							, padding:'10px 10px'
						};
		//NOTE: Bind click to the learn more link
		$('#' + this.markupUtil.getName('learnmoreimageissue')).live('click', function(){
			var messageBox = new com.art.photosToArt.components.ComponentMessagingLightbox(popupData,_this.app);
			messageBox.render();
			$('#ComponentMessagingLightbox').center(true);
		});
	}
};
/**
 * @method getLowResLearnMoreTemplate
 * @returns {String}
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.getLowResLearnMoreTemplate = function()
{
	var user = this.app.getModel().user;
	var doConvertToCm = com.art.core.utils.LocalizationManager.determineConvertToCm(user.countryIso, user.currencyIso, user.languageIso);
	var template = '<div style="color: #4C3327;font-family: Georgia,"Times New Roman",Times,serif;font-size: 17px;line-height: 150%;">'
		+ '<p><strong>' + this.app.getString('I received a warning "One or more of my photos has a problem." What are my options?') + '</strong>'
		+ '<div>' + this.app.getString("For the best quality artwork, use the highest resolution your camera can handle.") + '</div>' 
		+ '<div>' + this.app.getString("The higher the resolution, the larger you can print the image. If your resolution is too low, you will see a warning when you upload. We warn you if we think there is a possibility that the image might not print at the highest quality.") + '</div></p>'
		+ '<div>' + this.app.getString("For the best results, please reference our guidelines below:") + '</div>' 
		+ '<div style="padding-bottom:10px;">'
		+     '<ul>'
		+          '<li>' + this.app.getString("Upload TIFF or JPEG files") + '</li>'
		+          '<li>' + this.app.getString("We do not allow any uploads of images that are less than 500KB") + '</li>'
		+          '<li>' + this.app.getString("Please follow the optimal resolution for each canvas size we offer:") + '</li>'
		+     '</ul>'
		+     '<br />'
		+     '<table  class="lowresdiv" border="1px solid black" align="center" cellpadding="5">'
		+          '<tr>'
		+             '<th>' + this.app.getString("Size") + '</th>'
		+             '<th>' + this.app.getString("Minimum") + '</th>'
		+             '<th>' + this.app.getString("Optimal") + '</th>'
		+          '</tr>'
		+          '<tr>'
		+             '<td>' + com.art.core.utils.StringUtil.formatDimensions(8,10,doConvertToCm) + '</td>'
		+             '<td> 1375x1625 </td>'
		+             '<td> 2750x3250 </td>'
		+         '</tr>' 
		+         '<tr>'
		+            '<td>' + com.art.core.utils.StringUtil.formatDimensions(11,14,doConvertToCm) + '</td>'
		+            '<td> 1750x2125 </td>'
		+            '<td> 3500x4250 </td>'
		+         '</tr>' 
		+         '<tr>'
		+            '<td>' + com.art.core.utils.StringUtil.formatDimensions(16,20,doConvertToCm) + '</td>'
		+            '<td> 1900x2300 </td>'
		+            '<td> 4750x5750 </td>'
		+         '</tr>' 
		+         '<tr>'
		+            '<td>' + com.art.core.utils.StringUtil.formatDimensions(18,24,doConvertToCm) + '</td>'
		+            '<td> 2100x2700 </td>'
		+            '<td> 5250x6750 </td>'
		+         '</tr>' 
		+ '</div>'
		+ '</div>';
		
	return template;
	
};
/**
 * @method getTemplate
 * @returns {String}
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.getTemplate = function()
{

	//STEP: Get the markup from the ComponentUserImages
	//Changing this to try to support jCarousel - which needs to programmatically add the images
	var markup = this.getMarkupFromImages(this.userImageArray);
	
	//STEP: Get the raw string for the template
	var populatedTemplate = this.template;
	
	//STEP: Assign the module name
	populatedTemplate = populatedTemplate.replace('$NAME', this.markupUtil.getModuleId());
	
	//STEP: Do other text replacements
	populatedTemplate = populatedTemplate.replace(/\[NAME_BASE\]/gi, this.markupUtil.getPrefix(this) );
	populatedTemplate = populatedTemplate.replace(/\[IMAGE_BASEURL\]/gi, this.IMAGE_BASEURL );
	populatedTemplate = populatedTemplate.replace(/\[traytitlebar\]/gi, this.markupUtil.getGenericClassName('traytitlebar') );
	populatedTemplate = populatedTemplate.replace(/\[sorrytext\]/gi,this.app.getString('Sorry,_one_or_more_photos_has_a_problem._Please_delete_it_and_try_another_photo.'));
	populatedTemplate = populatedTemplate.replace(/\[select_your_photos\]/gi, this.app.getString('select_your_photos'));
	populatedTemplate = populatedTemplate.replace(/\[Add_More_Photos\]/gi, this.app.getString('Add_More_Photos'));
	populatedTemplate = populatedTemplate.replace(/\[sorryproblem\]/gi, this.app.getString('Sorry, one or more photos has a problem. Please delete it and try another photo.'));
	populatedTemplate = populatedTemplate.replace(/\[Learn_More\]/gi, this.app.getString('Learn_More'));
	populatedTemplate = populatedTemplate.replace(/\[photo_not_high_enough\]/gi, this.app.getString('This_photo_does_not_have_a_high_enough_resolution_to_be_printed._Please_delete_or_select_another_photo.'));
	populatedTemplate = populatedTemplate.replace(/\[EXPAND\]/gi, this.app.getString('expand'));
	populatedTemplate = populatedTemplate.replace(/\[COLLAPSE\]/gi, this.app.getString('collapse'));
	populatedTemplate = populatedTemplate.replace(/\[WARNING\]/gi, this.app.getString('warning'));
	
	//STEP: Put the UserImage markup into the PhotoTray container
	populatedTemplate = populatedTemplate.replace(/\[UserImages\]/gi, markup);
	
	//STEP: Now return the string (template)
	return populatedTemplate;
	return returnValue.replace('$NAME', this.NAME.toLowerCase());
	
};
/**
 * Defines the template markup for the ModulePhotoTray
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.template = '<div id="$NAME">'
	+ '<div class="[traytitlebar] cpointer" id="[NAME_BASE]titlebar">'
	+ '	<div class="[NAME_BASE]barcontent  [NAME_BASE]learnmorealign">'
	+ '		<img style="float:left" title="[IMAGE_BASEURL]1.png" alt="[IMAGE_BASEURL]1.png" src="[IMAGE_BASEURL]1.png">'
	+ '		<span class="[NAME_BASE]headtext">[select_your_photos]</span>'
	+ '	</div>'
	+ '	<div class="[NAME_BASE]arrow_div">'
	+ '		<img title="[EXPAND]" alt="[EXPAND]" src="[IMAGE_BASEURL]expand.png" class="[NAME_BASE]expand_img hidden">'
	+ '		<img title="[COLLAPSE]" alt="[COLLAPSE]" src="[IMAGE_BASEURL]collapse.png" class="[NAME_BASE]collapse_img">'
	+ '	</div>'
	+ '	<div id="[NAME_BASE]addimages_div" class="[NAME_BASE]addimages_div" style="white-space:nowrap;">'
	+ '		<div style="float:left" class="[NAME_BASE]addphotos_txt cpointer" id="show-panel">+ [Add_More_Photos]</div>'
	+ ' 		<span id="[NAME_BASE]nomorephotosimage" style="display:none;float:left"">'
	+ '				<img  src="[IMAGE_BASEURL]info_off.png" id="addMorePhotosInActiveMoreInfo" />'
	+ '			</span>'
	+ '		</div>'
	+ '</div>'

	+ '<div class="[NAME_BASE]lowresouter_div hidden">'
	+ '		<div class="floatleft">'
	+ '			<img title="[WARNING]" alt="[WARNING]" src="[IMAGE_BASEURL]warning.gif">'
	+ '		</div>'
	+ '		<div style="width:500px;float:left;" class="[NAME_BASE]lowreserrormsg [NAME_BASE]learnmorealign">[sorryproblem]</div>'
	+ '		<div style="width:150px;float:left;padding-top:6px;text-decoration:underline;" class="[NAME_BASE]learnmore cpointer" id="[NAME_BASE]learnmoreimageissue">[Learn_More] &gt;</div>'
	+ '		<div id="[NAME_BASE]photoresrollover" style="padding-left: 10px;padding-top: 4px;font-family: ITC New Baskerville, Times New Roman;font-size: 14px;font-style: italic;color:#FFFFFF;background-color:#990000;display:none">[photo_not_high_enough]</div>'
	+ '</div>'
	+ '<div class="clear"></div>'

	+ '<div class="[NAME_BASE]photos_outer_div">'
	+ '		<ul class="jcarousel-skin-tango" id="[NAME_BASE]photos_ul" style="width: 789px; left: 0px; visibility: visible;">'
	+ '		</ul>'
	+ '</div>			'
	+ '<div class="clear"></div>'
	+ '</div>'
	+ '</div>';
/**
 * @method getDeleteConfirmationTemplate
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.getDeleteConfirmationTemplate = function(){
	var template = '<div class="delpop" id="[NAME_BASE]delpop" style="[TOP-LEFT]">'
	+ ' <div id="[NAME_BASE]deleteconfirmpopup" style="background: none repeat scroll 0 0 #FFFFFF;left: 0;position: absolute;top: 0;z-index: 2000;display: block;position: absolute;'
    + '     border: 1px solid #727C73;min-width: 288px;" >'
	+ '		<div id="[NAME_BASE]deleteconfirmtitlebar" class="cPointer" style="height:30px;padding-top:5px;width:100%;vertical-align:middle;">'               
	+ '    		<div class="p2a_matc_lightboxtitle" style="float:left;cursor:pointer;padding-left: 10px;">[delete_photos_confirm]</div>'
	+ '    <div id="[NAME_BASE]closeimgdeletepopup" style="float:right;cursor:pointer;padding-right: 10px;">'
	+ '        <img title="close" src="[IMAGE_BASEURL]close.png" alt="close">'
	+ '    </div>'
	+ '    <div class="clear"></div>'
	+ '</div>'
	+ '<div class="clear"></div>'
	+ '<div class="[NAME_BASE]DeleteContent">'
	+ '    <div class="[NAME_BASE]delete_txt" style="color: #535353;font-family: Verdana;font-size:11px;line-height:20px;margin-top:25px;margin-left:69px;#margin-left:0px;text-align:center;width:150px;">[Are_you_sure_you_want_to_delete_this_photo]</div>'
	+ '    <div class="[NAME_BASE]delete_btn_container" style="margin-left: 20px;margin-top: 20px;">'
	+ '        <div class="[NAME_BASE]btn_delete_confirm" style="float:left;margin-right: 10px;margin-bottom:10px;cursor:pointer;">'
	+ '             <div id="[NAME_BASE]btndelpopconf" class="[NAME_BASE]deleteconfirmbutton [NAME_BASE]dbn_gold cpointer"'
	+ '					onmouseover="$(\'#[NAME_BASE]btndelpopconf\').removeClass(\'[NAME_BASE]dbn_gold\').addClass(\'[NAME_BASE]dbn_blue\'); "'
	+ '					onmouseout="$(\'#[NAME_BASE]btndelpopconf\').removeClass(\'[NAME_BASE]dbn_blue\').addClass(\'[NAME_BASE]dbn_gold\'); "'
	+				'>'
	+ '					<div style="padding: 5px;text-transform: uppercase;text-align: center;display: block;">[DELETE]</div>'
	+ '        		</div>'
	+ '	  	   </div>'
	+ '        <div style="float:left;cursor:pointer;">'
	+ '             <div id="[NAME_BASE]btndelpopcancel" class="[NAME_BASE]deletecancelbutton  [NAME_BASE]dbn_grey " style="cursor:pointer;width:110px;"'
	+ '					onmouseover="$(\'#[NAME_BASE]btndelpopcancel\').removeClass(\'[NAME_BASE]dbn_grey\').addClass(\'[NAME_BASE]dbn_blue\'); "'
	+ '					onmouseout="$(\'#[NAME_BASE]btndelpopcancel\').removeClass(\'[NAME_BASE]dbn_blue\').addClass(\'[NAME_BASE]dbn_grey\'); "'
	+				'>'
	+ ' 				<div style="padding: 5px;text-transform: uppercase;text-align: center;display: block;">[CANCEL]</div>'
	+ '				</div>'
	+ '			</div>'
	+ ' 	    <div style="clear:both"></div>'
	+ '    </div>'
	+ '</div>'
	+ '</div></div>';
	
	template = template.replace(/\[NAME_BASE\]/gi, this.markupUtil.getPrefix(this) );
	template = template.replace(/\[TOP-LEFT\]/gi, this.createTopLeftForPopup() );
	template = template.replace(/\[delete_photos_confirm\]/gi, this.app.getString('delete_photos?') );
	template = template.replace(/\[Are_you_sure_you_want_to_delete_this_photo\]/gi, this.app.getString('Are_you_sure_you_want_to_delete_this_photo?'));
	template = template.replace(/\[DELETE\]/gi, this.app.getString('DELETE') );
	template = template.replace(/\[CANCEL\]/gi,  this.app.getString('CANCEL') );
	template = template.replace(/\[IMAGE_BASEURL\]/gi, this.IMAGE_BASEURL );

	return template;
};
/**
 * @method createTopLeftForPopup
 * @returns {String}
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.createTopLeftForPopup = function(){
	
	var top = (Math.max($(document).height(), $(window).height(),/* For opera: */document.documentElement.clientHeight) / 2) - 125;
	var left = (Math.max($(document).width(), $(window).width(), /* For opera: */document.documentElement.clientWidth) / 2 ) - 144;
	return 'top:' + top + 'px;left:' + left + 'px;';
};
com.art.photosToArt.modules.ModulePhotoTray.prototype.isLowResolution = function(sizes)
{
	// Even a 21x21px image gets 1 size for each service type.
	// If they only have 1, and it's warning = true, then it's low res.

		var textResult = "Unknown";
		var hasSizeWithoutWarning = false;
		
		for(var service in sizes)
		{
			if(service === "__type")
				continue;
			
			// These are the service-specific objects
			for(var x = 0; x < sizes[service].length;x++)
			{
				if (sizes[service][x].Warning === "False")
				{
					hasSizeWithoutWarning = true;
					break;
				}	
			}
			if(hasSizeWithoutWarning)
			{
				break;
			}
		}
		return !hasSizeWithoutWarning;
};
/**
 * @method createComponentUserImageArray
 * @param imageVos
 * @returns {Array}
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.createComponentUserImageArray = function(gallery)
{
	//NOTE: Need to manage mapping between this module and its CUI children
	//STEP: Iterate over imageVos, creating ComponentUserImage objects, rendering out their markup
	var galleryItems = gallery.galleryItems;
	if(galleryItems.length === 0)
	{
		return new Array();
	}
	var userImageArray = new Array(galleryItems.length);
	var i = 0;
	this.maxImageCount = galleryItems.length;

	//NOTE: pass markupUtil instance in - trying to keep CUI as dumb and template-like as possible
	var markupUtil = this.app.getMarkupUtil().getInstance(com.art.photosToArt.components.ComponentUserImage.NAME);
	var item = {};
	var isLowRes = false;
	for (; i < this.maxImageCount; i++)
	{
		isLowRes = false;
		item = galleryItems[i].Item;
		isLowRes = this.isLowResolution(galleryItems[i].AvailableSizes);
		var dimensions = galleryItems[i].Item.ImageInformation.Original.Dimensions;
		
		// If landscape, provide the image height based on aspect ratio * 160px OR if not landscape pass zero as boolean flag because vertical centering OK with non-landscape.
		thumbHeight = dimensions.Width > dimensions.Height ? Math.round((dimensions.Height / dimensions.Width) * 160) : 160; 
		userImageArray[i] = new com.art.photosToArt.components.ComponentUserImage(
				item.ImageInformation.MediumImage.HttpImageURL
				, item.ImageInformation.ZoomImage ? item.ImageInformation.ZoomImage.HttpImageURL : item.ImageInformation.LargeImage.HttpImageURL
				, gallery.galleryId
				, galleryItems[i].GalleryItemId
				, item.Sku
				, isLowRes
				, this.markupUtil
				, thumbHeight
				, this.app.getModel().user.languageIso
				, this.app.getEnvironment().imagePath);	
	}
	
	return userImageArray;
};

com.art.photosToArt.modules.ModulePhotoTray.prototype.getComponentByImageGuid = function(imageGuid)
{
	var rightImage = {};
	for(var i = 0; i < this.userImageArray.length; i++)
	{
		try
		{
			if(this.userImageArray[i].imageData.imageGuid == imageGuid)
			{
				this.imageReturnIndex = i + 1;
				rightImage = this.userImageArray[i];
				break;
			}
		}
		catch(err){trace('Error in getComponentByImageGuid: ' + err.message);}
	}
	return rightImage;
};

/**
 * @method getMarkupFromImages
 * @param userImages
 * @returns {String}
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.getMarkupFromImages = function(userImages)
{
	var markup = new String();
	var i = 0;
	
	for (; i < this.maxImageCount; i++)
	{
		markup += userImages[i].render();
	}
	
	return markup;
};
/**
 * Creates and provides implementation for callbacks passed to UserImages which are the children of this object
 * @method assignCallbacksAndEvents
 * @param userImages
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.assignCallbacksAndEvents = function(userImages)
{
	for (var i = 0; i < this.maxImageCount; i++)
	{
		this.attachBehaviors(userImages[i]);
	}
};
com.art.photosToArt.modules.ModulePhotoTray.prototype.bindOneTimeEvents = function()
{
	// Logic here is to work with the AppProxy.updateSelectedItemWorkflow() method to make the item that was in the 
	//    shopping cart selected when user returns from shopping cart
	try
	{
		var selectedImageGuid = this.app.getModel().SelectedImageGuidGet();
		if(this.userImageArray.length > 0)
		{
			if(selectedImageGuid != null & selectedImageGuid != undefined)
			{
				var userImage = this.getComponentByImageGuid(selectedImageGuid);
				userImage.bindOneTimeEvents();
			}
			else
			{
				this.userImageArray[0].bindOneTimeEvents();
			}
		}
	}
	catch(err){trace('Error in MPT.bindOneTimeEvents: ' + err.message );}
};
com.art.photosToArt.modules.ModulePhotoTray.prototype.showImageInCarousel = function()
{
	trace('MPT.showImageInCarousel - ' + this.app.getModel().getGalleryItemCount() + ' items');
	if(this.app.getModel().getGalleryItemCount() === 0)
	{
		return false;
	}
	var selectedImageGuid = this.app.getModel().SelectedImageGuidGet();
	var userImage = this.getComponentByImageGuid(selectedImageGuid);
	
	// Scroll the image into view if it's not in view (viewer holds 4 images)
	if(this.imageReturnIndex > 4)
	{
		try
		{
			//trace('----------------trying to scroll');
			com.art.photosToArt.modules.ModulePhotoTray.carousel.scroll(this.imageReturnIndex - 3, true);
		}
		catch(err)
		{
			trace('--------------------scroll image failed');
		}
	}
	this.imageReturnIndex = 0;
};
com.art.photosToArt.modules.ModulePhotoTray.prototype.attachBehaviors = function(userImage)
{
	var _this = this;
	
	userImage.registerCallback(com.art.photosToArt.components.ComponentUserImage.USER_IMAGE_CLICK, function(userImage)
	{
		_this.notify(new com.art.core.utils.Note(PhotosToArtCore.events.USERIMAGE_CLICKED, { imageGuid: userImage.imageData.imageGuid },'vo'));
	});
	userImage.registerCallback(com.art.photosToArt.components.ComponentUserImage.IMAGE_ZOOM, function(userImage)
	{
		_this.app.getGoogleAnalytics().trackEvent('ThumbZoom');
		_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.SHOW_SUPER_ZOOM,{imageUrl:userImage.imageData.zoomUrl},""));
		
		//We prevented a click on the image itself (no update to Hero was needed), now re-enable that image click
		$('.p2a_cui_outer_div').each(function(){
			if($(this).hasClass('NO_SELECT'))
			{
				var newThis = $(this);
				window.setTimeout(function(){
					newThis.removeClass('NO_SELECT');
				}, 1000);
			}
		});
	});
	userImage.registerCallback(com.art.photosToArt.components.ComponentUserImage.USER_IMAGE_DELETE, function(userImage)
	{
			// NOTE: First, we show the delete confirmation.
			// Then, actual deletion occurs after the confirmation has been clicked
		
			//STEP: 1 -- Show the delete confirmation
			var name = _this.markupUtil.getPrefix(_this) + 'deleteconfirmpopup';
			var thisLightBox = new com.art.core.components.LightBox('LightBox','body', 0.4);
			thisLightBox.show();
			
			$('#LightBox').after(_this.getDeleteConfirmationTemplate());
			$('#' + name).show();
			
			var delPopHeight = 180;
			try
			{
				delPopHeight = $('#p2a_mpt_deleteconfirmpopup').height();
			}catch(err){trace('Delete Popup: ' + err.message);}
			$('#p2a_mpt_delpop').centerWithHeight(true, delPopHeight); 
			
			// Make sure the dialog sits on top of the lightbox
			var lightboxZ = parseInt($('#p2a_mpt_delpop').css('z-index')) - 1;
			$('#LightBox').css('z-index', lightboxZ);
			
			
			//STEP: 2 -- Setup the deletion confirmation
			var deleteButton = '#' + _this.markupUtil.getName('btndelpopconf');
			var cancelButton = '#' + _this.markupUtil.getName('btndelpopcancel');
			var cancelButton2 = '#' + _this.markupUtil.getName('closeimgdeletepopup');
			$(deleteButton).unbind();
			$(deleteButton).click( function(event) {

				// Allow this method to come off the stack and return false - allows DOM to remove element with jquery callback
				setTimeout(function(){_this.deleteNotification(userImage)}, 100);
				
				// Prevent UserImageClicked event
				event.stopPropagation();
				return false;
				
			});
			$(cancelButton + ',' + cancelButton2).live('click', function(){
				var outerImageDivSelector = '#p2a_cui_guid_' + userImage.imageData.imageGuid;
				$(outerImageDivSelector).removeClass('DELETE');
				$(outerImageDivSelector).removeClass('NO_SELECT');
				_this.cleanUpAfterDeletePopup();
			});
			
			// UserImage was not clicked, really
			return false;
	});
	userImage.registerEvents();
};
com.art.photosToArt.modules.ModulePhotoTray.prototype.deleteNotification = function(userImage)
{
	var model = this.app.getModel();
	var currentSelectedImageGuid = model.SelectedImageGuidGet();
	PhotosToArtCore.sendNotification(new com.art.core.utils.Note(
			PhotosToArtCore.events.GALLERY_REMOVE_ITEM, 
			{ 
				Sku: userImage.imageData.imageGuid
				, CurrentSelectedImageGuid: currentSelectedImageGuid
				, GalleryId: userImage.imageData.galleryId
				, GalleryItemId: userImage.imageData.galleryItemId 
				, apiKey: model.application.apiKey
				, sessionId: model.user.sessionId
				, authToken: model.user.authenticationToken
			},'vo'));
	this.cleanUpAfterDeletePopup();
};
/**
 * Removes the confirmation popup for deleting an image
 * @method cleanUpAfterDeletePopup
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.cleanUpAfterDeletePopup = function()
{
	$('#LightBox').empty();
	$('#LightBox').remove();
	$('.delpop').unbind();
	$('.delpop').empty();
	$('.delpop').remove();
};
/**
 * @method registerEvents
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.registerEvents = function()
{
	var _this = this;
	var prefix = this.markupUtil.getPrefix(this);
	var titleBar = '#' + this.markupUtil.getName('titlebar'); 
	var _this = this;
	$(titleBar).die("click");
	$(titleBar).unbind("click");
	
	$(titleBar).live('click', function(event) {
		
		if($(this).hasClass('suppressToggle'))
		{
			return false;
		}
    	//NOTE: hide the main photo tray. Only show the title bar.
		$('.' + prefix + 'photos_outer_div').slideToggle("slow", function(){});
		var divHeight = $('.' + prefix + 'photos_outer_div').height();
        event.stopPropagation();
        event.cancelBubble = true; //for IE

        if (divHeight < 50) {
            $('.' + prefix + 'collapse_img').show();
            $('.' + prefix + 'expand_img').hide();
        }
        else {
        	$('.' + prefix + 'collapse_img').hide();
        	$('.' + prefix + 'expand_img').show();
        }
	});
	$('.' + prefix + 'addimages_div').unbind();
	$('.' + prefix + 'addimages_div').live('click', function(event){
		_this.app.GATrackPageView('/p2a/upload-photos/loaded');
		
		// Need to prevent the toggling off this add photos click.
		$('#' + _this.markupUtil.getName('titlebar')).addClass('suppressToggle');
		var fileMax = _this.calculateFileCountMax();
		
		if(fileMax <= 0)
		{
			// Disable the click when user has max images
			return false;
		}
		
		_this.app.GATrackPageView('/p2a/create/add-more-photos');
		
		var lightbox = new com.art.core.components.LightBox('uploadLightbox','body', 0.2);
        lightbox.render();
        
		if(_this.app.getModel().objectPropertyCount(com.art.photosToArt.modules.ModulePhotoTray.flashUploader) === 0)
		{	
			com.art.photosToArt.modules.ModulePhotoTray.flashUploader = new com.art.photosToArt.modules.ModuleUpload({
				resourceRoot: _this.app.getEnvironment().imagePath + '/images/photostoart/'
				,persistentId: _this.app.getModel().user.persistentId
				,fileCountMaximum: fileMax
				,application: _this.app
				,applicationMode: 'application'
	
			});
		}
		try
		{
			com.art.photosToArt.modules.ModulePhotoTray.flashUploader.render(_this.calculateFileCountMax());
		}
		catch(err)
		{
			_this.app.logError(err);
		}
	
		setTimeout(function(){
			$('#' + _this.markupUtil.getName('titlebar')).removeClass('suppressToggle');
		}, 800);
	});
	
	$('.sizeArrow, .sizeTextBox').live('click', function(event) {
	    if ($('.sizeOptions li').length > 0) {
	        $('.sizeOptions').slideToggle("slow");
	    }
	    event.stopPropagation();
	    event.cancelBubble = true; //for IE 
	});
	 
	if(!$.browser.msie)
	{
		$('.jcarousel-skin-tango .jcarousel-next-horizontal').css('right', '-16px');
	}
};
com.art.photosToArt.modules.ModulePhotoTray.prototype.enforceMaximumPhotos = function()
{ 
	var _this = this;
	var tooltipname = 'nomorephotos';
	var pre = this.markupUtil.getPrefix(this);
	if(this.calculateFileCountMax() <= 0)
	{
		$('.' + pre + 'addphotos_txt').css({'color':'#AAAAAA','cursor':'auto'});
		$('#' + pre +  'nomorephotosimage').show();
		$('#' + pre +  'nomorephotosimage').live('mouseover', function(e)
	    {
	        toolTipContent = _this.getMaxImagesToolTip();
	        toolTipObj = new com.art.core.components.ToolTip(tooltipname);
	        var offset = $(this).offset();
	        relativeX = offset.left + 30;
	        relativeY = offset.top - 20;
	        toolTipObj.setToolTip(toolTipContent.title, toolTipContent.message); 
	        toolTipObj.render(relativeX, relativeY);
	        
	        // Remove any tooltips after 2 seconds
	        setTimeout(function(){$('[id ^=' + tooltipname + ']').empty().remove();}, 5000);
	    });
	}
};

com.art.photosToArt.modules.ModulePhotoTray.prototype.getMaxImagesToolTip = function()
	{
	    var returnValue = {title:' ', message:' '};
	    returnValue.title =" ";
	    var maxImages = this.app.getEnvironment().maxPhotosPerUser;
	    //NOTE: Because of a translation key issue, the key below has the numeral 10 hard coded.  But the value in translation has [MAX_IMG_COUNT].  Must follow thru by replacing both.
	    var msg = this.app.getString("You can only have a maximum of 10 images. Please delete images in order to upload more.");
	    
	    msg = msg.replace("[MAX IMG COUNT]", maxImages).replace("10",maxImages).replace("[MAX_IMG_COUNT]", maxImages);
	    
	    returnValue.message = ''
	       + '<div id="p2a_tooltip_container" style="background:white;width:160px;" src="' + this.IMAGE_INFO_OFF + '">' 
	       +  	'<img  class="p2a_tooltip_leftarrow" src="' + this.IMAGE_ARROW + '" />'                
	       +    '<div style="padding:10px 10px 10px 10px ;">' + msg + '</div>'
	       +    '<div class="clear"></div>'
	       + '</div>';
	    	    
	    return returnValue;
}; 

com.art.photosToArt.modules.ModulePhotoTray.prototype.createDelegate = function (object, method)
{
    var shim = function()
    {
        method.apply(object, arguments);
    };

    return shim;
};
com.art.photosToArt.modules.ModulePhotoTray.prototype.calculateFileCountMax = function()
{
	// Get the configurable maximum images number
	// Subtract the current number of images
	var max = 10;
	var gCount = 0;
	try{max = this.app.getEnvironment().maxPhotosPerUser;}catch(err){}
	try{gCount = this.app.getModel().getGalleryItemCount();}catch(err){}
	return parseInt(max) - parseInt(gCount);
};
com.art.photosToArt.modules.ModulePhotoTray.prototype.notify = function(note)
{
	this.app.sendNotification(note);
};

/**
 * @method getTarget
 * @returns
 */
com.art.photosToArt.modules.ModulePhotoTray.prototype.getTarget = function()
{
	return this.moduleData.target;
};

