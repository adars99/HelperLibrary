//CONSTRUCTOR: instantiates the instance, Every Object must implement the base
com.art.photosToArt.modules.ModuleServiceTray = function(data,app)
{
	this.app 		= app;
	this.moduleData = data;
	this.NAME		= com.art.photosToArt.modules.ModuleServiceTray.NAME;
	this.instance	= this;
	this.IMAGE_BASEURL = PhotosToArtCore.getEnvironment().imagePath;
	this.markupUtil = this.app.getMarkupUtil().getInstance(this);
	this.lightBox = {};
};
com.art.photosToArt.modules.ModuleServiceTray.NAME = "ModuleServiceTray";
com.art.photosToArt.modules.ModuleServiceTray.IMAGE_SUBFOLDER = "/images/photostoart/";
com.art.photosToArt.modules.ModuleServiceTray.IMAGE_NUMBER_TWO = "2.png";

com.art.photosToArt.modules.ModuleServiceTray.prototype.getTemplate = function ()
{
	//NOTE: Init is where you initialize the handlers for this module and any variables, etc instantiated object will need
	return this.template;
};

com.art.photosToArt.modules.ModuleServiceTray.prototype.getTarget = function ()
{
	//NOTE: Init is where you initialize the handlers for this module and any variables, etc instantiated object will need
	return this.moduleData.target;
};

com.art.photosToArt.modules.ModuleServiceTray.prototype.getLearnMoreDetails = function(popupTarget) 
{	
	    this.app.registerModule(new com.art.photosToArt.modules.ModuleHelp({"target":'#'+popupTarget}, this.app));
		this.app.startModule("ModuleHelp");

		//STEP 2: Render the Help Module -- This happens for the button click and can happen at anytime throughout the app
		this.app.getModule("ModuleHelp").render("photocanvases");
		this.app.getModule("ModuleHelp").registerEvents();
};

com.art.photosToArt.modules.ModuleServiceTray.prototype.init = function ()
{
	var _this = this;
	$(this.getTarget()).html(this.getTemplate());
    
	//COMPONENT: ServiceTrayTabs - Instantiate -----------------------------------------------------------------------------------------------------------
	this.componentServiceTrayTabs = new com.art.photosToArt.components.ComponentServiceTrayTabs(
			this.filterServices(this.app.getModel().data.serviceTypesAvailable), this.app.getModel().data.serviceTypes,this.app);

	//COMPONENT: ServiceTrayTabs: Attach component here
	if (this.componentServiceTrayTabs.getTabsCount() > 1)
		$('#' + this.markupUtil.getName("tabholder")).html(this.componentServiceTrayTabs.render());
	
	//COMPONENT: ServiceTrayTabs - register external events, must occur after scroll component is initialized
	this.componentServiceTrayTabs.registerCallback('tabclick', function(tabHtmlElement){
		
		var model = _this.app.getModel();

	 	if(!$(tabHtmlElement).hasClass(_this.componentServiceTrayTabs.ClassNameForSelectedTab) && !$(tabHtmlElement).hasClass(_this.componentServiceTrayTabs.ClassNameForInactiveTab))
		{
	 		var selectedItemServiceAsString = $(tabHtmlElement).attr('serviceid');
	 		//STEP: ALWAYS use the below method to get the itemService object and always speak of the itemService in terms of these objects and not by strings!
	 		var selectedItemService = _this.getItemServiceInformationByString(selectedItemServiceAsString, model.data.serviceTypesAvailable);

	 		if(selectedItemService == undefined || selectedItemService == "")
	 			throw new Error("ModuleServiceTray failed! selectedItemService is undefined.");
		 	
	 		//STEP: RULE: Check for Prev Canvas...if There is a Canvas service type selected before and this is a selected Canvas Service now, override with prev selected canvas service
	 		try
	 		{
    	 		if (_this.app.getModel().isServiceACanvasService(selectedItemService))
    	 		{
    	 		    if (_this.app.getModel().isServiceACanvasService(_this.app.getModel().state.selectedItemServiceSubType.canvas))
    	 		    {
    	 		        selectedItemService = _this.app.getModel().state.selectedItemServiceSubType.canvas;
    	 		    }
    	 		    
    	 		}
	 		}
	 		catch(err)
	 		{
	 		    _this.app.logError(err);
	 		}
		 	_this.app.getModel().SelectedItemServiceSet(selectedItemService);
		 	
	 		var requestParameters = new com.art.photosToArt.vos.UserImageChangeRequestVo(_this.app.getModel());
            _this.notify(new com.art.core.utils.Note(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS, requestParameters, 'vo'));
		}
	 		 		
	}); 
	
	//STEP: Set the default service: This is coming from an environment variable, call the method of the component which will protect against bad inputs
	var defaultTab;

	if (this.app.getModel().SelectedItemServiceGet() == undefined || this.app.getModel().SelectedItemServiceGet().name == undefined)
	{
		defaultTab = this.componentServiceTrayTabs.getTabByConfigurationValue(this.app.getEnvironment().serviceDefault);
	}
	else
	{
		defaultTab = this.componentServiceTrayTabs.getTabByConfigurationValue(this.app.getModel().SelectedItemServiceGet().name);
	}
	this.componentServiceTrayTabs.selectTab(defaultTab);
	
	this.registerEvents();
	
	//remove pointer cursor from header; not collapsable
	var n = this.NAME.toLowerCase();
	$("#"+n+">div").css("cursor","default");
	
};
com.art.photosToArt.modules.ModuleServiceTray.prototype.getItemServiceInformationByString = function(serviceAsString, itemServiceTypeCollectionObject)
{
    if ((/canvasmw|canvasmuseum|mw/gi.test(serviceAsString)) && itemServiceTypeCollectionObject.canvasMuseum !== undefined)
        return itemServiceTypeCollectionObject.canvasMuseum;
    else if ((/canvasgw|canvasgallery|gw/gi.test(serviceAsString)) && itemServiceTypeCollectionObject.canvasGallery !== undefined)
        return itemServiceTypeCollectionObject.canvasGallery;
    else if ((/framing/gi.test(serviceAsString)) && itemServiceTypeCollectionObject.framing !== undefined)
        return itemServiceTypeCollectionObject.framing;
    else if ((/mounting/gi.test(serviceAsString)) && itemServiceTypeCollectionObject.mounting !== undefined)
        return itemServiceTypeCollectionObject.mounting;
    else if ((/acrylic/gi.test(serviceAsString)) && itemServiceTypeCollectionObject.acrylic !== undefined)
        return itemServiceTypeCollectionObject.acrylic;
    else if ((/printonly/gi.test(serviceAsString)) && itemServiceTypeCollectionObject.printOnly !== undefined)
        return itemServiceTypeCollectionObject.printOnly;
    else
        //TODO: might need a more meaningful default here.
        return undefined;
};
com.art.photosToArt.modules.ModuleServiceTray.prototype.registerEvents = function()
{
	var _this = this; 
	$('.p2a_mst_learnmore').live('click', function()
	{
		_this.notify(new com.art.core.utils.Note(_this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/photocanvasfaq'},'vo'));
	});
};	

com.art.photosToArt.modules.ModuleServiceTray.prototype.selectedItemServiceIsCanvas = function(itemServiceName)
{
	trace("selectedItemServiceIsCanvas: "+itemServiceName);
	// Get the service from the name
	var itemService = {};
	var serviceList = this.app.getModel().data.serviceTypes;
	for(var svc in serviceList)
	{
        if(typeof this.serviceList[svc] == "object")
        {
    		if(svc.toLowerCase() === itemServiceName.toLowerCase())
    		{
    			itemService = serviceList[svc];
    			break;
    		}
        }
	}
	
	// See if it's canvas
	return PhotosToArtCore.getModel().isServiceACanvasService(itemService);
};

com.art.photosToArt.modules.ModuleServiceTray.prototype.filterServices = function(servicesAvailable)
{
	// deep clone
	var filteredList = jQuery.extend(true, {}, servicesAvailable);
	if(filteredList.canvasGallery !== undefined && filteredList.canvasMuseum !== undefined)
	{
		// Remove one of them. Need a clone of the object first
		delete filteredList.canvasGallery;
	}
	
	return filteredList;
};
com.art.photosToArt.modules.ModuleServiceTray.prototype.destroy = function()
{
	//NOTE: Destroy is where you destroy this object and clean up memory
	
};

com.art.photosToArt.modules.ModuleServiceTray.prototype.notify = function(note)
{
	//NOTE: 
	this.app.sendNotification(note);
};

com.art.photosToArt.modules.ModuleServiceTray.prototype.listNotificationInterests = function()
{
	//trace(this.NAME + ' listNotificationInterests');
	return [
	];
};

com.art.photosToArt.modules.ModuleServiceTray.prototype.handleNotification = function(note)
{
	//trace('MST.handleNotfication (no handlers): ' + note.name);
};

com.art.photosToArt.modules.ModuleServiceTray.prototype.getTemplate = function()
{
	
	//STEP: Get the raw string for the template
	var returnValue = this.template;
	//STEP: Replace the [IMAGE_DOMAIN] placeholder with the imagePath value
	returnValue = returnValue.replace(/\[IMAGE_DOMAIN\]/gi, this.IMAGE_BASEURL);
	//STEP: Replace any strings that require access to separate function calls
	
	//NOTE: traytitlebar is generic across modules
	returnValue = returnValue.replace(/\[TITLEBARCLASS\]/gi, this.markupUtil.getGenericClassName('traytitlebar') );
	returnValue = returnValue.replace(/\[TITLEBARCONTENTCLASS\]/gi, this.markupUtil.getName('titlebarcontent',this.markupUtil.buttonStates.ACTIVE));
	returnValue = returnValue.replace(/\[TITLEBARCONTENT2\]/gi,	this.IMAGE_BASEURL +  com.art.photosToArt.modules.ModuleServiceTray.IMAGE_SUBFOLDER	+  com.art.photosToArt.modules.ModuleServiceTray.IMAGE_NUMBER_TWO);
	returnValue = returnValue.replace(/\[TITLEBARCONTENTNUMBERTWO\]/gi, this.markupUtil.getName('number2',this.markupUtil.buttonStates.ACTIVE));
	returnValue = returnValue.replace(/\[TITLEBARTEXT\]/gi, this.markupUtil.getName('titlebartext',this.markupUtil.buttonStates.ACTIVE));
	returnValue = returnValue.replace(/\[LEARNMORE\]/gi, this.markupUtil.getName('learnmore',this.markupUtil.buttonStates.ACTIVE));
	
	//STEP: Replace strings that are phrases for translation
	returnValue = returnValue.replace(/\[TEXT_CHOOSE_OPTIONS\]/gi, this.app.getString('choose_your_options'));
	returnValue = returnValue.replace(/\[TEXT_LEARN_MORE\]/gi, this.app.getString('Learn_More_&gt;'));

	//STEP: Now return the string (template)
	returnValue = returnValue.replace("[TABS_HOLDER]", this.markupUtil.getName("tabholder"));
	//alert("it is not broken");
	
	//alert(returnValue);
	returnValue = returnValue.replace('$NAME', this.NAME.toLowerCase());
	return returnValue;
	
};

com.art.photosToArt.modules.ModuleServiceTray.prototype.template = '<div id="$NAME">'
+ ' <div class="[TITLEBARCLASS]">'
+ '		 <div class="[TITLEBARCONTENTCLASS]">'
+ '			  <img class="[TITLEBARCONTENTNUMBERTWO]" title="" alt="" src="[TITLEBARCONTENT2]" style="float:left">'
+ '			  <span class="[TITLEBARTEXT]">[TEXT_CHOOSE_OPTIONS]</span>'
+ '		 </div>'
+ '		 <div class="[LEARNMORE]">[TEXT_LEARN_MORE]</div>'
+ '      <div style="clear:both"></div>'
+ ' </div>'
+ '      <div id="[TABS_HOLDER]"></div>'
+ '      <div style="clear:both">'
+ '      </div>'
+ '</div>';

