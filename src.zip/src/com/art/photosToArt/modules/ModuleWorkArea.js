//CONSTRUCTOR: instantiates the instance, Every Object must implement the base
com.art.photosToArt.modules.ModuleWorkArea = function(data, app)
{
    this.app 			= app;
    this.moduleData 	= data;
    this.NAME 			= com.art.photosToArt.modules.ModuleWorkArea.NAME;
    this.heroImage;
    this.superZoomZIndex = -1;
    this.superZoom;
    this.spinner;
    this.lightbox;
    this.Modes =
    {
        LEFT : 'leftmode',
        RIGHT : 'right'
    };
    this.priceDetailsModal;
    this.detailsGrid; //simple table for showing price details
    this.currentMode = this.Modes.LEFT;

    this.instance = this;
    this.IMAGE_INFOBOX_CANVAS = this.app.getEnvironment().imagePath
            + '/images/photostoart/servicedetail/canvas_detail.gif';
    this.IMAGE_INFOBOX_CANVAS_WRAP = this.app.getEnvironment().imagePath
            + '/images/photostoart/servicedetail/canvaswrap_detail.gif';
    this.IMAGE_INFOBOX_ACRYLIC = this.app.getEnvironment().imagePath
            + '/images/photostoart/servicedetail/acrylic_detail.gif';
    this.IMAGE_INFOBOX_WOODMOUNTING = this.app.getEnvironment().imagePath
            + '/images/photostoart/servicedetail/mounting_detail.gif';
    this.IMAGE_INFOBOX_PRINT_ONLY = this.app.getEnvironment().imagePath
            + '/images/photostoart/servicedetail/print_only_detail.gif';

};
com.art.photosToArt.modules.ModuleWorkArea.NAME = "ModuleWorkArea";
com.art.photosToArt.modules.ModuleWorkArea.prototype.getTemplate = function()
{
    return this.template;
};
com.art.photosToArt.modules.ModuleWorkArea.prototype.getTarget = function()
{
    return this.moduleData.target;
};

com.art.photosToArt.modules.ModuleWorkArea.prototype.updateInterfaceByModel = function()
{
    //trace('MWA.updateInterfaceByModel() TOP');
    var _this = this;
    var model = this.app.getModel();
    // STEP: When init is called, this module will look into the cache and
    // attempt to load itself with cache data
    var selectedImageGuid = this.app.getModel().SelectedImageGuidGet();
    var selectedImage = this.app.getModel().getGalleryItemByImageGuid(selectedImageGuid);
    var selectedItemService = this.app.getModel().SelectedItemServiceGet();

    // COMPONENT: Hero Image
    var image = this.app.getModel().SelectedItemServiceImageGet();
    var data = {
    	'urls' : {
    	'imageUrlLarge' : image.HttpImageURL
        ,'imageUrlZoom' : image.HttpImageURL
    	}
    
    	, 'translatedContent' : {
         'Zoom' : this.app.getString("Zoom")
    	}
    };
    
    if(!this.heroImage)
    {
    	this.heroImage = new com.art.photosToArt.components.ComponentHeroImage("p2aHeroImage", data, this.app.getEnvironment().imagePath,this.app.getEnvironment().enableSharingTools);
    	$('#heroimagecomponent').html(this.heroImage.render());    	
    	this.heroImage.registerEvents(this);
    	this.heroImage.registerCallback(com.art.photosToArt.components.ComponentHeroImage.IMAGE_ZOOM,function(){
        	//_this.app.GATrackEvent('HeroImageZoom-'+ _this.app.getModel().SelectedItemServiceGet().itemServiceCode);
    		_this.app.GATrackPageView('/p2a/create/preview');
        	_this.showSuperZoom(_this.heroImage.getZoomImageUrl().replace("MXW:400+MXH:700", "MXW:1024+MXH:1024"));
        });
    	this.heroImage.registerCallback(com.art.photosToArt.components.ComponentHeroImage.IMAGE_LOADED,function(){
    		_this.hideSpinner();
    	});
    }
    else
    {
    	this.heroImage.setUrls(data.urls);
    	this.hideSpinner();
    }
    this.heroImage.updateHeroImage();
    
    
    // COMPONENT: InfoBox - Instantiate
    // -----------------------------------------------------------------------------------------------------------
    if(selectedItemService.name !== model.data.serviceTypes.framing.name)
    {
	    var classNamePrefix = this.app.getMarkupUtil().getInstance("ComponentServiceTrayInfo").getPrefix();
	
	    // Service Description - Component ServiceTray Info goes here
	    var infoBoxContent = this.getServiceInfoContent(selectedItemService);
	    var componentServiceInfoBox = new com.art.photosToArt.components.ComponentServiceTrayInfo(classNamePrefix, this.app.getEnvironment().imagePath);
	    componentServiceInfoBox.setContent(infoBoxContent.title,infoBoxContent.image, infoBoxContent.message);
	    $('#p2a_infobox').html(componentServiceInfoBox.render());
	    componentServiceInfoBox.registerEvents(this);
    }
    else
    {
    	$('#componentservicetrayinfo').hide();
    }
};
com.art.photosToArt.modules.ModuleWorkArea.prototype.showSuperZoom = function(img)
{
	if(this.superZoomZIndex ==-1)
	{
		var tmp = new com.art.core.components.LightBox("p2aLightBox","body","0.4");
		tmp.setLightBoxZIndex();
		this.superZoomZIndex = tmp.getLightBoxZIndex();
		delete tmp;
		this.superZoom 		= new com.art.core.components.SuperZoom("p2aSuperZoom",this.superZoomZIndex + 1);
		this.superZoom.registerEvents();
	}
	
	//get size
	var zWidth, zHeight;

    if (typeof window.innerWidth != 'undefined') {	    
        zWidth = window.innerWidth;
        zHeight = window.innerHeight;
    }
    else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
        //IE 6+ in 'standards compliant mode' 
    
        zWidth = document.documentElement.clientWidth;
        zHeight = document.documentElement.clientHeight;
    }
	trace("show super zoom: "+img);
	var zoomUrlImage = com.art.core.utils.BrowserUtil.getCroppedImageUrl(img,zWidth, zHeight, com.art.core.utils.BrowserUtil.cropperModes.NONE);
	trace("zoomUrlImage: "+zoomUrlImage);
	
	
	//var zoomWidth = $()
	this.superZoom.show(zoomUrlImage);
};
com.art.photosToArt.modules.ModuleWorkArea.prototype.init = function()
{
    $(this.getTarget()).html(this.getTemplate());
};
com.art.photosToArt.modules.ModuleWorkArea.prototype.getServiceInfoContent = function(itemService)
{
    var returnValue =
    {
        title : '',
        image : '',
        message : ''
    };
    switch (itemService.name)
    {
        case this.app.getModel().data.serviceTypes.canvasGallery.name:
            returnValue.title = this.app.getString("about canvas");
            returnValue.image = '<div class="p2a_csti_infoboxtop">'
                    + '<img border="0" alt="" src="'
                    + this.IMAGE_INFOBOX_CANVAS_WRAP + '" />' + '</div>';
            returnValue.message = '<div class="p2a_csti_infoboxbottom">'
                    + '<div style="line-height: 16px; padding-bottom: 10px;">'
                    + this.app.getString("Creating canvas prints of your photos is an elegant way to preserve your memories.")
                    + '</div>'
                    + '<ul class="p2a_csti_infoboxbottomUL">'
                    + '<li class="p2a_csti_infoboxbottomLI">'
                    + this.app.getString("Gicl&eacute;e printed on artist-grade cotton canvas")
                    + '</li>'
                    + '<li class="p2a_csti_infoboxbottomLI">'
                    + this.app.getString("UV coated acrylic finish to protect the image from fading, dust and moisture")
                    + ' </li>'
                    + '<li class="p2a_csti_infoboxbottomLI">'
                    + this.app.getString("Image is extended to cover the edges of the canvas for a polished look")
                    + ' </li>'
                    + '<li class="p2a_csti_infoboxbottomLI">'
                    + this.app.getString("1 1/2'' wooden support bars create a finished look that allows you to hang without a frame")
                    + ' </li>'
                    + '</ul>'
                    + '<div class="clear"></div>'
                    + '<div style="padding-top: 10px;">'
                    + this.app.getString("Your image will be cropped to fit the dimensions of the canvas size you choose.")
                    + ' </div>' + '</div>';
            break;
        case this.app.getModel().data.serviceTypes.canvasMuseum.name:
            returnValue.title = this.app.getString("about canvas");
            returnValue.image = '<div class="p2a_csti_infoboxtop">'
                    + '<img border="0" alt="" src="'
                    + this.IMAGE_INFOBOX_CANVAS + '" />' + '</div>';
            returnValue.message = '<div class="p2a_csti_infoboxbottom">'
                    + '<div style="line-height: 16px; padding-bottom: 10px;">'
                    + this.app.getString("Creating canvas prints of your photos is an elegant way to preserve your memories.")
                    + '</div>'
                    + '<ul class="p2a_csti_infoboxbottomUL">'
                    + '<li class="p2a_csti_infoboxbottomLI">'
                    + this.app.getString("Gicl&eacute;e printed on artist-grade cotton canvas")
                    + '</li>'
                    + '<li class="p2a_csti_infoboxbottomLI">'
                    + this.app.getString("UV coated acrylic finish to protect the image from dust moisture and fading")
                    + ' </li>'
                    + '<li class="p2a_csti_infoboxbottomLI">'
                    + this.app.getString("Museum Wrap finished with hand painted black edges to provide a clean look from front, side, and back")
                    + ' </li>'
                    + '<li class="p2a_csti_infoboxbottomLI">'
                    + this.app.getString("1 1/2'' wooden support bars create a finished look that allows you to hang without a frame")
                    + ' </li>'
                    + '</ul>'
                    + '<div class="clear"></div>'
                    + '<div style="padding-top: 10px;">'
                    + this.app.getString("Your image will be cropped to fit the dimensions of the canvas size you choose.")
                    + ' </div>' + '</div>';

            break;
        case this.app.getModel().data.serviceTypes.mounting.name:
            returnValue.title = this.app.getString("Wood Mounting");
            returnValue.image = '<img src="' + this.IMAGE_INFOBOX_WOODMOUNTING + '" />';
            returnValue.message = '<div class="p2a_csti_infoboxbottom">'
                    + '<div style="line-height: 16px; width:235px;">'
                    + this.app.getString("Mounted prints are a unique and elegant way to feature your favorite photos. Our wood mounting process permanently bonds images to a 1/4 inch thick piece of stabilized hardboard. The surface is treated to protect against moisture, dust, dirt, fingerprints, and protects against UV comparable to standard glass. A keyhole slot is used for hanging finished sizes of 8 x 10 or smaller. Larger items will be supplied with a wire hanger. The mount is braced in the back with a 1 cm strip of wood so as to lift your print off the wall.")
                    + '</div>' + '</div>';
            break;
        case this.app.getModel().data.serviceTypes.acrylic.name:
            returnValue.title = this.app.getString("about acrylic");
            returnValue.image = '<img src="' + this.IMAGE_INFOBOX_WOODMOUNTING + '" />';
            returnValue.message = '<div class="p2a_csti_infoboxbottom">'
                    + this.app.getString("Art on Acrylic adds a contemporary and modern look to any room. The image is digitally printed on archival quality photographic paper and mounted to 1/4'' flame edged acrylic, creating a translucent quality and unique visual statement. This process maximizes image clarity, crispness and quality that is unmatched in the marketplace. Brushed nickel standoff mounting hardware is provided to add depth to the finished product.")
                    + '</div>';
            break;
        case this.app.getModel().data.serviceTypes.printOnly.name:
            returnValue.title = this.app.getString("About print");
            returnValue.image = '<img src="' + this.IMAGE_INFOBOX_PRINT_ONLY + '" />';
            returnValue.message = this.app.getString("Our photographic prints are true photographic prints; they leverage sophisticated digital technology capturing the true essence of photography. The level of detail is absolutely stunning - colors are vivid and pure, with resolution far beyond that of any inkjet, at an apparent 4,000 dots per inch! These prints are worthy of home, museum, or gallery displays.");
            break;

    }
    return returnValue;
};
com.art.photosToArt.modules.ModuleWorkArea.prototype.showSpinner = function()
{
    var _this = this;
	if(this.lightbox == null)
	{
		this.lightbox = new com.art.core.components.LightBox("p2a_lightbox_comp","body",0);
		this.lightbox.setLightBoxZIndex(this.superZoomZIndex);
		this.spinner	= new com.art.core.components.Spinner("body");
	}
	else
	{
	    this.lightbox.changeOpacity(0);
	}
	this.spinner.alterDefaultSize(200,130);
	this.spinner.setMessage(this.app.getString("loading"));
	
	this.lightbox.show();
	this.spinner.show(this.lightbox.getLightBoxZIndex() + 1);
	this.spinner.appendOuterShadow();
	
	//STEP: Set timeout to darken background
	setTimeout(function(){_this.lightbox.changeOpacity(0.05);}, 3000);
};



com.art.photosToArt.modules.ModuleWorkArea.prototype.hideSpinner = function()
{
	this.lightbox.close();
	this.spinner.hide();
};

com.art.photosToArt.modules.ModuleWorkArea.prototype.destroy = function()
{
    // NOTE: Destroy is where you destroy this object and clean up memory
};

com.art.photosToArt.modules.ModuleWorkArea.prototype.notify = function()
{
    // NOTE:
    this.app.sendNotification(note);
};

com.art.photosToArt.modules.ModuleWorkArea.prototype.listNotificationInterests = function()
{
    return [this.app.events.RELOAD_USER_INTERFACE,
            this.app.events.SHOW_PRICE_DETAILS_MODAL,
            this.app.events.IMAGE_UPDATE_AND_GET_RESULTS,
            this.app.events.FRAME_UPDATE_MOULDING,
            this.app.events.SHOW_SUPER_ZOOM
           ];
};

com.art.photosToArt.modules.ModuleWorkArea.prototype.getTemplate = function()
{
    // STEP: Get the raw string for the template
    var returnValue = this.template;
    // STEP: Replace the [IMAGE_DOMAIN] placeholder with the imagePath value
    returnValue = returnValue.replace(/\[IMAGE_DOMAIN\]/gi, this.imagePath);
    // STEP: Now return the string (template)
    return returnValue.replace('$NAME', this.NAME.toLowerCase());
};

com.art.photosToArt.modules.ModuleWorkArea.prototype.getTarget = function()
{
    return this.moduleData.target;
};

com.art.photosToArt.modules.ModuleWorkArea.prototype.handleNotification = function(note)
{
    //trace('MWA.handleNotfication: ' + note.name);
	var _this = this;
    switch (note.name)
    {
        case this.app.events.RELOAD_USER_INTERFACE:
            this.updateInterfaceByModel();
            //this.hideSpinner();
            break;
        case this.app.events.FRAME_UPDATE_MOULDING:
        case this.app.events.IMAGE_UPDATE_AND_GET_RESULTS:
        	this.showSpinner();
        	break;
        case this.app.events.SHOW_PRICE_DETAILS_MODAL:
        	//if(this.priceDetailsModal == undefined)
        	//{
        		this.priceDetailsModal = new com.art.core.components.BaseModal("priceDetailsModal",550,"#FFFFFF",true,false);
        		this.priceDetailsModal.skin = com.art.core.components.BaseModal.APC_SKIN;
        	//}
        	if(this.detailsGrid == undefined)
        		this.detailsGrid = new com.art.core.components.GridDisplay("p2a_priceDetails_grid",500,2);
        	
        	
        	
        	
        	var item = this.app.getModel().SelectedGalleryItemGet().Item;
        	
        	
        	this.priceDetailsModal.setContents(this.getPriceDetails(item));
        	
        	
        	
        	setTimeout(function(){
        		_this.populatePriceDetailsGrid(item);
        		_this.priceDetailsModal.registerButton("p2a_price_detail_modal_btn", com.art.core.components.ArtButton.APC_RED, _this.app.getString(_this.app.getModel().EnVarLabelAddToCartButtonEnglishGet()), function(btn){
        			_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.DUPLICATE_FRAME_FOR_CART,{},'vo'));
        			btn.disable();
            	},com.art.core.components.ArtButton.ARROW_RIGHT);
        		//NOTE: Below is a quick fix to button beginning with upper case
        		_this.priceDetailsModal.registerButton("p2a_price_detail_modal_btn_close", com.art.core.components.ArtButton.APC_BLUE, _this.app.getString("cancel"), function(){
            		_this.priceDetailsModal.close();
            		_this.lightbox.close();
            		
            	});
        		_this.priceDetailsModal.registerEvents();
        		
        		$(".buttonBarTemplate").css("padding","5px");
        	},50);
        	
        	this.lightbox.show();
        	this.priceDetailsModal.registerCallback(com.art.core.components.BaseModal.CLOSE_CLICKED,function(){
        		_this.lightbox.close();
        	});
        	
        	$("body").append(this.priceDetailsModal.render(this.lightbox.getLightBoxZIndex()+1));
        	//add background tile
        	$("#"+this.priceDetailsModal.id).css({
        		"background-image":"url('http://cache1.allpostersimages.com/images/coreimages/tiles/modal_background_tile_apc.gif')",
        		"background-repeat":"repeat-x",
        		"background-position":"0px 0px"
        	});
        	if($.browser.msie && ($.browser.version).indexOf("7") == 0)
        		$("#baseExtend>div").css("marginTop","-27px");
        	
        	break;
        case this.app.events.SHOW_SUPER_ZOOM:
        	this.showSuperZoom(note.body.imageUrl);
        	break;
        default:

            // do nothing
    }
};


com.art.photosToArt.modules.ModuleWorkArea.prototype.populatePriceDetailsGrid = function(item)
{
	
	if(item == undefined || item.Service == undefined || item.Service.Frame == undefined)
		throw new Error("ModuleWorkArea.populatePriceDetailsGrid failed! Required item is undefined.");
	//details
	var d = item.Service.Frame;
	
	this.detailsGrid.addRow({columns:[{value:this.app.getString("Print_Price"),textAlign:"left",bold:true,color:"#000000"},{value:item.Service.Frame.PrintPrice.DisplayPrice,textAlign:"right",bold:true,color:"#000000"}],rowBackgroundColor:"#FFFFFF",useEllipse:true});
	
	//STEP: The Molding Item in the Item Object may not be translated, get the name from Molding inventory
    var molding = this.app.getModel().getMouldingByMouldingId(d.Moulding.ItemNumber);
    var moldingName = d.Moulding.Name;
    if (molding != undefined && molding.Name != undefined)
        moldingName = molding.Name;
    
	if(d.Moulding.Price != null)
		this.detailsGrid.addRow({columns:[{value:moldingName+" ("+this.app.getString("Frame")+")",textAlign:"left",bold:true,color:"#000000"},{value:d.Moulding.Price.DisplayPrice,textAlign:"right",bold:true,color:"#000000"}],rowBackgroundColor:"#FFFFFF",useEllipse:true});
		
	if(d.TopMat.Price != null)
		this.detailsGrid.addRow({columns:[{value:this.app.getString("Top_Mat")+" ("+d.TopMat.Name+")",textAlign:"left",bold:true,color:"#000000"},{value:d.TopMat.Price.DisplayPrice,textAlign:"right",bold:true,color:"#000000"}],rowBackgroundColor:"#FFFFFF",useEllipse:true});
	if(d.MiddleMat.Price != null)
		this.detailsGrid.addRow({columns:[{value:this.app.getString("Middle_Mat")+" ("+d.MiddleMat.Name+")",textAlign:"left",bold:true,color:"#000000"},{value:d.MiddleMat.Price.DisplayPrice,textAlign:"right",bold:true,color:"#000000"}],rowBackgroundColor:"#FFFFFF",useEllipse:true});
	if(d.BottomMat.Price != null)
		this.detailsGrid.addRow({columns:[{value:this.app.getString("Bottom_Mat")+" ("+d.BottomMat.Name+")",textAlign:"left",bold:true,color:"#000000"},{value:d.BottomMat.Price.DisplayPrice,textAlign:"right",bold:true,color:"#000000"}],rowBackgroundColor:"#FFFFFF",useEllipse:true});
	if(d.Glass.Price != null)
		this.detailsGrid.addRow({columns:[{value:d.Glass.Name,textAlign:"left",bold:true,color:"#000000"},{value:d.Glass.Price.DisplayPrice,textAlign:"right",bold:true,color:"#000000"}],rowBackgroundColor:"#FFFFFF",useEllipse:true});
	if(d.FittingFee.DisplayPrice != null)
		this.detailsGrid.addRow({columns:[{value:this.app.getString("Fitting_Fee"),textAlign:"left",bold:true,color:"#000000"},{value:d.FittingFee.DisplayPrice,textAlign:"right",bold:true,color:"#000000"}],rowBackgroundColor:"#FFFFFF",useEllipse:true});
	
	this.detailsGrid.addRow({columns:[{value:"",textAlign:"left",bold:true,color:"#000000"},{value:"",textAlign:"right",bold:true,color:"#000000"}],rowBackgroundColor:"#FFFFFF",useEllipse:false});
	
	this.detailsGrid.addRow({columns:[{value:"",textAlign:"left",bold:true,color:"#000000"},{value:this.app.getString("Your_Total")+" : "+item.ItemPrice.DisplayPrice+" ",textAlign:"right",bold:true,color:"#000000"}],rowBackgroundColor:"#FFFFFF",useEllipse:false});
	
	
	

};
com.art.photosToArt.modules.ModuleWorkArea.prototype.getPrintPrice = function(frameDetails,total)
{
	trace("total: "+total);
	if(frameDetails.TopMat.Price != undefined)
		total -= frameDetails.TopMat.Price.Price;
	if(frameDetails.MiddleMat.Price != undefined)
		total -= frameDetails.MiddleMat.Price.Price;
	if(frameDetails.BottomMat.Price != undefined)
		total -= frameDetails.BottomMat.Price.Price;
	if(frameDetails.FittingFee.Price != undefined)
		total -= frameDetails.FittingFee.Price;
	if(frameDetails.Glass.Price != undefined)
		total -= frameDetails.Glass.Price.Price;
	if(frameDetails.Moulding.Price != undefined)
		total -= frameDetails.Moulding.Price.Price;
	
	
	return Math.round(total*100)/100;
};
com.art.photosToArt.modules.ModuleWorkArea.prototype.getPriceDetails = function(item)
{	
	var timeToShip = this.app.getModel().SelectedItemTimeToShipTextGet(this.app.getModel().SelectedItemPodConfigIdGet());
	var user = this.app.getModel().user;
	var doConvertToCm = com.art.core.utils.LocalizationManager.determineConvertToCm(user.countryIso, user.currencyIso, user.languageIso);
	var dimensions = com.art.core.utils.StringUtil.formatDimensions(item.Service.Frame.FrameSummary.PhysicalDimensionsRounded.Width, item.Service.Frame.FrameSummary.PhysicalDimensionsRounded.Height, doConvertToCm);   
	
	var template ="<div style='marging-left:5px; margin-right:5px;padding:5px;width:500px;text-align:left;'>"+
		"<div style='width:430px;text-align:left;'>"+
		"<div style='padding:7px; color:#000000;font-size:12px;text-align:left;width:430px;'><b>"+this.app.getString("Price_Details")+"</b></div>"+
		"<div style='text-align:center;'><br/>"+this.app.getString("Framed_Size")+": "+dimensions+" | "+this.app.getString("Ship_Time")+" "+timeToShip+"</div>"+
		"<div style='padding:10px;text-align:left;'>$TABLE</div>"+
		"</div>"+
	"</div>";
	return template.replace("$TABLE",this.detailsGrid.getTemplate());
	
};
com.art.photosToArt.modules.ModuleWorkArea.prototype.template = '<div id="$NAME" style="margin-top:0px;background-color:white;padding: 10px 20px 20px;">'
        + '<div id="ChooseImageTabLeft" style="width:400px;float:left;" >'
        + '<div style="float:left" id="heroimagecomponent"></div>'
        + '</div>'
        + '<div id="ChooseImageTabRight" style="float:right;margin-left:10px; width:275px">'
        + '<div id="p2a_ms_taboptions"></div>'
        + '<div id="p2a_ms_addtocart"></div>'
        + '<div id="p2a_infobox"></div>'
        + '</div>' + '<div style="clear:both"></div>' + '</div>'
		+ '<div id="p2a_ms_mats_moulding"></div>';
