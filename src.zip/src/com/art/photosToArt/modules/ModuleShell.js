/**
 * The ModuleShell is where the app starts.  This initializes the app, the user, the galleries, and then loads in
 * the other modules.
 * @constructor 
 * @param data
 * @param app
 */
com.art.photosToArt.modules.ModuleShell = function(data,app)
{
    this.app         = app;
    this.moduleData = data;
    this.NAME        = com.art.photosToArt.modules.ModuleShell.NAME;
    this.instance    = this;
    this.markupUtil = this.app.getMarkupUtil().getInstance(this);
    this.isInline = this.moduleData.inline;
};
com.art.photosToArt.modules.ModuleShell.NAME = "ModuleShell";

com.art.photosToArt.modules.ModuleShell.prototype.init = function ()
{
    //trace('======(ModuleShell - Init)======');
    //WELCOME!!!: Welcome to the new P2A...,it all starts here, get the key from the cookie and lookup the user and take it from there
    var cookieHelper = new com.art.core.cookie.Cookie();
    var p2aKey = cookieHelper.getCookieDictionary
    (
            this.app.constants.P2A_COOKIE_DICTIONARY_PERSISTENT
            , this.app.constants.COOKIE_NAME_P2AKEY
     );
    
    //STEP: Extra opportunity: we will also take a p2aKey from the environment if one was passed, will allow partners to implement the p2aKey any way they wish
    if (p2aKey === undefined || p2aKey.length == undefined || p2aKey.length == 0)
    {
        p2aKey = this.app.getEnvironment().p2aKey;
    }    

    //CONDITION: The p2aKey must be an Int as it is the Uid for the persistentId..set value to blank string if isNan
    if (isNaN(p2aKey))
        p2aKey = '';
    
    this.registerEvents();
    
    //CONDITION: p2akey, with or without, it is time to start session, call InitializeApi...
    var apiKey = this.app.getEnvironment().apiKey;
    var applicationId = this.app.getEnvironment().applicationId;
    var countryCode = this.app.getEnvironment().countryCode;
    var languageIso = this.app.getEnvironment().languageIso;
    this.notify(new com.art.core.utils.Note(this.app.events.INITIALIZE_API,{'apiKey':apiKey,'persistentId':p2aKey, 'applicationId': applicationId,'countryCode':countryCode,'languageIso':languageIso},'vo'));

};

com.art.photosToArt.modules.ModuleShell.prototype.registerEvents = function()
{
    var _this = this;
    
    $('#id-button-home-upload').live('click', function(){
        if (_this.app.getModel() != undefined && _this.app.getModel().initializeGet() == false)
            _this.openUploader();
        else
            alert("App is still loading.  Try again in a few seconds.");
    });
    $('#id-button-home-loadimage').live('click', function(){
        if (_this.app.getModel() != undefined && _this.app.getModel().initializeGet() == false)
        {
            // User already has images and wants to see the application
        
            //_this.app.getModel().StateCurrentUserInterfaceModeSet(_this.app.constantsUI_MODE_APPLICATION);
            var itemCount = _this.app.getModel().getGalleryItemCount();
            _this.notify(new com.art.core.utils.Note(_this.app.events.LOAD_USER_INTERFACE,{itemCount:itemCount},'vo'));
        }
        else
            alert("App is still loading.  Try again in a few seconds.");
    });
};

com.art.photosToArt.modules.ModuleShell.prototype.openUploader = function()
{
    var _this = this;
    //trace('User clicked Image Upload from HomePage');
    var lightboxId = 'uploadLightbox';
    var lightbox = new com.art.core.components.LightBox(lightboxId,'body', 0.2);
    lightbox.render();
    var z = $('#' + lightboxId).css('z-index');
    $('#FlashUploaderTarget').css('z-index', z+1);
    var fileMax = parseInt(_this.app.getEnvironment().maxPhotosPerUser);
    var uploader = new com.art.photosToArt.modules.ModuleUpload({
         postTo: _this.app.getEnvironment().serviceUrlImageUpload
        ,resourceRoot: _this.app.getEnvironment().imagePath + '/images/photostoart/'
        ,onCompleteUrl: ''
        ,persistentId: _this.app.getModel().user.persistentId
        ,fileCountMaximum: fileMax
        ,application: _this.app
        ,applicationMode: 'landing'
    }); 
    uploader.render();
    
    // to made the uploader to be centered
    $('#uploader_flashPopup').hide();
    setTimeout(function(){
        $('#uploader_flashPopup').center(true);
        $('#uploader_flashPopup').show();
    }, 100);
    
    //_this.app.GATrackEvent(_this.app.getEnvironment().gaPartnerCode + ' UPLOAD ' + com.art.core.tracking.GoogleAnalytics.prototype.getDelimiter() + ' LOADED');
	this.app.GATrackPageView('/p2a/upload-photos/loaded');
    return false;
};

com.art.photosToArt.modules.ModuleShell.prototype.determineCurrentMode = function(itemCount)
{
	var goToWorkArea = this.app.getEnvironment().startMode.toLowerCase() === "workarea";
	var isFromCart = $.trim(document.location.search).length > 0;
	var isInitializing = this.app.getModel().initializeGet() && !isFromCart;
	var hasItems = itemCount > 0;
	
	//trace('goToWorkArea:' + goToWorkArea + ', isInitializing:' + isInitializing + ', hasItems:' + hasItems);
    if (hasItems && (goToWorkArea || !isInitializing))
    {
        //trace('======== determineCurrentMode says APPLICATION');
        this.app.getModel().StateCurrentUserInterfaceModeSet(this.app.constants.UI_MODE_APPLICATION);
    }
    else
    {
        //trace('======== determineCurrentMode says LANDING');
        this.app.getModel().StateCurrentUserInterfaceModeSet(this.app.constants.UI_MODE_LANDING);
    }
};
com.art.photosToArt.modules.ModuleShell.prototype.getUi = function(itemCount)
{
    var _this = this;

    //STEP: Determine the "Mode" here. Read the value below
    this.determineCurrentMode(itemCount);
    
    //NOTE: Init is where you initialize the handlers for this module and any variables, etc instantiated object will need
    //$(this.getTarget()).append(this.getTemplate());
    if (this.app.getModel().StateCurrentUserInterfaceModeGet() == this.app.constants.UI_MODE_APPLICATION)
    {
    	// trace('getUI - APPLICATION MODE - ');
        //this.app.getModel().data.homePageHtml = $(this.getTarget()).html();
        this.app.getModel().cacheHomePageMarkup($(this.getTarget()).html());
    }
    $(this.getTarget()).html(this.getTemplate());
    
    //STEP: If this was not an inline app, then center the app
    if (this.isInline == "false")
    {
        this.center(true);
        $('#' + this.markupUtil.getName("close")).show();
        $('#' + this.markupUtil.getName("close")).bind("click",function()
        {
            _this.notify(new com.art.core.utils.Note(_this.app.events.CLOSE_APP,{},'vo'));
        });
    }
        
    //NOTE: Now depending on the mode we will load sub-modules
    if (this.app.getModel().StateCurrentUserInterfaceModeGet() === this.app.constants.UI_MODE_APPLICATION)
    {
        //SECTION: PhotoTray
        this.app.registerModule(new com.art.photosToArt.modules.ModulePhotoTray({"target":"#"+this.markupUtil.getPrefix()+"photos"},this.app));
        this.app.startModule("ModulePhotoTray");
        
        //SECTION: ServiceTray
        this.app.registerModule(new com.art.photosToArt.modules.ModuleServiceTray({"target":"#"+this.markupUtil.getPrefix()+"services"},this.app));
        this.app.startModule("ModuleServiceTray");
        
        //SECTION: Work Area
        this.app.registerModule(new com.art.photosToArt.modules.ModuleWorkArea({"target":"#"+this.markupUtil.getPrefix()+"working"},this.app));
        this.app.startModule("ModuleWorkArea");
        
        //SECTION: TabOptions
        this.app.registerModule(new com.art.photosToArt.modules.ModuleTabOptions({"target":"#" + this.markupUtil.getPrefix() + "taboptions"}, this.app));
        this.app.startModule("ModuleTabOptions");
        
      //SECTION: framing mats and moulding selector
        //Framing Module
          trace("framing service");
  		this.app.registerModule(new com.art.photosToArt.modules.ModuleFramingService({target:"#" + this.markupUtil.getPrefix() + "mats_moulding"}, this.app));
  		this.app.startModule("ModuleFramingService");
        
        //SECTION: Add To Cart
        this.app.registerModule(new com.art.photosToArt.modules.ModuleAddToCart({"target":"#" + this.markupUtil.getPrefix() + "addtocart"}, this.app));
        this.app.startModule("ModuleAddToCart");
        
        
        
        //SECTION: Uploader
        this.app.registerModule(new com.art.photosToArt.modules.ModuleUpload(this.app));
        this.app.startModule("ModuleUpload");
        
        //NEXT: Get all the item-specific data loaded for the first image:
        //trace('getUI calling UserImage_Clicked');
        //this.notify(new com.art.core.utils.Note(PhotosToArtCore.events.USERIMAGE_CLICKED, { imageGuid: this.app.getModel().SelectedImageGuidGet() },'vo'));
        var requestParameters = new com.art.photosToArt.vos.UserImageChangeRequestVo(this.app.getModel());
        this.notify(new com.art.core.utils.Note(this.app.events.IMAGE_UPDATE_AND_GET_RESULTS, requestParameters, 'vo'));

        //NOTE: This event should only fire when the JS app is loaded
        //this.app.GATrackEvent('PB PHOTOS-TO-ART ' + com.art.core.tracking.GoogleAnalytics.prototype.getDelimiter() + ' LOADED');  // Environment isn't ready when this fires
        this.app.GATrackPageView('/p2a/create/loaded');
        
        //STEP: Raise events to get the content blocks
        var contentBlocks = this.app.getEnvironment().contentBlocks;
        if (contentBlocks.valueBox01 == 'on')
            this.notify(new com.art.core.utils.Note(this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/valueproposition01'},'vo'));
        if (contentBlocks.valueBox02 == 'on')
            this.notify(new com.art.core.utils.Note(this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/valueproposition02'},'vo'));
        if (contentBlocks.valueBox03 == 'on')
            this.notify(new com.art.core.utils.Note(this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/valueproposition03'},'vo'));
        if (contentBlocks.header.application == 'on')
            this.notify(new com.art.core.utils.Note(this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/header_application'},'vo'));
        if (contentBlocks.footer.application == 'on')
            this.notify(new com.art.core.utils.Note(this.app.events.CATALOG_GET_CONTENT,{contentBlockName:'p2a/footer_application'},'vo'));

        
/*        NOTE: The below demonstrates a working method of getting HTML content from an HTTP location using JQuery.getJSON
        $.getJSON(this.app.getEnvironment().sharingContentUrl +'?jsoncallback=?', function(data)
        {
            $('#' + _this.markupUtil.getPrefix() + "share").html(data.htmlsource);
        });
        
        */
    }
    else
    {
        //SECTION: Home Page
        this.app.registerModule(new com.art.photosToArt.modules.ModuleHomePage({"target":"#" + this.markupUtil.getPrefix() + "ModuleHomePage"}, this.app));
        this.app.startModule("ModuleHomePage");
    }
    
    
    //$("#"+this.markupUtil.getModuleId()).css({"position":"absolute","z-index":"1002","background-color":"#FFFFFF"});
};

com.art.photosToArt.modules.ModuleShell.prototype.getFailureUi = function(event)
{
    //NOTE: Init is where you initialize the handlers for this module and any variables, etc instantiated object will need
    $(this.getTarget()).append("<div style='font-size:16px;'>A Failure to an Ajax Call Occurred for Event: " + event + "</div>");
    
    
    $("#"+this.markupUtil.getModuleId()).css({"position":"absolute","z-index":"1002","background-color":"#FFFFFF"});
};

com.art.photosToArt.modules.ModuleShell.prototype.center = function ()
{
    //center app
    $("#"+this.markupUtil.getModuleId()).center(true);
};

com.art.photosToArt.modules.ModuleShell.prototype.destroy = function()
{
    art.core.utils.destroyChildEvents($("#"+this.markupUtil.getModuleId()));
};

com.art.photosToArt.modules.ModuleShell.prototype.close = function()
{
    //NOTE: Close is where you destroy this object and clean up memory
    $("#"+this.markupUtil.getModuleId()).empty();
    $("#"+this.markupUtil.getModuleId()).remove();
};
com.art.photosToArt.modules.ModuleShell.prototype.notify = function(note)
{
    //NOTE: 
    //trace('ModuleShell.notify: ' + note.name);
    this.app.sendNotification(note);
};

com.art.photosToArt.modules.ModuleShell.prototype.listNotificationInterests = function()
{
    return [
        , this.app.events.INITIALIZE_API_FAILURE 
        , this.app.events.AUTHENTICATE_ACCOUNT_FAILURE 
        , this.app.events.CREATE_ACCOUNT_FAILURE
        , this.app.events.GALLERY_GET_BY_USER_FAILURE
        , this.app.events.GALLERY_ADD_FOR_USER_FAILURE
        , this.app.events.GALLERY_GET_FAILURE
        , this.app.events.GALLERY_ADD_ITEM_SUCCESS
        , this.app.events.GALLERY_ADD_ITEM_FAILURE
        , this.app.events.CATALOG_ITEM_GET_VARIATIONS_SUCCESS
        , this.app.events.CATALOG_ITEM_GET_VARIATIONS_FAILURE
        , this.app.events.CATALOG_ITEM_VARIATIONS_GET_MASTER_FAILURE
        , this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS
        , this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_FAILURE
        , this.app.events.LOAD_USER_INTERFACE
        , this.app.events.UPLOAD_COMPLETE
        , this.app.events.UPLOAD_PROCESS_COMPLETE
        , this.app.events.CLOSE_APP
        , this.app.events.GALLERY_REMOVE_ITEM_SUCCESS
        , this.app.events.USERIMAGE_CLICKED
        , this.app.events.CATALOG_GET_CONTENT_SUCCESS
        , this.app.events.CATALOG_GET_CONTENT_FAILURE
        , this.app.events.ADDTOCART_GOTOCART_SUCCESS
        , this.app.events.ADDTOCART_STAY_SUCCESS
        , this.app.events.SHOW_HOMEPAGE
    ];
};

com.art.photosToArt.modules.ModuleShell.prototype.handleNotification = function(note)
{
	var marginLeft;
	var moduleWidth = note.body.moduleWidth; //pass in
	// //trace('MS.handleNotfication: ' + note.name);
	var _this = this;
	switch(note.name)
	{
           
        case this.app.events.SHOW_HOMEPAGE:
            // getUi calls determineCurrentMode Change the app mode
            this.getUi(0);
            break;
        
        case this.app.events.LOAD_USER_INTERFACE:
            var itemCount = note.body.itemCount;
            
            this.getUi(itemCount);
            break;    
            
        case this.app.events.CATALOG_ITEM_GET_VARIATIONS_SUCCESS: 
            if(note.body.Item)
            {
                //trace('SHELL - CATALOG_ITEM_GET_VARIATIONS_SUCCESS ' + note.body.Item.Sku);
                //STEP: Update the cached item with the data from the service call..the function will return TRUE if the update occur
                if(this.app.getModel().updateGalleryItem(note.body))
                {
                    var requestParameters = new com.art.photosToArt.vos.UserImageChangeRequestVo(this.app.getModel());
                    
                    // added by Greg
                    requestParameters.imageGuid = note.body.Item.Sku;
                    this.notify(new com.art.core.utils.Note(this.app.events.IMAGE_UPDATE_AND_GET_RESULTS, requestParameters, 'vo'));
                }
            }            
            break;
            
        case this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS:
            //STEP: Update cache for the affected item 
            if (note.body.Item != undefined && note.body.Item.Sku != undefined)
            {
                if(this.app.getModel().updateGalleryItem(note.body))
                {
                        this.app.getModel().updateStateOfSelectedItem(note.body);
                }
                this.notify(new com.art.core.utils.Note(this.app.events.RELOAD_USER_INTERFACE, {}, 'vo'));
            }
            break;
            
        case this.app.events.GALLERY_ADD_ITEM_SUCCESS: 
            var galleryVo = new com.art.photosToArt.vos.GalleryVo();
            galleryVo.parseGalleryFromServiceResponse(note.body.Gallery);
            this.app.getModel().addGalleryToCache(galleryVo);
            
            //STEP: Assumption: the added item is the last in the list, so get it
            var galleryItem = this.app.getModel().getGalleryItemLastAdded();
            var imageGuid = galleryItem.Item.Sku;
            break;
          
        case this.app.events.GALLERY_REMOVE_ITEM_SUCCESS:
            if(note.body.OperationResponse.ResponseCode === 200)
            {
                var proxy = this.app.getModel();
                // Update the cache. This call clears the existing cache
                var galleryVo = new com.art.photosToArt.vos.GalleryVo();
                
                galleryVo.parseGalleryFromServiceResponse(note.body.Gallery);
                proxy.addGalleryToCache(galleryVo);
                
                // if we have zero items, raise a show homepage event
                if(this.app.getModel().GalleryItemsForPhotosToArtGet().length === 0)
                {
                	// Reload the page - unable to get to homepage any other way. This works, and nothing else does.
                	window.location.reload();
                	// trace('Module Shell:GALLERY_REMOVE_ITEM_SUCCESS - going to homepage');
                    //this.notify(new com.art.core.utils.Note(this.app.events.SHOW_HOMEPAGE, {}, 'vo'));
                }
                else
                {   
                    // See if we need to update the selected image
                    if(note.body.currentSelectedImageGuid === note.body.deletedImageGuid)
                    {
                       proxy.SelectedImageGuidDefaultSet();
                    }
                    
                    // raise event for ModulePhotoTray, include deleted image guid
                	// trace('Module Shell:GALLERY_REMOVE_ITEM_SUCCESS - we have items - raising photo deleted event');
                    this.notify(new com.art.core.utils.Note(this.app.events.PHOTO_DELETED, note.body, 'vo'));
                }
            }
            else
            {
                //trace('Remove item truly FAILED - not network issue');
                var myErr = com.art.core.utils.LoggingManager.prototype.createError('GalleryRemoveItem error', note.body.OperationResponse.ResponseMessage);
                this.app.logError(myErr);
            }
            break;
        case this.app.events.UPLOAD_COMPLETE:
        	// This is when ONE file is successfully loaded
            var imageVo = new com.art.core.vos.ImageVO();
            try
            {
            	var myregexp = /.+?({.+}).+/;
            	var json = myregexp.exec(note.body)[1];
            	var jsonObject = $.parseJSON(json);
            }
            catch(err)
            {
            	// Display error
            	$('#uploaderror').show();
            	$('#uploaderdiv').hide();
                this.app.logError(err);
            	return false;
            }
            //var jsonObject = eval("(" + note.body + ")");
            imageVo.parseUploadCustomerPhotoData(jsonObject.Image);
            var requestObject = {
                    apiKey : this.app.getModel().application.apiKey
                    , galleryId : this.app.getModel().GalleryIdForPhotosToArtGet()
                    , sessionId : this.app.getModel().user.sessionId
                    , authToken : this.app.getModel().user.authenticationToken
                    , imageGuid : imageVo.ImageGuid
                    , lookupType : com.art.core.vos.ImageVO.itemTypeFromDomain.UserUploadedItem
                    , userImageTitle : imageVo.ItemDisplayedType
                };
            this.notify(new com.art.core.utils.Note(this.app.events.GALLERY_ADD_ITEM,requestObject,'vo'));
                        
            break;
        case this.app.events.UPLOAD_PROCESS_COMPLETE:
        	var newTotalFiles = parseInt(note.body.originalGalleryCount) + parseInt(note.body.totalFilesCount);
        	var actualGalleryCount = this.app.getModel().getGalleryItemCount();
        	//trace('UPLOAD_PROCESS_COMPLETE - newTotalFiles = ' + newTotalFiles + ', Current Gallery Count is ' + actualGalleryCount);
        	if(actualGalleryCount === newTotalFiles)
        	{
        		this.getUi(1);
        	}
        	else
        	{
        		// Try a delay then recurse?
        		trace('ModuleShell - upload finished before Gallery Add');
        		setTimeout(function(){_this.notify(note);}, 2000);
        	}
        	break;
        case this.app.events.USERIMAGE_CLICKED:
            var imageGuid = note.body.imageGuid;
            
            //STEP: if the new image has been filled with AvailableSizeData, so check that first
            if (this.app.getModel().doesItemHaveAvailableSizesLoaded(note.body.imageGuid))
            {
                //STEP: Move the current state into the previous state
                this.app.getModel().updatePreviousStateWithCurrentState();
                
                //STEP: Check if this requested imageGuid is in the previous state cache
                if (this.app.getModel().isImageGuidInPreviousState(imageGuid))
                {
                    //STEP: It is in the cache, so populate current with the previous
                    this.app.getModel().updateCurrentStateWithPreviousState(imageGuid);
                }
                else
                {
                    //STEP: it is not yet in previous cache, so this is the first time working with it...update cache
                    this.app.getModel().updateCurrentStateWithNewImageGuid(imageGuid);
                    this.app.getModel().SelectedItemPodConfigIdSet
                    (
                        this.app.getModel().getDefaultPodConfigIdForSelectedItem()
                    );
                }
                
                var requestParameters = new com.art.photosToArt.vos.UserImageChangeRequestVo(this.app.getModel());

                this.notify(new com.art.core.utils.Note(this.app.events.IMAGE_UPDATE_AND_GET_RESULTS, requestParameters, 'vo'));            }
            else
            {
                var requestParameters = 
                {
                    apiKey : this.app.getModel().application.apiKey
                    , sessionId : this.app.getModel().user.sessionId
                    , itemId : note.body.imageGuid
                    , lookupType : com.art.core.vos.ImageVO.itemLookupTypeFromDomain.UserUploadedItem
                };
                this.notify(new com.art.core.utils.Note(this.app.events.CATALOG_ITEM_GET_VARIATIONS,requestParameters,'vo'));
            }
            
            break;
            
        case this.app.events.ADDTOCART_GOTOCART_SUCCESS : 
        case this.app.events.ADDTOCART_STAY_SUCCESS : 
            //STEP: Make certain that the cartKey is in the Cookies for return visits...
            var xmlDoc, parser;
            xmlDoc = note.body;
            var cartKey = xmlDoc.getElementsByTagName("CartKey")[0].childNodes[0].nodeValue;
            var today = new Date();
            var d = new Date(today.getFullYear()+2, today.getMonth(), today.getDate(), today.getHours(), today.getMinutes(), today.getSeconds(), today.getMilliseconds());
            var cookieHelper = new com.art.core.cookie.Cookie();
            cookieHelper.setCookieDictionary(this.app.constants.ART_COOKIE_DICTIONARY_PERSISTENT
                    , this.app.constants.COOKIE_NAME_CARTKEY
                    , cartKey
                    , '/'
                    , cookieHelper.getCookieDomain("art")
                    , d
                    , false);
            //trace (note.body);
            
            if (note.name == this.app.events.ADDTOCART_GOTOCART_SUCCESS)
            {
                var cartUrl = this.app.getEnvironment().serviceUrlShoppingCart;
                window.location = cartUrl + (cartUrl.indexOf('?') > -1 ? "&" : "?") + "cartkey=" + cartKey;
            }
            
            break;

        case this.app.events.CATALOG_GET_CONTENT_SUCCESS:
            switch(note.body.contentBlockName.toLowerCase())
            {
                case "p2a/valueproposition01":
                    $('#' + this.markupUtil.getPrefix() + "share").html(note.body.ResponseValue);
                    break;
                case "p2a/valueproposition02":
                    $('#' + this.markupUtil.getPrefix() + "value").html(note.body.ResponseValue);
                    break;
                case "p2a/valueproposition03":
                    $('#' + this.markupUtil.getPrefix() + "help").html(note.body.ResponseValue);
                    break;
                case "p2a/header_application":
                	if (this.app.getModel().StateCurrentUserInterfaceModeGet() === this.app.constants.UI_MODE_APPLICATION)
                	{
	                    if (note.body.ResponseValue == null || note.body.ResponseValue.length == undefined || note.body.ResponseValue.length == 0)
	                        $('#' + this.markupUtil.getPrefix() + "header").html(this.getDefaultHeaderContent());
	                    else
	                        $('#' + this.markupUtil.getPrefix() + "header").html(note.body.ResponseValue);
                	}
                    break;
                case "p2a/footer_application":
                	if (this.app.getModel().StateCurrentUserInterfaceModeGet() === this.app.constants.UI_MODE_APPLICATION)
                	{
	                    if (note.body.ResponseValue == null || note.body.ResponseValue.length == undefined || note.body.ResponseValue.length == 0)
	                        $('#' + this.markupUtil.getPrefix() + "footer").html(this.getDefaultFooterContent());
	                    else
	                        $('#' + this.markupUtil.getPrefix() + "footer").html(note.body.ResponseValue);
	                    //STEP: Upon loading, if the QS parameter was sent to request the launch of the help section, then do it
	                    var load = com.art.core.utils.BrowserUtil.getQueryString('load').toLowerCase();
	                    if (this.app.getModel().initializeGet() == true)
	                    {
	                        switch(load)
	                        {
	                            case "privacy":
	                                $('#p2a-privacy').trigger('click');
	                                break;
	                        }
	                    }
	
	                    //STEP: IMPORTANT!!! - Because FOOTER is displayed for either UI mode, it is the best place to consider the "end" of loading the application, so reset flag here.
	                    this.app.getModel().initializeEnd();
                	}
                    break;
                
            }
            break;
        case this.app.events.CATALOG_GET_CONTENT_FAILURE:
            break;
        case this.app.events.ADDTOCART_GOTOCART_FAILURE : 
        case this.app.events.ADDTOCART_STAY_FAILURE : 
        case this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_FAILURE:
        case this.app.events.CATALOG_ITEM_GET_VARIATIONS_FAILURE:
        case this.app.events.GALLERY_ADD_ITEM_FAILURE:
        case this.app.events.GALLERY_ADD_FOR_USER_FAILURE:
        case this.app.events.GALLERY_GET_BY_USER_FAILURE:
        case this.app.events.INITIALIZE_API_FAILURE:
        case this.app.events.AUTHENTICATE_ACCOUNT_FAILURE:
        case this.app.events.CREATE_ACCOUNT_FAILURE:
        case this.app.events.GALLERY_REMOVE_ITEM_FAILURE:
            //NOTE: tell the user we cannot proceed
            this.getFailureUi(note.name);
            break;
            
        case this.app.events.CLOSE_APP:
            this.close();
            break;
        default:
            
            //do nothing
            
    }
};

com.art.photosToArt.modules.ModuleShell.prototype.getDefaultHeaderContent = function ()
{
    return '';
};

com.art.photosToArt.modules.ModuleShell.prototype.getDefaultFooterContent = function()
{
    return "";
};

com.art.photosToArt.modules.ModuleShell.prototype.getTarget = function ()
{
    //NOTE: Init is where you initialize the handlers for this module and any variables, etc instantiated object will need
	//trace('ModuleShell Target is: ' + this.moduleData.target);
    return this.moduleData.target;
};

com.art.photosToArt.modules.ModuleShell.prototype.getTemplate = function ()
{
    //NOTE: Init is where you initialize the handlers for this module and any variables, etc instantiated object will need
    var template =  this.template;
    var selector = '#' + this.markupUtil.getName('container');
    $(selector).empty();

    //STEP: Determine logic here...do we show landing page or application UI page?
    if (this.app.getModel().StateCurrentUserInterfaceModeGet() === this.app.constants.UI_MODE_APPLICATION)
    {
        //trace('ModuleShell-GetTemplate - getting app UI');
        template = template.replace('[MODULE_CONTENT]',this.templateApplicationUi);
    }
    else
    {
        //trace('ModuleShell-GetTemplate - getting HOMEPAGE');
        template = template.replace('[MODULE_CONTENT]',this.templateLandingPage);
    }
    
    //STEP: Replacing - replace placeholders in the template
    template =  template.replace(/\[MODULE_ID\]/gi, this.markupUtil.getModuleId() );
    template =  template.replace(/\[PREFIX\]/gi, this.markupUtil.getPrefix() );
    template =  template.replace(/\[MODULE_CLOSE\]/gi, this.markupUtil.getName("close") );
    template =  template.replace(/\[CLOSE_LABEL\]/gi, this.app.getString("close"));

    return template;
    return returnValue.replace('$NAME', this.NAME.toLowerCase());
    
};

com.art.photosToArt.modules.ModuleShell.prototype.templateLandingPage =
    '<div id="[PREFIX]header"></div>'
    + '<div id="[PREFIX]ModuleHomePage"></div>'
    + '<div id="[PREFIX]footer" style="float:left"></div>';

com.art.photosToArt.modules.ModuleShell.prototype.templateApplicationUi =
    '<div id="[PREFIX]header"></div>' +
    '<div id="[PREFIX]left" style="float:left">' +
        '<div id="[PREFIX]photos"></div>' +
        '<div class="clear"></div>' + 
        '<div id="borderdiv" style="border: 1px solid #DCDDDE;margin-top:10px; #margin-top:-10px;">' + 
            '<div id="[PREFIX]services"></div>' +
            '<div id="[PREFIX]working"></div>' +
        '</div>' +
    '</div>' +
    '<div id="[PREFIX]right" style="float:left">' +
        '<div id="[PREFIX]share" style="margin-bottom:10px;"></div>' +
        '<div id="[PREFIX]value" style="margin-bottom:10px;"></div>' +
        '<div id="[PREFIX]help"></div>' +
    '</div>' +
    '<div id="[PREFIX]footer" style="float:left"></div>';


com.art.photosToArt.modules.ModuleShell.prototype.template =
    '<div id="[MODULE_ID]" >'+
        '<div id="[MODULE_CLOSE]" align=right style="display:none">[CLOSE_LABEL]</div>' +
        '[MODULE_CONTENT]' + 
    '</div>' +
    '<div id="p2a_ms_popupwindow">' +
    '<div id="p2ahelpmodule" style="float:right;width:725px"></div>' +
      '</div>'
    + '<div id="sizepicker"></div>';
        