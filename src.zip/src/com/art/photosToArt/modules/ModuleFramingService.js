com.art.photosToArt.modules.ModuleFramingService = function(data, app)
{
	this.target 			= data.target;
	this.NAME 				= com.art.photosToArt.modules.ModuleFramingService.NAME;
	this.app 				= app;
	this.tabBar				= new com.art.core.components.TabBar(this.NAME + "_tabBar",752);
	this.artCarousel 		= new com.art.core.components.ArtCarousel(this.NAME+"_artCarousel",752,117,"mouldingId");
	this.MOULDINGS			= "mouldings";
	this.MATS				= "mats";
	this.MAT				= "mat";
	this.FRAME				= "frame";
	this.renderCollection	= [];
	this.startupFlag		= false;
	this.clickType			= "";
	this.ITEM_RENDERER_CLICK_TYPE 	= "itemRendererClickType";
	this.TAB_CLICK_TYPE				= "tabClickType";
	this.currentlyLoadedItemsInCarousel; //prevent reloading if already displayed; either mats or mouldings
	this.loadMoudlingsFlag	= false;
};
com.art.photosToArt.modules.ModuleFramingService.NAME = "ModuleFramingService";

com.art.photosToArt.modules.ModuleFramingService.prototype.init = function()
{
	var container = $(this.getTarget());
	if(container.width() < 0)
		throw new Error("ModuleFramingService failed! Template is invalid.");
	
	container.html(this.getTemplate());
};

com.art.photosToArt.modules.ModuleFramingService.prototype.listNotificationInterests = function()
{
    return [         
            this.app.events.INITIALIZE_API_SUCCESS,
            this.app.events.FRAME_GET_COMPONENTS_SUCCESS,
            this.app.events.RELOAD_USER_INTERFACE,
            this.app.events.FRAME_GET_MOULDING_PRICE_SUCCESS,
            this.app.events.USERIMAGE_CLICKED,
            this.app.events.PHOTO_DELETED,
            this.app.events.UPLOAD_PROCESS_COMPLETE
     ];
};

com.art.photosToArt.modules.ModuleFramingService.prototype.handleNotification = function(note)
{
	switch(note.name)
	{
		case this.app.events.RELOAD_USER_INTERFACE:
			if(this.app.getModel().SelectedItemServiceGet().name != this.app.getModel().data.serviceTypes.framing.name)//This is the proper way in this code base to compare service objects
			{
				this.hideFramingOptions();
			}
			else
			{
				if(this.app.getModel().getFramingComponents() == undefined || this.app.getModel().getFramingComponents()[this.app.getModel().SelectedItemPodConfigIdGet()] == undefined )
					this.app.sendNotification(new com.art.core.utils.Note(this.app.events.FRAME_GET_COMPONENTS,{}, 'vo'));
				else
				{
					this.showFramingOptions();
					
				}
			}
			break;
		case this.app.events.FRAME_GET_COMPONENTS_SUCCESS:
			trace("ModuleFramingService FRAME_GET_COMPONENTS_SUCCESS");
			this.app.getModel().setFramingComponents(note.body);
			this.showFramingOptions();
			break;
		case this.app.events.FRAME_GET_MOULDING_PRICE_SUCCESS:
			var obj 		= this.artCarousel.getItemByCustomKey(note.body.mouldingId);
			if(obj == undefined)
				return; //items not yet added to carousel
			obj.price = note.body.price; //note.body.price == "" ? this.app.getString("price not available") : p;
			obj.itemRenderer.setPrice(obj.price);
			break;
		case this.app.events.USERIMAGE_CLICKED:
			//$("#carousel_tabs").html("");
			//this.tabBar.clearAllTabs();
			this.app.getModel().matCount = 0; //reset
			this.startupFlag = false;
			
			//always go back to mouldings when user changes images
			this.app.getModel().setSelectedTabObject({id:this.app.constants.FRAME,label:this.app.getString("frame"),value:this.app.constants.FRAME});
			this.loadMouldingsFlag = true;
			break;
		case this.app.events.UPLOAD_PROCESS_COMPLETE:
			//reset on upload too
		case this.app.events.PHOTO_DELETED:
			if(this.app.getModel().SelectedItemServiceGet().name.toLowerCase() == this.app.constants.FRAMING)
			{
				this.app.getModel().matCount = 0; //reset
				this.startupFlag = false;
				this.loadCarouselControl(this.MOULDINGS);
				this.app.getModel().setSelectedTabObject({id:this.app.constants.FRAME,label:this.app.getString("frame"),value:this.app.constants.FRAME});
			}
			break;
		
			
	}
};

com.art.photosToArt.modules.ModuleFramingService.prototype.hideFramingOptions = function()
{
	//if not yet rendered ignore
	if(!this.tabBar.isRendered() || !this.artCarousel.isRendered())
		return;
	
	this.artCarousel.hide();
	this.tabBar.hide();
};

com.art.photosToArt.modules.ModuleFramingService.prototype.showFramingOptions = function()
{
	this.showTabControl();
	
	this.showCarouselControl();
	
	//update hover price for default moulding ONLY if on frame tab
	if(this.app.getModel().selectedFramingTabObject.id == this.app.constants.FRAME)
		this.updateSelectedFramePrice();
	
	
	this.setInitialState();
	//select the framing tab on first view only
	if(!this.startupFlag)
	{
		this.startupFlag = true;
	}
	else
	{
		trace("CLICK TYPE: "+this.clickType);
	}
	
	
};


//Update frame price display at bottom if price changed
com.art.photosToArt.modules.ModuleFramingService.prototype.updateSelectedFramePrice = function()
{
	var mouldingId 	= this.app.getModel().SelectedGalleryItemGet().Item.Service.Frame.Moulding.ItemNumber;
	
	//refresh bottom moulding display
	this.app.sendNotification(new com.art.core.utils.Note(this.app.events.FRAME_GET_MOULDING_PRICE,{frameId:this.app.getModel().SelectedItemFrameIdGet(),mouldingId:mouldingId},'vo'));
};
com.art.photosToArt.modules.ModuleFramingService.prototype.setInitialState = function()
{
	var _this = this;
	var tabType;
	//no need to setInitialState, should be set already
	if(this.app.getModel().getMatCount() > 0)
	{
		var id = this.app.getModel().selectedFramingTabObject.id;
		id = id.toLowerCase();
		tabType = id.indexOf(this.MAT) == -1 ? this.MOULDINGS : this.MATS;
		if(this.clickType == this.TAB_CLICK_TYPE)
			this.scrollToAndSelectItem(tabType,true);
		return;
	}
	
	var item = this.app.getModel().SelectedGalleryItemGet().Item.Service.Frame;
	
	
	for(var prop in item)
	{
		if(prop.indexOf("Mat") > -1 && item[prop].ItemNumber > 0 && item[prop].Name != null)
			this.app.getModel().setMatCountById(prop);
		
		//if Mat is on the item BUT has not yet been added to tabBar let's add new tab
		if(prop.indexOf("Mat") > -1 && item[prop].ItemNumber > 0 && !this.tabBar.hasTabById(prop) && item[prop].Name != null)
		{
			var label 	= this.app.getString(this.app.getModel().getMatTab().label);
			var id		= this.app.getModel().getMatTab().id;
			this.tabBar.addTab(id,label, function(obj){ _this.tabClick(obj);});
		}
		else if(prop.indexOf("Mat") > -1 && item[prop].ItemNumber == "0" && this.tabBar.hasTabById(prop))
		{
			this.tabBar.removeTabById(prop)
		}
	}
	this.updateTabControls();
	this.app.getModel().setSelectedTabObject({id:this.app.constants.FRAME,label:this.app.getString("frame"),value:this.app.constants.FRAME});
	this.tabBar.resetAllTabs();
//	this.tabBar.selectTabByIndex(this.app.getModel().getMatCount());
	this.tabBar.selectTabByIndex(0);
	
	//scroll to selection
	this.scrollToAndSelectItem();
};

/**
 * common functionality for all matTab clicks
 */
com.art.photosToArt.modules.ModuleFramingService.prototype.tabClick = function(obj)
{
	this.clickType = this.TAB_CLICK_TYPE;
	
	var id = obj.id;
	id = id.toLowerCase();
	var tabType = id.indexOf(this.MAT) == -1 ? this.MOULDINGS : this.MATS;
	
	var prevID;
	if(this.app.getModel().selectedFramingTabObject.id != undefined)
	{
		prevID = this.app.getModel().selectedFramingTabObject.id;
		prevID = prevID.toLowerCase();
	}
	this.app.getModel().setSelectedTabObject(obj);
	
	//check to see if we need to reload carousel
	if((prevID == undefined) || (tabType == this.MATS && prevID == this.FRAME) || ((tabType == this.MOULDINGS) && prevID.indexOf(this.MAT)>-1))
	{
		this.loadCarouselControl(tabType);
	}
		
	//scroll to selection
	this.scrollToAndSelectItem(tabType,true);
};

com.art.photosToArt.modules.ModuleFramingService.prototype.loadCarousel = function()
{
	trace(this.app.getModel().getSelectedTabObject());
};



com.art.photosToArt.modules.ModuleFramingService.prototype.initializeTabControl = function()
{
	var _this = this;
	
	//Add control tab "+ add mat
	this.tabBar.addTab("addMat","+ " + this.app.getString("add_mat"), function(obj){
		_this.app.getModel().matCount++;
		_this.clickType = _this.TAB_CLICK_TYPE; //so we show selected
		_this.updateTabControls();
		_this.loadCarouselControl(_this.MATS);
		_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.FRAME_UPDATE_MAT_COUNT,{frameId:_this.app.getModel().SelectedItemFrameIdGet(),matCount:_this.app.getModel().getMatCount()}));
		
		var t = _this.app.getModel().getMatTab();
		var label 	= t.label;
		var id		= t.id;
		_this.app.getModel().setSelectedTabObject(t);
		_this.tabBar.addTab(id,_this.app.getString(label.replace(" ","_")),function(obj){_this.tabClick(obj);});
			
			
		
		_this.tabBar.resetAllTabs();
		trace("initializeTabControl getMatCount()");
		_this.tabBar.selectTabByIndex(_this.app.getModel().getMatCount());
		
		//scroll to selection
		_this.scrollToAndSelectItem();
		
	},true);
	
	//Add control tab "- remove mat"
	this.tabBar.addTab("removeMatID","- " +this.app.getString("remove_mat"), function(obj){
		_this.clickType = _this.TAB_CLICK_TYPE; //so we show selected
		_this.app.getModel().matCount = _this.app.getModel().getMatCount() == 0 ? 0 : _this.app.getModel().getMatCount() - 1;
		trace("matCount: "+_this.app.getModel().getMatCount());
		_this.tabBar.removeTab();
		_this.updateTabControls();
		_this.tabBar.resetAllTabs();
		if(_this.app.getModel().matCount == 0)
		{
			_this.app.getModel().setSelectedTabObject({id:_this.app.constants.FRAME,label:_this.app.getString("frame"),value:_this.app.constants.FRAME});
		}
		else
		{
			var t = _this.app.getModel().getMatTab();
			_this.app.getModel().setSelectedTabObject(t);
		}
		_this.tabBar.selectTabByIndex(_this.app.getModel().getMatCount());
		var type = _this.app.getModel().getMatCount() == 0 ? _this.MOULDINGS : _this.MATS;
		_this.loadCarouselControl( type );
		//scroll to selection
		_this.scrollToAndSelectItem();
		
		_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.FRAME_UPDATE_MAT_COUNT,{frameId:_this.app.getModel().SelectedItemFrameIdGet(),matCount:_this.app.getModel().getMatCount()}));
	},true);
	
	
	//add frame tab on startup
	this.tabBar.addTab("frame",this.app.getString("frame"), function(obj){ _this.tabClick(obj);});
	
	this.updateTabControls();

};

com.art.photosToArt.modules.ModuleFramingService.prototype.updateTabControls = function()
{
	//hide ADD button
	if(this.app.getModel().getMatCount() == this.app.constants.MAX_MAT_COUNT)
	{
		var addID = this.tabBar.getControlTabByIndex(0);
		$("#" + addID).css("display","none");
	}
	//hide REMOVE button
	if(this.app.getModel().getMatCount() == 0)
	{
		var addID = this.tabBar.getControlTabByIndex(1);
		$("#" + addID).css("display","none");
	}
	//show REMOVE button
	if(this.app.getModel().getMatCount() > 0 )
	{
		var removeID = this.tabBar.getControlTabByIndex(1);
		$("#" + removeID).css("display","inline-block");
	}
	//show ADD button
	if(this.app.getModel().getMatCount() < this.app.constants.MAX_MAT_COUNT )
	{
		var addID = this.tabBar.getControlTabByIndex(0);
		$("#" + addID).css("display","inline-block");
	}
};
com.art.photosToArt.modules.ModuleFramingService.prototype.scrollToAndSelectItem = function(type)
{
	trace("ModuleFramingService.scrollToAndSelectItem");
	trace("this.app.getModel().getSelectedTabObject().id: "+this.app.getModel().getSelectedTabObject().id);
	//var index = -1;
	if(this.app.getModel().getSelectedTabObject().id == this.app.constants.FRAME)
	{
		index = this.app.getModel().getFrameIndexById();
		this.updateSelectedFramePrice();
	}
	else	
	{
		index = this.app.getModel().getMatIndexById(this.app.getModel().getSelectedTabObject().id);
	}
	
	if(index > -1)
		this.artCarousel.selectItemByIndex(index,true);
};
com.art.photosToArt.modules.ModuleFramingService.prototype.loadCarouselControl = function(type)
{
	
	trace("loadCarouselControl: type:"+type);
	this.currentlyLoadedItemsInCarousel = type;
	
	var _this 		= this;
	this.renderCollection 	= [];
	var collection 			= type == this.MOULDINGS ? this.getMouldingsCollection() : this.getMatsCollection();
	var RendererClass		= type == this.MOULDINGS ? com.art.photosToArt.components.MouldingItemRenderer : com.art.photosToArt.components.MatItemRenderer;
	
	var hashKey				= type == this.MOULDINGS ? "mouldingId" : "MatId";
	
	//remove events first
	this.artCarousel.stopIntervals();
	this.artCarousel.clearCallbacks();
	this.artCarousel.setCustomHashKey(hashKey);
	
	if(collection.length == 0)
		throw new Error("ModuleFramingService.loadCarouselControl() failed! "+type+" collection is empty.");
	
	for(var i=0; i < collection.length; i++)
	{
		var tmp = collection[i];
		tmp.itemRenderer = new RendererClass(117,117,tmp.getThumbImageUrl(),i,tmp.Name);
		if(type == this.MATS)
		{
			tmp.itemRenderer.hexColor 		= tmp.hexColor;
			tmp.itemRenderer.fallbackImage	= tmp.getFallbackImage();
		}
		this.renderCollection.push(tmp);
	}
	this.artCarousel.addItems(this.renderCollection);
	
	
	if(type == this.MOULDINGS)
	{
		//register callbacks
		this.artCarousel.registerCallback(com.art.core.components.ArtCarousel.MOUSE_OVER,function(obj){			
			if(!obj.itemRenderer.isSelected && !obj.itemRenderer.isOver)
			{
				obj.itemRenderer.showHover();
				_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.FRAME_GET_MOULDING_PRICE,{frameId:_this.app.getModel().SelectedItemFrameIdGet(),mouldingId:obj.mouldingId},'vo'));
			}
			else
			{
			}
		});
		this.artCarousel.registerCallback(com.art.core.components.ArtCarousel.MOUSE_OUT,function(obj){
			trace("MOULDING MOUSE OUT");
			
			if(!obj.itemRenderer.isSelected)
				obj.itemRenderer.removeHover();
		});
		
		this.artCarousel.registerCallback(com.art.core.components.ArtCarousel.CLICK,function(obj){
			_this.clickType = _this.ITEM_RENDERER_CLICK_TYPE;
			
			if(!obj.itemRenderer.isSelected)
			{
				_this.artCarousel.selectItemByIndex(obj.itemRenderer.index);
				_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.FRAME_UPDATE_MOULDING,{frameId:_this.app.getModel().SelectedItemFrameIdGet(),mouldingItemNumber:obj.mouldingId},"request"));
			}
			else
			{
				trace("frame is selected");
			}
		});
		
	}
	
	if(type == this.MATS)
	{
		//register callbacks
		this.artCarousel.registerCallback(com.art.core.components.ArtCarousel.MOUSE_OVER,function(obj){
			if(!obj.itemRenderer.isSelected && !obj.itemRenderer.isOver)
				obj.itemRenderer.showHover();
		});
		this.artCarousel.registerCallback(com.art.core.components.ArtCarousel.MOUSE_OUT,function(obj){
			if(!obj.itemRenderer.isSelected)
				obj.itemRenderer.removeHover();
		});
		
		this.artCarousel.registerCallback(com.art.core.components.ArtCarousel.CLICK,function(obj){
			_this.clickType = _this.ITEM_RENDERER_CLICK_TYPE;
			_this.artCarousel.selectItemByIndex(obj.itemRenderer.index);
			var pos = _this.app.getModel().getMatPosition();
			var args = {frameId:_this.app.getModel().SelectedItemFrameIdGet(),matItemNumber:obj.MatId,position:pos};
			_this.app.sendNotification(new com.art.core.utils.Note(_this.app.events.FRAME_UPDATE_MAT,args,'request'));
		});
	}


};


/**
 * This is will show mat/moulding component below hero image
 */
com.art.photosToArt.modules.ModuleFramingService.prototype.showCarouselControl = function()
{
	
	if(!this.artCarousel.isRendered())
	{
		$("#carousel").append(this.artCarousel.render());
		this.loadCarouselControl(this.MOULDINGS);
	}
	else
	{
		//if user moves from oversized to non oversized we must refresh the mat collection
		//that's why we have this condition
		var id = this.app.getModel().selectedFramingTabObject.id;
		id = id.toLowerCase();
		var type = id.indexOf(this.MAT) == -1 ? this.MOULDINGS : this.MATS;
		if(type == this.MATS && this.refreshMatCollectionRequired())
		{
			//set it to ITEM_RENDERER_CLICK_TYPE
			//so we can select and scroll to it, otherwise it wont auto select
			this.clickType = this.TAB_CLICK_TYPE;
			this.loadCarouselControl(type);
		}
		else
		{
			//user clicked on new image lets always go back to mouldings
			if(this.loadMouldingsFlag)
			{
				this.loadMouldingsFlag = false;
				this.loadCarouselControl(this.MOULDINGS);
			}
			this.artCarousel.show();
		}
		
		
		
		
		
	}
};
/**
 * refreshMatCollectionRequired() indicates if user is navigating between an oversized size and normal size
 * We need to refresh the mat collection to only so oversized mats or non-oversized mats
 * This method tells us if need to perform this method; it looks at what is currently loaded in the carousel vs what size is currently selected
 * 
 * 
 * @returns {Boolean}
 */
com.art.photosToArt.modules.ModuleFramingService.prototype.refreshMatCollectionRequired = function()
{
	var itemsLoadedAreOversized = this.artCarousel.itemCollection[0].isOverSized == "1";
	var selectedItemIsOversized	= this.app.getModel().SelectedGalleryItemGet().Item.Service.Frame.FrameSummary.AreMatsOversized;
	return (itemsLoadedAreOversized && !selectedItemIsOversized) || (!itemsLoadedAreOversized && selectedItemIsOversized);
};
com.art.photosToArt.modules.ModuleFramingService.prototype.showTabControl = function()
{
	if(!this.tabBar.isRendered() || !this.tabBar.isInitialized())
	{
		$("#carousel_tabs").append(this.tabBar.render());
		this.initializeTabControl();
	}
	else
	{
		this.tabBar.show();
	}
};

com.art.photosToArt.modules.ModuleFramingService.prototype.getTarget = function()
{
	return this.target;
};

com.art.photosToArt.modules.ModuleFramingService.prototype.getTemplate = function()
{
	return this.template.replace("$ID",this.NAME);
};

com.art.photosToArt.modules.ModuleFramingService.prototype.getMouldingsCollection = function()
{
	trace("getMouldingsCollection");
	return this.app.getModel().getFramingComponents()[this.app.getModel().SelectedItemPodConfigIdGet()].Mouldings;
};


com.art.photosToArt.modules.ModuleFramingService.prototype.getMatsCollection = function()
{
	return this.app.getModel().getMats();
};


com.art.photosToArt.modules.ModuleFramingService.prototype.template = '<div id="$ID" style="padding:18px;">'+
	'<div id="carousel_tabs"></div>'+
	'<div id="carousel"></div>'+
	'</div>';


