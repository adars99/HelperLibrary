if (com == null)
	var com = {};
if (com.art == null)
	com.art = {};
if (com.art.common == null)
	com.art.common = {};
if (com.art.common.modules == null)
	com.art.common.modules = {};

com.art.photosToArt.modules.ModuleUpload = function(args) {

	this.resourceRoot = args.resourceRoot;
	this.onCompleteUrl = args.onCompleteUrl;
	this.noFlashUrl = args.noFlashUrl;
	this.contentPolicyUrl = args.contentPolicyUrl;
	this.printReadyUrl = args.printReadyUrl;
	this.persistentId = args.persistentId;
	this.fileCountMaximum = args.fileCountMaximum;
	this.app = args.application;

	
	com.art.photosToArt.modules.ModuleUpload.applicationMode = args.applicationMode;
	com.art.photosToArt.modules.ModuleUpload.uploaderInitialized = false;
	com.art.photosToArt.modules.ModuleUpload.apiKey = PhotosToArtCore.getModel().application.apiKey;
	com.art.photosToArt.modules.ModuleUpload.minimumSizeConfig = {};
	com.art.photosToArt.modules.ModuleUpload.totalFilesCount = 0;
	com.art.photosToArt.modules.ModuleUpload.originalGalleryCount = 0;
	com.art.photosToArt.modules.ModuleUpload.getMinimumSizeConfig = function()
	{
		try
		{
			if(!('Small' in com.art.photosToArt.modules.ModuleUpload.minimumSizeConfig))
			{
				com.art.photosToArt.modules.ModuleUpload.minimumSizeConfig = PhotosToArtCore.getModel().getMinimumSizeConfig();
			}
		}
		catch(err){alert(err);}
		return com.art.photosToArt.modules.ModuleUpload.minimumSizeConfig;
	};
	this.css = '\
    <style type="text/css">\
        #FlashUploaderTarget {\
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;\
        }\
    </style>\
    ';

	this.render = function(maxImages) {
		if(maxImages !== null && maxImages !== undefined)
		{
			this.fileCountMaximum = maxImages;
		}
		var targetId = 'FlashUploaderTarget';
		// This data will be consumed later by the uploader:
		com.art.photosToArt.modules.ModuleUpload.getMinimumSizeConfig();
		
		if (!com.art.photosToArt.modules.ModuleUpload.uploaderInitialized === true)
		{
			com.art.photosToArt.modules.ModuleUpload.uploaderInitialized = true;
			if (document.getElementById('FlashUploaderTarget') == null) {
				$('body').append('<div id="FlashUploaderTarget"></div>');
				$('body').append(this.css);
			}
			
			var playerVersion = swfobject.getFlashPlayerVersion();
			if (playerVersion.major < 10 || (playerVersion.major == 10 && playerVersion.min < 3)) {
				this.renderNoFlash(targetId);
				var hiZ = com.art.core.utils.BrowserUtil.getNextHighestZIndex();
				$('#uploader_noFlashPopup').css('z-index', hiZ);
			}else
				this.renderUploader(targetId);
	
			this.registerEvents();
		}
		else
		{
			// NEW fix for uploading files after the initial upload - change max files 'fileFilter.maxCount' : this.fileCountMaximum,
			try{MultiPowUpload.setParameter('fileFilter.maxCount',(this.fileCountMaximum + ''));}catch(err){trace('ERROR trying to set max photos ' + err.message);} 
			var newZ = $('#uploadLightbox').css('z-index') + 2;
			$('#uploader_flashPopup').parent().css({'z-index': newZ - 1, 'position':'absolute'});
			$('#uploader_flashPopup').css({'z-index': newZ , 'position':'absolute'});
		}
		
		$('#FlashUploaderTarget').show();
	};

	this.renderUploader = function(targetId) {
		var html = '<div id="uploader_flashPopup" style="border: 1px solid #d6d6d6; background: white;width: 580px; z-index:1003; text-align: center;font-family: Arial;">'
			    + '       <div class="gradient_gray titlebar cPointer" style="height: 30px; width: 100%; padding-top: 5px;">' 
                + '            <div class="floatleft" style="padding-top: 2px; padding-left: 10px; color: #647691; font-family: Arial, Helvetica, sans-serif; font-size: 18px; vertical-align: middle;" >'
                + '                 [UPLOADPHOTOS]'
                + '            </div>'
                + '            <div class="clear"></div>'
                + '					<div id="closeuploader" style="float: right; margin-right: 8px; margin-top: -19px; #margin-top: -25px; cursor: pointer;" >'
				+ '						<img src="'
				+ 							this.resourceRoot
				+ '							close.png" />'
				+ '					</div>'
				+ '            </div>'
				+ '			   <div id="uploaderdiv" style="display:none;width: 580px; height: 480px;  text-align: center; text-align: left; padding-top:20px;">'
				+ '					<div id="divMultiPowUpload" style="width: 580px; height: 460px;"></div>'
				+ '				</div>'
				+ '				<div style="margin-top:30px;width: 580px;padding-bottom:20px;" id="uploadertermsdiv">'
				+ '    				<div style="color:#747167;width:540px;margin-left:20px;margin-top:10px;border-bottom: solid 1px #b0c9dd;">'
                + '        				<span style="font-size: 14px;font-weight:bold;">' 
                + 							this.app.getString("Getting ready to upload, but first...") 
                + '						</span>'
                + '    				</div>'
				+ '					<div style="width:530px;color: #747167; text-align: left; margin: 5px 20px 5px 20px;" id="divUploadRequirements">'
				+ '						<div style="text-align:center;font-weight:bold; padding: 15px 0px 5px 0px; font-size: 12px">'
				+ 									this.app.getString('Image Requirements')
				+ '					    </div>'
				+ '						<ul style="margin-left:172px">'
				+ '							<li>[FORMAT]</li>'
				+ '							<li>[FILESIZE]</li>'
				+ '							<li>[MAX10IMAGES]</li>'
				+ '						</ul>'
				+ '					</div>'
				+ '			 		<div style="margin-top:60px">'
				+ 						this.app.getString('By clicking the button below I agree to the ')
				+ '						<a href="#" id="termsofuselink" >'
				+ 							this.app.getString('Terms of use')
				+ '						</a>' + this.app.getString('_zu_')
				+ '			 		</div>'
				+            '		<div id="agreetouploadterms" style="margin-top:6px;margin-left:220px;#margin-left:0px;width:140px;" class="btn_orange btn_global_doubleline btn_global link"  '
				+ '						onmouseout="this.className=\'btn_orange btn_global_doubleline btn_global link\'" '
				+ '						onmouseover="this.className=\'btn_over btn_global_doubleline btn_global link\'" >'
				+                '  	<div class="btn_text text-align-center" style="padding-right: 0px!important;font-size:13px;font-weight:bold;height:28px;">'
				+ 							"<div style='padding-top:7px;'>" + this.app.getString('I Agree') + "</div>"
				+ ' 		 			</div>'
				+            		'</div>'
				+ '				</div>'
				+ '				<div style="display:none;font-family: verdana, sans-serif;color:red;text-align:center;font-size:16px;height:140px;margin-top:110px;clear:right;" id="uploaderror">'
				+					this.app.getString('We are sorry, but an error occurred while uploading this image.')
				+ '					<br />' 
				+ 					this.app.getString('Please try again later.')
				+ '					</div>'
				+ '				</div>';
		
		html = html.replace(/\[UPLOADPHOTOS\]/gi, this.app.getString('Upload_Photos'));
		html = html.replace(/\[FILESIZE\]/gi, this.app.getString('File_Size:_500KB_to_20MB'));
		html = html.replace(/\[FORMAT\]/gi, this.app.getString('Format:_JPEG_or_TIFF'));
		html = html.replace(/\[MAX10IMAGES\]/gi, this.app.getString('Maximum:_10_images'));
		
		$('#' + targetId).html(html);
		if ($('#uploadLightbox').length > 0) {
			var newZ = $('#uploadLightbox').css('z-index') + 2;
			$('#uploader_flashPopup').parent().css({'z-index': newZ - 1, 'position':'absolute'});
			$('#uploader_flashPopup').css({'z-index': newZ, 'position':'absolute'});
		}
		
		try
		{
			// to made the uploader to be centered
			$('#uploader_flashPopup').hide();
	    	    setTimeout(function(){
	    		$('#uploader_flashPopup').center(true);
	    		$('#uploader_flashPopup').show();
	        }, 100);
		}
		catch(err)
		{
	        this.app.logError(err);
		}
		var params = {
			wmode : "transparent"
		};

		var attributes = {
			id : "MultiPowUpload",
			name : "MultiPowUpload"
		};

		var isNewUploader = false;
		var languagePath = PhotosToArtCore.getEnvironment().uploaderTranslationFileLocation + "Language_" + this.app.getModel().user.languageIso + ".xml";
		var environment = this.app.getEnvironment();
		var flashvars = {
			'method' : 'post',
			'postTo' : environment.serviceUrlImageUpload,
			'uploadUrl' : environment.serviceUrlImageUpload,
			'messages.fileSizeNotEnough' : this.app.getString('Files must be at least 500 KB in size to ensure a high quality print. <COUNTINVALIDFILES> of your files do not meet this requirement.') ,
			'fileFilter.maxCount' : this.fileCountMaximum,
			'fileFilter.maxSize' : 	environment.maxImageSize !== undefined ? environment.maxImageSize : 20480000,
			'fileFilter.minSize' : environment.maxImageSize !== undefined ? environment.minImageSize : 512000,
			'fileFilter.types' : 'Images|*.jpg:*.jpeg:*.tif:*.tiff:',
			'minResolutionShortSide' : '800',
			'defaultView' : 'grid',
			'onCompleteUrl' : this.onCompleteUrl,
			'imageRoot' : PhotosToArtCore.getEnvironment().imagePath + '/images/photostoart/',
			'postFields.file' : 'ImageXml',
			'useExternalInterface' : 'true',
			'javaScriptEventsPrefix' : 'MultiPowUpload',
			'clearListOnAddNewFiles' : 'false',
			'removeUploadedFilesFromList' : 'true',
			'dateFormatString' : 'm/d/Y H:i',
			'constant.decimalSeparator' : '.',
			'thumbnail.loadFromExif' : 'false',
			'language.autoDetect' : 'false',
			'language.source' : languagePath,
			'listViewButton.x' : 250,
			'loadingText' : this.app.getString('loading'),
			'fileView.defaultView' : 'thumbnails'

		};
		var swfFilename = '';
		if (isNewUploader) {
			// Trying to pass these post fields here because the _onAddFiles
			// isn't being called now.
			flashvars.customPostFields = 'persistentid:'
					+ PhotosToArtCore.getModel().user.persistentId;
			flashvars.customPostFields += ',apikey:'
					+ com.art.photosToArt.modules.ModuleUpload.apiKey;
			swfFilename = "support/FlashUploader.swf";

		} else {
			flashvars.serialNumber = '00826431142282254711118525282576169286728410211';
			swfFilename = "support/ElementITMultiPowUpload.swf";
		}

		swfobject.embedSWF(PhotosToArtCore.getEnvironment().virtualPath
				+ swfFilename, "divMultiPowUpload", "580", "460", "10.0.0",
				"support/expressInstall.swf", flashvars, params, attributes);

		// If cookie is present, show the uploader, not the "accept terms" dialog
		var cookieHelper = new com.art.core.cookie.Cookie();
	    var acceptsTerms = cookieHelper.getCookieDictionary
	    (
	            this.app.constants.P2A_COOKIE_DICTIONARY_PERSISTENT
	            , this.app.constants.COOKIE_NAME_ACCEPTS_TERMS
	     );
	    if (!(acceptsTerms === undefined || acceptsTerms.length == undefined || acceptsTerms.length == 0))
	    {
			$('#uploadertermsdiv').hide();
			$('#uploaderdiv').show();
	    }    
	};
};

// Should this be CMS-able?
this.renderNoFlash = function(targetId) {
	var html = '<div id="uploader_noFlashPopup" style="position: absolute; top: 125px; text-align: center; width: 100%; font-family: Arial;">\
				<span style="width: 500px; height: 275px; border: 1px solid #d6d6d6; background: white; text-align: center; display: inline-block;">\
					<div onclick="$(\'#FlashUploaderTarget\').remove();$(\'#uploadLightbox\').empty().remove();" style="float: right; margin-right: 6px; margin-top: 6px; cursor: pointer;" >\
						<img src="'
			+ this.resourceRoot
			+ 'close.png" />\
					</div>\
					<div style="font-family:Arial,Helvetica,sans-serif;margin-top: 20px;font-size:22px;color:#B51821">\
						[NEEDFLASH]\
					</div>\
					<span style="margin-top: 49px; display: inline-block;">\
						<div style="width: 315px; margin-top: 9px;">\
							[FLASHMSG]\
						</div>\
					</span>\
					<div style="margin-top: 30px;">\
							<a href="http://get.adobe.com/flashplayer\"><img src="http://www.adobe.com/images/shared/download_buttons/get_adobe_flash_player.png" /></a>\
					</div>\
				</span>\
			';
	html = html.replace(/\[NEEDFLASH\]/gi, this.app.getString('Flash_Is_Required'));
	html = html.replace(/\[FLASHMSG\]/gi, this.app.getString('It_does_not_look_like_you_have_the_<b>version_10.3</b>_or_higher_Flash_Player_plug-in_installed.'));
	$('#' + targetId).html(html);
};
com.art.photosToArt.modules.ModuleUpload.prototype.NAME = 'ModuleUpload';
com.art.photosToArt.modules.ModuleUpload.prototype.init = function() {
};
com.art.photosToArt.modules.ModuleUpload.prototype.listNotificationInterests = function() {
	return [];
};
com.art.photosToArt.modules.ModuleUpload.prototype.destroy = function() {
	$('#FlashUploaderTarget').hide();
	var bQuit = false;
	for(var i = 0; i < 10 && bQuit === false; i++)
	{
		if($('#uploadLightbox').length > 0)
		{
			$('#uploadLightbox').empty();
			$('#uploadLightbox').remove();
		}
		else
		{
			bQuit = true;
		}
	}
};
com.art.photosToArt.modules.ModuleUpload.prototype.registerEvents = function() {
	
	var _this = this;
	$('div#closeuploader').live('click', function() {
		
		try
		{
			com.art.photosToArt.modules.ModuleUpload.prototype.destroy();
		}
		catch(err)
		{
			alert('Error while destroying uploader: ' + err.message);
	        this.app.logError(err);
		}
	});
	
	$('#agreetouploadterms').live(
			'click',
			function() {
				_this.app.GATrackPageView('/p2a/upload-photos/agree-terms');
				$('#uploadertermsdiv').hide();
				$('#uploaderdiv').show();
				
				$('#uploader_flashPopup').hide();
		    	setTimeout(function(){
		    		$('#uploader_flashPopup').center(true);
		    		$('#uploader_flashPopup').show();
		        }, 100);
				
				// Set cookie so user doesn't see this dialog every time
				var cookieHelper = new com.art.core.cookie.Cookie();
				var today = new Date();
				var d = new Date(today.getFullYear(), today.getMonth(), today.getDate()+1, today.getHours(), today.getMinutes(), today.getSeconds(), today.getMilliseconds());
				cookieHelper.setCookieDictionary(
						_this.app.constants.P2A_COOKIE_DICTIONARY_PERSISTENT,
						_this.app.constants.COOKIE_NAME_ACCEPTS_TERMS, true,
						'/', cookieHelper.getCookieDomain(""), d, false);
	});
	
	$('#termsofuselink').live('mouseover', function() {
		$(this).css('cursor', 'pointer');
	});
	$('#termsofuselink').live('mouseout', function() {
		$(this).css('cursor', 'default');
	});
	$('#termsofuselink').unbind();
	$('#termsofuselink').live(
			'click',
			function() {
				PhotosToArtCore.sendNotification(new com.art.core.utils.Note(
						_this.app.events.CATALOG_GET_CONTENT, {
							contentBlockName : 'p2a/termsofusefaq'
						}, 'vo'));
			});
};
com.art.photosToArt.modules.ModuleUpload.applicationMode = function() {
};
function MultiPowUpload_onCancel(){
	com.art.photosToArt.modules.ModuleUpload.prototype.destroy();
}
function MultiPowUpload_onServerResponse(file) {
	PhotosToArtCore.sendNotification(new com.art.core.utils.Note(
			PhotosToArtCore.events.UPLOAD_COMPLETE, file.serverResponse, 'vo'));
}
function MultiPowUpload_onAddFiles(files) {
	
    for(var i=0; i<files.length; i++)
    {
        // See if I now get the loaded event so I can get the actual image dimensions
    	MultiPowUpload.generateThumbnail(files[i].id);
    	trace(i + 1 + ') Upload Added: ' + files[i].id); 
    	
    	// increment the file count
    	com.art.photosToArt.modules.ModuleUpload.totalFilesCount += 1;
    	
    }
    trace('total upload files count = ' + com.art.photosToArt.modules.ModuleUpload.totalFilesCount);
	MultiPowUpload.addPostField("persistentid",	PhotosToArtCore.getModel().user.persistentId);
	PhotosToArtCore.GATrackPageView('/p2a/upload-photos/photo-added');
	MultiPowUpload.addPostField("apikey", com.art.photosToArt.modules.ModuleUpload.apiKey);
}
function MultiPowUpload_onRemoveFiles(files) {
    for(var i=0; i<files.length; i++)
    {
    	trace(i + 1 + ') Upload Removed: ' + files[i].id); 
    	// increment the file count
    	com.art.photosToArt.modules.ModuleUpload.totalFilesCount -= 1;
    }
    trace('total upload files count = ' + com.art.photosToArt.modules.ModuleUpload.totalFilesCount);
}
function MultiPowUpload_onError(file, message) {
	if (message.indexOf('#2049') > -1) {
		message = 'Cross-domain upload not permitted without crossdomain.xml on server directory root';
	}
	var err = com.art.core.utils.LoggingManager.prototype.createError(
			'FileUploadError', 'Uploading file ' + file.name
					+ ' caused error: ' + message);
	PhotosToArtCore.logError(err);
}
function MultiPowUpload_onImageLoaded(file)
{
	var isLandscape = file.imageWidth > file.imageHeight;
	var short;
	var long;
	try
	{
		//THIS IS COMMENTED BECAUSE WE HAVE CERTAIN IMAGES WHICH ARE FAILING THIS TEST WHICH HAVE HIGH RESOLUTION
		var minSizeConfig = com.art.photosToArt.modules.ModuleUpload.getMinimumSizeConfig();
		short = isLandscape ? file.imageHeight : file.imageWidth;
		long = isLandscape ? file.imageWidth : file.imageHeight;
		minShort = minSizeConfig.Small * minSizeConfig.Dpi;
		minLong = minSizeConfig.Large * minSizeConfig.Dpi;
		if(short < minShort || long < minLong)
		{
			var msg = PhotosToArtCore.getString("Unable to process your photo") + " \"" + file.name + "\" " + PhotosToArtCore.getString("because it does not meet minimum dimension requirements");
			alert(PhotosToArtCore.getString(msg));
			MultiPowUpload.removeFile(file.id);
		}
	}
	catch(err){alert(err.message);}
}
function MultiPowUpload_onStart(){
	PhotosToArtCore.GATrackPageView('/p2a/upload-photos/initiated');
	com.art.photosToArt.modules.ModuleUpload.originalGalleryCount = PhotosToArtCore.getModel().getGalleryItemCount();
	
}
function MultiPowUpload_onComplete() {
	PhotosToArtCore.GATrackPageView('/p2a/upload-photos/completed');
	com.art.photosToArt.modules.ModuleUpload.prototype.destroy();
	window.setTimeout(function(){
		PhotosToArtCore.sendNotification(new com.art.core.utils.Note(
					PhotosToArtCore.events.UPLOAD_PROCESS_COMPLETE, {originalGalleryCount: com.art.photosToArt.modules.ModuleUpload.originalGalleryCount, totalFilesCount: com.art.photosToArt.modules.ModuleUpload.totalFilesCount}, 'vo'));
	}, 2000);
}

if($.browser.msie){
	userAgent = $.browser.version;
	userAgent = userAgent.substring(0,userAgent.indexOf('.'));
	version = userAgent;
	}
