/**
 * This component allows the user to set the area within their photo to use for the print
 * @param data
 * @param app
 */
com.art.photosToArt.components.ComponentPrintAreaSelect = function(data,app)
{	
	com.art.core.components.BaseComponent.extend(this);
	
	this.cropData = {
						 'imageItem': data.imageItem
						, 'getSelectedImageCropData' : data.getSelectedImageCropData
						, 'jsMethodToUpdateCropData' : data.jsMethodToUpdateCropData
						, 'jsMethodToGetGalleryWrapData' : data.jsMethodToGetGalleryWrapData
					 };
	this.app = app;

	this.NAME 		= com.art.photosToArt.components.ComponentPrintAreaSelect.NAME;
	this.IMAGE_BASEURL = this.app.getEnvironment().imagePath;

	this.callbacks = [];

	this.markupUtil = this.app.getMarkupUtil().getInstance(this);
	
	this.swfDirectory = com.art.photosToArt.components.ComponentPrintAreaSelect.SWF_DIRECTORY;
	
	this.clickAndDragText = data.clickAndDragText;
};


//SECTION: Component Static Properties
com.art.photosToArt.components.ComponentPrintAreaSelect.NAME = "ComponentPrintAreaSelect";
com.art.photosToArt.components.ComponentPrintAreaSelect.SWF_DIRECTORY = 'support/'; 

/**
 * @method render
 */
com.art.photosToArt.components.ComponentPrintAreaSelect.prototype.render = function()
{
	return this.getTemplate();
};
/**
 * @method registerCallbacks
 * @param name
 * @param callback
 */
com.art.photosToArt.components.ComponentPrintAreaSelect.prototype.registerCallbacks = function(name,callback)
{
	this.callbacks[name] = callback;
	//trace("callbacks:");
	//trace(this.callbacks);
};

//SECTION: Component Functions - Standard 
/**
 * @method destroy
 */
com.art.photosToArt.components.ComponentPrintAreaSelect.prototype.destroy = function()
{
    $("#" + this.markupUtil.getModuleId()).empty();
    $("#" + this.markupUtil.getModuleId()).remove();
};
/**
 * For Localization
 */
com.art.photosToArt.components.ComponentPrintAreaSelect.prototype.getClickAndDragText = function()
{
	return this.clickAndDragText;
};
/**
 * Initializes and loads the Flash movie 
 * Used as callback from ModuleTabOptions
 * @method invokeFlash
 */
com.art.photosToArt.components.ComponentPrintAreaSelect.prototype.invokeFlash = function()
{
	var imageWidth = this.cropData.imageItem.ImageInformation.LargeImage.Dimensions.Width;
	var imageHeight = this.cropData.imageItem.ImageInformation.LargeImage.Dimensions.Height;

	// 245 is width of two buttons APPLY & CANCEL.
	var pl = (imageWidth - 245) / 2;
	
	$('#' + this.markupUtil.getPrefix() + 'printarea_btn_div').css('padding-left', pl);
	$("#" + this.markupUtil.getPrefix() + "printareapopup").show();
	
	// Passing in strings representing data callbacks consumed by Flash
	var flashVars = { 
		'getSelectedImageCropData' : this.cropData.getSelectedImageCropData, 
		'jsMethodToUpdateCropData' : this.cropData.jsMethodToUpdateCropData, 
		'jsMethodToGetGalleryWrapData' : this.cropData.jsMethodToGetGalleryWrapData,
		'clickAndDragText': this.getClickAndDragText()};

    var params = { allowscriptaccess: 'always', wmode: 'transparent' };
    var attributes = { bgcolor: '#FF9900' };

    try
    {
    	swfobject.embedSWF(this.app.getEnvironment().virtualPath + 'support/ImageTools_APC.swf', 'printarea_target', imageWidth, imageHeight, "9", this.app.getEnvironment().virtualPath + "support/expressInstall.swf", flashVars, params, attributes);
    	swfobject.registerObject("printarea_target", "9");
    	$('#printarea_target').css('visibility', 'visible');
    }
    catch(err)
    {
        this.app.logError(err);
    }
};
com.art.photosToArt.components.ComponentPrintAreaSelect.prototype.registerEvents = function(module)
{
	var _this = this;
		
	// User Clicks APPLY CROP
	var prefix = _this.markupUtil.getPrefix();
	var apply = '#' + prefix + 'printareapopupapply_btn';
	var cancel = '#' + prefix + 'printareapopupcancel_btn';
	var close = '#' + prefix + 'closeprintareapopup';
	
	// //trace(apply + '  ' + cancel + '  ' + close);
	$(apply).die();
	$(apply).unbind("click");
	
	$(apply).live('click', function(){
		_this.callbacks['applycrop'](_this);
	});
	
	// User Cancels out of dialog
	$(cancel).live('click', function(){
		//trace('Cancel crop');
		_this.callbacks['cropcancel'](_this);
	});
	$(close).live('click', function(){
		//trace('Cancel crop');
		_this.callbacks['cropcancel'](_this);
	});
	
	$('#printarea_target').css('visibility', 'visible');
};

//SECTION: Component Functions - Specific to this component
/**
 * This template represents the part of the UI where we see the "Change Print Area" button,
 * unless the user image matches the print size aspect ratio perfectly.
 */
com.art.photosToArt.components.ComponentPrintAreaSelect.prototype.getTemplate = function()
{
	var returnValue = "";
	returnValue += ''
+ '   <div class="PrintAreaContent" style="background:#FFFFFF">'
+ '			<div id="printarea_target" style="visibility: visible;"></div>'				
+ '		    <div class="[NAME_BASE]printarea_btn_div" style="margin:10px 0px 10px;padding-left:[PADLEFT]px;">'
+ '		       	<div style="float:left" class="[NAME_BASE]printarea_confirm_btn">'
+ '						<div id="[NAME_BASE]printareapopupapply_btn" onmouseout="this.className=\'gold	btn_global_doubleline  btn_global link\'" '
+ '             				onmouseover="this.className=\'btn_over btn_global_doubleline btn_global link\'"'
+ '								class="gold btn_global_doubleline btn_global link" '
+ '								style="margin-right:[BM]px;padding:[BP]px;width:[BW]px;" >'
+ '							  <div class="btn_text uCase text-align-center">[APPLY]</div>'
+ '						</div>  '
+ '		    	</div>'
+ '		        <div style="float:left" class="btn_printarea_cancel">'
+ '					    <div id="[NAME_BASE]printareapopupcancel_btn" onmouseout="this.className=\'gold btn_global_doubleline  btn_global link\'"' 
+ '							onmouseover="this.className=\'btn_over  btn_global_doubleline  btn_global link\'"' 
+ '							class="gold  btn_global_doubleline  btn_global link" style="margin-left:[BM]px;padding:[BP]px;width:[BW]px;" >'
+ '					    	<div class="btn_text uCase text-align-center">[CANCEL]</div>'
+ '				   		</div>'

+ '			    </div>'
+ '			    <div class="clear"></div>'
+ '        </div>'
+ '    </div>';

	var buttonWidth = 94;
	var buttonMargin = 5;
	var buttonPadding = 8;
	returnValue = returnValue.replace(/\[BM\]/gi,  buttonMargin);
	returnValue = returnValue.replace(/\[BW\]/gi,  buttonWidth);
	returnValue = returnValue.replace(/\[BP\]/gi,  buttonPadding);
	returnValue = returnValue.replace(/\[NAME_BASE\]/gi,  this.markupUtil.getPrefix());
	returnValue = returnValue.replace(/\[IMAGE_BASEURL\]/gi,  this.app.getEnvironment().imagePath );
	returnValue = returnValue.replace(/\[APPLY\]/gi,  this.app.getString('apply').toUpperCase());
	returnValue = returnValue.replace(/\[CANCEL\]/gi,  this.app.getString('cancel').toUpperCase());
	returnValue = returnValue.replace(/\[SWF_DIRECTORY\]/gi, com.art.photosToArt.components.ComponentPrintAreaSelect.SWF_DIRECTORY);
	returnValue = returnValue.replace(/\[PADLEFT\]/gi,  this.getPadLeft(buttonWidth, buttonMargin, buttonPadding));
	
	return returnValue;
};
com.art.photosToArt.components.ComponentPrintAreaSelect.prototype.getPadLeft = function(buttonWidth, buttonMargin, buttonPadding)
{
	return (this.cropData.imageItem.ImageInformation.LargeImage.Dimensions.Width - ((buttonWidth * 2) + (buttonMargin * 2) + (buttonPadding * 4))) / 2;
};