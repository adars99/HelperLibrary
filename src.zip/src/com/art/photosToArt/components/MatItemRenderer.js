com.art.photosToArt.components.MatItemRenderer = function(width,height,imageURL,index,label)
{
	this.id					= com.art.core.utils.StringUtil.generateUID();
	this.isSelected			= false;
	this.isOver				= false;
	this.label 				= label;
	this.index 				= index;
	this.width 				= width;
	this.height				= height;
	this.hexColor;
	this.fallbackImage;
	this.template 			= "<div index='$INDEX' id='$ID' style='background-color:#FFFFFF;padding:1px;width:$Wpx;height:$Hpx;padding-top:4px;'>"+
								"<div id='$ID_container' style='background-image:url(\"$FALLBACK\");background-repeat:no-repeat; width:100px;height:100px; background-color:#$HEX_COLOR;'>"+
									"<div id='$ID_backgroundImage' style='background-image:url(\""+imageURL+"\");background-repeat:no-repeat;width:100px;height:100px;'>"+
										"<div id='$ID_border' style='width:110px;height:100px;border:1px solid #666666;display:none;'>"+
											"<div id='$ID_name' style='text-align:center;background-color:#FFFFFF;'>$NAME</div>"+
										"</div>"+
									"</div>"+
								"</div>"+
							"</div>";
};
com.art.photosToArt.components.MatItemRenderer.prototype.render = function()
{
	return this.template.replace("$W",this.width).replace("$H",this.height).replace(/\$ID/g,this.id).replace('$IW',this.width-4).replace('$IH',this.height-4).replace("$INDEX", this.index).replace("$NAME", this.label).replace("$FALLBACK", this.fallbackImage).replace("$HEX_COLOR",this.hexColor);
};

com.art.photosToArt.components.MatItemRenderer.prototype.getHoverState = function()
{
	return {"display":"block"};
};

com.art.photosToArt.components.MatItemRenderer.prototype.getDefaultState = function()
{
	return {"display":"none"};
};

com.art.photosToArt.components.MatItemRenderer.prototype.hide = function()
{
	$("#"+this.id).css(this.getDefaultState());
};

com.art.photosToArt.components.MatItemRenderer.prototype.show = function()
{
	$("#"+this.id).css(this.getHoverState());
};
com.art.photosToArt.components.MatItemRenderer.prototype.deselect = function()
{
	this.isSelected = false;
	$("#"+this.id+">div>div>div").css(this.getDefaultState());
};
com.art.photosToArt.components.MatItemRenderer.prototype.showHover = function()
{
	this.isOver = true;
	//$("#"+this.id).css(this.getHoverState());
	$("#"+this.id+">div>div>div").css(this.getHoverState());
};

com.art.photosToArt.components.MatItemRenderer.prototype.removeHover = function()
{
	this.isOver = false;
	$("#"+this.id+">div>div>div").css(this.getDefaultState());
};

com.art.photosToArt.components.MatItemRenderer.prototype.select = function()
{
	trace("MatIR select");
	this.isSelected = true;
	trace(this);
	trace(this.getHoverState());
	//$("#"+this.id).css(this.getHoverState());
	$("#"+this.id+">div>div>div").css(this.getHoverState());
};
