//CONSTRUCTOR: instantiates the instance, Every Object must implement the base
com.art.photosToArt.components.ComponentServiceTrayInfo = function(classNamePrefix,imagePath)
{	
	com.art.core.components.BaseComponent.extend(this);
	
	this.instance	= this;
    //this.serviceInfoBox = serviceInfoBox;
	this.NAME 		= com.art.photosToArt.components.ComponentServiceTrayInfo.NAME;
	this.IMAGE_BASEURL = imagePath;
	
	//this.model = model;

	this.callbacks = [];
	//this.target;
	//setting the local variable
	this.classNamePrefix = classNamePrefix;
	this.processing = false; //true when async call is in process; block additional interaction
	this.infoBoxContent = {'title' :'', 
			               'image' :'', 
			               'message' :''};
};

//SECTION: Component Static Properties
com.art.photosToArt.components.ComponentServiceTrayInfo.NAME = "ComponentServiceTrayInfo";
//SECTION: Component Static Properties
com.art.photosToArt.components.ComponentServiceTrayInfo.prototype.render = function()
{
    var template =  this.getTemplate();
	return template;
};
/**
 * registerEvents is called only once on initialization
 */

com.art.photosToArt.components.ComponentServiceTrayInfo.prototype.registerCallback = function(name,callback)
{
	this.callbacks[name] = callback;
	//trace("callbacks:");
	//trace(this.callbacks);
};

//SECTION: Component Functions - Standard 
com.art.photosToArt.components.ComponentServiceTrayInfo.prototype.init = function()
{

};

com.art.photosToArt.components.ComponentServiceTrayInfo.prototype.registerEvents = function(module)
{
	
};

//SECTION: Component Functions - Specific to this component
com.art.photosToArt.components.ComponentServiceTrayInfo.prototype.setContent = function (title, imgSrc, message)
{
      this.infoBoxContent.title = title;
      this.infoBoxContent.image = imgSrc;
      this.infoBoxContent.message = message;
};
com.art.photosToArt.components.ComponentServiceTrayInfo.prototype.getTemplate = function()
{
	var returnValue = this.template;
	
	returnValue = returnValue.replace(/\[INFOBOXCLASS\]/gi, this.classNamePrefix + 'infobox');
	returnValue = returnValue.replace(/\[INFOBOXTITLE\]/gi, this.classNamePrefix +'infoboxtitle' );
	returnValue = returnValue.replace(/\[IMGCLASS\]/gi, this.classNamePrefix +'imgclass' );
	//returnValue = returnValue.replace(/\[INFOBOXMSGCLASS\]/gi, this.classNamePrefix +'infoboxmsgclass' );
	returnValue = returnValue.replace(/\[INFOBOXMESSAGE\]/gi, this.classNamePrefix +'infoboxmessage' );
	
	//STEP: Replace strings that are phrases for translation
    returnValue = returnValue.replace(/\[INFOBOXIMAGE\]/gi,	this.infoBoxContent.image);
   returnValue = returnValue.replace(/\[TEXT_INFOBOX_TITLE\]/gi, this.infoBoxContent.title);
   returnValue = returnValue.replace(/\[TEXT_INFOBOX_MESSAGE\]/gi, this.infoBoxContent.message);
	
	return returnValue.replace('$NAME', this.NAME.toLowerCase());
	
};

com.art.photosToArt.components.ComponentServiceTrayInfo.prototype.template ='<div id="$NAME">'
	+ '<div class="[INFOBOXCLASS]" style="width:275px;">'
	+ '          <div class="[INFOBOXTITLE]">[TEXT_INFOBOX_TITLE]</div>'
	+ '      <div class="[IMGCLASS]">'
	+ '			 [INFOBOXIMAGE]'
	+ '      </div>'
	//+ '      <div class="[INFOBOXMSGCLASS]">'
	+ '			 <div class="[INFOBOXMESSAGE]">[TEXT_INFOBOX_MESSAGE]</div>'
	//+ '      </div>'
	+ '</div>'
    + '<div style="clear:both"></div>'
	+ '</div>'
	+ '<div style="clear:both"></div>';
	
	
	


