/**
*	This module is meant to make it easier to display a chunk of HTML in the ModuleLightbox
*	It will enable you to create a lightbox and display the html in 1 or 2 lines of code.
*	It depends on having a div in the current page id id "ModuleLightbox"
*/
com.art.photosToArt.components.ComponentMessagingLightbox = function(data,app)
{
	this.NAME = "ComponentMessagingLightbox";
	this.app = app;
	if(!this.app)
		//trace('ComponentMessagingLightbox - app is undefined');
	this.lightBox = {};
	this.moduleData = {
							html : data.html
							, title : data.title
							, zindex : (data.zindex ? data.zindex : '1100')
							, height : (data.height ? data.height : '200')
							, width : (data.width ? data.width 	: '400')
							, padding : (data.padding ? data.padding : '0')
					   };
	//trace('ComponentMessagingLightbox  has width of ' + this.moduleData.width);
	this.IMAGE_BASEURL = com.art.photosToArt.components.ComponentMessagingLightbox.IMAGE_BASEURL;
};

com.art.photosToArt.components.ComponentMessagingLightbox.IMAGE_BASEURL = 'http://cache1.artprintimages.com/images/photostoart/';

com.art.photosToArt.components.ComponentMessagingLightbox.prototype.render = function()
{
	var _this = this;
	var lightboxId = 'p2a_lightbox';

	try
	{
		//this.app.registerSubscriber(_this);
		this.lightBox = new com.art.core.components.LightBox(lightboxId,'body',0.4);
		this.lightBox.show();
	}
	catch(err)
	{
		//alert('From ComponentMessagingLightbox.render ' + err);
        this.app.logError(err);
	}
	
	$('#' + lightboxId).css('z-index', 1005).after(_this.getTemplate());
	
	$('#closepopup').live('click', function(){
		var selector = "#" + _this.NAME;
		//trace('Trying to ClosePopup using selector ' + selector);
    	$(selector).remove();
    	if($(selector).length > 0)
    	{
    		//trace("====ComponentMessagingLightbox NOT REMOVED");
    	}
    	_this.lightBox.close();
	});
	
};
com.art.photosToArt.components.ComponentMessagingLightbox.prototype.cleanUpAfterDeletePopup = function()
{
	// Is this being called ever?
	alert('Yes, cleanUpAfterDeletePopup is being called');
	var outerDiv = '#' + 'messagingpopup';
	$(outerDiv).remove();
	$('#ModuleLightbox').remove();
};

com.art.photosToArt.components.ComponentMessagingLightbox.prototype.getTemplate = function()
{
	// 11-2-11: removed width:290px; from lightboxtitle
	var template = ''
		+ '<div id="ComponentMessagingLightbox" style="background: none repeat scroll 0 0 #FFFFFF;[POSITIONING] z-index: 1200; display: block;position: absolute;'
	    + '          border: 1px solid #727C73;" >'
		+ '	   <div id="popuptitlebar" class="cPointer" style="height:30px;padding-top:5px;width:100%;vertical-align:middle;background: -moz-linear-gradient(center top , #FFFFFF, #EFEFDE) repeat scroll 0 0 transparent;">'               
		+ '    		<div class="floatleft p2a_matc_lightboxtitle" style="text-align:left;padding-left: 10px;">[popup_title]</div>'
		+ '    <div id="closepopup" class="floatright cpointer" >'
		+ '        <img title="close" style="padding-right:6px; padding-top:3px;" src="[IMAGE_BASEURL]/images/photostoart/close.png" alt="close">'
		+ '    </div>'
		+ '    <div class="clear"></div>'
		+ '</div>'
		+ '<div class="clear"></div>'
		+ '		<div class="popupcontent" style="text-align:left;padding: [PADDING]">'
		+ '			[popup_content]'
		+ '		    <div class="clear"></div>'
		+ '		</div>'
		+ '    <div class="clear"></div>'
		+ '</div>';
	
	template = template.replace(/\[popup_title\]/gi, this.moduleData.title);
	template = template.replace(/\[popup_content\]/gi, this.moduleData.html);
	template = template.replace(/\[IMAGE_BASEURL\]/gi, this.app.getEnvironment().imagePath);
	template = template.replace(/\[POSITIONING\]/gi, this.createPositioningForPopup() );
	template = template.replace(/\[Z-INDEX\]/gi, this.moduleData.zindex);
	template = template.replace(/\[PADDING\]/gi, this.moduleData.padding);
	return template;
};

com.art.photosToArt.components.ComponentMessagingLightbox.prototype.createPositioningForPopup = function(){
	// DO NOT set the height here.
	var docHeight = Math.max($(document).height(), $(window).height(),/* For opera: */document.documentElement.clientHeight) / 2;
	var docWidth = Math.max($(document).width(), $(window).width(), /* For opera: */document.documentElement.clientWidth) / 2;
	////trace('Popup - docHeight: ' + docHeight + ', docWidth: ' + docWidth);
	var top = Math.round(docHeight - (parseInt(this.moduleData.height)));
	var left = Math.round(docWidth - (parseInt(this.moduleData.width) * .58));
	return 'top:' + top + 'px;left:' + left + 'px;width:' + this.moduleData.width + 'px;';
};
