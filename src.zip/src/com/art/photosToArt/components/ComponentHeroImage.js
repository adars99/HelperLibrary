com.art.photosToArt.components.ComponentHeroImage = function(id, data, imagePath, enableSharingTools)
{	
	this.init();
	this.id = id;
	this.NAME 		= com.art.photosToArt.components.ComponentHeroImage.NAME;
	this.IMAGE_BASEURL = imagePath;
	this.IMAGE_SUBFOLDER = "/images/photostoart/";
	this.enableSharingTools = enableSharingTools;
	this.heroImageVo = data.urls; //this.makeHeroImageVo(data);
	this.translatedContent = data.translatedContent;
	this.IMAGE_LOADED = com.art.photosToArt.components.ComponentHeroImage.IMAGE_LOADED;
};

com.art.photosToArt.components.ComponentHeroImage.NAME = "ComponentHeroImage";
com.art.photosToArt.components.ComponentHeroImage.IMAGE_ZOOM = 'IMAGE_ZOOM';
com.art.photosToArt.components.ComponentHeroImage.IMAGE_LOADED = 'IMAGE_LOADED';

com.art.photosToArt.components.ComponentHeroImage.prototype.getHeroImageSelector = function(){ return "#"+ this.id+"_heroImage";};
com.art.photosToArt.components.ComponentHeroImage.prototype.getSuperZoomSelector = function(){ return "#"+ this.id+"_heroImageZoom";};


com.art.photosToArt.components.ComponentHeroImage.prototype.render = function()
{
	return this.getTemplate();
};

com.art.photosToArt.components.ComponentHeroImage.prototype.destroy = function()
{
    $(this.getHeroImageSelector()).empty();
    $(this.getSuperZoomSelector()).remove();
};

com.art.photosToArt.components.ComponentHeroImage.prototype.registerEvents = function(module)
{
	var _this = this;

    $(this.getHeroImageSelector()).imagesLoaded(function()
    {
    	//trace("imagesloaded!");
    	//_this.toggleLoadingImage(false);
    	//$(this).fadeIn();
    	//$('#herotools').show();
    	$(_this.getSuperZoomSelector()).removeClass('hidden');
    	if(_this.callbacks[_this.IMAGE_LOADED] != undefined)
    		_this.callbacks[_this.IMAGE_LOADED]();
    	
    });
    
    $(this.getHeroImageSelector()+ "," + this.getSuperZoomSelector()).click(function(){
    	//PhotosToArtCore.GATrackEvent(PhotosToArtCore.getEnvironment().gaPartnerCode + ' PREVIEW ' + com.art.core.tracking.GoogleAnalytics.prototype.getDelimiter() + ' LOADED');
    	if(_this.callbacks[com.art.photosToArt.components.ComponentHeroImage.IMAGE_ZOOM] != undefined)
    		_this.callbacks[com.art.photosToArt.components.ComponentHeroImage.IMAGE_ZOOM](_this);
    });
    
};

com.art.photosToArt.components.ComponentHeroImage.prototype.updateHeroImage = function()
{
	$('#herotools').hide();
	if($(this.getHeroImageSelector()).attr('src') != this.heroImageVo.imageUrlLarge)
	{
		$(this.getHeroImageSelector()).attr('src',this.heroImageVo.imageUrlLarge);
	}
};

com.art.photosToArt.components.ComponentHeroImage.prototype.setUrls = function(urls)
{
	this.heroImageVo = urls;
};

com.art.photosToArt.components.ComponentHeroImage.prototype.getZoomImageUrl = function()
{
	return this.heroImageVo.imageUrlZoom;
};

com.art.photosToArt.components.ComponentHeroImage.prototype.getTemplate = function()
{
	var share = this.enableSharingTools ? this.shareTemplate : "";
	var imagePath = this.IMAGE_BASEURL + this.IMAGE_SUBFOLDER;
	return this.template.replace(/\$ID/g,this.id).replace("$SHARE",share).replace("$IMG_PATH",imagePath).replace(/\[ZOOM\]/g, this.translatedContent.Zoom);
};

com.art.photosToArt.components.ComponentHeroImage.prototype.template = '<div id="$ID">'+
	'<img id="$ID_heroImage" src="" alt="" title="" /></div>'+
	'<br/>$SHARE'+
	'<div style="float:right;cursor:pointer;" class="hidden" id="$ID_heroImageZoom"><img src="$IMG_PATHzoom.gif" alt="[ZOOM]" title="[ZOOM]"></div>'+
	'</div>';

com.art.photosToArt.components.ComponentHeroImage.prototype.shareTemplate = '<div id="herotools">'+
	'<span id="">Share this:</span>'+
	'<div class="floatLeft addthis_toolbox addthis_default_style" addthis:url="" id="addthis_toolbox">'+
	'<a class="addthis_button_facebook"></a>'+
	'<a class="addthis_button_twitter"></a>'+
	'<a class="addthis_button_delicious"></a>'+
	'<img id="button-emailfriend" style="cursor:pointer;padding: 0 2px 0 4px;" class="floatLeft" src="" border="0" alt="Email This" title="Email This" />'+
	'|'+
	'<a class="addthis_button" addthis:url="">More</a>'+
	'</div>';

com.art.core.components.BaseComponent.extend(com.art.photosToArt.components.ComponentHeroImage.prototype);
