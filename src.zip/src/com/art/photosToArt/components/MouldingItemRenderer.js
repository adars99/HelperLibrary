com.art.photosToArt.components.MouldingItemRenderer = function(width,height,imageURL,index,label)
{
	this.id		= com.art.core.utils.StringUtil.generateUID();
	this.isSelected = false;
	this.isOver		= false;
	this.label = label;
	this.index = index;
	this.width 	= width;
	this.height	= height;
	this.template = "<div index='$INDEX' id='$ID' style='padding:1px;width:$Wpx;height:$Hpx;background-image:url(\""+imageURL+"\");background-repeat:no-repeat;background-position:1px 0px;'>"+
		"<div id='$ID_container' style='width:$IWpx;height:$IHpx;border:1px solid #666666;display:none;'>"+
			"<div id='$ID_name' style='text-align:center;background-color:#FFFFFF;'>$NAME</div>"+
			"<div style='margin-top:80px;text-align:center;background-color:#FFFFFF' id='$ID_price'></div>"+
		"</div>"+
	"</div>";
};
com.art.photosToArt.components.MouldingItemRenderer.prototype.render = function()
{
	return this.template.replace("$W",this.width).replace("$H",this.height).replace(/\$ID/g,this.id).replace('$IW',this.width-4).replace('$IH',this.height-4).replace("$INDEX", this.index).replace("$NAME", this.label);
};

com.art.photosToArt.components.MouldingItemRenderer.prototype.getHoverState = function()
{
	return {"display":"block"};
};

com.art.photosToArt.components.MouldingItemRenderer.prototype.getDefaultState = function()
{
	return {"display":"none"};
};
com.art.photosToArt.components.MouldingItemRenderer.prototype.setPrice = function(value)
{
	trace("setPrice: value:"+value);
	$("#"+this.id+"_price").html(value);
	var h = $("#"+this.id+"_name").height();
	var topMargin = h > 0 ? 80 - (h - 15) : 80;
	$("#"+this.id+"_price").css("marginTop",topMargin+"px");
		
};

com.art.photosToArt.components.MouldingItemRenderer.prototype.hide = function()
{
	$("#"+this.id).css(this.getDefaultState());
};

com.art.photosToArt.components.MouldingItemRenderer.prototype.show = function()
{
	$("#"+this.id).css(this.getHoverState());
};
com.art.photosToArt.components.MouldingItemRenderer.prototype.select = function()
{
	this.isSelected = true;
	$("#"+this.id+">div").css(this.getHoverState());
};
com.art.photosToArt.components.MouldingItemRenderer.prototype.showHover = function()
{
	trace("showHover");
	this.isOver = true;
	$("#"+this.id+">div").css(this.getHoverState());
};
com.art.photosToArt.components.MouldingItemRenderer.prototype.removeHover = function()
{
	trace("removeHover");
	this.isOver = false;
	$("#"+this.id+">div").css(this.getDefaultState());
};
com.art.photosToArt.components.MouldingItemRenderer.prototype.deselect = function()
{
	this.isSelected = false;
	$("#"+this.id+">div").css(this.getDefaultState());
};
