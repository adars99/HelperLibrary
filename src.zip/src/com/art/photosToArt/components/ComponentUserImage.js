/**
 * Component used in ModulePhotoTray, renders as <li> element which is a child of the jCarousel
 * jQuery plugin. Contains an uploaded user image, and supports item-level zoom and delete actions.
 * The component is intended to be "dumb", and the PhotoTray is supposed to be relatively knowledgeable.
 * @param imageSource
 * @param galleryId
 * @param galleryItemId
 * @param imageGuid
 * @param markupUtil
 */
com.art.photosToArt.components.ComponentUserImage = function(imageSource, zoomUrl, galleryId, galleryItemId, imageGuid, isLowRes, markupUtil, thumbHeight, languageIso, imagePath)
{
	this.init();
	this.markupUtil = markupUtil;
	this.imageData = {
						galleryId: galleryId
						, imageSource: imageSource
						, zoomUrl : zoomUrl
						, galleryItemId: galleryItemId
						, imageGuid: imageGuid
						, isLowRes: isLowRes
						, thumbHeight: thumbHeight
					 };
	
	this.isSelected = false;
	this.NAME		= com.art.photosToArt.components.ComponentUserImage.NAME;
	this.IMAGEITEM_TOPPPADDING			= '30';
	this.IMAGEITEM_MOUSEENTER			= com.art.photosToArt.components.ComponentUserImage.IMAGEITEM_MOUSEENTER;
	this.IMAGEITEM_MOUSELEAVE			= com.art.photosToArt.components.ComponentUserImage.IMAGEITEM_MOUSELEAVE;
	this.IMAGE_ZOOM						= com.art.photosToArt.components.ComponentUserImage.IMAGE_ZOOM;	
	this.IMAGE_ZOOMTOOLTIP				= String(com.art.photosToArt.components.ComponentUserImage.IMAGE_ZOOMTOOLTIP).replace("[LANG]", languageIso.toUpperCase());
	this.IMAGE_DELETE					= com.art.photosToArt.components.ComponentUserImage.IMAGE_DELETE;
	this.IMAGE_DELETETOOLTIP			= String(com.art.photosToArt.components.ComponentUserImage.IMAGE_DELETETOOLTIP).replace("[LANG]", languageIso.toUpperCase());
	this.IMAGE_WARNING					= com.art.photosToArt.components.ComponentUserImage.IMAGE_WARNING;
	this.IMAGE_BASEURL					= imagePath + com.art.photosToArt.components.ComponentUserImage.IMAGE_BASEURL;
	this.IMAGE_LOWRESWARNING			= com.art.photosToArt.components.ComponentUserImage.IMAGE_LOWRESWARNING;
	this.USER_IMAGE_DELETE				= com.art.photosToArt.components.ComponentUserImage.USER_IMAGE_DELETE;
	

};

//SECTION: Component Event Definitions
com.art.photosToArt.components.ComponentUserImage.IMAGE_BASEURL = '/images/PhotosToArt/';
com.art.photosToArt.components.ComponentUserImage.IMAGEITEM_MOUSEENTER = 'imageitem_mouseenter';
com.art.photosToArt.components.ComponentUserImage.IMAGEITEM_MOUSELEAVE = 'imageitem_mouseleave';
com.art.photosToArt.components.ComponentUserImage.IMAGE_ZOOM = 'zoom_off.png';
com.art.photosToArt.components.ComponentUserImage.IMAGE_ZOOMTOOLTIP = 'zoom_tag_[LANG].gif';
com.art.photosToArt.components.ComponentUserImage.IMAGE_DELETE = 'delete_off.png';
com.art.photosToArt.components.ComponentUserImage.IMAGE_DELETETOOLTIP	= 'delete_tag_[LANG].gif';
com.art.photosToArt.components.ComponentUserImage.IMAGE_LOWRESWARNING = 'warning.gif';
com.art.photosToArt.components.ComponentUserImage.USER_IMAGE_CLICK = 'userimageclicked';
com.art.photosToArt.components.ComponentUserImage.USER_IMAGE_ZOOM = 'userimagezoom';
com.art.photosToArt.components.ComponentUserImage.USER_IMAGE_DELETE = 'userimagedelete';
com.art.photosToArt.components.ComponentUserImage.PREFIX			= 'p2a_cui_';

//SECTION: Component Static Properties
com.art.photosToArt.components.ComponentUserImage.NAME = "ComponentUserImage";

//SECTION: Required Methods
/**
 * Attaches event handlers to UserImage. Add callbacks prior to calling this.
 * Use this method only for individual objects - not for classes.
 * @method registerEvents
 */
com.art.photosToArt.components.ComponentUserImage.prototype.registerEvents = function()
{
	var _this = this;
	var _namePrefix = com.art.photosToArt.components.ComponentUserImage.PREFIX;
	//p2a_cui_lowres_0DAEB933-DD56-4583-926B-0B09900E9288
	if(this.imageData.isLowRes)
	{
		//trace('ComponentUserImage is low res');
		var lowResSelector = '#p2a_cui_lowres_' + this.imageData.imageGuid;
		$(lowResSelector).removeClass('hidden');
		var outerdiv = $(lowResSelector).parent().parent();
		if(!outerdiv.hasClass('lowres'))
		{
			outerdiv.addClass('lowres');
		}
	}
	
	var cssObj = {};
	var imgDiv;
	if(this.imageData.thumbHeight !== 160)
	{
		imgDiv = $('#p2a_mpt_container').find('[src="' + this.imageData.imageSource + '"]');
		cssObj = {
			'margin-top': parseInt((160 - this.imageData.thumbHeight) / 2) + 'px',
			'text-align':'center'
		};
		imgDiv.css(cssObj); 
	}
	
	//NOTE: Here we select a particular UserImage
	var outerImageDivSelector = '#' + _namePrefix + 'guid_' + _this.imageData.imageGuid;
	$(outerImageDivSelector).live('click', function() {
		if($(this).hasClass('NO_SELECT'))
		{
			return false;
		}
		//NOTE: only do this if not already selected. Cannot use the class name to indicate this due to the mouseover effect.
		var selected = $(this).attr('selected');
		if(!selected)
		{
			//NOTE: remove selected class from other images
			$('.p2a_cui_outer_div').each(function(){
				//var id = $(this).attr('id');
				////trace('Removing selection from ' + id);
				$(this).removeClass(_namePrefix + 'outer_selected');
				$(this).removeAttr('selected');
			});
			
			//NOTE: make this image selected. Keeping TWO classes for selection to prevent interference from mouse over effects
			$(this).addClass(_namePrefix + 'outer_selected');
			$(this).attr('selected', 'selected');
			
			// Call back to the Module. Need to prevent adding and readding the same events and triggers to elements
			if(_this.callbacks[com.art.photosToArt.components.ComponentUserImage.USER_IMAGE_CLICK] === undefined)
			{
				//trace('Callback is undefined');
			}
			_this.callbacks[com.art.photosToArt.components.ComponentUserImage.USER_IMAGE_CLICK](_this);
		}
		else
		{
			//trace('Image Click: Nothing needed to be changed');
		}
	});
	$('#' + _namePrefix + 'btnzoom_' + this.imageData.imageGuid).die('click');
    $('#' + _namePrefix + 'btnzoom_' + this.imageData.imageGuid).live('click', function(){
    	////trace('componentuserimage = trying to zoom');
    	$(outerImageDivSelector).addClass('NO_SELECT');
    	if(_this.callbacks[_this.IMAGE_ZOOM] != undefined)
    		_this.callbacks[_this.IMAGE_ZOOM](_this);
    }); 
    $('#' + _namePrefix + 'btndelete_' + this.imageData.imageGuid).die('click');
    $('#' + _namePrefix + 'btndelete_' + this.imageData.imageGuid).live('click', function(){
    	// FIRST - stop the image click handler to prevent the image click
    	// Must put it back if the user cancels the delete
    	$(outerImageDivSelector).addClass('NO_SELECT');
    	if(_this.callbacks[_this.USER_IMAGE_DELETE] != undefined)
    		_this.callbacks[_this.USER_IMAGE_DELETE](_this);
    });
};

/**
 * This method is for binding markup elements on a one-time basis - like an initializer for all UserImages and 
 * 	the photo tray.
 * @method bindOneTimeEvents
 */
com.art.photosToArt.components.ComponentUserImage.prototype.bindOneTimeEvents = function()
{
	var _namePrefix = com.art.photosToArt.components.ComponentUserImage.PREFIX;

	/*****************Image Tray mouse over actions *******************/
	var zoomSelector = '[id^="' +  _namePrefix + 'btnzoom"]';
	var deleteSelector = '[id^="' +  _namePrefix + 'btndelete"]';
	var tooltipSelector = '[name="tooltip"]';

	// Pre-select first item. Note that the class for Clicks and for mouseovers are different
	$('#' + _namePrefix + 'guid_' + this.imageData.imageGuid).addClass(_namePrefix + 'outer_selected');
	
	$('.' + _namePrefix + 'outer_div').live('mouseover', function() {
		$(this).addClass(_namePrefix + 'outer_sel');
		
		// Show the zoom image and the delete image
		$(this).find('.' + _namePrefix + 'toolbox').removeClass('hidden').find('img[class$="img"]').show();
		$(this).find('.' + _namePrefix + 'toolbuttons').removeClass('hidden').show();
		$(this).find('.' + _namePrefix + 'toolbtn_div').removeClass('hidden').show();
    });
    $('.' + _namePrefix +'outer_div').live('mouseout', function() {
    	$(this).removeClass(_namePrefix +'outer_sel');
		// Show the zoom image and the delete image
		$(this).find('.' + _namePrefix + 'toolbox').addClass('hidden').find('img[class$="img"]').hide();
		$(this).find('.' + _namePrefix + 'toolbuttons').addClass('hidden').hide();
		$(this).find('.' + _namePrefix + 'toolbtn_div').addClass('hidden').hide();
    });
    $(zoomSelector).live('mouseover', function() {
    	$(this).css('cursor', 'pointer');
    	$(this).find(':last-child').removeClass('hidden').show();
        if ($(zoomSelector + " > .p2a_cui_tool_img").attr('src').indexOf('_on.png' < 0))
        	$(zoomSelector + " > .p2a_cui_tool_img").attr('src',
                    $(zoomSelector + " > .p2a_cui_tool_img").attr('src').replace('_off.png','_on.png'));
    });
    $(zoomSelector).live('mouseout', function() {
    	$(this).css('cursor', 'auto');
    	$(this).find(':last-child').addClass('hidden').hide();
        if ($(zoomSelector + " > .p2a_cui_tool_img").attr('src').indexOf('_off.png' < 0))
            $(zoomSelector + " > .p2a_cui_tool_img").attr('src',
                    $(zoomSelector + " > .p2a_cui_tool_img").attr('src').replace('_on.png','_off.png'));

    });
    $(deleteSelector).live('mouseover', function() {
    	$(this).find(tooltipSelector).removeClass('hidden').show();//.attr('style','left:75px');
        if ($(deleteSelector + " > .p2a_cui_tool_img").attr('src').indexOf('_on.png' < 0))
            $(deleteSelector + " > .p2a_cui_tool_img").attr('src',
                    $(deleteSelector + " > .p2a_cui_tool_img").attr('src').replace('_off.png','_on.png'));
    });
    $(deleteSelector).live('mouseout', function() {
    	$(this).find(tooltipSelector).addClass('hidden').hide();
        if ($(deleteSelector + " > .p2a_cui_tool_img").attr('src').indexOf('_off.png' < 0))
            $(deleteSelector + " > .p2a_cui_tool_img").attr('src',
                    $(deleteSelector + " > .p2a_cui_tool_img").attr('src').replace('_on.png','_off.png'));
    });
    
    $('.p2a_cui_image').addDropShadow('angle');   
    
};
/**
 * Render is the method called by the parent object to return the html markup of this item.
 * @returns
 */
com.art.photosToArt.components.ComponentUserImage.prototype.render = function()
{
	return this.getTemplate();
};
/**
 * Actually renders the markup for this item.
 * @returns {String}
 */
com.art.photosToArt.components.ComponentUserImage.prototype.getTemplate = function(){
	var template = '<li style="width:182px;height:200px;">' 
	+ '<div  id="[NAME_BASE]guid_[IMAGE_GUID]" class="[NAME_BASE]outer_div" >'
	+ '		<div class="[NAME_BASE]image_div" >'
	+ '			<img style="[IMAGE_CSS]"  class="[NAME_BASE]image" src="[USER_IMAGE]" />'
	+ '		</div>'
	+ '		<div id="[NAME_BASE]lowres_[IMAGE_GUID]" class="[NAME_BASE]lowres hidden" style="position:absolute;top:25px;left:148px;">'
	+ '   		<img class="[NAME_BASE]lowreserror_img" src="[LOWRES_WARNING_IMAGE]" />'
	+ '		</div>'
	+ ' 	<div class="[NAME_BASE]toolbox hidden" >'
	+ '		</div>'
	+ ' <div class="[NAME_BASE]toolbuttons" >'
	+ '		<div style="cursor:pointer" class="[NAME_BASE]toolbtn_div hidden [NAME_BASE]zoombtn" id="[NAME_BASE]btnzoom_[IMAGE_GUID]" >'
	+ ' 		<img  class="[NAME_BASE]tool_img" src="[IMAGE_ZOOM]" />'
	+ ' 		<img name="tooltip" class="[NAME_BASE]tool_tt hidden" src="[IMAGE_ZOOMTOOLTIP]" />'
	+ '		</div>'
	+ '		<div style="cursor:pointer" class="[NAME_BASE]toolbtn_div [NAME_BASE]deletebtn hidden"  id="[NAME_BASE]btndelete_[IMAGE_GUID]">'
	+ ' 		<img  class="[NAME_BASE]tool_img" src="[DELETE_IMAGE]" />'
	+ ' 		<img style="margin-left:45px" name="tooltip" class="[NAME_BASE]tool_tt hidden"  src="[IMAGE_DELETETOOLTIP]" />'
	+ ' 	</div>'
	+ '  </div>'
	+ '	</div>'
	+ '</li>';
	
	var prefix = com.art.photosToArt.components.ComponentUserImage.PREFIX; 
	template = template.replace(/\[NAME_BASE\]/gi,			prefix);
	template = template.replace(/\[USER_IMAGE\]/gi,			this.imageData.imageSource);
	template = template.replace(/\[IMAGE_GUID\]/gi,			this.imageData.imageGuid);
	template = template.replace(/\[IMAGE_ZOOM\]/gi, 		this.IMAGE_BASEURL + this.IMAGE_ZOOM);
	template = template.replace(/\[IMAGE_ZOOMTOOLTIP\]/gi,	this.IMAGE_BASEURL + this.IMAGE_ZOOMTOOLTIP);
	template = template.replace(/\[DELETE_IMAGE\]/gi,		this.IMAGE_BASEURL + this.IMAGE_DELETE);
	template = template.replace(/\[IMAGE_DELETETOOLTIP\]/gi, this.IMAGE_BASEURL + this.IMAGE_DELETETOOLTIP);
	template = template.replace(/\[LOWRES_WARNING_IMAGE\]/gi, this.IMAGE_BASEURL + this.IMAGE_LOWRESWARNING);
	
//	if(!$.browser.msie){
//		template = template.replace(/\[IMAGE_CSS\]/gi, 'margin-top:20px');
//	}
	
	return template;
};

com.art.core.components.BaseComponent.extend(com.art.photosToArt.components.ComponentUserImage.prototype);

