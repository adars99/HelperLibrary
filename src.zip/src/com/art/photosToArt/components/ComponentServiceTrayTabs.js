/**
 * General Description for this thing here.
 * @class ComponentServiceTrayTabs
 * @param serviceList A list of available services
 * @param app
 */
com.art.photosToArt.components.ComponentServiceTrayTabs = function(serviceList, serviceListMaster, app)
{	
	com.art.core.components.BaseComponent.extend(this);
	
	this.app = app;
	this.serviceListMaster = serviceListMaster;
	this.serviceList = serviceList;
	this.NAME 		= com.art.photosToArt.components.ComponentServiceTrayTabs.NAME;
	this.IMAGE_BASEURL = this.app.getEnvironment().imagePath;
	
	//this.model = model;

	this.callbacks = [];
	//this.target;

	this.processing = false; //true when async call is in process; block additional interaction
	
	//NOTE: need to use serviceList to see if a service is supported. Need to check mapping between global consts
	// and this list. 
	this.tabs = {};
	var counter = -1;
	for( var property in this.serviceList) //  (var i = 0; i < this.serviceList.length; i++)
	{
		if(typeof this.serviceList[property] == "object")
		{
			counter++;
			
			switch(this.serviceList[property].name)
			{
				case this.serviceListMaster.canvasMuseum.name:
					if(this.tabs.CANVAS == undefined)
						this.tabs.CANVAS = this.makeTabObject(this.serviceListMaster.canvasMuseum.name, this.app.getString('Canvas'), counter, 'SelectCanvas',this.IMAGE_BASEURL + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_SUBFOLDER + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_CANVAS, true);
					break;
				case this.serviceListMaster.canvasGallery.name :
					if(this.tabs.CANVAS == undefined)
						this.tabs.CANVAS = this.makeTabObject(this.serviceListMaster.canvasGallery.name, this.app.getString('Canvas'), counter, 'SelectCanvas',this.IMAGE_BASEURL + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_SUBFOLDER + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_CANVAS, true);
					break;
				case this.serviceListMaster.framing.name :
					this.tabs.FRAMING = this.makeTabObject(this.serviceListMaster.framing.name, this.app.getString('Framing'), counter, 'SelectFraming',this.IMAGE_BASEURL + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_SUBFOLDER + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_FRAMING);
					break;
				case this.serviceListMaster.mounting.name :
					this.tabs.WOOD_MOUNT = this.makeTabObject(this.serviceListMaster.mounting.name, this.app.getString('Wood_Mounting'), counter, 'SelectWoodMount', this.IMAGE_BASEURL + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_SUBFOLDER + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_WOODMOUNT);
					break;
				case this.serviceListMaster.acrylic.name :
					this.tabs.ACRYLIC = this.makeTabObject(this.serviceListMaster.acrylic.name, this.app.getString('Acrylic'), counter, 'SelectAcrylic', this.IMAGE_BASEURL + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_SUBFOLDER + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_ACRYLIC);
					break;
				case this.serviceListMaster.printOnly.name :
					this.tabs.PRINT_ONLY = this.makeTabObject(this.serviceListMaster.printOnly.name, this.app.getString('Print_Only'), counter, 'SelectPrintOnly', this.IMAGE_BASEURL + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_SUBFOLDER + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_PRINT_ONLY);
					break;
			}
		}
	}
	// this.markupUtil.buttonStates.ACTIVE
	// this.markupUtil.getName(theName ('tab'),button state (if null, assumes ID not class))
	this.markupUtil = this.app.getMarkupUtil().getInstance(this);
	
	this.IdNameForTabsTray = this.markupUtil.getName('tabs');
	this.ClassNameForSelectedTab = this.markupUtil.getName('tab',this.markupUtil.buttonStates.SELECTED);
    this.ClassNameForInactiveTab = this.markupUtil.getName('tab',this.markupUtil.buttonStates.INACTIVE);
    this.ClassNameForActiveTab = this.markupUtil.getName('tab',this.markupUtil.buttonStates.ACTIVE);
    this.ClassNameForOverTab = this.markupUtil.getName('tab', this.markupUtil.buttonStates.OVER);
    
    this.ClassNameForActiveDownArrow = this.markupUtil.getName('downarrow', this.markupUtil.buttonStates.ACTIVE);
    this.ClassNameForSelectedDownArrow = this.markupUtil.getName('downarrow', this.markupUtil.buttonStates.SELECTED);
    this.ClassNameForOverDownArrow = this.markupUtil.getName('downarrow', this.markupUtil.buttonStates.OVER);
};


//SECTION: Component Static Properties
com.art.photosToArt.components.ComponentServiceTrayTabs.NAME = "ComponentServiceTrayTabs";


//SECTION: Component Static Properties
com.art.photosToArt.components.ComponentServiceTrayTabs.SERVICETRAYITEM_MOUSEENTER = 'servicetrayitem_mouseenter';
com.art.photosToArt.components.ComponentServiceTrayTabs.SERVICETRAYITEM_MOUSELEAVE = 'servicetrayitem_mouseleave';

com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_SUBFOLDER = '/images/photostoart/';
com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_FRAMING = 'services_icons_framing.png';
com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_TAB_ARROW = 'down_arrow.gif';
com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_CANVAS = 'services_icons_canvas.png';
com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_WOODMOUNT = 'mounting_icon.png';
com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_ACRYLIC = 'acrylic_icon.png';
com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_PRINT_ONLY = 'print_only_icon.png';

com.art.photosToArt.components.ComponentServiceTrayTabs.NAME_PREFIX = 'p2a_st_';


com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.render = function()
{
	this.registerEvents();
	return this.getTemplate();
};
/**
 * registerEvents is called only once on initialization
 */


com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.registerCallback = function(name,callback)
{
	this.callbacks[name] = callback;
	//trace("callbacks:");
	//trace(this.callbacks);
};

//SECTION: Component Functions - Standard 
com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.destroy = function()
{
	$(this.NAME_PREFIX + 'tab').die();
	$(this.NAME_PREFIX + 'tabs').empty();
	$(this.NAME_PREFIX + 'tabs').remove();
};

com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.registerEvents = function()
{
	var tabName;
	var _this = this;
	
	$('.'+this.ClassNameForActiveTab).live('click', function()
    {	
        if (_this.callbacks.tabclick)
            _this.callbacks['tabclick'](this);			

		if(!$(this).hasClass(_this.ClassNameForSelectedTab) && !$(this).hasClass(_this.ClassNameForInactiveTab))
		{
			//STEP: Important this is one of the first things done after the check for if it is already active
			$('.'+_this.ClassNameForActiveTab).removeClass(_this.ClassNameForSelectedTab);
			$('.' + _this.ClassNameForActiveDownArrow).removeClass(_this.ClassNameForSelectedDownArrow);
			
			$(this).addClass(_this.ClassNameForSelectedTab);
			$("#" + this.id + ' > .'+_this.ClassNameForActiveDownArrow).addClass(_this.ClassNameForSelectedDownArrow);
		}
		// value will be like 'F' (for framing)
		var serviceid = _this.getItemServiceCode($(this).attr('serviceid'));
		//_this.app.GATrackEvent('ServiceChanged:' + serviceid);
		_this.app.GATrackPageView('/p2a/create/change-service-option');
    });			
	//EVENTS FOR OBJECTS - Mouseout
	$('.'+this.ClassNameForActiveTab).live('mouseout', function() {
		$(this).removeClass(_this.ClassNameForOverTab);
		$(this).find('.' + _this.ClassNameForActiveDownArrow).removeClass(_this.ClassNameForOverDownArrow);
	});	
	//EVENTS FOR OBJECTS - Mouseover
	$('.'+this.ClassNameForActiveTab).live('mouseover', function() {
		////trace(_this.NAME + ' ' + tabName +  '_over!');
		$(this).addClass(_this.ClassNameForOverTab);
		$(this).find('.' + _this.ClassNameForActiveDownArrow).addClass(_this.ClassNameForOverDownArrow);
	});
};
com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.getItemServiceCode = function(label)
{
	try
	{
		var result = this.app.getModel().data.serviceTypes[this.camelCaseFromPascalCase(label)].itemServiceCode;
		return result;
	}
	catch(err)
	{
		//trace('ComponentServiceTrayTabs.getItemServiceCode: ' + err.message);
	}
	 
};
com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.camelCaseFromPascalCase = function(anyString)
{
	var result = anyString.substring(0,1).toLowerCase() + anyString.substring(1); 
	return result;
};
//SECTION: Component Functions - Specific to this component
com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.makeTabObject = function (tabId, tabName, tabOrder, tabMethod, imageSource, isDefault)
{
	if (isDefault === undefined)
	{
		isDefault = false;
	}
	return {'id':tabId,'name':tabName,'order':tabOrder,'method': tabMethod, 'imageSource' : imageSource, 'isdefault': isDefault};
};

com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.getTabsCount = function(){
	var count = 0; 
	for (var property in this.tabs) {
	    count++;
	  }
	return count;
};

com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.selectTab = function (tab)
{
	if(!(this.getTabElementReference(tab).hasClass(this.ClassNameForSelectedTab)) && !(this.getTabElementReference(tab).hasClass(this.ClassNameForInactiveTab)))
	{
		//STEP: Important this is one of the first things done after the check for if it is already active
		
		////trace('ACTIVE class: ' + '.'+this.ClassNameForActiveTab);
		
		$('.'+this.ClassNameForActiveTab).removeClass(this.ClassNameForSelectedTab);
		//this.getTabElementReference(tab).removeClass(this.ClassNameForInactiveTab);
		$('.' + this.ClassNameForActiveDownArrow).removeClass(this.ClassNameForSelectedDownArrow);
		
		this.getTabElementReference(tab).addClass(this.ClassNameForSelectedTab);
		//this.getTabElementReference(tab).find('.' + this.ClassNameForActiveDownArrow).show();
		this.getTabElementReference(tab).find('.'+this.ClassNameForActiveDownArrow).addClass(this.ClassNameForSelectedDownArrow);
	}
};

com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.selectTabByMethodName = function (methodName)
{
	$('.servicetraytabli').removeClass('servicetraytabliselected');
	var tabToSelect = null;
	for (var eachTab in this.tabs)
	{
		if(this.tabs[eachTab].method === methodName)
		{
			tabToSelect = this.tabs[eachTab];
			break;
		}
	}
	if (tabToSelect !== null)
		this.getTabElementReference(tabToSelect).addClass('servicetrayliselected');
};


com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.deactivateTabs = function (tabs)
{
	//this.activateTabs([this.tabs.SIMILAR,this.tabs.ARTIST, this.tabs.COLOR, this.tabs.SUBJECT, this.tabs.EXACT]);
	//STEP: tabs is expected to be an array
	for (var i = 0; i < tabs.length; i++)
	{
		this.getTabElementReference(tabs[i]).addClass('servicetraytabliinactive');
	}
};

com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.activateTabs = function (tabs)
{
	//this.deactivateTabs([this.tabs.SIMILAR,this.tabs.ARTIST, this.tabs.COLOR, this.tabs.SUBJECT, this.tabs.EXACT]);
	//STEP: tabs is expected to be an array
	for (var i = 0; i < tabs.length; i++)
	{
		this.getTabElementReference(tabs[i]).removeClass('servicetraytabliinactive');
	}
};

com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.click = function (tab)
{
	this.getTabElementReference(tab).trigger('click');
};

com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.getTabElementReference = function(tab)
{
	return $('.' + this.ClassNameForActiveTab + ':eq('+ tab.order + ')');
};

com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.getTabByMethodName = function(methodName)
{
	for (var eachTab in this.tabs)
	{
		if (this.tabs[eachTab].method == methodName)
		{
			return this.tabs[eachTab];
			break;
		}
	}
	return null;
};

com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.getTabByOrder = function(order)
{
	////trace('tabs length: ' + this.tabs.length);
	for (var eachTab in this.tabs)
	{
		////trace('testing tab: '+ this.tabs[eachTab].name + " : " + this.tabs[eachTab].order);
		if (this.tabs[eachTab].order == order)
		{
			return this.tabs[eachTab];
		}
	}
};

com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.hideTab = function(tab)
{
	var tabElement = this.getTabElementReference(tab);
	tabElement.hide();
};

com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.showTab = function(tab)
{
	var tabElement = this.getTabElementReference(tab);
	tabElement.show();
};

com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.getSelectedMethod = function()
{
	var selectedMethod = $('.servicetraytabliselected').attr('method');
	//trace('getSelectedMethod: ' + selectedMethod);
	return selectedMethod;
};

com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.getSelectedMethodId = function()
{
	var selectedMethodId = $('.servicetraytabliselected').attr('id');
	//trace('getSelectedMethod: ' + selectedMethod);
	return selectedMethodId;
};
com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.serviceIsSupported = function(tab)
{
	//NOTE: determine whether this service tab should be included in the markup
	for(var property in this.serviceList) //(var i = 0; i < this.serviceList.length; i++)
	{
		if(typeof this.serviceList[property] == "object")
		{
			if(this.serviceList[property].name === tab.id)
			{
				return true;
			}
		}
	}
	return false;
};
com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.getTabByConfigurationValue = function(configurationValue)
{
    switch(configurationValue.toLowerCase())
    {   case "canvas":
        case "canvasmuseum":
        case "canvasmw":
        case "canvasgallery":
        case "canvasgw":
        case "gw":
        case "mw":
        case PhotosToArtCore.constants.SERVICE_TYPE_CANVAS :
            return this.tabs.CANVAS;
            break;
        case "framing":
        case PhotosToArtCore.constants.SERVICE_TYPE_FRAMING :
            return this.tabs.FRAMING;
            break;
        case "mount":
        case "wood_mount":
        case "wood mount":
        case "mounting":
        case PhotosToArtCore.constants.SERVICE_TYPE_WOODMOUNTING :
            return this.tabs.WOOD_MOUNT;
            break;
        case "acrylic":
        case PhotosToArtCore.constants.SERVICE_TYPE_ACRYLIC :
            return this.tabs.ACRYLIC;
            break;
        case "printonly":
        case "print_only":
        case "print only":
        case "print":
        case PhotosToArtCore.constants.SERVICE_TYPE_PRINTONLY :
            return this.tabs.PRINT_ONLY;
            break;
        default:
            return this.tabs.CANVAS;
    }
};
com.art.photosToArt.components.ComponentServiceTrayTabs.prototype.getTemplate = function()
{
	var returnValue  = "<ul id='" + this.IdNameForTabsTray + "'>";
	var tab;
	////trace('tabs length: ' + this.tabs.length);
	var activeClass = '';
	var downArrow = this.IMAGE_BASEURL + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_SUBFOLDER + com.art.photosToArt.components.ComponentServiceTrayTabs.IMAGE_TAB_ARROW;
	for (var i = 0; i < this.getTabsCount(); i++)
	{
		// NOTE - tabs are ONE-based
		tab = this.getTabByOrder(i);

		if(this.serviceIsSupported(tab))
		{
			//NOTE: IsDefault needs to be overruled here by the user who has returned and was working with particular service
			if (tab.isdefault==true)
				activeClass = this.ClassNameForSelectedTab; 
			
			var styleAttr = '';
			
			returnValue += '<li class="' + this.ClassNameForActiveTab + '" id="' + this.ClassNameForActiveTab+i + '" serviceid="' + tab.id + '">'
			    + '<div class="' + this.markupUtil.getName('innerservicediv', this.markupUtil.buttonStates.ACTIVE) + '">'
				+ '		<img title="' + tab.name + '" alt="' + tab.name + '" src="' + tab.imageSource + '" class="' + this.markupUtil.getName('imgtab',this.markupUtil.buttonStates.ACTIVE) + '">'
				+ '		<div class="clear"></div>'
				+ '		<div class="' + this.markupUtil.getName('servicetitle',this.markupUtil.buttonStates.ACTIVE)+  '">' + tab.name + '</div>' 
				+ '</div>'
				+ '<div id="' + this.markupUtil.getName('downarrow'+i) + '" class="' + this.markupUtil.getName('downarrow',this.markupUtil.buttonStates.ACTIVE) + '"><img title="" alt="" src="' + downArrow + '" width="158" height="17"></div>'
				+ '</li>';
		}
	}
	//rgb(186, 188, 190)
	returnValue += "</ul>"
				+ '<div style="position:relative;border-top: 1px solid #8C929C;top:119px; #top:118px;"></div>'; //This creates a consistent line below the tabs
	return returnValue;
	
};

