com.art.photosToArt.components.ComponentAvailableSizePicker = function(target, sizeData, isSelectedImageLandscape, selectedSizeId, imagePath, markupNames, doConvertToCm, translatableContent)
{	
	com.art.core.components.BaseComponent.extend(this);
	
	this.NAME 		= com.art.photosToArt.components.ComponentAvailableSizePicker.NAME;
	this.IMAGE_BASEURL = imagePath;

	this.callbacks = [];
	this.target = target;
	
	this.markup = {componentName : this.NAME, closeButtonId : 'close-panel', sizeSelector: 'lightbox-sizeselector'};
	if (markupNames != undefined)
		this.markup = markupNames;
	
	this.translatableContent = translatableContent;
	
	this.componentInput = { sizeData : sizeData, isSelectedImageLandscape : isSelectedImageLandscape, selectedSizeId : selectedSizeId, doConvertToCm : doConvertToCm };
	
	this.images = 
	{
            imageCloseWindow : this.IMAGE_BASEURL  + "/images/photostoart/close.png"
            ,imageIconRectangle : this.IMAGE_BASEURL  + "/images/photostoart/icon_rectangle_landscape.gif"
            ,imageIconSquare : this.IMAGE_BASEURL  + "/images/photostoart/icon_square_landscape.gif"
            ,imageIconPanorama : this.IMAGE_BASEURL  + "/images/photostoart/icon_panorama_landscape.gif"	
	};
	
	this.availableSizeGrouping = { Unknown : 0,BestFit : 1,Rectangle : 2,Square : 3,Panorama : 4 };
	
	this.SizeGroups = [{id:1,label:'BestFit'},{id:2,label:'Rectangle'},{id:3,label:'Square'},{id:4,label:'Panorama'}];
	
};

//SECTION: Component Static Properties
com.art.photosToArt.components.ComponentAvailableSizePicker.NAME = "ComponentAvailableSizePicker";

com.art.photosToArt.components.ComponentAvailableSizePicker.prototype.render = function(zIndex)
{
    //trace("Begin rendering Available Size component");
	$("#" + this.target).html(this.getTemplate(zIndex));
	$("#" + this.markup.componentName).center(true);
    //trace("END rendering Available Size component");
};

com.art.photosToArt.components.ComponentAvailableSizePicker.prototype.registerCallback = function(name,callback)
{
	this.callbacks[name] = callback;
};

//SECTION: Component Functions - Standard 
com.art.photosToArt.components.ComponentAvailableSizePicker.prototype.destroy = function()
{
    $("#" + this.markup.componentName).empty();
    $("#" + this.markup.componentName).remove();
};

com.art.photosToArt.components.ComponentAvailableSizePicker.prototype.registerEvents = function()
{
	var _this = this;
		
	//EVENTS FOR OBJECTS - Click
	$("#" + this.markup.closeButtonId).bind('click', function()
    {
		_this.destroy();
        if (_this.callbacks.close)
            _this.callbacks['close']();	
    });
	
    $('ul.sizelistclass > li').bind('click',function()
	{
    	PhotosToArtCore.GATrackPageView('/p2a/create/select-size');
        var id = $(this).attr('sizeid');
        var label = $(this).attr('label');
            if (_this.callbacks.sizeclick)
                _this.callbacks['sizeclick'](id,label);
        $("#" + _this.markup.closeButtonId).click();
    });
};

/**
= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =
BEGIN - SECTION: Available Size PopUp
**/
/**
Return all sizes for popup window when user hits 'more sizes'
**/
com.art.photosToArt.components.ComponentAvailableSizePicker.prototype.getSizeGroupings = function()
{
    var h = {};
    //skip "BestFit"
    for (var x = 1; x < this.SizeGroups.length; x++)
    {
        h[this.SizeGroups[x].label] = this.getMatchingSizes(this.SizeGroups[x].id);
    }
    return h;
};
//get sizes in groups also include best match per business
com.art.photosToArt.components.ComponentAvailableSizePicker.prototype.getMatchingSizes = function(groupID)
{
    var tmp = [];
    var obj = this.componentInput.sizeData; 

    for (var eachIndex in obj)
    {
        var group = obj[eachIndex].Group;
        if (group.indexOf(groupID) > -1)
        {
            var w = obj[eachIndex].Small;
            var h = obj[eachIndex].Large;
            var label = com.art.core.utils.StringUtil.formatDimensions(w,h,this.componentInput.doConvertToCm); // w + " x " + h; //TODO: Make the CORE call for formatting the dimensions this.localizeDimensionDisplay(w, h);
            tmp.push({ small: w, large: h, id: obj[eachIndex].PodConfigId, label: label});
        }
    }
    tmp.sort(this.sortSizes);
    return tmp;
};

com.art.photosToArt.components.ComponentAvailableSizePicker.prototype.sortSizes = function(a, b)
{
    return ((Number(a.small) < Number(b.small)) ? -1 : ((Number(a.small) > Number(b.small)) ? 1 : ((Number(a.large) < Number(b.large)) ? -1 : 1)));
};

com.art.photosToArt.components.ComponentAvailableSizePicker.prototype.initAllSizesPanel = function()
{
	var isLandscape, sizeData, selectedPodConfigId, imageDomain;
	isLandscape = this.componentInput.isSelectedImageLandscape;
	sizeData = this.getSizeGroupings();
	selectedPodConfigId = this.componentInput.selectedSizeId;
	imageDomain = this.IMAGE_BASEURL;
    try
    {
        if (isLandscape)
        {
            $('#iconSizeRectangle').attr('src', $('#iconSizeRectangle').attr('src').replace("_portrait", "_landscape"));
            $('#iconSizeSquare').attr('src', $('#iconSizeSquare').attr('src').replace("_portrait", "_landscape"));
            $('#iconSizePanoramic').attr('src', $('#iconSizePanoramic').attr('src').replace("_portrait", "_landscape"));
        }
        else
        {
            $('#iconSizeRectangle').attr('src', $('#iconSizeRectangle').attr('src').replace("_landscape", "_portrait"));
            $('#iconSizeSquare').attr('src', $('#iconSizeSquare').attr('src').replace("_landscape", "_portrait"));
            $('#iconSizePanoramic').attr('src', $('#iconSizePanoramic').attr('src').replace("_landscape", "_portrait"));
        }
    }
    catch(err)
    {}

    this.fillAllSizesSection(sizeData, selectedPodConfigId, imageDomain);

    return sizeData;
};


com.art.photosToArt.components.ComponentAvailableSizePicker.prototype.fillAllSizesSection = function(sectionSizeData, selectedPodConfigId, imageDomain)
{

    var labelRectangle = "Rectangle";
    var labelSquare = "Square";
    var labelPanorama = "Panorama";

    this.fillAllSizesSectionListHtml(sectionSizeData[labelRectangle], labelRectangle, selectedPodConfigId, imageDomain);
    this.fillAllSizesSectionListHtml(sectionSizeData[labelSquare], labelSquare, selectedPodConfigId, imageDomain);
    this.fillAllSizesSectionListHtml(sectionSizeData[labelPanorama], labelPanorama, selectedPodConfigId, imageDomain);
};


com.art.photosToArt.components.ComponentAvailableSizePicker.prototype.fillAllSizesSectionListHtml = function(sectionSizeData, sectionId, selectedPodConfigId, imageDomain)
{
    $('#list' + sectionId + " li").remove();
    if (sectionSizeData.length > 0)
    {
        for (var i = 0; i < sectionSizeData.length; i++)
        {
            $('#list' + sectionId).append(this.getLineItemSizeDataHtml(sectionSizeData[i], sectionId, selectedPodConfigId, imageDomain));
        }
        $('#section' + sectionId).show();
    }
    else
    {
        $('#section' + sectionId).hide();
    }
};

com.art.photosToArt.components.ComponentAvailableSizePicker.prototype.getLineItemSizeDataHtml = function(sectionSizeData, sectionId, selectedPodConfigId, imageDomain)
{
    var returnValue = "<li id='" + sectionId + sectionSizeData.id + "' sizeid='" + sectionSizeData.id + "' label='" + sectionSizeData.label + "'>";
    
    //trace("selectedPodConfigId: " + selectedPodConfigId + "sectionSizeData.id: " +sectionSizeData.id);
    if (selectedPodConfigId == sectionSizeData.id)
    {
        returnValue += "<b>" + sectionSizeData.label + '</b>&nbsp;<img src="' + imageDomain + '/images/photostoart/checkmark.gif" border="0" width="12" height="12"/>';
    }
    else
    {
        returnValue += sectionSizeData.label;
    }
    returnValue += '</li>';
    return returnValue;
};


com.art.photosToArt.components.ComponentAvailableSizePicker.prototype.getSectionUiHtml = function(sizeGroup)
{
    var returnValue = '';
    var imageHtml = "", imageLabel = "", textLabel = "";
    switch (sizeGroup)
    {
        case this.availableSizeGrouping.Rectangle:
            imageHtml = this.images.imageIconRectangle;
            textLabel = this.translatableContent.rectangle;
            imageLabel = "Rectangle";
            break;
        case this.availableSizeGrouping.Square:
            imageHtml = this.images.imageIconSquare;
            textLabel = this.translatableContent.square;
            imageLabel = "Square";
            break;
        case this.availableSizeGrouping.Panorama:
            imageHtml = this.images.imageIconPanorama;
            textLabel = this.translatableContent.panorama;
            imageLabel = "Panoramic";
            break;
    }
    returnValue += ("<div>");
    returnValue += ("<img src='" + imageHtml + "' border=0 align='' id='iconSize" + imageLabel + "' style='vertical-align:middle;padding-bottom:10px;' alt='" + textLabel + "'/>&nbsp;<span class=''>" + textLabel + "</span>");
    returnValue += ("<div class='clear'></div><div style='border-top: 1px dotted #A3A3A3;'>");
    returnValue += ("</div></div>");
    return returnValue;
};
 
//SECTION: Component Functions - Specific to this component
com.art.photosToArt.components.ComponentAvailableSizePicker.prototype.getTemplate = function(zIndex)
{
	var returnValue = 
			'<div id="' + this.markup.componentName + '" style="z-index:' + zIndex + '; width: 470px; margin: 0px; background-color: #FFFFFF; display:inline-block;">'
			+ '<style>'
			+ 'ul.sizelistclass {float: left;width: 45em;margin: 10px, 0px, 0px, 0px;padding: 0;list-style: none;margin-left: 0px !important;} '
			+ 'ul.sizelistclass li {float: left;width: 10em;height: 15px;  margin: 0px; padding: 10px 7px 0px 0px;cursor:pointer;} '
			+ '</style>'
			+ '    <div class="gradient_gray titlebar cPointer" style="height: 30px; width: 469px; padding-top: 5px;">'
			+ '        <div class="floatleft" style="padding-left: 10px; color: #3A261E; font-family:ITC New Baskerville,Times New Roman,Serif; font-size: 21px;">'
			+          this.translatableContent.select_print_size
			+ '        </div>'
			+ '        <div class="floatright" style="padding-right: 10px; padding-top: 3px; cursor: pointer;">'
			+ '            <img id="' + this.markup.closeButtonId + '" src="' + this.images.imageCloseWindow + '" alt="close" /></div>'
			+ '			<div style="clear:both"></div>'
			+ '    </div>'
            + '    <div class="clear"></div>'
			+ '    <div style="padding: 25px;">'
			+ '        <div id="sectionRectangle">'
			+              this.getSectionUiHtml(this.availableSizeGrouping.Rectangle)
			+ '            <ul id="listRectangle" class="sizelistclass">'
			+ '            </ul>'
			+ '        </div>'
			+ '        <div class="clear"></div>'
			+ '        <div id="sectionSquare" style="margin-top:25px;">'
			+              this.getSectionUiHtml(this.availableSizeGrouping.Square)
			+ '            <ul id="listSquare" class="sizelistclass">'
			+ '            </ul>'
			+ '        </div>'
			+ '        <div class="clear"></div>'
			+ '        <div id="sectionPanorama" style="margin-top:25px;">'
			+              this.getSectionUiHtml(this.availableSizeGrouping.Panorama)
			+ '            <ul id="listPanorama" class="sizelistclass">'
			+ '            </ul>'
			+ '        </div>'
			+ '    </div>'
			+ '    <div>&nbsp;</div>'
			+ '</div>';

	return returnValue;
};
