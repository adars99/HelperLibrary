com.art.photosToArt.proxies.ApplicationProxy = function(_environment)
{
    this.NAME = com.art.photosToArt.proxies.ApplicationProxy.NAME;
    this.CANVAS = "canvas";
    this.environment = _environment;
    this.user = {sessionId:'',persistentId:'',email:'',countryIso:'',countryIsoGeoLocation:'',languageIso:'',currencyIso:'',authenticationToken:'',cartKey:''};
    this.application = {apiKey:'',applicationId:'',photosToArtApnum:'',customerZoneId:'',servicePriceBucketId:''};
    this.matCount = 0;
    this.sizes = {};
    this.galleries = [];
    this.framingComponents = {};
    this.selectedFramingComponents = {frame:{},mats:{}};
    this.selectedFramingTabObject = {};
    this.data = {homePageHtml:''};
    this.data.serviceTypes = new com.art.photosToArt.vos.ItemServicesMetaInformation();
    this.data.serviceTypesAvailable = new com.art.photosToArt.vos.ItemServicesMetaInformation(this.environment.serviceList);
    
    this.state = {initializing:false,galleryIdForPhotosToArt:'', selectedItemServiceSubType: {Canvas: {}}, currentUserInterfaceMode: '', imageCropIdOverride:0};
    this.state.current = new com.art.photosToArt.proxies.StateData(this.data.serviceTypesAvailable);
    this.state.previous = [];
    
    //Cached Price info for Moulding Rollovers
    //indexed by [frameID][podconfigid] = $10.00;
    this.cachedMouldingPrices = {};

};
com.art.photosToArt.proxies.ApplicationProxy.NAME = "ApplicationProxy";

com.art.photosToArt.proxies.ApplicationProxy.prototype.setSelectedTabObject = function(obj)
{
    this.selectedFramingTabObject = obj;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getSelectedTabObject = function()
{
    return this.selectedFramingTabObject;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getFrameIndexById = function()
{
    var id = this.SelectedGalleryItemGet().Item.Service.Frame.Moulding.ItemNumber;
    var arr = this.framingComponents[this.SelectedItemPodConfigIdGet()].Mouldings;
    for(var i=0; i < arr.length; i++)
    {
        if(id == arr[i].mouldingId)
        {
            return i;
        }
    }
    return 13;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.cacheHomePageMarkup = function(markup,shellContainerName)
{
    //N
    if (this.data.homePageHtml == '')
        this.data.homePageHtml = markup;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getMatObjectByMatId = function(matId)
{
	var podConfigId = this.SelectedItemPodConfigIdGet();
	if(this.framingComponents[podConfigId] == undefined)
		return;
	
	var mats = this.framingComponents[podConfigId].Mats;
	for(var i=0; i < mats.length; i++)
	{
		if(mats[i].MatId == matId)
			return mats[i];
	}
	return null;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getMatIndexById = function(id)
{	
	var num = this.SelectedGalleryItemGet().Item.Service.Frame[id].ItemNumber;
	
	var arr = this.getMats();
	
	for(var i=0; i < arr.length; i++)
	{
		if(num == arr[i].MatId)
			return i;
	}
	return -1;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.setUser = function(keyValueObject)
{
    switch (keyValueObject.key.toLowerCase())
    {
        case 'sessionid' :
            this.user.sessionId = keyValueObject.value;
            break;
        case 'persistentid' :
            this.user.persistentId = keyValueObject.value;
            break;
        case 'email' :
            this.user.email = keyValueObject.value;
            break;
        case 'countryiso' :
            this.user.countryIso = keyValueObject.value;
            break;
        case 'languageiso' :
            this.user.languageIso = keyValueObject.value;
            break;
        case 'currencyiso' :
            this.user.currencyIso = keyValueObject.value;
            break;
        case 'authenticationtoken' :
            this.user.authenticationToken = keyValueObject.value;
            break;
    }
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.setApplicationValue = function(keyValueObject)
{
    switch (keyValueObject.key.toLowerCase())
    {
        case 'apikey' :
            this.application.apiKey = keyValueObject.value;
            break;
        case 'applicationid' :
            this.application.applicationId = keyValueObject.value;
            break;
        case 'photostoartapnum' :
            this.application.photosToArtApnum = keyValueObject.value;
            break;
        case 'customerzoneid' :
            this.application.customerZoneId = keyValueObject.value;
            break;
        case 'servicepricebucketid' :
            this.application.servicePriceBucketId = keyValueObject.value;
            break;

    }
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.addGalleryToCache = function(galleryVo)
{
    var indexToUpdate = this.galleries.length;
    //STEP: Is this a new Gallery?  Found out by iterating and matching on galleryId
    for (var i = 0; i < this.galleries.length; i++)
    {
        if (galleryVo.galleryId == this.galleries[i].galleryId)
        {
            indexToUpdate = i;
            break;
        }
    }
    this.galleries[indexToUpdate] = galleryVo;
};
/**
 * Set mat object for framed image
 * @param matid
 * @param object
 */
com.art.photosToArt.proxies.ApplicationProxy.prototype.setMatObject = function(matid,object)
{
    if(matid != PhotosToArtCore.constants.TOP_MAT || matid != PhotosToArtCore.constants.MIDDLE_MAT || PhotosToArtCore.constants.BOTTOM_MAT)
        throw new Error("ApplicationProxy.setMatObject() failed! Invalid matid used[abc].");
};
/**
 * Get total mat count of selected Frame image
 * @returns {Number}
 */
com.art.photosToArt.proxies.ApplicationProxy.prototype.getMatCount = function()
{
    return this.matCount;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.getMatPosition = function()
{
    var tabID = this.selectedFramingTabObject.id;
    tabID = tabID.toLowerCase();
    trace("tabID: "+tabID);
    
    if(tabID.indexOf("top") > -1)
    {
        return 1;
    }
    if(tabID.indexOf("middle") > -1)
    {
        return 2;
    }
    if(tabID.indexOf("bottom") > -1)
    {
        return 3;
    }
};

/**
 * Get Mat Tab label/value
 * @param galleryId
 * @returns
 */
com.art.photosToArt.proxies.ApplicationProxy.prototype.getMatTab = function()
{
    
    if(this.matCount == 1)
        return {id:"TopMat",label:"top mat",value:"topMat"};
    if(this.matCount == 2)
        return {id:"MiddleMat",label:"middle mat",value:"middleMat"};
    if(this.matCount == 3)
        return {id:"BottomMat",label:"bottom mat",value:"bottomMat"};
    
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.setMatCountById = function(id)
{
    trace("setMatCountById: "+id);
    
    if(id == "TopMat")         this.matCount     = 1;
    if(id == "MiddleMat")     this.matCount     = 2;
    if(id == "BottomMat")     this.matCount     = 3;
    
};

/**
 * Set selected moulding objectc
 * @param galleryId
 * @returns
 */
com.art.photosToArt.proxies.ApplicationProxy.prototype.setSelectedMoulding = function(obj)
{
    if(typeof obj == "string" || obj == undefined || typeof obj == "number")
        throw new Error("ApplicationProxy.setSelectedMoulding(obj) failed!  Invalid argument used.");
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getGalleryByGalleryId = function(galleryId)
{
    var gallery = null;
    for (var i = 0; i < this.galleries.length; i++)
    {
        if (this.galleries[i].galleryId == galleryId)
        {
            gallery = this.galleries[i];
            break;
        }
    }
    return gallery;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.getGalleryByGalleryTitle = function(galleryTitle)
{
    var gallery = null;
    for (var i = 0; i < this.galleries.length; i++)
    {
        if (this.galleries[i].title.toLowerCase() == galleryTitle.toLowerCase())
        {
            gallery = this.galleries[i];
            break;
        }
    }
    return gallery;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.getGalleryItemsByGalleryId = function(galleryId)
{
    var galleryItems = null;
    for (var i = 0; i < this.galleries.length; i++)
    {
        if (this.galleries[i].galleryId == galleryId)
        {
            galleryItems = this.galleries[i].galleryItems;
            break;
        }
    }
    return galleryItems;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getGalleryItemCount = function()
{
    var thisGallery = this.GalleryForPhotosToArtGet();
    var result = 0;
    if(thisGallery !== null && thisGallery !== undefined && thisGallery.galleryItems !== undefined && thisGallery.galleryItems.length > 0)
    {
        result = thisGallery.galleryItems.length;
    }
    return result;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getGalleryItemByGalleryItemId = function(galleryItemId)
{
    var galleryItem = null;
    for (var i = 0; i < this.galleries.length; i++)
    {
        for(var j = 0; j < this.galleries[i].galleryItems.length; j++)
        {
            if (this.galleries[i].galleryItems[j].GalleryItemId == galleryItemId)
            {
                galleryItem = this.galleries[i].galleryItems[j];
                break;
            }
            if (galleryItem != null)
                break;
        }
    }
    return galleryItem;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getGalleryItemLastAdded = function()
{
    //STEP: Assumption, the gallery item that was last added is the last one in the collection
    var galleryItems = this.GalleryItemsForPhotosToArtGet();
    //TODO: need to protect against empty collection
    return galleryItems[galleryItems.length-1];
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getGalleryItemByImageGuid = function(imageGuid)
{
    var galleryItem = null;
    for (var i = 0; i < this.galleries.length; i++)
    {
        if (this.galleries[i].galleryItems)
        {
            for(var j = 0; j < this.galleries[i].galleryItems.length; j++)
            {
                if (this.galleries[i].galleryItems[j].Item.Sku == imageGuid)
                {
                    galleryItem = this.galleries[i].galleryItems[j];
                    break;
                }
                if (galleryItem != null)
                    break;
            }
        }
    }
    return galleryItem;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getSelectedItemPodConfigIdForGivenSizeAndService = function(small, large, selectedItemServiceObject)
{
    var returnValue = 0;
    trace("********WITH THESE: " + small + " x " + large);
    var sizes = this.getItemAvailableSizes(this.SelectedImageGuidGet(), selectedItemServiceObject);
    for(var i = 0; i < sizes.length; i++)
    {
        if(sizes[i].Large === large && sizes[i].Small === small)
        {
            returnValue = sizes[i].PodConfigId;
            break;
        }
    }
    trace("***********FOUND THIS: " + returnValue);
    return returnValue;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.doesItemHaveAvailableSizesLoaded = function(imageGuid)
{
    var counter = 0;
    var returnValue = false;
    if(imageGuid.length !== 0)
    {
        var galleryItem = this.getGalleryItemByImageGuid(imageGuid);
        if(galleryItem.AvailableSizes !== null && galleryItem.AvailableSizes !== undefined)
        {
            for(var property in galleryItem.AvailableSizes)
            {
                counter++;
            }
            if (counter > 0)
                returnValue = true;
        }    
    }
    return returnValue;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.objectPropertyCount = function (obj)
{
    var counter = 0;
    if (obj !== undefined)
        {
            for(var property in obj)
            {
                counter++;
            }
        }   
    return counter;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.getItemAvailableSizes = function(imageGuid, service)
{
    var galleryItem = this.getGalleryItemByImageGuid(imageGuid);
    var availableSizes = galleryItem.AvailableSizes;
    var sizeList = this.combineSizeDataWithMaster(this.getItemAvailableSizesClone(availableSizes[service.labelForData]),this.sizes[service.labelForData]);
    return sizeList;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getItemAvailableSizeByPodConfigId = function(imageGuid, service, podConfigId)
{
    var returnValue = {};
    var sizes = this.getItemAvailableSizes(imageGuid, service);
    for(var i = 0; i < sizes.length; i++)
    {
        if(sizes[i].PodConfigId === podConfigId)
        {
            returnValue = sizes[i];
            break;
        }
    }
    return returnValue;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getItemAvailableSizesClone = function(availableSizes)
{
    var returnValue = [];
    for (var index in availableSizes)
    {
        returnValue[returnValue.length] = availableSizes[index];
    }
    return returnValue;
};
/**
 * Get Mats either oversized or regular, never both
 * 
 */
com.art.photosToArt.proxies.ApplicationProxy.prototype.getMats = function()
{
	if(this.SelectedGalleryItemGet().Item == undefined || this.SelectedGalleryItemGet().Item.Service == undefined || this.SelectedGalleryItemGet().Item.Service.Frame == undefined || this.SelectedGalleryItemGet().Item.Service.Frame.FrameSummary == undefined)
		throw new Error("ApplicationProxy.getMats failed! Required Data is missing.");
	
	var oversized = this.SelectedGalleryItemGet().Item.Service.Frame.FrameSummary.AreMatsOversized;
	var mats = this.getFramingComponents()[this.SelectedItemPodConfigIdGet()].Mats;
	var tmp = [];
	var cnt = 0;
	for(var i=0; i < mats.length; i++)
	{
		var val = mats[i].isOverSized;
		var matIsOversized = val == "1";
		if(oversized && matIsOversized)
		{
			tmp.push(mats[i]);
		}
		if(!oversized && mats[i].isOverSized == "0")
		{
				tmp.push(mats[i]);
		}
	}
	return tmp;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getItemAvailableSizesBestFit = function(imageGuid, service)
{
    var galleryItem = this.getGalleryItemByImageGuid(imageGuid);
    var availableSizes = galleryItem.AvailableSizes;
    var sizeList = this.getItemAvailableSizesClone(availableSizes[service.labelForData]);
    var validSizesList = [];
    for(var i = 0; i < sizeList.length; i++)
    {
        if (sizeList[i].Group.indexOf('1') !== -1)
        {
            validSizesList.push(sizeList[i]);
        }
    }
    
    //STEP: This is all about getting the best fit list...however, if nothing "best fits" and there are other legit sizes, then return one of them
    var allUndefined = true;
    for(var property in validSizesList)
    {
        if (validSizesList[property] != undefined)
        {
            allUndefined = false;
            break;
        }
    }
    if (allUndefined)
    {
        validSizesList = [];
        validSizesList[0] = this.getItemAvailableSizesClone(availableSizes[service.labelForData])[0];
        //STEP: Add Group "1" for the group of this in order to now treat it as a best fit
        validSizesList[0].Group = validSizesList[0].Group + (validSizesList[0].Group.length > 0 ? ",":"") + "1";
    }
    
    return this.combineSizeDataWithMaster(validSizesList,this.sizes[service.labelForData]);
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.getItemImageCropByItemService = function(itemService)
{
    var selectedPodConfigId = this.state.current[itemService.name].selectedPodConfigId;
    return this.getItemImageCropByItemServiceAndPodConfigId(itemService, selectedPodConfigId);
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.getItemImageCropByItemServiceAndPodConfigId = function(itemService, podConfigId)
{
    var galleryItem = this.getGalleryItemByImageGuid(this.SelectedImageGuidGet());

    //STEP: Set up default CropInfo 
    var returnValue = {CropType:0,Dimensions:{Height:0,Width:0},Coordinates:{CoordinateX:0,CoordinateY:0},Image:null,CustomCropInformation:{ImageCropId:0,ImageCropGuid:"",PodConfigId:0,ItemServiceCode:""}};
    
    var currentCrop;
    if (galleryItem.Item.AvailableCrops && galleryItem.Item.AvailableCrops.length)
    {
        for(var i = 0; i < galleryItem.Item.AvailableCrops.length; i++)
        {
            currentCrop = galleryItem.Item.AvailableCrops[i];
            if (currentCrop.CustomCropInformation)
            {
                if (currentCrop.CustomCropInformation.ItemServiceCode == itemService.itemServiceCode
                    &&
                    currentCrop.CustomCropInformation.PodConfigId == podConfigId)
                {
                    //trace('getItemImageCropByItemServiceAndPodConfigId CROP with CropX ' + currentCrop.Coordinates.CoordinateX);
                    returnValue = currentCrop;
                    break;
                }
            }
        }
    }
    return returnValue;
};



com.art.photosToArt.proxies.ApplicationProxy.prototype.updateGalleryItem = function(response)
{
    var bFound = false;
    for (var i = 0; i < this.galleries.length; i++)
    {
        if (this.galleries[i].galleryItems)
        {
            for(var j = 0; j < this.galleries[i].galleryItems.length; j++)
            {
                if (this.galleries[i].galleryItems[j].Item.Sku == response.Item.Sku)
                {
                    // For debugging only
                    if(response.Item.Service == undefined)
                    {
                        //trace("AP.updateGalleryItem -  received Item with no service");
                    }
                    else
                    {
                        //trace("AP.updateGalleryItem -  received Item OK");
                    }
                    this.galleries[i].galleryItems[j].Item = response.Item;
                    if(!this.galleries[i].galleryItems[j].AvailableSizes || this.galleries[i].galleryItems[j].AvailableSizes === undefined)
                    {
                        this.galleries[i].galleryItems[j].AvailableSizes = response.AvailableSizes;
                    }
                    bFound = true;
                    
                    break;
                }
            }
        }
        if (bFound) break;
    }
    return bFound;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.addMasterSizeDataToCache = function(serviceResponse)
{
    this.sizes = (serviceResponse.AvailableSizes);
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.getDefaultPodConfigIdForSelectedItem = function()
{
    var returnValue = 0;
    var sizes = this.getItemAvailableSizesBestFit(this.SelectedImageGuidGet(), this.SelectedItemServiceGet());
    if(sizes !== undefined && sizes.length !== 0)
    {
        for (var size in sizes)
        {
            if (sizes[size].Default == "True" && sizes[size].Warning != "True")
                returnValue = sizes[size].PodConfigId;
        }
        
        if (returnValue == 0 && sizes.length !== undefined && sizes.length > 0 && sizes[0] != undefined)
        {
            // Find the largest size without a warning
            var largestArea = 0; 
            var currentArea = 0;
            for(var size in sizes)
            {
                currentArea = sizes[size].Small * sizes[size].Large;
                if(sizes[size].Warning === "False" && currentArea > largestArea)
                {
                    largestArea = currentArea;
                    returnValue = sizes[size].PodConfigId;
                }
            }
        }
        
        if(returnValue == 0 && sizes.length !== undefined && sizes.length > 0 && sizes[0] != undefined)
        {
            // Last resort - just give first config
            returnValue = sizes[0].PodConfigId;
        }
    }
    else
    {
        var data = {html : "<div style='color:red;font-size:14px;padding:30px'>" + PhotosToArtCore.getString("We are sorry, but there are no print sizes available at this time for the image and service you have selected") + "</div>"
                 , title : PhotosToArtCore.getString("No Print Sizes Available")
                 , padding : 20};
        var msgBox =  new com.art.photosToArt.components.ComponentMessagingLightbox(data, PhotosToArtCore);
        msgBox.render();
        $('#ComponentMessagingLightbox').hide();
        setTimeout(function(){
            $('#ComponentMessagingLightbox').center(true);
            $('#ComponentMessagingLightbox').show();
        }, 500);
    }
    
    return returnValue;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.getMasterSizeByPodConfigId = function(podConfigId)
{
    var podConfig = '';
    for (var property in this.sizes)
    {
    	if(property === "__type")
    		continue;
    	
        for(var j = 0; j < this.sizes[property].length; j++)
        {
            podConfig = '';
            try
            {
                podConfig = this.sizes[property][j].PodConfigId;
                if (podConfig == podConfigId)
                {
                    return this.sizes[property][j];
                }
            }
            catch(err)
            {}
        }
    }
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.getMouldingByMouldingId = function(mouldingId)
{
    var result = undefined;
    try
    {
        var moulding = this.getFramingComponent(this.SelectedItemPodConfigIdGet(), mouldingId, PhotosToArtCore.constants.FRAMING_COMPONENT_MOULDING);
        if(moulding != undefined && this.objectPropertyCount(moulding) > 0 )
        {
            result = moulding;
        }
    }
    catch(err){this.app.logError(err);}
    return result;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getMouldingPrice = function(mouldingId)
{

    var selectedService = this.SelectedItemServiceGet();
    var selectedPodConfigId = this.state.current[selectedService.name].selectedPodConfigId;
    var selectedFrameId		= this.SelectedItemFrameIdGet();
    if(this.cachedMouldingPrices[selectedFrameId] == undefined || this.cachedMouldingPrices[selectedFrameId][selectedPodConfigId] == undefined || this.cachedMouldingPrices[selectedFrameId][selectedPodConfigId][mouldingId] == undefined)
    	return null;
    
    return this.cachedMouldingPrices[selectedFrameId][selectedPodConfigId][mouldingId];
    /*
    var moulding = this.getFramingComponent(selectedPodConfigId, mouldingId, PhotosToArtCore.constants.FRAMING_COMPONENT_MOULDING);
    if(moulding != undefined && this.objectPropertyCount(moulding) > 0 )
    {
        if(moulding.price != undefined && moulding.price != null)
        {
            result = moulding.price;
        }
    }
    return result;
    */
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getFramingComponent = function(podConfigId, componentId, framingComponentType)
{
    var currentItem = {};
    var isMoulding = framingComponentType === PhotosToArtCore.constants.FRAMING_COMPONENT_MOULDING;
    if(this.framingComponents != undefined && this.objectPropertyCount(this.framingComponents) !== 0)
    {
        var podData = this.framingComponents[podConfigId];
        if(podData != undefined)
        {
            var componentData = isMoulding ? podData.Mouldings : podData.Mats;

            for(var item in componentData)
            {
                switch(framingComponentType)
                {
                    case PhotosToArtCore.constants.FRAMING_COMPONENT_MOULDING:
                        if(componentData[item].apNum == componentId)
                            currentItem = componentData[item];
                        break;
                        
                    case PhotosToArtCore.constants.FRAMING_COMPONENT_MAT:
                        if(componentData[item].MatId == componentId)
                            currentItem = componentData[item];
                        break;
                    default:
                        break;
                    
                }
                if(currentItem.hasOwnProperty('height'))
                {
                    break;
                }
            }
        }
    }
    return currentItem;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getFramingComponents = function()
{
    return this.framingComponents;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.setFramingComponents = function(components)
{
    // Convert each collection of mouldings and mats to VO arrays - which are then children to a header with a PODConfigID. These headers are array under the Proxy.FramingComponents.
    //         FramingComponents[PodConfigId].MouldingVOs
    //                                       .MatVOs
    trace("components");
    trace(components);
    try
    {
        if(this.framingComponents[components.PodConfigId] == undefined || this.framingComponents[components.PodConfigId].length === 0)
        {
            this.framingComponents[components.PodConfigId] = {
                    Mouldings : com.art.core.vos.MouldingVO.ConvertToMouldingVOArray(components.Mouldings,this.environment.imagePath), 
                    Mats : this.sortMatsByColor(com.art.core.vos.MatVO.ConvertToMatVOArray(components.Mats,this.environment.imagePath))
            };
        }
    }
    catch(err)
    {
        throw new Error(err.message);
    }
};


com.art.photosToArt.proxies.ApplicationProxy.prototype.sortMatsByColor = function(arr)
{
    trace("sort mats by color: "+typeof arr);
    var newArr = [];
    for(var m=0; m < arr.length; m++)
    {
        var tmp = arr[m];
        var color = parseInt(tmp.hexColor,16);
        var rc = (color >> 16) & 255;
        var gc = (color >> 8) & 255;
        var bc = color & 255;
        var yvalue = .299 * .587 * .114 * rc;
        var ivalue = .596 * -.275 * -.311 *gc;
        var qvalue = .212 * -.523 * .311 * bc;
        tmp.yiq = yvalue * ivalue * qvalue;
    
        newArr.push(tmp);
        //matThumbs.push({hue:this.getHue(rc,gc,bc),yiq:yiq,position:m,total:mats.length(),width:115,height:115,node:mat,name:n,url:"http://cache1.artprintimages.com/images/framing/mats/hires/"+apnum+"/swatch/"+apnum+"_a.jpg"}); //url:'http://artfiles.art.com/images/framing/hires/5092317/thumb/5092317.jpg'});
    }
    //now sort
    newArr.sort(function(a,b) {
          if (a.yiq < b.yiq)
                 return -1;
              if (a.yiq > b.yiq)
                return 1;
              return 0;
            });
    return newArr;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.updateMouldingPrice = function(mouldingId, price)
{
	if(mouldingId == undefined || price == undefined)
		throw new Error("ApplicationProxy.updateMouldingPrice failed! One or more required inputs are undefined.");
    // Trying to update the data
    //this.getFramingComponent(podConfigId, mouldingId, PhotosToArtCore.constants.FRAMING_COMPONENT_MOULDING).price = price;
	var selectedFrameId = this.SelectedItemFrameIdGet();
	var selectedService = this.SelectedItemServiceGet();
	var selectedPodConfigId = this.state.current[selectedService.name].selectedPodConfigId;
	
	if(this.cachedMouldingPrices[selectedFrameId] == undefined)
		this.cachedMouldingPrices[selectedFrameId] = {};
	if(this.cachedMouldingPrices[selectedFrameId][selectedPodConfigId] == undefined)
		this.cachedMouldingPrices[selectedFrameId][selectedPodConfigId] = {};
	
	this.cachedMouldingPrices[selectedFrameId][selectedPodConfigId][mouldingId] = price;
	
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getMinimumSizeConfig = function()
{
    var smallestDimension = 999;
    var smallestCandidate = {};
    
    try
    {
    // Look at our master sizes, return object with smallest dimensions
    for(var outer in this.sizes)
    {
        if(outer === "__type")
        {
            continue;
        }
        //trace("Outer loop");
        for(var inner in this.sizes[outer])
        {
            //trace("inner loop");
            if(this.sizes[outer][inner].Small < smallestDimension)
            {
                //trace("found smaller dimension");
                smallestCandidate = this.sizes[outer][inner];
                smallestDimension = this.sizes[outer][inner].Small;
            }
        }
    }
    }
    catch(err)
    {
        throw new Error(err.message);
    }
    return smallestCandidate;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.isServiceACanvasService = function(itemService)
{
    return itemService.name.toLowerCase().substring(0,6) === 'canvas';
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.isImageGuidInPreviousState = function(imageGuid)
{
    var returnValue = false;
    if (this.state.previous[imageGuid] != undefined)
        returnValue = true;
    return returnValue;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.getStateFromPreviousState = function(imageGuid)
{
    var returnValue = {};
    if (this.isImageGuidInPreviousState(imageGuid))
        returnValue = this.state.previous[imageGuid];
    return returnValue;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.updateStateOfSelectedItem = function(response)
{
    this.SelectedImageGuidSet(response.Item.Sku);
    this.state.current.selectedItemServiceAttributes.areMatsOversizedChanged = false;
    try
    {
        if(this.state.current.selectedItemServiceAttributes.areMatsOversized != response.Item.Service.Frame.FrameSummary.AreMatsOversized)
        {
            if (this.state.current.selectedItemServiceAttributes.areMatsOversized != undefined || this.state.current.selectedItemServiceAttributes.areMatsOversized != '')
            {
                this.state.current.selectedItemServiceAttributes.areMatsOversizedChanged = true;
            }
            this.state.current.selectedItemServiceAttributes.areMatsOversized = response.Item.Service.Frame.FrameSummary.AreMatsOversized;
        }
    }
    catch(err){}
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.updatePreviousStateWithCurrentState = function()
{
    this.state.previous[this.state.current.selectedImageGuid] = this.state.current.clone();
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.updateCurrentStateWithPreviousState = function(imageGuid)
{
    var selectedItemService = this.SelectedItemServiceGet();
    this.state.current = this.state.previous[imageGuid];
    this.state.current.selectedItemService = selectedItemService;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.updateCurrentStateWithNewImageGuid = function(imageGuid)
{
    this.state.current.selectedImageGuid = imageGuid;
    this.SelectedImageCartItemIdSet('');
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.updateSelectedItemWorkflow = function()
{
    // When app initializes (or re-initializes), see if querystring from Shopping Cart
    //    is telling us to load a particular configuration
    //        ServiceType=C
    //        &PODConfigID=7550114
    //        &ImageGUID=6C51DF24-6608-4FD2-A0BC-28AC51D3CDE0
    //        &ImageCropGUID=6C51DF24-6608-4FD2-A0BC-28AC51D3CDE0
    //        &IID=3A9ECDFCC80E4ACB9274C417A4CBDA22
    //        &ServiceSubType=gw
    // get querystring as an array split on "&"
    //http://qa4-www.allposters.com/gallery_photostoart.asp?startat=/photostoart/default.asp

    var querystring = location.search.replace( '?', '' ).split( '&' );
    if(querystring.length !== 1)
    {
        // declare object
        var queryObj = {};
        
        // loop through each name-value pair and populate object
        for ( var i=0; i<querystring.length; i++ ) {
              // get name and value
              var name = querystring[i].split('=')[0].toLowerCase();
              var value = querystring[i].split('=')[1];
              // populate object
              queryObj[name] = value;
        }
        //STEP: Place try catch here, because if any attempt to access a missing QS param will throw error
        try
        {
            // If canvas, then gw or mw
            var service = (queryObj['servicetype'].toLowerCase() == 'c'? queryObj['servicesubtype'] : queryObj['servicetype']).toLowerCase();
            switch(service)
            {
                case 'gw':
                    service = 'canvasgallery';
                    break;
                case 'mw':
                    service = 'canvasmuseum';
                    break;
                case 'm':
                    service = 'mounting';
                    break;
                case 'f':
                    service = 'framing';
                    break;
                case 'a':
                    service = 'acrylic';
                    break;
                case 'p':
                    service = 'printonly';
                    break;
                default:
                    service = 'canvasgallery';
                    break;
            }
    
            this.SelectedItemServiceSet(service);
            this.SelectedItemServiceSubTypeSet(this.SelectedItemServiceGet());
            this.SelectedItemPodConfigIdSet(queryObj['podconfigid']);
            var imageGuid = (queryObj['parentimageguid']) ? queryObj['parentimageguid'].length > 5 ? queryObj['parentimageguid'] : queryObj['imageguid'] : queryObj['imageguid'];
            this.SelectedImageGuidSet(imageGuid);
            this.SelectedImageCartItemIdSet(queryObj['iid']);
            this.StateImageCropIdOverrideSet(queryObj['imagecropid']);
            this.environment.startAuto = true;
           }
        catch(err)
        {}
    }
};
//SECTION: Properties...these are the GETTER and SETTER functions for the private variables inside Model
//------- GALLERY RELATED
com.art.photosToArt.proxies.ApplicationProxy.prototype.GalleryIdForPhotosToArtSet = function(galleryId)
{
    this.state.galleryIdForPhotosToArt = galleryId;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.GalleryIdForPhotosToArtGet = function()
{
    return this.state.galleryIdForPhotosToArt;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.GalleryForPhotosToArtGet = function()
{
    return this.getGalleryByGalleryId(this.GalleryIdForPhotosToArtGet());
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.GalleryItemsForPhotosToArtGet = function()
{
    return this.getGalleryItemsByGalleryId(this.GalleryIdForPhotosToArtGet());
};
//------- ENVIRONMENT VARIABLE RELATED
com.art.photosToArt.proxies.ApplicationProxy.prototype.EnVarLabelAddToCartButtonEnglishGet = function()
{
    var returnValue = this.environment.labelForAddToCartButtonEnglish;
    if (returnValue == undefined)
        returnValue = "Add to Cart";
    return returnValue;
};

//------- STATE RELATED
com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedItemDisplayPriceGet = function()
{
    var galleryItem = this.getGalleryItemByImageGuid(this.SelectedImageGuidGet());
    var displayPrice = galleryItem.Item.ItemPrice.DisplayPrice;

    if(displayPrice == null)
        throw new Error("ApplicationProxy.SelectedItemDisplayPriceGet failed! displayPrice is null.");
    
    return displayPrice;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedItemTimeToShipTextGet = function(podConfigId)
{
    var textResult = "Unknown";
    if (this.SelectedItemServiceGet().name == this.data.serviceTypes.framing.name)
    {
        textResult = this.SelectedImageGet().TransitTime.TransitTimeText;
    }
    if (textResult == "Unknown")
    {
        for(var x = 0; x < this.sizes[this.SelectedItemServiceGet().labelForData].length; x++)
        {
            if (this.sizes[this.SelectedItemServiceGet().labelForData][x].PodConfigId === podConfigId)
            {
                textResult = this.sizes[this.SelectedItemServiceGet().labelForData][x].TimeToShipText;
            }    
        }
    }
    if (textResult == "Unknown")
    {
        for(var service in this.sizes)
        {
            if(service === "__type")
                continue;
            
            for(var x = 0; x < this.sizes[service].length; x++)
            {
                if (this.sizes[service][x].PodConfigId === podConfigId)
                {
                    textResult = this.sizes[service][x].TimeToShipText;
                }    
            }
        }
    }
    return textResult;
    
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedItemServiceGet = function()
{
    var returnValue = '';
    var canGetFromCache = false;
    if (this.state.current.selectedItemService != undefined)
    {
        for(var prop in this.state.current.selectedItemService) 
        {    
            if (this.state.current.selectedItemService.hasOwnProperty(prop)) 
            {          
             canGetFromCache = true;
             break;
            } 
        }
    }
    if (canGetFromCache)
    {
        returnValue = this.state.current.selectedItemService;
    }
    else
    {
        var selectedItemService = this.environment.serviceDefault;
        this.SelectedItemServiceSet(selectedItemService);
        returnValue = this.state.current.selectedItemService;
    }
    return returnValue;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedItemServiceImageGet = function()
{
    var selectedService = this.state.current.selectedItemService;
    var galleryItem = this.getGalleryItemByImageGuid(this.SelectedImageGuidGet());
    
    // TEMP Hard-coding Canvas Gallery service because Framing doesn't have the service data yet ================== debug only ===============================
    var imageToUse;
    if(galleryItem.Item.Service[selectedService.labelForObjectProperty] == undefined)
    {
        imageToUse = galleryItem.Item.Service["CanvasGallery"].Image;
        trace("GalleryItem with labelForData " + selectedService.labelForData + " is undefined, so we're using the CANVAS GALLERY image data.");
    }
    else
    {
        imageToUse = galleryItem.Item.Service[selectedService.labelForObjectProperty].Image;
    }
    return imageToUse;
};


com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedItemServiceImageCropGet = function()
{
    var selectedService = this.SelectedItemServiceGet();
    var selectedPodConfigId = this.state.current[selectedService.name].selectedPodConfigId;
    return this.getItemImageCropByItemServiceAndPodConfigId(selectedService, selectedPodConfigId);
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedItemServiceImageCropSet = function(imageGuid, service, podConfigId, imageCropId)
{
    var galleryItem = this.getGalleryItemByImageGuid(imageGuid);

    //STEP: Set up default CropInfo 
    var returnValue = {CropType:0,Dimensions:{Height:0,Width:0},Coordinates:{CoordinateX:0,CoordinateY:0},Image:null,CustomCropInformation:{ImageCropId:0,ImageCropGuid:"",PodConfigId:0,ItemServiceCode:""}};
    
    returnValue.CustomCropInformation.ImageCropId = imageCropId;
    returnValue.CustomCropInformation.PodConfigId = podConfigId;
    returnValue.CustomCropInformation.ItemServiceCode = service.itemServiceCode;
    
    galleryItem.Item.AvailableCrops = [];
    
    galleryItem.Item.AvailableCrops[0] = returnValue;
   
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedItemServiceSet = function(itemService)
{
    var k = (itemService.name) ? itemService.name.toLowerCase() : itemService.toLowerCase();
    trace("SelectedItemServiceSet: "+k);
    switch(k)
    {
        case 'mounting':
        case 'woodmounting':
            this.state.current.selectedItemService = this.data.serviceTypes.mounting;
            break;
        case 'canvas':
        case 'canvastransfer':
        case 'canvasmuseum':
        case 'mw':
            this.state.current.selectedItemService = this.data.serviceTypes.canvasMuseum;
            break;
        case 'canvasgallery':
        case 'canvasgw':
        case 'gw':
            this.state.current.selectedItemService = this.data.serviceTypes.canvasGallery;
            break;
        case 'framing':
            this.state.current.selectedItemService = this.data.serviceTypes.framing;
            break;
        case 'acrylic':
            this.state.current.selectedItemService = this.data.serviceTypes.acrylic;
            break;
        case 'printonly':
            this.state.current.selectedItemService = this.data.serviceTypes.printOnly;
            break;
        default:
            throw new Error("Unsupported Service not assigned to SelectedItemService");
            break;
    }
    
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedItemServiceSubTypeSet = function(itemService)
{
    //Step: Determine what itemService
    if(itemService.name === this.data.serviceTypes.canvasMuseum.name || itemService.name === this.data.serviceTypes.canvasGallery.name)
    {
        this.state.selectedItemServiceSubType.canvas = itemService;
    }
    else
    {
        // try to find a canvas type, if none, then use null
        if(this.data.serviceTypesAvailable.canvasMuseum !== undefined)
        {
            this.state.selectedItemServiceSubType.canvas = this.data.serviceTypes.canvasMuseum;
        }
        else if(this.data.serviceTypesAvailable.canvasGallery !== undefined)
        {
            this.state.selectedItemServiceSubType.canvas = this.data.serviceTypes.canvasGallery;
        }
        else
        {
            this.state.selectedItemServiceSubType.canvas = undefined;
        }
    }
    
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedItemServiceSubTypeGet = function()
{
    return this.state.selectedItemServiceSubType.canvas;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedImageGet = function()
{
    var imageGuid = this.SelectedImageGuidGet();
    var galleryItem = this.getGalleryItemByImageGuid(imageGuid);
    if(galleryItem)
        return  galleryItem.Item;
    else
        return {};
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedGalleryItemGet = function()
{
    return this.getGalleryItemByImageGuid(this.SelectedImageGuidGet());
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedImageGuidGet = function()
{
    var returnValue = '';
    var candidateGuid = '';
    var isFound = false;
    var photosToArtGallery = this.GalleryItemsForPhotosToArtGet();
    var imageItem = {};
    
    if (this.state.current.selectedImageGuid)
    {
        for(var item in photosToArtGallery)
        {
            imageItem = photosToArtGallery[item].Item;
            if(imageItem.Sku === this.state.current.selectedImageGuid)
            {
                // The imageGuid is valid
                isFound = true;
                break;
            }
            else
            {
                if(candidateGuid.length === 0)
                {
                    candidateGuid = imageItem.Sku;
                }
            }
        }
        if(!isFound)
        {
            this.state.current.selectedImageGuid = candidateGuid;
        }
        // In any case, the state is now correct
        returnValue = this.state.current.selectedImageGuid;
    }
    else
    {
        returnValue = this.SelectedImageGuidDefaultSet();//NOTE: this will return the selectedImageGuid
    }
    return returnValue;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedImageGuidSet = function(imageGuid)
{
    this.state.current.selectedImageGuid = imageGuid;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedImageCartItemIdSet = function(cartItemId)
{
    this.state.current.selectedItemCartItemId = cartItemId;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedImageCartItemIdGet = function()
{
    return this.state.current.selectedItemCartItemId;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedImageGuidDefaultSet = function(imageGuid)
{
    var photosToArtGallery = this.GalleryForPhotosToArtGet();
    if (imageGuid !== undefined && imageGuid.length)
    {
        // before doing this, make sure we have the image also
        for(var item in photosToArtGallery.galleryItems)
        {
            if(photosToArtGallery.galleryItems[item].Sku === imageGuid)
            {
                // The imageGuid is valid
                this.state.current.selectedImageGuid = imageGuid;
            }
        }
    }
    else
    {
        // We may have just gotten our selectedimageguid from the querystring as we return from shopping cart
        if(!(location.search.length > 5 && this.state.current.selectedImageGuid.length > 5))
        {
            if (photosToArtGallery.galleryItems.length > 0)
            {
                this.state.current.selectedImageGuid = photosToArtGallery.galleryItems[0].Item.Sku;
            }
            else
            {
                this.state.current.selectedImageGuid = '';
            }
        }
    }
    return this.state.current.selectedImageGuid;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedImageIdGet = function()
{
    var returnValue = 0;
    var galleryItem = this.getGalleryItemByImageGuid(this.SelectedImageGuidGet());
    try
    {
        if (galleryItem != undefined)
            returnValue = galleryItem.Item.ImageInformation.ImageAttributes.ImageId;
    }
    catch(Error)
    {
    }
    
    return returnValue;
};

//NOTE: This presumes that the selected item is indeed framed.  If that is the case, then the below attempt to fetch its
//      value will result in success.  If not true, the try/catch will fail, and a 0 will be returned.  The caller can use
//      this to determine if the item is indeed framed or not.
com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedItemFrameIdGet = function()
{
    
    var item = this.SelectedGalleryItemGet();
    if(item == undefined || item.Item == undefined || item.Item.Service == undefined || item.Item.Service.Frame == undefined || item.Item.Service.Frame.FrameSummary == undefined || item.Item.Service.Frame.FrameSummary.FrameId == undefined)
        return 0;
    
    return item.Item.Service.Frame.FrameSummary.FrameId;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedItemPodConfigIdSet = function(podConfigId)
{
    this.state.current[this.state.current.selectedItemService.name].selectedPodConfigId = podConfigId;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.SelectedItemPodConfigIdGet = function()
{
    if (this.state.current[this.state.current.selectedItemService.name].selectedPodConfigId == undefined || this.state.current[this.state.current.selectedItemService.name].selectedPodConfigId == '')
        this.SelectedItemPodConfigIdSet(this.getDefaultPodConfigIdForSelectedItem());
    return this.state.current[this.state.current.selectedItemService.name].selectedPodConfigId;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.StateCurrentUserInterfaceModeGet = function()
{
    return this.state.currentUserInterfaceMode;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.StateCurrentUserInterfaceModeSet = function(applicationMode)
{
    this.state.currentUserInterfaceMode = applicationMode;    
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.StateImageCropIdOverrideGet = function()
{
    var returnValue = this.state.imageCropIdOverride;
    this.state.imageCropIdOverride = 0;
    return returnValue;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.StateImageCropIdOverrideSet = function(imageCropId)
{
    this.state.imageCropIdOverride = imageCropId;
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.UserCartKeyGet = function(cookieDictionary, cookieKey)
{
    if (this.user.cartKey.length == 0)
    {
        var cookieHelper = new com.art.core.cookie.Cookie();
        this.user.cartKey = cookieHelper.getCookieDictionary
        (
               cookieDictionary, cookieKey
         );
    }
    return this.user.cartKey;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.invokeCallToActionButtons = function()
{
    // Need to show different buttons depending on whether the user has images or not
    var itemCount = this.getGalleryItemCount();
    var buttonLoading = '#id-button-home-loading';
    var buttonToShow = itemCount > 0 ? '#id-button-home-loadimage' : '#id-button-home-upload';
    var buttonToHide = itemCount === 0 ? '#id-button-home-loadimage' : '#id-button-home-upload';

    setTimeout(function() {
        $(buttonLoading).hide();
        $(buttonToShow).show();
        $(buttonToHide).hide();
        if (loadHomePageButtons !== undefined)
            loadHomePageButtons();
    }, 500);
};
com.art.photosToArt.proxies.ApplicationProxy.prototype.initializeBegin = function()
{
    this.state.initializing = true;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.initializeEnd = function()
{
    this.state.initializing = false;
};

com.art.photosToArt.proxies.ApplicationProxy.prototype.initializeGet = function()
{
    return this.state.initializing;
};

//SECTION - Private Utility Functions - these are helpers that are meant to be only used within the ApplicationProxy file
com.art.photosToArt.proxies.ApplicationProxy.prototype.combineSizeDataWithMaster = function(sizes, masterSizes)
{
    for (var property in sizes) 
    {
        for(var masterProperty in masterSizes)
        {
            if(sizes[property].PodConfigId == masterSizes[masterProperty].PodConfigId)
            {
                sizes[property].AspectRatioTarget = masterSizes[masterProperty].AspectRatioTarget;
                sizes[property].Dpi = masterSizes[masterProperty].Dpi;
                sizes[property].Large = masterSizes[masterProperty].Large;
                sizes[property].Price = masterSizes[masterProperty].Price;
                sizes[property].PriceList = masterSizes[masterProperty].PriceList;
                sizes[property].Small = masterSizes[masterProperty].Small;
                sizes[property].TimeToShipText = masterSizes[masterProperty].TimeToShipText;
                break;
            }
        }
    }
    return sizes;
};

//SECTION - Classes - these classes are used by the Caching proxy
com.art.photosToArt.proxies.StateData = function(serviceTypes)
{
    this.selectedImageGuid = '';
    this.selectedItemService = {};
    this.selectedItemServiceAttributes = {areMatsOversized: ''};
    this.selectedItemCartItemId = '';
    for(var property in serviceTypes)
    {
        this[serviceTypes[property].name] = new com.art.photosToArt.proxies.State();
    }
    this.matCount = 0;
};

com.art.photosToArt.proxies.State = function()
{
    this.selectedPodConfigId = '';
};

com.art.photosToArt.proxies.StateData.prototype.clone = function() {
  var newObj = (this instanceof Array) ? [] : {};
  for (var i in this) {
    if (i == 'clone') continue;
    if (this[i] && typeof this[i] == "object") {
        this[i].clone = com.art.photosToArt.proxies.StateData.prototype.clone;
      newObj[i] = this[i].clone();
    } else newObj[i] = this[i];
  } 
  newObj.clone = com.art.photosToArt.proxies.StateData.prototype.clone;
  return newObj;
};
