com.art.photosToArt.commands.ApplicationCommand = function(app)
{
	this.NAME = com.art.photosToArt.commands.ApplicationCommand.NAME;
	this.app = app;
	this.service	= this.app.getServiceProvider(); //use defaults

};

com.art.photosToArt.commands.ApplicationCommand.NAME = "ApplicationCommand";
// Private events for App Command
com.art.photosToArt.commands.ApplicationCommand.prototype.events = {
		FRAME_GET_MOULDING_PRICE_COMPLETE : 'FRAME_GET_MOULDING_PRICE_COMPLETE'
};
com.art.photosToArt.commands.ApplicationCommand.prototype.init = function()
{
	
};
com.art.photosToArt.commands.ApplicationCommand.prototype.listNotificationInterests = function()
{
	return [
	          this.app.events.STARTUP
	        , this.app.events.INITIALIZE_API
	        , this.app.events.INITIALIZE_API_SUCCESS
	        , this.app.events.AUTHENTICATE_ACCOUNT 
	        , this.app.events.AUTHENTICATE_ACCOUNT_SUCCESS 
	        , this.app.events.CREATE_ACCOUNT
	        , this.app.events.CREATE_ACCOUNT_SUCCESS
	        , this.app.events.CATALOG_ITEM_VARIATIONS_GET_MASTER
	        , this.app.events.CATALOG_ITEM_VARIATIONS_GET_MASTER_SUCCESS
	        , this.app.events.GALLERY_GET_BY_USER
	        , this.app.events.GALLERY_GET_BY_USER_SUCCESS
	        , this.app.events.GALLERY_ADD_FOR_USER
	        , this.app.events.GALLERY_ADD_FOR_USER_SUCCESS
	        , this.app.events.GALLERY_GET
	        , this.app.events.GALLERY_GET_SUCCESS
	        , this.app.events.GALLERY_ADD_ITEM
	        , this.app.events.GALLERY_REMOVE_ITEM
	        , this.app.events.CATALOG_ITEM_GET_VARIATIONS
	        , this.app.events.IMAGE_UPDATE_AND_GET_RESULTS
	        , this.app.events.CATALOG_GET_CONTENT
	        , this.app.events.ADDTOCART_GOTOCART
	        , this.app.events.ADDTOCART_STAY
	        , this.app.events.FRAME_GET_COMPONENTS
	        , this.app.events.FRAME_GET_MOULDING_PRICE
	        , this.events.FRAME_GET_MOULDING_PRICE_COMPLETE
	        , this.app.events.FRAME_UPDATE_MAT_COUNT
	        , this.app.events.FRAME_UPDATE_MOULDING
	        , this.app.events.FRAME_UPDATE_MAT
	        , this.app.events.DUPLICATE_FRAME_FOR_CART
	        , this.app.events.GET_SALES_EVENT_MESSAGE_FOR_PRODUCT
	       ];
};
com.art.photosToArt.commands.ApplicationCommand.prototype.initializeApi = function(note)
{
	var _this = this;
	var apiKey = note.body.apiKey;
	var persistentId = note.body.persistentId;
	var applicationId = note.body.applicationId;
	var countryCode = note.body.countryCode;
	var languageIso = note.body.languageIso;
	if (isNaN(persistentId) || persistentId <= 0)
			    persistentId = -1;
	var handlers = this.service.createHandlers(
	        this.getHandlerFunction(_this.app.events.INITIALIZE_API_SUCCESS,_this)
			,this.getHandlerFunction(_this.app.events.INITIALIZE_API_FAILURE,_this)
			,this.getHandlerFunction("",_this)
	);
	
	this.service.ecommerceAPIService.initializeApi(
            handlers
            ,apiKey
	        ,applicationId
            ,countryCode
            ,languageIso
            ,persistentId
	);
	
};
com.art.photosToArt.commands.ApplicationCommand.prototype.initializeApiSuccess = function(note)
{
	var _this = this;
    //STEP: We have a successful API validation for this new user, which means we have now a valid sessionId...this will be used for the anonymous users account
    var responseCode    = note.body.OperationResponse.ResponseCode;
    if (responseCode == 200)
    {
        var sessionId = note.body.SessionId;
        var cookieHelper = new com.art.core.cookie.Cookie();
        
        //STEP: set this as the value of the cookie for anonymous return
        var today = new Date();
        var d = new Date(today.getFullYear()+2, today.getMonth(), today.getDate(), today.getHours(), today.getMinutes(), today.getSeconds(), today.getMilliseconds());
        
        cookieHelper.setCookieDictionary(this.app.constants.P2A_COOKIE_DICTIONARY_PERSISTENT
                , this.app.constants.COOKIE_NAME_SESSIONID
                , sessionId
                , '/'
                , cookieHelper.getCookieDomain("")
                , d
                , false);
        
        //trace('INITIALIZE_API_SUCCESS -- PersistentId = ' + note.body.PersistentId + ', SessionId = ' + note.body.SessionId);
        var persistentId = note.body.PersistentId;
        var application = note.body.Application;
                        
        cookieHelper.setCookieDictionary(this.app.constants.P2A_COOKIE_DICTIONARY_PERSISTENT
                , this.app.constants.COOKIE_NAME_P2AKEY
                , persistentId
                , '/'
                , cookieHelper.getCookieDomain("")
                , d
                , false);
        
        //NOTE: Application Configuration - Caching the Environment Variable
        try
        {
            for (var property in application.Configuration.KeyValuePairs)
            {
            	//trace(application.Configuration.KeyValuePairs[property].Key);
            	try
            	{
            		var key = application.Configuration.KeyValuePairs[property].Key;
            		var value = this.convertConfigValue(application.Configuration.KeyValuePairs[property].Value);
            		this.app.addToEnvironment(key,value );
            		////trace('Added to Application: key: ' + key + ' value: ' + value);
            	}
            	catch(err){this.app.logError(err);}
            }
            
        }
        catch(err){this.app.logError(err);}
        
        //STEP: IMPORTANT!!! - Here is where we instantiate the Model for the entire application
        this.app.initModel(this.app.getEnvironment());
        
        //STEP: Now get the model into a local variable
        var model = this.app.getModel();
        
        //STEP: IMPORTANT!!! - Between now and the end of the routine (where the user sees the UI) this is the "initializing" step...set a flag in the Model for this
        model.initializeBegin();
        
    	//STEP: The ApplicationProxy (Model) will hold values (cache).  These are "application" values that need to be stored in the Model, capture here...
    	model.setApplicationValue({key:'apiKey',value:this.app.getEnvironment().apiKey});
        
        //NOTE: Application Configuration - This is where configuration values come from server and are set for the app
    	model.setApplicationValue({key:'applicationId',value:this.app.getEnvironment().applicationId});
    	model.setApplicationValue({key:'customerZoneId',value:application.DefaultCustomerZoneId});
    	model.setApplicationValue({key:'photosToArtApnum',value:application.GenericItemNumbers.PhotosToArt});
    	model.setApplicationValue({key:'servicePriceBucketId',value:application.ServicePriceBucketId});
    	
	    //NOTE: IMPORTANT!!! - Getting the sessionId from the service call
        var anonymousUserNameAndPassword = this.createAnonymousUidPwd(persistentId, "@art.com");
        var email = anonymousUserNameAndPassword.username;
        var password = anonymousUserNameAndPassword.password;    		    
        model.setUser({'key':'sessionId','value':sessionId});
        model.setUser({'key':'countryIsoGeoLocation','value':note.body.GeoIPCountryCode});
        model.setUser({'key':'countryIso','value':this.app.getEnvironment().countryCode});
        model.setUser({'key':'currencyIso','value':note.body.IsoCurrencyCode});
        model.setUser({'key':'persistentId','value':persistentId});
        model.setUser({'key':'languageIso','value':this.app.getEnvironment().languageIso});
        model.setUser({'key':'email','value':email});
        
        //NOTE: Set Identifier values for the Logging Mananger
        this.app.getLoggingManager().sessionIdSet(sessionId);
        
    	//NOTE: Set Defaults: Item Service
    	model.SelectedItemServiceSet(this.app.getEnvironment().serviceDefault);
	    
        //NOTE: Initialize the state.SelectedItemServiceSubType. Defaults to museum normally.
        model.SelectedItemServiceSubTypeSet(model.SelectedItemServiceGet());
        
        //NOTE: If we are returning from the ShoppingCart, we need to consume querystring values.
		model.updateSelectedItemWorkflow();
        
		//STEP: Update app environment variable with model environment variable cause it may have changed within that last function call
		this.app.addToEnvironment("startAuto", model.environment.startAuto);
		
        this.registerCMSEvents();
        
        //CONDITION: p2akey exists...now it must be looked up

        var apiKey = model.application.apiKey;
        
        //NOTE: Set the Language Dictionary
        this.app.getLocalizationManager().setLanguageDictionary(this.app.getEnvironment().apiKey, sessionId, this.app.getEnvironment().localizationAppId);
        this.app.getLocalizationManager().load();
        this.app.getLocalizationManager().registerCallback(com.art.core.utils.LocalizationManager.LOADED,function(){
        	_this.notify(new com.art.core.utils.Note(_this.app.events.AUTHENTICATE_ACCOUNT,{'sessionId':sessionId,'apiKey':apiKey,'email':email,'password':password},'vo'));
        });
        this.app.getLocalizationManager().registerCallback(com.art.core.utils.LocalizationManager.ERROR,function(){
            _this.notify(new com.art.core.utils.Note(_this.app.events.AUTHENTICATE_ACCOUNT,{'sessionId':sessionId,'apiKey':apiKey,'email':email,'password':password},'vo'));
        });    
        
    }
    else
    {
    	this.notify(new com.art.core.utils.Note(this.app.events.INITIALIZE_API_FAILURE,{},'vo'));
    }
};
com.art.photosToArt.commands.ApplicationCommand.prototype.authenticateAccount = function(note)
{
	var _this = this;
	var sessionId = note.body.sessionId;		
    var apiKey = note.body.apiKey;          
	var email = note.body.email;
	var password = note.body.password;
	var handlers = this.service.createHandlers(
	        this.getHandlerFunction(_this.app.events.AUTHENTICATE_ACCOUNT_SUCCESS,_this)
			,this.getHandlerFunction(_this.app.events.AUTHENTICATE_ACCOUNT_FAILURE,_this)
			,this.getHandlerFunction("",_this)
	);
	this.service.accountAuthorizationAPIService.accountAuthenticate(
            handlers
            ,apiKey
	        ,sessionId
            ,email
            ,password
	);
	
};
com.art.photosToArt.commands.ApplicationCommand.prototype.authenticateAccountSuccess = function(note)
{
	var model = this.app.getModel();
	var responseCode    = note.body.OperationResponse.ResponseCode;
    var persistentId = model.user.persistentId;
    var sessionId = model.user.sessionId;
    var apiKey = model.application.apiKey;
    
    if(responseCode == 200) 
    {
        //CONDITION: We have the user, capture the details here
        var authToken = note.body.AuthenticationToken;
        model.setUser({'key':'AuthenticationToken','value':authToken});
        ///STEP: The user has been authenticated...now start app, starting with loading app data
		this.loadMasterSizeData();
    }
    else
    {
        //CONDITION: Create a new account using the sessionId
        var anonymousUserNameAndPassword = this.createAnonymousUidPwd(persistentId, "@art.com");
        var email = anonymousUserNameAndPassword.username;
        var password = anonymousUserNameAndPassword.password;
        this.notify(new com.art.core.utils.Note(this.app.events.CREATE_ACCOUNT,{'apiKey':apiKey,'email':email,'password':password,'sessionId':sessionId },'vo'));
    }
};
com.art.photosToArt.commands.ApplicationCommand.prototype.createAccount = function(note)
{
	var _this = this;
	var sessionId = note.body.sessionId;      
    var apiKey = note.body.apiKey;          
    var handlers = this.service.createHandlers(
            this.getHandlerFunction(_this.app.events.CREATE_ACCOUNT_SUCCESS,_this)
            ,this.getHandlerFunction(_this.app.events.CREATE_ACCOUNT_FAILURE,_this)
            ,this.getHandlerFunction("",_this)
    );
    var email = note.body.email;
    var password = note.body.password;
    this.service.accountAuthorizationAPIService.accountCreate(
            handlers
            ,apiKey
            ,sessionId
            ,email
            ,password
    );
};
com.art.photosToArt.commands.ApplicationCommand.prototype.createAccountSuccess = function(note)
{
    var responseCode    = note.body.OperationResponse.ResponseCode;
    if(responseCode == 200) //Check the response code for a 200
    {
        var authToken = note.body.AuthenticationToken;
        this.app.getModel().setUser({'key':'AuthenticationToken','value':authToken});
        ///STEP: The user has been authenticated...now start app, starting with loading app data
        this.loadMasterSizeData();
    }
};
com.art.photosToArt.commands.ApplicationCommand.prototype.catalogItemVariationsGetMaster = function(note)
{
	var _this = this;
    var sessionId = note.body.sessionId;      
    var apiKey = note.body.apiKey;       
    var lookupType = note.body.lookupType;
    var handlers = this.service.createHandlers(
            this.getHandlerFunction(_this.app.events.CATALOG_ITEM_VARIATIONS_GET_MASTER_SUCCESS,_this)
            ,this.getHandlerFunction(_this.app.events.CATALOG_ITEM_VARIATIONS_GET_MASTER_FAILURE,_this)
            ,this.getHandlerFunction("",_this)
    );

    this.service.ecommerceAPIService.catalogItemVariationsGetMaster(
            handlers
            ,apiKey
            ,sessionId
            ,lookupType
    );
};
com.art.photosToArt.commands.ApplicationCommand.prototype.catalogItemVariationsGetMasterSuccess = function(note)
{
	var model = this.app.getModel();
    //STEP: first step here is to cache this master data
	model.addMasterSizeDataToCache(note.body);

    var apiKey = model.application.apiKey;
    var sessionId = model.user.sessionId;
    var authToken = model.user.authenticationToken;
      
    this.notify(new com.art.core.utils.Note(this.app.events.GALLERY_GET_BY_USER,{'apiKey':apiKey,'sessionId':sessionId,'authToken':authToken },'vo'));
};
com.art.photosToArt.commands.ApplicationCommand.prototype.galleryGetByUser = function(note)
{
	var _this = this;
	var sessionId = note.body.sessionId;      
    var apiKey = note.body.apiKey;       
    var authToken = note.body.authToken;
    var handlers = this.service.createHandlers(
            this.getHandlerFunction(_this.app.events.GALLERY_GET_BY_USER_SUCCESS,_this)
            ,this.getHandlerFunction(_this.app.events.GALLERY_GET_BY_USER_FAILURE,_this)
            ,this.getHandlerFunction("",_this)
    );

    this.service.ecommerceAPIService.galleryGetByUser(
            handlers
            ,apiKey
            ,sessionId
            ,authToken
    );
};
com.art.photosToArt.commands.ApplicationCommand.prototype.galleryGetByUserSuccess = function(note)
{
	var makeNewGalleryForUser = false;
    var responseCode = note.body.OperationResponse.ResponseCode;
    var model = this.app.getModel();
    
    if(responseCode == 200) //Check the response code for a 200 -- happy path...
    {
        //STEP: We got gallery(ies), we need the "P2A" gallery, as named by a constant in the P2aCore
        var galleries = note.body.Galleries;
        var galleryId = 0;
        var galleryName = '';
        if (galleries)
        {
            var gallery = new com.art.photosToArt.vos.GalleryVo();
            gallery.getGalleryFromServiceResponseByTitle(galleries, this.app.constants.GALLERY_PHOTOSTOART_DEFAULT_NAME);
            
            if (gallery.isLoaded)
            {
                galleryId = gallery.galleryId;
                galleryName = gallery.title;
            }
        }
        if (galleryId > 0)
        {
            //STEP: Save this to the model
            model.GalleryIdForPhotosToArtSet(galleryId);
            var apiKey = model.application.apiKey;
            var sessionId = model.user.sessionId;
            this.notify(new com.art.core.utils.Note(this.app.events.GALLERY_GET,{'apiKey':apiKey,'sessionId':sessionId,'galleryId':galleryId},'vo'));
        }
        else
        {
            makeNewGalleryForUser = true;
        }
    }
    else
    {
            makeNewGalleryForUser = true;             
    }
    if (makeNewGalleryForUser)
    {
        //STEP: We do not have a galleryId, so make one...
    	var apiKey = model.application.apiKey;
        var sessionId = model.user.sessionId;
        var authToken = model.user.authenticationToken;
        galleryName = this.app.constants.GALLERY_PHOTOSTOART_DEFAULT_NAME;
        var galleryVisibility = this.app.constants.GALLERY_PHOTOSTOART_DEFAULT_VISIBILITY;

        this.notify(new com.art.core.utils.Note(this.app.events.GALLERY_ADD_FOR_USER,{'apiKey' : apiKey, 'sessionId':sessionId, 'authToken':authToken, 'galleryName':galleryName, 'galleryVisibility':galleryVisibility },'vo'));                    
    }
};
com.art.photosToArt.commands.ApplicationCommand.prototype.galleryAddForUser = function(note)
{
	var _this = this;
    var sessionId = note.body.sessionId;      
    var apiKey = note.body.apiKey;       
    var authToken = note.body.authToken;
    var galleryName = note.body.galleryName;
    var galleryVisibility = note.body.galleryVisibility;
    var handlers = this.service.createHandlers(
            this.getHandlerFunction(_this.app.events.GALLERY_ADD_FOR_USER_SUCCESS,_this)
            ,this.getHandlerFunction(_this.app.events.GALLERY_ADD_FOR_USER_FAILURE,_this)
            ,this.getHandlerFunction("",_this)
    );

    this.service.ecommerceAPIService.galleryAddForUser(
            handlers
            ,apiKey
            ,sessionId
            ,authToken
            ,galleryName
            ,galleryVisibility
    );
};
com.art.photosToArt.commands.ApplicationCommand.prototype.galleryAddForUserSuccess = function(note)
{
    //STEP: We have added a gallery to be used for items and we have no items yet, so save in the model and call next step
	var model = this.app.getModel();
    var galleryVo = new com.art.photosToArt.vos.GalleryVo();
    galleryVo.parseGalleryFromServiceResponse(note.body.Gallery);
    var galleryId = galleryVo.galleryId;
    
    model.GalleryIdForPhotosToArtSet(galleryId);
    model.addGalleryToCache(galleryVo);
    
    //galleryGet = function(callbacks, apiKey, sessionId, galleryId)
    var apiKey = model.application.apiKey;
    var sessionId = model.user.sessionId;
    this.notify(new com.art.core.utils.Note(this.app.events.GALLERY_GET,{'apiKey':apiKey,'sessionId':sessionId,'galleryId':galleryId},'vo'));

};
com.art.photosToArt.commands.ApplicationCommand.prototype.galleryGet = function(note)
{
	var _this = this;
    var sessionId = note.body.sessionId;      
    var apiKey = note.body.apiKey;       
    var galleryId = note.body.galleryId;
    var handlers = this.service.createHandlers(
            this.getHandlerFunction(_this.app.events.GALLERY_GET_SUCCESS,_this)
            ,this.getHandlerFunction(_this.app.events.GALLERY_GET_FAILURE,_this)
            ,this.getHandlerFunction("",_this)
    );

    this.service.ecommerceAPIService.galleryGet(
            handlers
            ,apiKey
            ,sessionId
            ,galleryId
    );
};
com.art.photosToArt.commands.ApplicationCommand.prototype.galleryGetSuccess = function(note)
{
	var model = this.app.getModel();
	var galleryVo = new com.art.photosToArt.vos.GalleryVo();
	galleryVo.parseGalleryFromServiceResponse(note.body.Gallery);
	model.addGalleryToCache(galleryVo);
	
	var itemCount = 0;
	if (note.body.Gallery && note.body.Gallery.GalleryItems && note.body.Gallery.GalleryItems.length && note.body.Gallery.GalleryItems.length > 0 )
	{
		itemCount = note.body.Gallery.GalleryItems.length;
		model.SelectedImageGuidDefaultSet();
	}
	
	//STEP: At this point we have a user and a Gallery for that user, so now initialize is complete
    model.initializeEnd();

	
	//STEP: Determine if we load the UI now based on Config Value
    if (this.app.getEnvironment().startAuto == true)
    {
        //STEP: There should be one place that calls "LOAD_USER_INTERFACE" and this is it...
        this.notify(new com.art.core.utils.Note(this.app.events.LOAD_USER_INTERFACE,{itemCount:itemCount},'vo'));
    }
    else
    {
        //STEP: We are then assuming we are in a state where we need to invoke the call to action buttons
        this.app.getModel().invokeCallToActionButtons();
    }
};

com.art.photosToArt.commands.ApplicationCommand.prototype.galleryRemoveItem = function(note)
{
	//trace('AppCmd received event GALLERY_REMOVE_ITEM');
	var _this = this;
	var galleryId = note.body.GalleryId;
	var galleryItemId = note.body.GalleryItemId;
	var apiKey = note.body.apiKey;
	var sessionId = note.body.sessionId;
	var authToken = note.body.authToken;
	var keyValuePairs = { deletedImageGuid : note.body.Sku, currentSelectedImageGuid : note.body.CurrentSelectedImageGuid};
    var handlers = this.service.createHandlers(
            this.getHandlerFunctionCustom(_this.app.events.GALLERY_REMOVE_ITEM_SUCCESS,_this, keyValuePairs)
            ,this.getHandlerFunctionCustom(_this.app.events.GALLERY_REMOVE_ITEM_FAILURE,_this, keyValuePairs)
            ,this.getHandlerFunction("",_this)
    );
    //takes: callbacks, apiKey, sessionId, authToken, galleryId, galleryItemId
    this.service.ecommerceAPIService.galleryRemoveItem(
    		handlers
    		, apiKey
    		, sessionId
    		, authToken
    		, galleryId
    		, galleryItemId);
};
com.art.photosToArt.commands.ApplicationCommand.prototype.catalogItemGetVariations = function(note)
{
	var _this = this;
	var sessionId = note.body.sessionId;      
    var apiKey = note.body.apiKey;       
    var itemId = note.body.itemId;
    var lookupType = note.body.lookupType;
    var handlers = this.service.createHandlers(
            this.getHandlerFunction(_this.app.events.CATALOG_ITEM_GET_VARIATIONS_SUCCESS,_this)
            ,this.getHandlerFunction(_this.app.events.CATALOG_ITEM_GET_VARIATIONS_FAILURE,_this)
            ,this.getHandlerFunction("",_this)
    );

    this.service.ecommerceAPIService.catalogItemGetVariations(
            handlers
            ,apiKey
            ,sessionId
            ,itemId
            ,lookupType
    );
};
com.art.photosToArt.commands.ApplicationCommand.prototype.frameGetComponents = function(note)
{
	trace('in AppCmd: FRAME_GET_COMPONENTS');
	var _this = this;
	var model = this.app.getModel();
	//This is a specific request from the ModuleFramingService
    var handlers = this.service.createHandlers(
    		this.getHandlerFunction(_this.app.events.FRAME_GET_COMPONENTS_SUCCESS, _this)
    		,this.getHandlerFunction(_this.app.events.FRAME_GET_COMPONENTS_FAILURE, _this)
    		,this.getHandlerFunction("",_this)
    );
	this.app.getServiceProvider().ecommerceAPIService.frameGetComponentsForUserImage(
            handlers
            ,model.application.apiKey
	        ,model.user.sessionId
	        ,model.SelectedItemPodConfigIdGet() 
	        ,com.art.core.vos.ImageVO.itemTypeFromDomain.UserUploadedItem
	);
};
com.art.photosToArt.commands.ApplicationCommand.prototype.frameGetMouldingPrice = function(note)
{
	trace('in AppCmd: FRAME_GET_MOULDING_PRICE');
	var _this = this;
	var model = this.app.getModel();
	
	//frameGetMoldingPriceByFrameId = function(callbacks,apiKey,sessionId,frameId,moldingId)
	
	// First, try fetching from model -  I think it's best if I take care of figuring out the podConfig rather than require it to be passed in.
	var price = model.getMouldingPrice(note.body.mouldingId);
	if(price == null)
	{
		// Service call to get the price
		// frameId is what we really need to make the service call - it can be used server side to get the podConfigId
        var handlers = this.service.createHandlers(
        		this.getHandlerFunction(this.events.FRAME_GET_MOULDING_PRICE_COMPLETE, _this)
        		,this.getHandlerFunction(_this.app.events.FRAME_GET_MOULDING_PRICE_FAILURE, _this)
        		,this.getHandlerFunction("",_this)
        );
        
    	trace("frameGetMouldingPrice else");
    	trace(note);
        this.app.getServiceProvider().ecommerceAPIService.frameGetMoldingPriceByFrameId(
        		handlers
        		,model.application.apiKey
        		,model.user.sessionId
        		,note.body.frameId
        		,note.body.mouldingId
        );
	}
	else
	{
		// We already have the data - send it out.
		// TODO: make sure the note that would go out
		this.notify(new com.art.core.utils.Note(this.app.events.FRAME_GET_MOULDING_PRICE_SUCCESS, 
			{	'price' : price,
				'mouldingId' : note.body.mouldingId
			}, 'vo'));
	}
};
com.art.photosToArt.commands.ApplicationCommand.prototype.frameGetMouldingPriceComplete = function(note)
{
	// Update the model. If isComplete is true, it means this notification would be redundant
	//   since service call was unnecessary
	var model = this.app.getModel();
	trace('in AppCmd: FRAME_GET_MOULDING_PRICE_COMPLETE');
	if(this.operationSuccessful(note, this.events.FRAME_GET_MOULDING_PRICE_COMPLETE))
	{
		var obj = {	'price' : note.body.PriceFormatted,
					'mouldingId' : note.body.Molding.MouldingId
		};
		this.notify(new com.art.core.utils.Note(this.app.events.FRAME_GET_MOULDING_PRICE_SUCCESS, obj, 'vo'));
    	model.updateMouldingPrice(note.body.Molding.MouldingId, note.body.PriceFormatted);
	}
};
com.art.photosToArt.commands.ApplicationCommand.prototype.frameUpdateMoulding = function(note)
{
	var _this = this;
	var model = this.app.getModel();
	trace('in AppCmd: FRAME_UPDATE_MOLDING');
	// I don't think I need to update the model here - worst case is that the model is correct right now and I make unnecessary service call
    var handlers = this.service.createHandlers(
    		this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS, _this)
    		,this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_FAILURE, _this)
    		,this.getHandlerFunction("",_this)
    		);
    this.service.ecommerceAPIService.frameUpdateMolding(
    		handlers
    		,model.application.apiKey
    		,model.user.sessionId
    		,note.body.frameId
    		,note.body.mouldingId
    );
    
};
com.art.photosToArt.commands.ApplicationCommand.prototype.frameUpdateMat = function(note)
{
	var _this = this;
	try
	{
	var model = this.app.getModel();
	trace('in AppCmd: FRAME_UPDATE_MAT');
	// I don't think I need to update the model here - worst case is that the model is correct right now and I make unnecessary service call
    var handlers = this.service.createHandlers(
    		this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS, _this)
    		,this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_FAILURE, _this)
    		,this.getHandlerFunction("",_this)
    		);
    //frameUpdateMat = function(callbacks,apiKey,sessionId,frameIdentifier,matItemNumber,position)
    this.service.ecommerceAPIService.frameUpdateMat(
    		handlers
    		,model.application.apiKey
    		,model.user.sessionId
    		,note.body.frameId
    		,note.body.mouldingId
    		,note.body.position
    );
	}
	catch(err)
	{
		trace('Error in AC.frameUpdateMat: ' + err.message);
	}
    
};
com.art.photosToArt.commands.ApplicationCommand.prototype.frameUpdateMatCount = function(note)
{
	var _this = this;
	var model = this.app.getModel();
	trace('in AppCmd: FRAME_UPDATE_MAT_COUNT');
	// I don't think I need to update the model here - worst case is that the model is correct right now and I make unnecessary service call
    var handlers = this.service.createHandlers(
    		this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS, _this)
    		,this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_FAILURE, _this)
    		,this.getHandlerFunction("",_this)
    		);
    //frameUpdateMat = function(callbacks,apiKey,sessionId,frameIdentifier,matItemNumber,position)
    this.service.ecommerceAPIService.frameUpdateMatCount(
    		handlers
    		,model.application.apiKey
    		,model.user.sessionId
    		,note.body.frameId
    		,note.body.matCount
    );
    
};

/**
 * Update frame
 * @param note
 */
com.art.photosToArt.commands.ApplicationCommand.prototype.frameUpdateMolding = function(note)
{
	var _this = this;
	var model = this.app.getModel();
	trace('in AppCmd: FRAME_UPDATE_MAT_COUNT');
	// I don't think I need to update the model here - worst case is that the model is correct right now and I make unnecessary service call
    var handlers = this.service.createHandlers(
    		this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS, _this)
    		,this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_FAILURE, _this)
    		,this.getHandlerFunction("",_this)
    		);
    //frameUpdateMolding = callbacks,apiKey,sessionId,frameIdentifier,moldingItemNumber,position
    this.service.ecommerceAPIService.frameUpdateMolding(
    		handlers
    		,model.application.apiKey
    		,model.user.sessionId
    		,note.body.frameId
    		,note.body.mouldingItemNumber
    		,0
    );
};

/**
 * Frame updateMat
 */
com.art.photosToArt.commands.ApplicationCommand.prototype.frameUpdateMat = function(note)
{
	var _this = this;
	var model = this.app.getModel();
	trace('in AppCmd: FRAME_UPDATE_MAT');
	// I don't think I need to update the model here - worst case is that the model is correct right now and I make unnecessary service call
    var handlers = this.service.createHandlers(
    		this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS, _this)
    		,this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_FAILURE, _this)
    		,this.getHandlerFunction("",_this)
    		);
    //frameUpdateMat = callbacks,apiKey,sessionId,frameIdentifier,matItemNumber,position
    trace('FrameUpdateMat is updating matItemNumber to ' + note.body.matItemNumber);
    this.service.ecommerceAPIService.frameUpdateMat(
    		handlers
    		,model.application.apiKey
    		,model.user.sessionId
    		,note.body.frameId
    		,note.body.matItemNumber
    		,note.body.position
    );
};
com.art.photosToArt.commands.ApplicationCommand.prototype.galleryAddItem = function(note)
{
	//galleryAddItem = function(callbacks, apiKey, sessionId, authToken, galleryId, itemId, lookupType, userImageTitle)
	var _this = this;
    var sessionId = note.body.sessionId;      
    var apiKey = note.body.apiKey;
    var authToken = note.body.authToken;
    var galleryId = note.body.galleryId;
    var itemIdentifier = note.body.imageGuid;
    var lookupType = note.body.lookupType;
    var userImageTitle = note.body.userImageTitle;
    var handlers = this.service.createHandlers(
              this.getHandlerFunction(_this.app.events.GALLERY_ADD_ITEM_SUCCESS,_this)
            , this.getHandlerFunction(_this.app.events.GALLERY_ADD_ITEM_FAILURE,_this)
            , this.getHandlerFunction("",_this)
    );

    this.service.ecommerceAPIService.galleryAddItem(
            handlers
            ,apiKey
            ,sessionId
            ,authToken
            ,galleryId
            ,itemIdentifier
            ,lookupType
            ,userImageTitle
    );
};
com.art.photosToArt.commands.ApplicationCommand.prototype.imageUpdateAndGetResults = function(note)
{
	var _this = this;
	var handlers = {};
	var model = this.app.getModel();
	var service = model.SelectedItemServiceGet().name;
	var authToken = model.user.authenticationToken;
	
	if(service === model.data.serviceTypes.framing.name)
	{
    	trace('in AppCmd:  IMAGE_UPDATE_AND_GET_RESULTS - for FRAMING');
		//This is a specific request from the ModuleFramingService
        handlers = this.service.createHandlers(
        		this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS, _this)
        		,this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_FAILURE, _this)
        		,this.getHandlerFunction("",_this)
        );
        if(note.body.ImageCropId == undefined)
        {
            note.body.ImageCropId = 0;
        }
        if(note.body.action === 'crop')
        {
        	this.frameUpdateCrop(handlers, note.body);
        }
        else if(note.body.action === 'sizecrop')
        {
        	this.frameUpdateImageSize(handlers, note.body);
        }
        else
        {
			this.service.ecommerceAPIService.frameCreateForUserImage(
	                handlers
	                ,model.application.apiKey
	                ,model.user.sessionId
	                ,authToken
	                ,model.user.persistentId
			        ,note.body.imageGuid
			        ,note.body.podConfigId
			        ,note.body.ImageCropId
			);
        }
	}
	else
	{
		//trace('APPCMD - IMAGE_UPDATE_AND_GET_RESULTS non-framing service ');
        handlers = this.service.createHandlers(
                this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_SUCCESS,_this)
                ,this.getHandlerFunction(_this.app.events.IMAGE_UPDATE_AND_GET_RESULTS_FAILURE,_this)
                ,this.getHandlerFunction("",_this)
        );
        //trace('APPCMD__IMAGE_UPDATE- sel.SVC - ' + parms.selectedService);
        //trace('Calling imageUpdate with CropX ' + parms.cropX + ' and CropW ' + parms.cropW);
        var parms = note.body;
		this.service.ecommerceAPIService.imageUpdate(handlers, parms.apiKey, authToken, parms.sessionId, parms.imageId, parms.imageGuid, parms.ImageCropId, parms.cropX, parms.cropY, parms.cropW, parms.cropH, parms.podConfigId, parms.selectedService, parms.selectedServiceSubType, parms.maxImageAreaWidth, parms.maxImageAreaHeight);
	}
};
com.art.photosToArt.commands.ApplicationCommand.prototype.catalogGetContent = function(note)
{
	var contentBlockName = note.body.contentBlockName;
	var anchor = "";
	if (note.body.anchor != undefined)
		anchor = note.body.anchor;
	
	this.getContentBlock(contentBlockName, anchor);
};
com.art.photosToArt.commands.ApplicationCommand.prototype.addToCart = function(note)
{
	var handlers = {};
	var _this = this;
	var successEvent = note.name == this.app.events.ADDTOCART_GOTOCART ? this.app.events.ADDTOCART_GOTOCART_SUCCESS : this.app.events.ADDTOCART_STAY_SUCCESS; 
	var failureEvent = note.name == this.app.events.ADDTOCART_GOTOCART ? this.app.events.ADDTOCART_GOTOCART_FAILURE : this.app.events.ADDTOCART_STAY_FAILURE; 
    handlers = this.service.createHandlers(
            this.getHandlerFunction(successEvent,_this)
            ,this.getHandlerFunction(failureEvent,_this)
            ,this.getHandlerFunction("",_this)
    );

    var queryString = note.body.queryString;
	this.service.adcNetService.addToCart(handlers, queryString);
};

com.art.photosToArt.commands.ApplicationCommand.prototype.duplicateFrameForCart = function(note)
{
    var _this = this;
    var model = this.app.getModel();
    trace('in AppCmd: duplicateFrameForCart');
    // I don't think I need to update the model here - worst case is that the model is correct right now and I make unnecessary service call
    var handlers = this.service.createHandlers(
            this.getHandlerFunction(_this.app.events.DUPLICATE_FRAME_FOR_CART_SUCCESS, _this)
            ,this.getHandlerFunction(_this.app.events.DUPLICATE_FRAME_FOR_CART_FAILURE, _this)
            ,this.getHandlerFunction("",_this)
            );
    //frameUpdateMat = callbacks,apiKey,sessionId,frameIdentifier,matItemNumber,position
    this.service.ecommerceAPIService.frameDuplicateForCart(
            handlers
            ,model.application.apiKey
            ,model.user.sessionId
            ,model.SelectedItemFrameIdGet()
    );
};

com.art.photosToArt.commands.ApplicationCommand.prototype.handleNotification = function(note)
{
	switch(note.name)
	{
		case this.app.events.STARTUP:
			break;
			//NOTE:  moved to ValidateApiKeyCommand	
		case this.app.events.INITIALIZE_API:
			this.initializeApi(note);
			break;
		case this.app.events.INITIALIZE_API_SUCCESS:
			this.initializeApiSuccess(note);
			break;
		case this.app.events.AUTHENTICATE_ACCOUNT:
			this.authenticateAccount(note);
			break;
		case this.app.events.AUTHENTICATE_ACCOUNT_SUCCESS:
			this.authenticateAccountSuccess(note);
		    break;
        case this.app.events.CREATE_ACCOUNT:
            this.createAccount(note);
            break;
        case this.app.events.CREATE_ACCOUNT_SUCCESS:
        	this.createAccountSuccess(note);
            break;
        case this.app.events.CATALOG_ITEM_VARIATIONS_GET_MASTER:
        	this.catalogItemVariationsGetMaster(note);
            break;          
        case this.app.events.CATALOG_ITEM_VARIATIONS_GET_MASTER_SUCCESS:
        	this.catalogItemVariationsGetMasterSuccess(note);
            break;            
        case this.app.events.GALLERY_GET_BY_USER:
        	this.galleryGetByUser(note);
            break;          
        case this.app.events.GALLERY_GET_BY_USER_SUCCESS:
            this.galleryGetByUserSuccess(note);
            break;
        case this.app.events.GALLERY_ADD_FOR_USER:
        	this.galleryAddForUser(note);
            break;  
        case this.app.events.GALLERY_ADD_FOR_USER_SUCCESS:
        	this.galleryAddForUserSuccess(note);
            break;
        case this.app.events.GALLERY_GET:
        	this.galleryGet(note);
            break;   
        case this.app.events.GALLERY_GET_SUCCESS:
        	this.galleryGetSuccess(note);
    		break;
        case this.app.events.GALLERY_REMOVE_ITEM:
        	this.galleryRemoveItem(note);
            break;   
        case this.app.events.CATALOG_ITEM_GET_VARIATIONS:
        	this.catalogItemGetVariations(note);
            break;          
        case this.app.events.FRAME_GET_COMPONENTS:
            this.frameGetComponents(note);
			break;
        case this.app.events.FRAME_GET_MOULDING_PRICE:
        	this.frameGetMouldingPrice(note);
        	break;
        case this.events.FRAME_GET_MOULDING_PRICE_COMPLETE:
        	this.frameGetMouldingPriceComplete(note);
        	break;
        case this.app.events.FRAME_UPDATE_MOLDING:
        	this.frameUpdateMoulding(note);
        	break;
        case this.app.events.FRAME_UPDATE_MAT:
        	this.frameUpdateMat(note);
        	break;
        case this.app.events.FRAME_UPDATE_MAT_COUNT:
        	this.frameUpdateMatCount(note);
        	break;
        case this.app.events.FRAME_UPDATE_MOULDING:
        	this.frameUpdateMolding(note);
        	break;
        case this.app.events.GALLERY_ADD_ITEM:
        	this.galleryAddItem(note);
        	break;
        case this.app.events.IMAGE_UPDATE_AND_GET_RESULTS:
        	this.imageUpdateAndGetResults(note);
			break;
        case this.app.events.CATALOG_GET_CONTENT:
        	this.catalogGetContent(note);
        	break;
        case this.app.events.ADDTOCART_GOTOCART:
        case this.app.events.ADDTOCART_STAY:
        	this.addToCart(note);
        	break;
        case this.app.events.DUPLICATE_FRAME_FOR_CART:
            this.duplicateFrameForCart(note);
            break;
        case this.app.events.GET_SALES_EVENT_MESSAGE_FOR_PRODUCT:
            this.getSalesEventMessageForProduct(note);
            break;
	}
};

com.art.photosToArt.commands.ApplicationCommand.prototype.getSalesEventMessageForProduct = function(note)
{
    var _this = this;
    var model = this.app.getModel();
    var customerZoneId = model.application.customerZoneId;
    var languageIsoCode = model.user.languageIso;
    var countryIsoCode = com.art.core.utils.LocalizationManager.convertCountryIsoA2ToCountryIsoNumber(model.user.countryIso); //10/2011 - this service expects IsoNumber for Country, not Iso A2
    var apnum = model.application.photosToArtApnum;
    var podConfigId = model.SelectedItemPodConfigIdGet();
    var serviceCode = 1; //pessimistic default setting in case good data not availabel
    
    //STEP: the following codes are what the event messaging is expecting in the form of service information
    switch(model.SelectedItemServiceGet().name)
    {
        case model.data.serviceTypes.printOnly.name:
            serviceCode = 0; //PNP = 0,
            break;
        case model.data.serviceTypes.framing.name:
            serviceCode = 1; //FRAMED = 1,
            break;
        case model.data.serviceTypes.mounting.name:
            serviceCode = 2; //MOUNTED = 2,
            break;
        case model.data.serviceTypes.acrylic.name:
            serviceCode = 6; //LAMINATED = 6,
            break;
        case model.data.serviceTypes.canvasMuseum.name:
        case model.data.serviceTypes.canvasGallery.name:
            serviceCode = 4; //CANVASTRANSFER = 4
            break;
    }
    
    var currentTime = new Date();
    if(note.body.dateToday)
    {
        currentTime = new Date(note.body.dateToday);
    }
    var month = currentTime.getMonth() + 1; var day = currentTime.getDate(); var year = currentTime.getFullYear();
    var hour = currentTime.getHours(); var minute = currentTime.getMinutes();
    var dateUserCurrent = month + "/" + day + "/" + year + "+" + hour + ":" + minute; 
    var handlers = this.service.createHandlers(
            this.getHandlerFunction(_this.app.events.GET_SALES_EVENT_MESSAGE_FOR_PRODUCT_SUCCESS, _this)
            ,
            this.getHandlerFunction(_this.app.events.GET_SALES_EVENT_MESSAGE_FOR_PRODUCT_FAILURE, _this)
            ,
            this.getHandlerFunction("",_this)
    );
    
    this.service.adcNetService.getEventMessageForProduct(
            handlers
            , customerZoneId
            , languageIsoCode
            , countryIsoCode
            , apnum
            , podConfigId
            , serviceCode
            , dateUserCurrent
    );
};


com.art.photosToArt.commands.ApplicationCommand.prototype.getContentBlock = function(contentBlockName, anchor)
{
	var _this = this;
	var model = this.app.getModel();
	var sessionId = model.user.sessionId;
	var apiKey = model.application.apiKey;
	
	var handlers = this.service.createHandlers(
			this.getHandlerFunctionCustom(_this.app.events.CATALOG_GET_CONTENT_SUCCESS, _this, {contentBlockName:contentBlockName, anchor: anchor})
	        ,
			this.getHandlerFunctionCustom(_this.app.events.CATALOG_GET_CONTENT_FAILURE, _this, {contentBlockName:contentBlockName, anchor: anchor})
	        ,
	        this.getHandlerFunction("",_this)
	);
	
	this.service.ecommerceAPIService.catalogGetContentBlockString(
	        handlers
	        ,apiKey
	        ,sessionId
	        ,contentBlockName
	);
};

com.art.photosToArt.commands.ApplicationCommand.prototype.notify = function(note)
{
	this.app.sendNotification(note);
};

com.art.photosToArt.commands.ApplicationCommand.prototype.getHandlerFunction = function(event, commandObject)
{
    //STEP: If event was passed in, return a function that raises that event with the response...
    if (event !== undefined && event.length > 0)
       return function(response)
        {
            //trace(commandObject.NAME + ": Success Command");
            //trace('AppCommand callback: ' + event);
            commandObject.app.sendNotification(new com.art.core.utils.Note(event,response,'ajax'));
        };
    else //ELSE: Return an empty function, as we need a function, but do not want anything to happen for this handler
        return function(){};
};

com.art.photosToArt.commands.ApplicationCommand.prototype.getHandlerFunctionCustom = function(event, commandObject, keyValuePairs)
{
    //STEP: If event was passed in, return a function that raises that event with the response...
    if (event !== undefined && event.length > 0)
       return function(response)
        {
    		for(var k in keyValuePairs)
    		{
    			response[k] = keyValuePairs[k];
    		}
    		
            //trace(commandObject.NAME + ": Success Command");
            //trace('AppCommand callback: ' + event);
            commandObject.app.sendNotification(new com.art.core.utils.Note(event,response,'ajax'));
        };
    else //ELSE: Return an empty function, as we need a function, but do not want anything to happen for this handler
        return function(){};
};
com.art.photosToArt.commands.ApplicationCommand.prototype.createAnonymousUidPwd = function(persistentId, domain)
{
    return {'username':persistentId+domain,'password':persistentId};
};

com.art.photosToArt.commands.ApplicationCommand.prototype.loadMasterSizeData = function()
{
	var model = this.app.getModel();
	var requestParameters = 
	{
		apiKey : model.application.apiKey
		, sessionId : model.user.sessionId
		, lookupType : com.art.core.vos.ImageVO.itemLookupTypeFromDomain.UserUploadedItem
	};
	this.notify(new com.art.core.utils.Note(this.app.events.CATALOG_ITEM_VARIATIONS_GET_MASTER,requestParameters, 'vo'));
};

com.art.photosToArt.commands.ApplicationCommand.prototype.convertConfigValue = function(value)
{
    switch(value.toLowerCase())
    {
        case "true":
            return true;
            break;
        case "false":
            return false;
            break;
        default:
            return value;
            break;
    }
};

com.art.photosToArt.commands.ApplicationCommand.prototype.operationSuccessful = function(note, eventName)
{
	var result = false;
	try
	{
		result = note.body.OperationResponse.ResponseCode === 200;
		trace(eventName + ' Operation ' + (result ? 'Successful' : 'Failed'));
	}
	catch(err)
	{
		trace('Error in AppCmd.operationSuccessful: ' + err.message);
	}
	return result;
};
/**
 * Register handlers for header, footer, etc - CMS content with hooks
 */
com.art.photosToArt.commands.ApplicationCommand.prototype.registerCMSEvents = function()
{
	var _this = this;
	var _model = this.app.getModel();
	$('#p2a-cart').live('click', function(){
		var cartKey = _model.UserCartKeyGet(PhotosToArtCore.constants.ART_COOKIE_DICTIONARY_PERSISTENT, PhotosToArtCore.constants.COOKIE_NAME_CARTKEY);
		var cartUrl = _this.app.getEnvironment().applicationRootUrl + _this.app.getEnvironment().serviceUrlShoppingCart + '?cartkey=' + cartKey; 
		window.location.href = cartUrl;
	});
	
	$('#p2a-ordertrack-2').live('click', function(){
		var url = _this.app.getEnvironment().applicationRootUrl + _this.app.getEnvironment().serviceUrlOrderTracking;
		window.location.href = url;
	});
	
	$('#p2a-returnToPartner').live('click', function(){
		window.location.href = _this.app.getEnvironment().returnToPartnerUrl;
	});
};

com.art.photosToArt.commands.ApplicationCommand.prototype.getGASeparator = function()
{
	//return '-'; // to right  of zero on alpha keypad.
	//return '%45';
	return '-'; // numeric keypad minus sign (WORKS in IE and FF)
};
com.art.photosToArt.commands.ApplicationCommand.prototype.frameUpdateCrop = function(handlers, noteBody)
{
    var model = this.app.getModel();
    this.app.getServiceProvider().ecommerceAPIService.frameUpdateCrop(
			handlers, 
			model.application.apiKey, 
			model.user.sessionId, 
			model.SelectedItemFrameIdGet(), 
			noteBody.ImageCropId, 
			noteBody.cropX, 
			noteBody.cropY, 
			noteBody.cropW, 
			noteBody.cropH);
};
com.art.photosToArt.commands.ApplicationCommand.prototype.frameUpdateImageSize = function(handlers, noteBody)
{
	var model = this.app.getModel();
    this.app.getServiceProvider().ecommerceAPIService.frameUpdateImageSize(
			handlers, 
			model.application.apiKey, 
			model.user.sessionId, 
			model.SelectedItemFrameIdGet(),
			model.SelectedItemPodConfigIdGet()
			);
};