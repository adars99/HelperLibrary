var apiSettings = ( function (global) {

	var
		_API_SERVICES = {
			JSON : "json"
		,	JSONP : "jsonp"
		}
	;

	return {
		APIROOT : "http://developer-api.art.com/ECommerceAPI.svc/jsonp"
	,   API_PAYMENT : "https://developer-api.art.com/PaymentAPI.svc/jsonp"
		// Note: jQuery ajax method does automatic same-host optimization
	,	API_SERVICE : _API_SERVICES.JSONP
	,	API_SERVICES : _API_SERVICES
	,	PRINTURL: "http://qa-kiosk.art.com/public/receipt/default.aspx"
	//,	PRINTURL: "/dev-art-print/"
	,	KEY: "92035AA30FBD49C78D425395A6EAB23C"
		// Set APP ID based on appId query string parameter
	,	APPID: utils.getQueryParam('appId')
	};

} (this) );
