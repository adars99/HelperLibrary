var utils = ( function (global) {
	var	_this = {}; 	
	var	_defaultParam = "";
	var _fileLocation ="";
	_this.getQueryParam = function(name,_defaultParam) {
		name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
		var regexS = "[\\?&]" + name + "=([^&#]*)";
		var regex = new RegExp(regexS);
		var results = regex.exec(window.location.search);
	  	if(results == null) {
	  	if(_defaultParam==undefined)
    	  	{
	  		return "";
	  		}
	  		else
	  		{
	  		   return _defaultParam;
	  		}
	  		
	  	} else {
	  		return decodeURIComponent(results[1].replace(/\+/g, " "));
	  	}
	}	
	_this.fileExists = function(_fileLocation) {
		var http = jQuery.ajax({
			type:"HEAD",
			url: _fileLocation,
			async: false
		})
		return http.status!=404;
	}	
	return _this;
	
} () );
