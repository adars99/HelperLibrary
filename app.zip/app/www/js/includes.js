( function () {
	var
		
		files = [ //Here's where you can control the load order
			"js/bin/debug.js"
		,	"js/bin/lib.js"
		,	"js/utils.js"
		,	"js/apiSettings.js"
		,	"js/bin/viewSystem.js"
		,	"js/bin/com_art.js"
		]
	,	i
	,	l
	;

	for( i = 0, l = files.length; i < l; i++ ){
		document.write('<script src="' + files[ i ] + '"></script>' );
	}
	
})();
