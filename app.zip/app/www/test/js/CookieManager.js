var Managers = Managers || {};

Managers.CookieManager = ( function() {
	/* private */

	/* end private */

	function _CookieManager() {
		/* public */
	}
	_CookieManager.setCookie = function( name, content, exdays ) {
			if ( name != "" ) {
				var exdate = new Date();
				exdate.setDate( exdate.getDate() + exdays );
				var c_content = name + "=" + escape( content )
						+ ((exdays==null)? "" : ";expires=" + exdate.toUTCString());
				document.cookie = c_content;
			}
		};
	_CookieManager.getCookie = function( in_name ) {
			var i, name, value;
			var cookieArr = document.cookie.split(";");
			in_name = in_name.replace( /^\s+|\s+$/g, "" );
			for ( i=0; i<cookieArr.length; i++ ) {
				name = cookieArr[i].substr( 0, cookieArr[i].indexOf("=") );
				value = cookieArr[i].substr( cookieArr[i].indexOf("=") + 1 );
				name = name.replace( /^\s+|\s+$/g, "" );
				if ( name == in_name ) {
					return unescape( value );
				}
			}
		};
	_CookieManager.removeCookie = function( name ) {
			var exdate = new Date();
			exdate.setDate( exdate.getDate() - 1 );
			var c_content = name + "=;expires=" + exdate.toUTCString();
			document.cookie = c_content;
		};
	return _CookieManager;
} )();
