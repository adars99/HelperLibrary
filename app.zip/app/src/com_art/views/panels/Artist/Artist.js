at.ns.Artist = ( function ( global, ns, root ){
	var
		_ME = "Artist"
	,	_NAME = ns._name_ + "." + _ME
	,	_const = root.CONST
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}

	return ns.AbstractPanel.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var _that = this;
				this._super();
				this.addProps( [
					"state"
				,	[ "artists", [] ]
				] );

				_that.state(_that.STATES.LOADING );

				$( document.body ).bind(
						root.model.artistList.CHANGE_EVENT
					,	this.scope( function( e, val ){
							var
								state = root.model.artistList.getState()
							,	artists = root.model.artistList.getArtists()
							;
							_that.artists( artists );
							if ( state === root.model.artistList.STATE.LOADING ) {
								_that.artists( artists );
								_that.state(_that.STATES.LOADING );
							} else if ( state === root.model.artistList.STATE.ERROR ) {
								_that.error( _const.ERROR.ARTISTLIST );
								_that.state( _that.STATES.FAIL );
							} else if ( state === root.model.artistList.STATE.UNMET_DEPENDENCIES ) {
								_that.error( _const.ERROR.ARTISTLIST );
								_that.state( _that.STATES.FAIL );
							} else {
								_that.state( _that.STATES.SUCCESS );
							}
						} )
				);
			}
		,	needsMet: function(){ return this._state; }
		,	error: function( errorMessage ) {
				if ( _def( errorMessage ) ) {
					this._error = (errorMessage.length < 200) ? _errorMessage : root.CONST.ERROR.DATA;
				}
				return this._error || _const.ERROR.DATA;
			}
		,	data: function () {
				return {};
			}
		,	dataFail: function() {
				// TODO: alternately close panel and deactivate artists button?
				return {
					error: this.error()
				};
			}
		,	dataSuccess: function() {
				return {
					namespace: _NAME
				,	artists: this.artists()
				};
			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	show: function () {
				this._super();
				$(this.node()).slideDown('slow');
			}
		,	load: function (){
				var
					_that = this
				, 	_scrllCnt = 1
				,	_maxCnt
				;
				
				$('.artistItem', _that.node()).click(function(e){
					var
						_artistCategoryId
					,	_artistName
					;
					e.preventDefault();
					_artistCategoryId = $(this).attr( 'artistCategoryId' );
					_artistName = $(this).attr( 'artistName' );
					$.bbq.removeState('loadingHome');
					$.bbq.pushState( {
						page: _const.PAGE.GALLERY
					,	artistCategoryId: _artistCategoryId
					,	artistName: _artistName
					,	categoryId: ""
					,	categoryTitle: ""
					,	pageIndex: 1
					} );
					$( document.body ).trigger(root.EVENTS.FOOTER.SET_INACTIVE);
					root.main.hidePanel();
				});

				$('.closePanel img.close', _that.node()).click(function(e){
					e.preventDefault();
					$('.com_art_views_Footer .artists').removeClass('active');
					$(_that.node()).slideUp('slow', function() {
						root.main.hidePanel();
					});
					$( document.body ).trigger(root.EVENTS.FOOTER.SET_INACTIVE);
				});
				$('.closePanel img.scrlUp', _that.node()).click(function(e){
					e.preventDefault();
					if ( _scrllCnt > 1 ) {
						_scrllCnt -= 1;
						$('.listContent ul', _that.node()).animate({
							top: '+=350'
						}, 1000);
					}
				});
				$('.closePanel img.scrlDwn', _that.node()).click(function(e){
					e.preventDefault();
					_maxCnt = Math.ceil( $('.listContent ul', _that.node()).height() / ($(_that.node()).height()-$('.listContent .closePanel').height()) );
					if (_scrllCnt < _maxCnt) {
						_scrllCnt += 1;
						$('.listContent ul', _that.node()).animate({
							top: '-=350'
						}, 1000);
					}
				});

				$('.retryArtistList').click(function(){
					$( document.body ).trigger(
						root.EVENTS.GLOBAL_DATA.ARTISTS_CHANGE
					,	{}
					);
				});

			}
		}
	} );
}( this, at.ns, at.root ) );