at.ns.Collection = ( function ( global, ns, root ){
	var
		_ME = "Collection"
	,	_NAME = ns._name_ + "." + _ME
	,	_const = root.CONST
	;

	return ns.AbstractPanel.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var _that = this;
				this._super();

				root.model.collectionList.setBlank();
				$( document.body ).bind( root.model.collectionList.CHANGE_EVENT, this.scope( this.isNotSoFresh ) );
			}
		,	data: function() {
				return {
					collections: root.model.collectionList.getAllItems(
								true // filterOutUnactionableItems
							)
				};
			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	show: function () {
				this._super();
				$(this.node()).slideDown('slow');

			}
		,	load: function (){
				var
					_that = this
				, 	_scrllCnt = 1
				,	_maxCnt
				;
				$('.closePanel img.close', _that.node()).click(function(e){
					e.preventDefault();
					$('.com_art_views_Footer .collections').removeClass('active');
					$(_that.node()).slideUp('slow', function() {
						root.main.hidePanel();
					});
					$( document.body ).trigger(root.EVENTS.FOOTER.SET_INACTIVE);
				});
				$('.closePanel img.scrlUp', _that.node()).click(function(e){
					e.preventDefault();
					if ( _scrllCnt > 1 ) {
						_scrllCnt -= 1;
						$('.listContent ul', _that.node()).animate({
							top: '+=350'
						}, 1000);
					}
				});
				$('.closePanel img.scrlDwn', _that.node()).click(function(e){
					e.preventDefault();
					_maxCnt = Math.ceil( $('.listContent ul', _that.node()).height() / ($(_that.node()).height()-$('.listContent .closePanel').height()) );
					if (_scrllCnt < _maxCnt) {
						_scrllCnt += 1;
						$('.listContent ul', _that.node()).animate({
							top: '-=350'
						}, 1000);
					}
				});

				$('li', _that.node()).click(function(e){
					e.preventDefault();
					_linkType = $(this).attr('linkType');
					_linkParam = $(this).attr('linkParameter');
					_linkTitle = $(this).attr('linkTitle');
					$.bbq.removeState('loadingHome');
					if (_linkType == root.data.ARTAPI.LINK_TYPES.CONTENT_BLOCK) {
						$.bbq.pushState( {
							page: _const.PAGE.COLLECTION
						,	collection: _linkParam
						,	collectionTitle: _linkTitle
						,	pageIndex: 1
						} );
					} else if ( _linkType == root.data.ARTAPI.LINK_TYPES.CATEGORY ) {
						$.bbq.pushState( {
							page: _const.PAGE.GALLERY
						,	categoryId: _linkParam
						,	categoryTitle: _linkTitle
						,	artistCategoryId: ""
						,	artistName: ""
						,	pageIndex: 1
						} );
					} else {
						// #ifdef debug
						debug.warn( "Collection panel:click listener for collection items: Unrecognized link type.", _linkType );
						// #endif
					}
					$( document.body ).trigger(root.EVENTS.FOOTER.SET_INACTIVE);
					$(_that.node()).slideUp('slow', function() {
						root.main.hidePanel();
					});
				});
			}
		}
	} );
}( this, at.ns, at.root ) );