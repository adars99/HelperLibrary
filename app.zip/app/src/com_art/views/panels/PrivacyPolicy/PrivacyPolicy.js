at.ns.PrivacyPolicy = ( function ( global, ns, root ){
	var
		_ME = "PrivacyPolicy"
	,	_NAME = ns._name_ + "." + _ME
	;

	return ns.AbstractPanel.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var _that = this;
				this._super();
			}
		,	data: function() {
			
			}
		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	show: function () {
				this._super();
				$(this.node()).slideDown('slow');

			}
		,	load: function (){
				var
					_that = this
				, 	_scrllCnt = 1
				,	_maxCnt
				;
				$('.closePanel img.close', _that.node()).click(function(e){
					e.preventDefault();
					$(_that.node()).slideUp('slow', function() {
						root.main.hidePanel();
						$('.com_art_views_Footer').removeClass('shippingView');
						root.main.setChildValue( "footer", root.CONST.OFF );
					});
				});
				$('.closePanel img.scrlUp', _that.node()).click(function(e){
					e.preventDefault();
					if ( _scrllCnt > 1 ) {
						_scrllCnt -= 1;
						$('.policyText', _that.node()).animate({
							top: '+=320'
						}, 1000);
					}
				});
				$('.closePanel img.scrlDwn', _that.node()).click(function(e){
					e.preventDefault();
					_maxCnt = Math.ceil( $('.policyText', _that.node()).height() / 320 )
					if (_scrllCnt < _maxCnt) {
						_scrllCnt += 1;
						$('.policyText', _that.node()).animate({
							top: '-=320'
						}, 1000);
					}
				});
			}
		}
	} );
}( this, at.ns, at.root ) );