/**
 * @fileoverview
 *
 * @requires viewSystem.views.Abstract
 *
 */

at.ns.AbstractPanel = ( function ( global, ns, root ){
	var _NAME = ns._name_ + ".AbstractPage";

	return viewSystem.View.extend( {
		namespace: _NAME
	,	model: {
			init: function () {
				this._super();
			}
		}
	,	controller: {
		}
	} );

}( this, at.ns, at.root ) );