at.ns.Help = ( function ( global, ns, root ){
	var
		_ME = "Help"
	,	_NAME = ns._name_ + "." + _ME
	,	_const = root.CONST
	;

	return ns.AbstractPanel.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var _that = this;
				this._super();
				$( document.body ).bind( root.model.currentCollection.CHANGE_EVENT, this.scope( this.isNotSoFresh ) );
				$( document.body ).bind( root.model.page.CHANGE_EVENT, this.scope( this.isNotSoFresh ) );
			}
		,	data: function() {

			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	show: function () {
				this._super();
				$(this.node()).slideDown('slow');

			}
		,	load: function (){
				var
					_that = this
				,	$body = $( document.body )
				,	_page = root.model.page
				,	_collection = root.model.currentCollection
				,	_landingContentBlockName = root.model.globalAppData.getLandingContentBlockName()
				,	_node = this.node()
				;

				//Set View on first load of Panel
				showSection(_page.get());

				//Listen for change in Collection Name to display Home or Category help text
				$body.bind( _collection.CHANGE_EVENT, function ( e ) {
					showSection(_const.PAGE.COLLECTION);
				});

				//Listen for page changes to show help section based on page type
				$body.bind( _page.CHANGE_EVENT, function ( e ) {
					showSection(_page.get());
				});

				function showSection (pageType) {
					$('.helpText').hide();
					if (pageType == _const.PAGE.COLLECTION) {
						if ( _landingContentBlockName !== root.model.currentCollection.get().id ) {
							$('.categoryView', _node).show();
						} else {
							$('.homeView', _node).show();
						}
					} else {
						switch(_page.get()) {
							case _const.PAGE.GALLERY:
								$('.galleryView', _node).show();
							break;
							case _const.PAGE.ITEM:
								$('.productView', _node).show();
							break;
							case _const.PAGE.CART:
								$('.cartView', _node).show();
							break;
							case _const.PAGE.SHIPPINGINFO:
							case _const.PAGE.BILLINGINFO:
							case _const.PAGE.CONFIRMORDER:
							case _const.PAGE.ORDERCOMPLETE:
								$('.checkoutView', _node).show();
							break;
						}
					}
				}

				//Close the panel on click of close button
				$('.closePanel img.close', _that.node()).click(function(e){
					e.preventDefault();
					$('.com_art_views_Footer .collections').removeClass('active');
					$(_that.node()).slideUp('slow', function() {
						root.main.hidePanel();
					});
					$body.trigger(root.EVENTS.FOOTER.SET_INACTIVE);
				});
			}
		}
	} );
}( this, at.ns, at.root ) );