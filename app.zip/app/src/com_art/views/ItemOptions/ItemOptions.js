at.ns.ItemOptions = ( function ( global, ns, root ){
	var
		_ME = "ItemOptions"
	,	_NAME = ns._name_ + "." + _ME
	,	_events = root.EVENTS
	,	_model = root.model
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}

	return ns.Abstract.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var 
					_that = this
				,	$body = $( document.body )
				;
				this._super();				

				this.addProps( [
					"state"
				] );

				$body.bind(_model.activeItem.CHANGE_EVENT, this.scope( 
					function( e, val ){
						// Use active item, not current item number aka item number on *first* entry only into item view
						_that.placeFramedVariationsCall( val.itemNumber );
					} )
				); 
				//$body.bind(root.model.currentItemFramedVariations.CHANGE_EVENT, this.scope( this.isNotSoFresh ) ); 
			}
		,	needsMet: function(){ return this._state; }
		,	placeFramedVariationsCall: function ( itemNumber ) {
				if ( !_def( itemNumber ) ) {
					return;
				}
				var
					_dao = root.data.itemFramedVariations
				,	_that = this
				;
				_dao.get(
					{
						success: function ( itemFramedVariations ) {
							if ( _def( itemFramedVariations ) ) {
								_model.currentItemFramedVariations.setFramedItems( itemFramedVariations );
							} else {
								// #ifdef debug
								debug.warn("successful response, but null item framed variations." );
								// #endif
							}
							_that.state( _that.STATES.SUCCESS );
						}
					,	fail: function ( rawData ) {
							// #ifdef debug
							debug.warn( "placeFramedVariationsCall: Error response." );
							// #endif
							_that.error( rawData );
							_that.state( _that.STATES.FAIL );
						}
					}
				,	itemNumber
				);
				this.state( this.STATES.LOADING );
			}
		,	error: function( rawData ){
				if ( _def( rawData ) ) {
					if ( root.data.artComAPIUtils.isValidResponse( rawData ) ) {
							this._error = root.data.artComAPIUtils.getResponseMessage( rawData );
					} else {
						this._error = root.CONST.ERROR.DATA;
					}
				}
				return this._error || root.CONST.ERROR.DATA;
			}
		,	dataFail: function(){
				return {
					error: this.error()
				};
			}
		,	data: function() {
				var 
					framedItems = (_model.currentItemFramedVariations.get()) ? _model.currentItemFramedVariations.getFramedItems() : []
				;
				return {
					itemFramedVariations: framedItems
				}
			}
		,	dataSuccess: function() {
				var 
					framedItems = (_model.currentItemFramedVariations.get()) ? _model.currentItemFramedVariations.getFramedItems() : []
				;
				return {
					itemFramedVariations: framedItems
				}
			}
		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	load: function (){
				var 
					$body = $( document.body )
				, 	_this = this
				;

				$('.jList').jcarousel();	
								
				$('.optionList li', this.node()).click(function(e){
					if (!$(this).hasClass('selected')) {
						var 
							_detailSrc = $(this).attr('imageDetail')
						,	_activeItem = _model.activeItem
						;

						$('.optionList li', _this.node()).removeClass('selected');
						$(this).addClass('selected');
						$('.optionList li', _this.node()).find('.measurements').removeClass('secondaryColor');
						$(this).find('.measurements').addClass('secondaryColor');
						if (!$(this).hasClass('noFrame')) {
							$body.trigger( _events.ITEM.SET_FRAME_ITEM, {
								img: _detailSrc
							,	itemNum: $(this).attr('itemNum')
							, 	itemType:$(this).attr('itemType')
							,	price: $(this).attr('price')
							, 	framed:$(this).find('.measurements').html()
							} );
						} else {
							//If you have a frame selected it will clear out frame id.
							$body.trigger( _events.ITEM.SET_FRAME_ITEM, {
								img: _activeItem.get().genericImageURL
							,	itemNum: _activeItem.get().itemNumber
							, 	itemType:root.data.ARTAPI.ITEM_TYPE.CATALOG_ITEM
							,	price: _activeItem.get().price
							, 	framed:"No"
							} );
						}
					}
				});
			}
		}
	} );
}( this, at.ns, at.root ) );