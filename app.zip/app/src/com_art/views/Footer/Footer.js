at.ns.Footer = ( function ( global, ns, root ){
	var
		_ME = "Footer"
	,	_NAME = ns._name_ + "." + _ME
	,	_events = root.EVENTS
	,	_model = root.model
	,	_const = root.CONST
	;

	return ns.Abstract.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var _that = this;
				this._super();
				this.addProps(
					[
						"page"
					]
				);
			}
		,	data: function() {

			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	load: function (){
			 	var 
			 		$body = $( document.body )
			 	,	_node = this.node()
			 	,	_activeClass = 'active'
			 	;

			 	$body.bind( _model.page.CHANGE_EVENT,	this.scope( function(){
			 			$('.com_art_views_Footer').removeClass('shippingView');
						if (_model.page.get() == _const.PAGE.ITEM) {
							$('.zoom', _node).show();
						} else {
							$('.zoom', _node).hide();
						}
						var iOS = ( navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false );
						if (_model.page.get() == _const.PAGE.SHIPPINGINFO) {						
							if(iOS==true)
							{	
								$('.close', _node).hide();
							}
							else
							{
								$('.close', _node).hide();
							}

						} else {
							$('.close', _node).hide();
						}
						if (_model.page.get() == _const.PAGE.BILLINGINFO) {
							if(iOS==true)
							{	
								$('.close', _node).hide();
							}
							else
							{
								$('.close', _node).hide();
							}
							
						} else {
							$('.close', _node).hide();
						}
						if (_model.page.get() == _const.PAGE.CONFIRMORDER) {
							$('.cancel', _node).show();
						} else {
							$('.cancel', _node).hide();
						}
						if (_model.page.get() == _const.PAGE.CART) {
							$('.cart', _node).addClass(_activeClass);
						} else {
							$('.cart', _node).removeClass(_activeClass);
						}
					} )
				);

			 	$body.bind(  _events.ITEM.ZOOMOUT, function(){
			 		$('.zoom', _node).removeClass("zoomOut");
			 	});

			 	$body.bind(  _events.FOOTER.SET_INACTIVE, function(){
			 		$('div', _node).removeClass(_activeClass);
			 	});
				
				$body.bind( _events.CART.ITEM_ADD,	function ( event, params ) {
					$('.cart', _node).removeClass("disabled");
				});
				
				$body.bind( _events.FOOTER.DISABLE_CART,	function ( event, params ) {
					$('.cart', _node).addClass("disabled");
				});

				$('.home', _node).click(function(e){
					e.preventDefault();
					$.bbq.pushState( {
						page: _const.PAGE.COLLECTION
					,	collection: _model.globalAppData.getLandingContentBlockName()
					,	collectionTitle: _model.globalAppData.getLandingContentBlockName()
					,	pageIndex: 1 } );
				});
				$('.collections', _node).click(function(e){
					e.preventDefault();
					if (!$(this).hasClass(_activeClass)) {
						$('div', _node).removeClass(_activeClass);
						$(this).addClass(_activeClass);
						root.main.showCollectionPanel();
					} else {
						$('div', _node).removeClass(_activeClass);
						root.main.hidePanel();
					}
				});
				$('.artists', _node).click(function(e){
					e.preventDefault();
					if (!$(this).hasClass(_activeClass)) {
						$('div', _node).removeClass(_activeClass);
						$(this).addClass(_activeClass);
						root.main.showArtistPanel();
					} else {
						$('div', _node).removeClass(_activeClass);
						root.main.hidePanel();
					}
				});		
				$('.help', _node).click(function(e){
					e.preventDefault();
					if (!$(this).hasClass(_activeClass)) {
						$('div', _node).removeClass(_activeClass);
						$(this).addClass(_activeClass);
						root.main.showHelpPanel();
					} else {
						$('div', _node).removeClass(_activeClass);
						root.main.hidePanel();
					}
				});
				$('.active', _node).click(function(e){
					e.preventDefault();
					$('div', _node).removeClass(_activeClass);
					root.main.hidePanel();
				});				
				$('.cart', _node).click(function(e){
					e.preventDefault();
					if (!$(this).hasClass("disabled") && !$(this).hasClass(_activeClass) ) {
						if (root.model.page.get() == root.CONST.PAGE.SHIPPINGINFO || root.model.page.get() == root.CONST.PAGE.BILLINGINFO || root.model.page.get() == root.CONST.PAGE.CONFIRMORDER) {
							root.model.page.set(root.CONST.PAGE.CART);
						} else {
							$body.trigger(_events.CART.SHOW);
							$.bbq.pushState( { page:_const.PAGE.CART } );
						}
					}
				});
				$('.zoom', _node).click(function(e){
					e.preventDefault();
					$body.trigger( _events.ITEM.ZOOM );
				});
				$('.cancel', _node).click(function(e){
					e.preventDefault();
					root.model.page.set(root.CONST.PAGE.CART);
				});
				$('.close', _node).click(function(e){
					e.preventDefault();
					$('.com_art_views_Footer').removeClass('shippingView');
					root.main.setChildValue( "footer", _const.OFF );
					root.main.hidePanel();
				});
				$('.back', _node).click(function(e){
					e.preventDefault();
					if (root.model.page.get() == root.CONST.PAGE.CONFIRMORDER) {
						root.model.page.set(root.CONST.PAGE.BILLINGINFO);
					} 
					else if (root.model.page.get() == root.CONST.PAGE.BILLINGINFO) {
						root.model.page.set(root.CONST.PAGE.SHIPPINGINFO);
					}
					else if (root.model.page.get() == root.CONST.PAGE.SHIPPINGINFO) {
						root.model.page.set(root.CONST.PAGE.CART);
					} 
					else {
						if (!$.bbq.getState('loadingHome')) {
							history.back();
						}
					}
				});

			}
		}
	} );
}( this, at.ns, at.root ) );
