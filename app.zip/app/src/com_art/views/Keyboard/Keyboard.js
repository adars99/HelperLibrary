at.ns.Keyboard = ( function ( global, ns, root ){
	var
		_ME = "Keyboard"
	,	_NAME = ns._name_ + "." + _ME
	,	$body = $(document.body)
	,	_events = root.EVENTS
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	
	return ns.Abstract.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var _that = this;
				this._super();
				this.addProps( [
					"state"
				] );				
			}
		,	needsMet: function(){ return this._state; }
		,	placeCartGetCall: function () {
				var
					_dao = root.data.cart
				,	_that = this
				;
				_dao.get(
					{
						success: function ( cart ) {
							_that.cart( cart );
							_that.state( _that.STATES.SUCCESS );
						}
					,	fail: function ( rawData ) {
							_that.state( _that.STATES.FAIL );
						}
					}
				);
				this.state( this.STATES.LOADING );
			}
		,	cart: function ( cart ) {
				if	( _def( cart ) ) {
					this._cart = cart;
				}
				return this._cart;
			}
		,	data: function() {
			
			}
		,	dataSuccess: function() {
				return {
					shippingAdd: this.cart().shippingAddress
					,billingAdd: this.cart().billingAddress
				};
			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	show: function (){	
				this._super();
				this.model().placeCartGetCall();
			}
		,	load: function (){	
				var 
					frm = $('form', this.node())
				,	_this = this
				,	lineHTML = ""
				,	lock = 1
				,	slock = 1
				,	uca = 0
				,	initial= 0
				,	filter = /[a-z]/
				,	origLineHTML = ""
				,	el_LastC
				,	resetShift = 1
				,	qp = new GETQueryParser(window.location.search)
				,	lineHTML = qp.getValueRaw('value')
				,	password = (qp.getValueRaw('pw')=='1')
				,	isGeneric = (qp.getValueRaw('object')=='1')
				,	elId = qp.getValueRaw('name')
				,	elCustom = qp.getValueRaw('custom')
				,	selectedInput = ""
				;
				
				$body.bind(_events.FORM.ISVALID, function ( event, params ) {
									
					if($('#sameAsShipping').length) {

						if (!params.valid) {
								$('span#submit.btn', _this.node()).addClass('disabled');
						
							}
							else {
								$('span#submit.btn', _this.node()).removeClass('disabled');
							}
							
						}
						else
						{
							if (!params.valid) {
							  $('span#continueBtn.btn', _this.node()).addClass('disabled');
							} 
							else {
								$('span#continueBtn.btn', _this.node()).removeClass('disabled');
							}

						}				

				});
				
				$body.bind(_events.FORM.INPUT_SELECT, function ( event, params ) {
					lineHTML = params.text;
					selectedInput = params.id;
					$("#keyboard").val(lineHTML);
					var iOS = ( navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false );				
					if(iOS==true)
					{			
						$('.numMain').hide();
						$('.main').hide();
						$('.formNav').hide();
						$('#continueBtn').css('margin-right','20px');
						$('#submit').css('margin-right','20px');
						$('#submit').removeClass('disabled');
						$('#continueBtn').removeClass('disabled');
						$('.numberpad').css('float','right');
					}
					return false;
				});
				
				$body.bind( _events.FORM.LIST_SHOW, function ( event, params ) {
					if (!params.showList) {
						$('.upArrow').addClass('disabled');
						$('.downArrow').addClass('disabled');
						$('.select').addClass('btn').addClass('disabled').removeClass('button');
					} else {
						$('.upArrow').removeClass('disabled');
						$('.downArrow').removeClass('disabled');
						$('.select').removeClass('btn').removeClass('disabled').addClass('button');
					}
					return false;
				});
				
				qp= 0;
				origLineHTML= lineHTML;
				//Necessary when page is loading because the table isn't fully formed
				function SetKeyboardText(s)
				{
					var el = $("#keyboard");
					var clw = document.body.clientWidth/2;//-(document.body.style.margin*2);
					el.value = s;
					
				}

				function skey(i)
				{
					var updKP = 1;

					if(i == "uc")
					{
						resetShift= 0;
						updKP= !isGeneric;

						slock = (slock * -1);
						if (slock < 0)
						{
							uca = 1;
							if(frm.caps) frm.caps.val("SHIFT");
						}
						else
						{
							uca = 0;
							if(frm.caps)
							{
								if (lock < 0)
									frm.caps.val("CAPS");
								else
									frm.caps.val("");
							}
						}
					}
					else if(frm.caps && i == "caps")
					{
						updKP= !isGeneric;

						lock = (lock * -1);
						if (lock < 0)
							frm.caps.val("CAPS");
						else
							frm.caps.val("");
					}
					if(updKP)
						UpdateKeyPress(i, 0);
					else
						el_LastC.val("");

					resetShift= 1;
				}

				function zkey(i)
				{
					if(uca == 1)
					{
						switch(i)
						{
							case "1": i= "!"; break;
							case "2": i= "@"; break;
							case "3": i= "#"; break;
							case "4": i= "$"; break;
							case "5": i= "%"; break;
							case "6": i= "^"; break;
							case "7": i= "&"; break;
							case "8": i= "*"; break;
							case "9": i= "("; break;
							case "0": i= ")"; break;
							case "`": i= "~"; break;
							case "[": i= "{"; break;
							case "]": i= "}"; break;
							case "\\": i= "|"; break;
							case ";": i= ":"; break;
							case "\'": i= "\""; break;
							case ",": i= "<"; break;
							case ".": i= ">"; break;
							case "/": i= "?"; break;
							case "-": i= "_"; break;
							case "=": i= "+"; break;
						}
					}
					lineHTML = chkOverwrite(lineHTML,i);
					if(frm.caps && !isGeneric) frm.caps.focus();
					var isLimited = (selectedInput == "phone") ? true : false;					
					if (!isLimited) {
						$("#keyboard").val(lineHTML);
						$body.trigger( _events.FORM.VALUE_CHANGE, {text: lineHTML} );
					} else {
						if (lineHTML.length <= 24) {
							$("#keyboard").val(lineHTML);
							$body.trigger( _events.FORM.VALUE_CHANGE, {text: lineHTML} );
						}
					}
					
					if(frm.caps)
					{
						frm.caps.val("CAPS");
					}
					UpdateKeyPress(i);					
				}

				function letterKey(i)
				{
					if((uca==1 && filter.test(i)) || (lock < 0 && filter.test(i)))
					{
						i= i.toUpperCase();
					}
					lineHTML= chkOverwrite(lineHTML, i);
					if(frm.caps && !isGeneric) frm.caps.focus();

					$("#keyboard").val(lineHTML);
					$body.trigger( _events.FORM.VALUE_CHANGE, {text: lineHTML} );

					UpdateKeyPress(i);
				}

				function fkey(i)
				{
					if(i == "bs")
					{
						Backsp();
						return;
					}
					if(frm.caps && !isGeneric) frm.caps.focus();
					$("#keyboard").val(lineHTML);
					$body.trigger( _events.FORM.VALUE_CHANGE, {text: lineHTML} );
					UpdateKeyPress(i);
				}

				function ekey()
				{
					//var el= document.getElementById("CloseMe"); if(el==null) return;
					if(frm.CloseMe && !isGeneric) frm.CloseMe.val("yes");
					el_LastC.val('return');
				}

				function leavekey()
				{
					$("#keyboard").value = origLineHTML;
					if(frm.CloseMe) frm.CloseMe.val("yes");
				}

				function clearallkey()
				{
					lineHTML= "";
					$("#keyboard").val(lineHTML);
					if(frm.KeyPressEvent) frm.KeyPressEvent.val("");
				}

				function chkOverwrite(curText, newCh)
				{
					var text = "";
					text= ((document.all) ? document.selection.createRange().text : document.getSelection());
					//nothing selected
					if (text == "")
					{
						return (curText += newCh);
					}
					//entire string is selected, replace all
					if (text == curText)
					{
						return newCh;
					}

					var stIndex = 0;
					var ctr= 0;
					stIndex= curText.indexOf(text, stIndex);
					if (curText.indexOf(text, stIndex + text.length) != -1)
					{
						//highlighted string is not unique, so don't know where to replace, do nothing
						return curText;
					}

					//substitute the string
					var newText1;
					newText1 = curText.substr(0,stIndex);
					newText1 = newText1 += newCh;
					newText1 = newText1 += curText.substr(stIndex + text.length, curText.length - stIndex - text.length);
					return newText1;
				}

				var keyPressYes=2;

				function UpdateKeyPress(i)
				{
					if(resetShift)
					{
						uca = 0;
						slock = 1;
					}
					el_LastC.value= i;
					if(!frm.KeyPressEvent) return;
					if(keyPressYes==2)
					{
						keyPressYes= (frm.KeyPressEvent.value=='yes' ? 1 : 0);
						//clear buffer so KioWare won't use it as a key
						if(!keyPressYes) frm.KeyPressEvent.value="";
					}
					if(!keyPressYes) return;
					frm.KeyPressEvent.val(i);
				}

				function Backsp()
				{
					if(lineHTML.length > 0)
					{
						lineHTML = lineHTML.substring(0, lineHTML.length-1);
						$("#keyboard").val(lineHTML);
						$body.trigger( _events.FORM.VALUE_CHANGE, {text: lineHTML} );
						el_LastC.value = "\x08";
					}

				}

				function leftKey()
				{
					el_LastC.value = "left";
				}

				function rightKey()
				{
					el_LastC.value = "right";
				}

				function upKey()
				{
					el_LastC.value = "up";
				}

				function downKey()
				{
					el_LastC.value = "down";
				}

				function tabKey()
				{
					el_LastC.value = "\x09";
				}

				function escKey()
				{
					el_LastC.value = "\x1B";
				}

				function MM_callJS(jsStr)
				{ //v2.0
				  return eval(jsStr)
				}

				function MM_preloadImages()
				{ //v3.0
				  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
				    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
				    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
				}

				function MM_findObj(n, d)
				{ //v4.01
				  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
				    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
				  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
				  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
				  if(!x && d.getElementById) x=d.getElementById(n); return x;
				}


				function ToSafeHtml(s)
				{
					var sz= s.length;
					var str="";
					var c;
					
					for(var i= 0; i < sz; ++i)
					{
						c= s.charAt(i);
						if(c=='&')
						{
							str+='&#38;';
						}
						else if(c=='<')
						{
							str+='&lt;';
						}
						else if(c==='>')
						{
							str+='&gt;';
						}
						else if(c==="\"")
						{
							str+='&quot;';
						}
						else if(c==='\'')
						{
							str+='&#39;';
						}
						else str+=c;
					}
					return str;
				}

				function GETQueryParser(queryStr)
				{
					var q= queryStr;

					if(q.length > 1)
						q= q.substring(1);
					else
						q= "";

					//IE 6 may escape twice
					//have to unescape here and below in this case
					if(q.indexOf("&")==-1)
					{
						q= unescape(q);
					}
					this.ArgsArr=new Array();

					if(q)
						this.ArgsArr= q.split("&");
					
					this.getValueRaw = function(s)
					{
						var v=new Array();

						for(var j= 0; j < this.ArgsArr.length; ++j)
						{
							v= this.ArgsArr[j].split("=");
							if(v[0] == s)
								//unescape strips off %hex - not all characters are unescaped though, such as double quotes
								return unescape(v[1]);
						}
						return "";
					}

					this.getValue = function(s)
					{
						return ToSafeHtml(this.getValueRaw(s));
					}

					this.setValue = function(s, newVal)
					{
						newVal= escape(newVal);
						var eq= "=";
						var v=new Array();

						for(var j= 0; j < this.ArgsArr.length; ++j)
						{
							v= this.ArgsArr[j].split(eq);
							if(v[0] == s)
							{
								this.ArgsArr[j]= v[0]+eq+newVal;
								return;
							}
						}
						this.ArgsArr.push(s+eq+newVal);
					}
					
					this.getQueryString = function()
					{
						var s = "?";

						for(var j = 0; j < this.ArgsArr.length; ++j)
						{
							s = s+this.ArgsArr[j]+"&";
						}
						if(this.ArgsArr.length)
							s = s.substring(0, s.length-1);
						return s;
					}
				}

				function ClW()
				{
					//Firefox: window.innerWidth
					return document.body.parentNode.offsetWidth;
				}
				function ClH()
				{
					return document.body.parentNode.offsetHeight;
				}

				function GetEl(id){return document.getElementById(id);}

				function CreateEl(par, tagName, id, cl, type)
				{
					var d = document;
					var eln = d.createElement(tagName);
					eln.setAttribute("id", id);
					eln.className = cl;
					eln.setAttribute("type", type);
					par.append(eln);
					return eln;
				}

				function GetTypeA(el)
				{
					return el.getAttribute("type");
				}

				function SetTypeA(el, type)
				{
					var d= document;
					var id= el.id;
					var cl= el.className;
					var tagName= el.nodeName;
					var par= el.parent();

					par.removeChild(el);

					return CreateEl(par, tagName, id, cl, type);
				}

				if(!$("#keyboard"))
				{
					return;
				}
				el_LastC= CreateEl($("#keyboard").parent(), 'input', 'LastCharacter', 'InvisibleField', 'hidden');
				MM_preloadImages();
				if(password)
					SetTypeA($("#keyboard"), "password");
				SetKeyboardText(lineHTML);
												
				$('.kbd').click(function() {
					letterKey(this.id);
				});

				$('.kbshft').click(function() {
					zkey(this.id);
				});
				
				$('#Bspc').click(function() {
					Backsp();
				});

				$('.shift').click(function() {
					skey('uc');
				});

				$('.enter').click(function() {
					ekey();
				});
				
				$('#space').click(function() {
					letterKey(' ')
				});
				
				$('.controlBtn').click(function() {
					$body.trigger(_events.FORM.LIST_SELECT, {focusUpdate: false});
					$body.trigger( _events.FORM.FOCUS_CHANGE, {btn: this.id} );
				});
				
				$('#toolbar').click(function() {
					root.main.setChildValue( "footer", root.CONST.FOOTER );
					$('.com_art_views_Footer').addClass('shippingView');
				});
				
				$('#privacy').click(function() {
					root.main.setChildValue( "footer", root.CONST.FOOTER );
					$('.com_art_views_Footer').addClass('shippingView');
					root.main.showPrivacyPanel();
				});
				
				$('.numShift').add('.symbolShift').click(function() {
					$('.numMain').toggle();
					$('.numAlt').toggle();
				});
				
				$('#submit').click(function() {			
					if (!$(this).hasClass("disabled")) {
						$(document).trigger( _events.FORM.SUBMIT);
						return false;
					}
				});

				$('#continueBtn').click(function() {			
					if (!$(this).hasClass("disabled")) {
						$(document).trigger( _events.FORM.CONTINUE);
						return false;
					}
				});				
				
				$('#cancel').click(function(e) {
					e.preventDefault();
					root.model.page.set(root.CONST.PAGE.CART);
				});
				
				$('.listBtn').click(function() {
					if (!$(this).hasClass('disabled')) {
						$body.trigger(_events.FORM.LIST_NAV, {btn: this.id});
					}
				});
				
				$('.select').click(function() {
					if (!$(this).hasClass('disabled')) {
						$body.trigger(_events.FORM.LIST_SELECT, {focusUpdate: true});
					}
				});

				var iOS = ( navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false );				
				if(iOS==true)
				{			
					$('.numMain').hide();
					$('.main').hide();
					$('.formNav').hide();
					$('#continueBtn').css('margin-right','20px');
					$('#submit').css('margin-right','20px');
					$('#submit').removeClass('disabled');
					$('#continueBtn').removeClass('disabled');
					$('.numberpad').css('float','right');
				}
			}
		}
	} );
}( this, at.ns, at.root ) );