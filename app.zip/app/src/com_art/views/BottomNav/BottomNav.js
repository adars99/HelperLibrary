at.ns.BottomNav = ( function ( global, ns, root ){
	var
		_ME = "BottomNav"
	,	_NAME = ns._name_ + "." + _ME
	,	_const = root.CONST
	;

	return ns.Abstract.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var _that = this;
				this._super();

				root.model.collectionList.setBlank();
				$( document.body ).bind( root.model.page.CHANGE_EVENT, this.scope( this.isNotSoFresh ) );
				$( document.body ).bind( root.model.collectionList.CHANGE_EVENT, this.scope( this.isNotSoFresh ) );
				$( document.body ).bind( root.model.galleryList.CHANGE_EVENT, this.scope( this.isNotSoFresh ) );
				$( document.body ).bind( root.model.currentCollection.CHANGE_EVENT, this.scope( this.isNotSoFresh ) );
				$( document.body ).bind( root.model.currentGallery.CHANGE_EVENT, this.scope( this.isNotSoFresh ) );
			}
		,	data: function() {
				var 
					_items
				,	_pageCnt
				,	_currentCollection = root.model.currentCollection.get()
				,	_collectionPageNumber = _currentCollection ? _currentCollection.pageNumber : 1
				,	_currentGallery = root.model.currentGallery.get()
				,	_galleryType = (_currentGallery) ? _currentGallery.type : root.model.currentGallery.TYPE.NONE
				,	_galleryId = (_currentGallery) ? _currentGallery.id : ""
				,	_galleryPageNumber = (_currentGallery) ? _currentGallery.pageNumber : 1
				,	_pageNumber = 1
				;
				switch (root.model.page.get()) {
					case _const.PAGE.GALLERY:
						if ( root.model.galleryList.isLoaded( _galleryPageNumber, _galleryType, _galleryId ) ) {
						_items = root.model.galleryList.getCurrentItems(_galleryPageNumber);
							_pageCnt = root.model.galleryList.getPageCount();
							_pageNumber = _galleryPageNumber;
						}
					break;
					case _const.PAGE.COLLECTION:
						_items = root.model.collectionList.getCurrentItems(
							_collectionPageNumber
						,	true // filterOutUnactionableItems
						);
						_pageCnt = root.model.collectionList.getPageCount();
						_pageNumber = _collectionPageNumber;
					break;
					default:
						break;
				}
				return {
					gallery: (_items) ? _items : {}
				,	pageIndex: _pageNumber
				, 	pageCnt: (_pageCnt) ? _pageCnt : 1
				}
			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	load: function (){
				var 
					_navContent = $('.ada .nav')
				,	_navItems = $('.ada .nav .item') 
				,	_navCnt = (_navItems.length < 4) ? _navItems.length : 4
				,	_navWidth
				,	_linkType
				,	_linkParam
				,	_linkTitle
				,	_itemNumber
				,	_pageDirection
				,	_newPage
				, 	_pageCnt = null
				, 	_pageNumber = null
				;
				/**
				 * Get page numbers, page counts for pagination
				 */
				switch ( root.model.page.get() ) {
					case _const.PAGE.GALLERY:
						if ( root.model.currentGallery
								&& root.model.currentGallery.get()
						) {
							_pageNumber = root.model.currentGallery.get().pageNumber;
						}
						_pageCnt = root.model.galleryList.getPageCount();
						break;
					case _const.PAGE.COLLECTION:
						if ( root.model.currentCollection
								&& root.model.currentCollection.get()
						) {
							_pageNumber = root.model.currentCollection.get().pageNumber;
						}
						_pageCnt = root.model.collectionList.getPageCount();
						break;
				}
				_pageNumber = _pageNumber ? parseInt(_pageNumber) : 1;
				_pageCnt = _pageCnt ? _pageCnt : 1;

				/**
				 *  Fade in new button items on page change 
				 */
				$('.ada', this.node()).fadeIn('slow');
				
				_navItems.each(function(){
					var 
						_titleTxt = $(this).find('span').html()
					,	_newTxt
					;
					if (_titleTxt.length > 60) {
						_newTxt = _titleTxt.slice(0, 60);
						_newTxt = _newTxt.substring(0, _newTxt.lastIndexOf(' '))+ "..." ;
						$(this).find('span').html(_newTxt);
					}
				});

				/**
				 * Ada navigation click events
				 */
				_navItems.click(function(e){
					e.preventDefault();
					_linkType = $(this).attr('linkType');
					_linkParam = $(this).attr('linkParameter');
					_linkTitle = $(this).attr('linkTitle');
					_itemNumber = $(this).attr('itemNumber');
					$.bbq.removeState('loadingHome');
					if ( _itemNumber && _itemNumber !== "" ) {
						// Gallery item
						$.bbq.pushState( {
							page: _const.PAGE.ITEM
						,	itemNumber: _itemNumber
						} );
					} else {
						// Collection item or other
						if ( _linkParam && _linkParam.trim() !== "" ) {
							// Must have a link parameter to do anything
							switch ( parseInt(_linkType) ) {
								case root.data.ARTAPI.LINK_TYPES.CONTENT_BLOCK:
									$.bbq.pushState( {
										page: _const.PAGE.COLLECTION
									, 	collection: _linkParam
									, 	collectionTitle: _linkTitle
									,	pageIndex: 1
									} );
									break;
								case root.data.ARTAPI.LINK_TYPES.CATEGORY:
									$.bbq.pushState( {
										page: _const.PAGE.GALLERY
									,	categoryId: _linkParam
									,	categoryTitle: _linkTitle
									,	pageIndex: 1
									,	artistCategoryId: ""
									,	artistName: ""
									} );
									break;
								default:
									// Can't do anything without a recognized link type
									// #ifdef debug
									debug.warn( "BottomNav:click listener for nav items: Unrecognized link type!", _linkType );
									// #endif
									break;
							}
						} else {
							// #ifdef debug
							debug.warn( "BottomNav:click listener for nav items: No link parameter!" );
							// #endif
						}
					}
				});

				/**
				 *  Pagination click events
				 */
				$('.pagination .btn.right').click(function() {
					if ( _pageCnt > _pageNumber ) {
						_pageDirection = 1
						_newPage = _pageNumber + _pageDirection;
						$.bbq.pushState( { pageIndex: _newPage } );
						setBtnClass();
					}
				});
				$('.pagination .btn.left').click(function() {
					if ( _pageNumber > 1 ) {
						_pageDirection = -1
						_newPage = _pageNumber + _pageDirection;
						$.bbq.pushState( { pageIndex: _newPage } );
						setBtnClass();
					}
				});

				/**
				 *  Set width of Nav items based on number of the items display.
				 */
				if (_navCnt >= 4) {
					_navItems.width('220px');
				} else if (_navCnt == 3) {
					_navItems.width('300px');
				} else if (_navCnt == 2) {
					_navItems.width('455px');
				} else {
					_navItems.width('94%');
				}

				/**
				 *  Set the active class of the next and previous pagination buttons
				 */
				function setBtnClass() {
					var
						_activeClass = "active"
					,	_next = $('.pagination .btn.right')
					,	_prev = $('.pagination .btn.left')
					;
					if ( _pageCnt <= _pageNumber ) {
						_next.removeClass(_activeClass);
					} else {
						_next.addClass(_activeClass);
					}

					if ( _pageNumber <= 1 ) {
						_prev.removeClass(_activeClass);
					} else {
						_prev.addClass(_activeClass);
					}
				}
				setBtnClass();
			}
		}
	} );
}( this, at.ns, at.root ) );