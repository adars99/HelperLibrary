at.ns.Header = ( function ( global, ns, root ){
	var
		_ME = "Header"
	,	_NAME = ns._name_ + "." + _ME
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}

	return ns.Abstract.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var _that = this;
				this._super();
				this.addProps( [
					"state"
				] );

				$( document.body ).bind(
						root.model.headerBlockName.CHANGE_EVENT
					,	this.scope( function( e, val ){
							_that.placePrintReceiptCall( root.CONST.PRINT_RECEIPTS );
							_that.placeHeaderCall( val );
						} )
				);
			}

		,	needsMet: function(){ return this._state; }

		,	placeHeaderCall: function ( val ) {
				if ( !_def( val ) ) {
					return;
				}
				var
					_dao = root.data.contentBlock
				,	_that = this
				;
				_dao.get(
					{
						success: function ( data ) {
							var headerBanner = null
							,	i = null
							,	banner
							;
							if ( data.banners ) {
								for ( i in data.banners ) {
									banner = data.banners[i];
									if ( banner.linkType
											=== root.data.ARTAPI.LINK_TYPES.HEADER ) {
										headerBanner = banner;
										break;
									}
								}
							}
							if ( headerBanner && headerBanner.image
									&& headerBanner.image.url ) {
								// valid header (image) data
								_that.header( headerBanner );
								// #ifdef debug
								debug.debug( "Header success with image: " + headerBanner.image.url );
								// #endif
								_that.state( _that.STATES.SUCCESS );
							} else {
								// invalid header (image) data
								_that.header( data.header );
								_that.state( _that.STATES.FAIL );
							}
						}
					,	fail: function ( rawData ) {
							// #ifdef debug
							debug.debug( "Header fail", rawData );
							// #endif
							_that.error( rawData );
							_that.state( _that.STATES.FAIL );
						}
					}
				,	val
				);
				this.state( this.STATES.LOADING );
			}
		,	placePrintReceiptCall: function ( val ) {
			if ( !_def( val ) ) {
				return;
			}
			var
				_dao = root.data.contentBlock
			,	_that = this
			;
			_dao.get(
				{
					success: function ( data ) {
						var receiptBanner = null
						,	i = null
						,	banner
						;
						if ( data.banners ) {
							for ( i in data.banners ) {
								banner = data.banners[i];
								if ( banner.linkType
										=== root.data.ARTAPI.LINK_TYPES.HEADER ) {
									receiptBanner = banner;
									break;
								}
							}
						}
						if ( receiptBanner && receiptBanner.linkParameter) {
							// valid receipt print data	
							root.EVENTS.PRINT_NUM_COPIES=receiptBanner.linkParameter;
							_that.receipt( receiptBanner );
							_that.state( _that.STATES.SUCCESS );
						} else {
							// invalid receipt pint data
							_that.receipt( data.title );
							_that.state( _that.STATES.FAIL );
						}
					}
				,	fail: function ( rawData ) {
						_that.error( rawData );
						_that.state( _that.STATES.FAIL );
					}
				}
			,	val
			);
			this.state( this.STATES.LOADING );
		}
		,	receipt: function( val ){
			if ( _def( val ) ) {
				this._receipt = val;
			}

			return this._receipt;
		}	
		,	header: function( val ){
				if ( _def( val ) ) {
					this._header = val;
				}

				return this._header;
			}
		,	error: function( rawData ){
				if ( _def( rawData ) ) {
					if ( root.data.artComAPIUtils.isValidResponse( rawData ) ) {
						this._error = (_data.artComAPIUtils.getResponseMessage( rawData ).length < 200) ? _data.artComAPIUtils.getResponseMessage( rawData ) : root.CONST.ERROR.DATA;
					} else {
						this._error = root.CONST.ERROR.DATA;
					}
				}
				return this._error || root.CONST.ERROR.DATA;
			}
		,	data: function() {
				return {
					namespace: _NAME
				,	header: this.header()
				};
			}
		,	dataFail: function(){
				return {
					error: this.error()
				};
			}
		,	dataSuccess: function(){
				return {
					namespace: _NAME
				,	header: this.header()
				};
			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	load: function (){

			}
		}
	} );
}( this, at.ns, at.root ) );