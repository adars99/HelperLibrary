/**
 * @fileoverview
 *
 * @requires viewSystem.views.Abstract
 *
 */

at.ns.Abstract = ( function ( global, ns, root ){
	var _NAME = ns._name_ + ".Abstract";

	return viewSystem.View.extend( {
		namespace: _NAME
	,	model: { }
	,	controller: { }
	} );

}( this, at.ns, at.root ) );