at.ns.FormError = ( function ( global, ns, root ){
	var
		_ME = "FormError"
	,	_NAME = ns._name_ + "." + _ME
	;

	return ns.AbstractOverlay.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var _that = this;
				this._super();
			}
		,	data: function() {
			
			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	load: function (){
			
			}
		}
	} );
}( this, at.ns, at.root ) );