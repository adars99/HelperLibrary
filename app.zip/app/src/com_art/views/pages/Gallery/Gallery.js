at.ns.Gallery = ( function ( global, ns, root ){
	var
		_ME = "Gallery"
	,	_NAME = ns._name_ + "." + _ME
	,	_model = root.model
	,	_data = root.data
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( v ) {
		return _def( v ) && v !== null;
	}

	return ns.AbstractPage.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var
					_that = this
				,	_changeGalleryDataFunction
				;

				this._super();

				_changeGalleryDataFunction = function( e, val ){
					var
						_currentGallery = _model.currentGallery.get()
					,	_galleryListModel = _model.galleryList
					,	_pageNumber
					;
					if ( !_currentGallery
							|| root.CONST.PAGE.GALLERY != _model.page.get() ) {
						// #ifdef debug
						debug.debug( "Gallery page: changeFunction: no current gallery chosen or not in gallery view page state. No change." );
						// #endif
						return;
					}
					_pageNumber = _currentGallery.pageNumber;
					_that.title( _currentGallery.title );
					if ( _galleryListModel.isLoaded( _pageNumber
								,	_currentGallery.type
								,	_currentGallery.id )
					) {
						// #ifdef debug
						debug.log( "Gallery view: changeFunction binding: gallery already loaded for view page number " + _pageNumber );
						// #endif
						_that.isNotSoFresh.call( _that );
						return;
					}
					_that.state( _that.STATES.LOADING );
					_galleryListModel.loadToCover(
						_currentGallery.type
					,	_currentGallery.id
					,	_pageNumber
					,	_that	// callbackContext
					,	// successCallback
						function ( gallery ) {
							_that.state( _that.STATES.SUCCESS );
						}
					,	// failCallback
						function ( rawData ) {
							_that.error( rawData );
							_that.state( _that.STATES.FAIL );
						}
					,	// errorCallback
						function ( message ) {
							_that.errorMessage( message );
							_that.state( _that.STATES.FAIL );
						}
					);
				};

				$( document.body ).bind(
						_model.currentGallery.CHANGE_EVENT
					,	this.scope( _changeGalleryDataFunction )
				);
			}
		,	title: function ( title ) {
				if	( _def( title ) ) {
					this._title = title;
				}
				return this._title || "";
			}
		,	setEmptyError: function(){
				this._error = root.CONST.ERROR.NO_ITEMS;
				return this._error;
			}
		,	errorMessage: function ( message ) {
				this._error = message;
			}
		,	error: function( rawData ){
				if ( _def( rawData ) ) {
					if ( _data.artComAPIUtils.isValidResponse( rawData ) ) {
						this._error = (_data.artComAPIUtils.getResponseMessage( rawData ).length < 200) ? _data.artComAPIUtils.getResponseMessage( rawData ) : root.CONST.ERROR.DATA;
					} else {
						this._error = root.CONST.ERROR.DATA;
					}
				}
				return this._error || root.CONST.ERROR.DATA;
			}
		,	data: function() {
				return {
					namespace: _NAME
				,	title: this.title()
				,	items: _model.galleryList.getCurrentItems()
				};
			}
		,	dataFail: function(){
				return {
					error: this.error()
				};
			}
		,	dataSuccess: function(){
				var
					_pageNumber = (_model.currentGallery.get().pageNumber)
				;
				_pageNumber = _pageNumber ? _pageNumber : 1;
				return {
					namespace: _NAME
				,	title: this.title()
				,	items: _model.galleryList.getCurrentItems(_pageNumber)
				};
			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	load: function (){
				//$.bbq.pushState( { pageIndex: 1 } );
				$('.collectionLink').click(function(e){
					e.preventDefault();
					root.main.showCollection();
				});
				$('.galleryItem').click(function(e){
					var
						_itemNumber
					;
					e.preventDefault();
					_itemNumber = $(this).attr('itemNumber');
					$.bbq.pushState( {
						page: root.CONST.PAGE.ITEM
					,	itemNumber: _itemNumber
					} );
				});
				$('.back', this.node()).click(function(e){
					e.preventDefault();
					history.back();
				});
			}
		}
	} );
}( this, at.ns, at.root ) );