at.ns.Cart = ( function ( global, ns, root ){
	var
		_ME = "Cart"
	,	_NAME = ns._name_ + "." + _ME
	,	_events = root.EVENTS
	,	_model = root.model
	,	_data = root.data
	,	_const = root.CONST
	,	$body = $( document.body )
	/*  
	 *	On startup first row will be selected
	 * 	This will be updated as the user tranverses the cart table
	 */
	, 	selectedItem = 0
	;

	function _def( val ) {
		return ( typeof ( val ) !== "undefined" );
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}

	return ns.AbstractPage.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var 
					_that = this
				;
				this._super();

				$body.bind(
					_events.CART.ITEM_ADD
				,	function ( event, params ) {
						if ( _exists( params ) ) {
							_that.placeCartAddItemCall( params.itemNumber, params.itemType );
							_that.activeCartItemId( null );
						}
					}
				);
				$body.bind(
					_events.CART.CART_ITEM_QUANTITY_UPDATE
				,	function ( event, params ) {
						if ( _exists( params ) ) {
							_that.placeCartItemUpdateQuantityCall( params.cartItemId, params.quantity );
							_that.activeCartItemId( params.cartItemId );
						}
					}
				);
				$body.bind(
					_events.CART.CART_DELETE_ITEM
				,	function ( event, params ) {
						if ( _exists( params ) ) {
							_that.placeCartItemDeleteCall( params.cartItemId, params.quantity );
							_that.activeCartItemId( params.cartItemId );
							if (_that.cart().cartItems.length <= 1) {
								$body.trigger(_events.FOOTER.DISABLE_CART);
							}
						}
					}
				);

				$body.bind(	_events.CART.SHOW
				,	function ( event ) {
						_that.placeCartGetCall();
					}
				);		

				$body.bind( _model.page.CHANGE_EVENT, this.scope( this.isNotSoFresh ) );

			}
		,	placeCartAddItemCall: function ( itemNumber, itemType ) {
				if ( !_exists( itemNumber ) || !_exists( itemType ) ) {
					//#ifdef debug
					debug.error( "Cart View: placeCartAddItemCall: parameters do not exist.")
					//#endif
					return;
				}
				var
					_dao = _data.cartAddItem
				,	_that = this
				;
				_dao.get(
					{
						success: function ( cart ) {
							_that.cart( cart );
							_that.state( _that.STATES.SUCCESS );
						}
					,	fail: function ( rawData ) {
							_that.error( rawData );
							_that.state( _that.STATES.FAIL );
						}
					}
				,	itemNumber
				,	itemType
				);
				this.state( this.STATES.LOADING );
			}
		,	placeCartItemUpdateQuantityCall: function ( cartItemId, quantity ) {
				if ( !_exists( cartItemId ) || !_exists( quantity ) ) {
					// #ifdef debug
					debug.error( "Cart View: placeCartItemUpdateQuantityCall: parameters do not exist.")
					// #endif
					return;
				}
				var
					_dao = _data.cartUpdateCartItemQuantity
				,	_that = this
				;
				_dao.get(
					{
						success: function ( cart ) {
							_that.cart( cart );
						}
					,	fail: function ( rawData ) {
							_that.error( rawData );
							_that.state( _that.STATES.FAIL );
						}
					}
				,	cartItemId
				,	quantity
				);
			}
		,	placeCartItemDeleteCall: function ( cartItemId, quantity ) {
				if ( !_exists( cartItemId ) || !_exists( quantity ) ) {
					// #ifdef debug
					debug.error( "Cart View: placeCartItemUpdateQuantityCall: parameters do not exist.")
					// #endif
					return;
				}
				var
					_dao = _data.cartUpdateCartItemQuantity
				,	_that = this
				;
				_dao.get(
					{
						success: function ( cart ) {
							_that.cart( cart );
							_that.state( _that.STATES.SUCCESS );
						}
					,	fail: function ( rawData ) {
							_that.error( rawData );
							_that.state( _that.STATES.FAIL );
						}
					}
				,	cartItemId
				,	quantity
				);
			}
		,	placeCartGetCall: function () {
				var
					_dao = _data.cart
				,	_that = this
				;
				_dao.get(
					{
						success: function ( cart ) {
							_that.cart( cart );
							_that.state( _that.STATES.SUCCESS );
						}
					,	fail: function ( rawData ) {
							_that.error( rawData );
							_that.state( _that.STATES.FAIL );
						}
					}
				);
				this.state( this.STATES.LOADING );
			}
		,	cart: function ( cart ) {
				if	( _def( cart ) ) {
					this._cart = cart;
				}
				return this._cart;
			}
		,	activeCartItemId: function ( cartItemId ) {
				if ( _def( cartItemId ) ) {
					this._activeCartItemId = cartItemId;
				}
				return this._activeCartItemId || null;
			}
		,	error: function( rawData ){
				if ( _def( rawData ) ) {
					if ( _data.artComAPIUtils.isValidResponse( rawData ) ) {
						this._error = (_data.artComAPIUtils.getResponseMessage( rawData ).length < 200) ? _data.artComAPIUtils.getResponseMessage( rawData ) : root.CONST.ERROR.DATA;
					} else {
						this._error = _const.ERROR.DATA_RETRIEVAL;
					}
				}
				return this._error || _const.ERROR.DATA;
			}
		,	data: function() {
				return {
					namespace: _NAME
				,	cart: this.cart()
				,	initialActiveCartItemId: this.activeCartItemId()
				};
			}
		,	dataFail: function(){
				if (this.error() == com_art.CONST.ERROR.INVALID_SESSION) {
					$('.mainError').css({'position':'absolute', 'bottom':"400px"});
				}
				return {
					error: this.error()
				};
			}
		,	dataSuccess: function(){
				var 
					itemCnt = 0
				,	i
				,	l
				;

				for( i = 0, l = this.cart().cartItems.length; i < l; i++ ){
					var item = this.cart().cartItems[i];
					itemCnt += item.quantity;
				}
				return {
					namespace: _NAME
				, 	itemCnt: itemCnt
				,	cart: this.cart()
				,	initialActiveCartItemId: this.activeCartItemId()
				};
			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	load: function (){
				var
					_this = this
				,	node = this.node()
				,	cartTable = $('.cartContents table', node)
				,	cartTableRow = $('.cartContents table tr', node)
				,	selectedRow = $('.cartContents table tr:eq('+selectedItem+')', node)
				,	newRow
				,	qntyBlock
				,	adaQnty = $('.quantity-cntrl .count', node)
				,	curQnty
				,	newQuantity
				,	itemId
				;

				$('.priceInfo').currency({ region: root.model.globalAppData.getISOCurrencyCode()});
				$('.cartContents table tr:eq(0)', node).addClass('select');
				adaQnty.html(selectedRow.find('.count').html());
				_model.collectionList.setHash(
					_model.globalAppData.getLandingContentBlockName()
				,	_model.homeCollection.get()
				);

				/*
				 * Select Row based on user interaction with table or ADA scroll buttons
				 */
				function selectRow(el) {
					if (!el.hasClass('select') && !el.hasClass('head')) {
						var
							_minPos = 365
						,	_maxPos = 1210
						,	_itemPos
						;
						
						$('.cartContents table tr', node).removeClass('select');
						el.addClass('select');
						selectedItem =  $('.cartContents table tr', node).index(el);
						_itemPos = el.position().top;
						// #ifdef debug
						debug.debug( _itemPos );
						// #endif
						if (!cartTable.is(':animated')) {
							if (_itemPos > _maxPos) {
								cartTable.animate({marginTop: '+='+(el.outerHeight()*-1) }, 250);
							} else if (_itemPos < _minPos) {
								cartTable.animate({marginTop: '+='+(el.outerHeight()) }, 250);
							}
						}
						curQnty = el.find('.count').html()
						adaQnty.html(curQnty);
					}
				}

				$('.cartContents table tr', node).click(function(e){
					e.preventDefault();
					selectRow($(this));
				});

				$('.scrollDwn', node).click(function(e){
					e.preventDefault();
					selectedRow = $('.cartContents table tr.select');
					if (!cartTable.is(':animated')) {
						newRow = selectedRow.next();
						if (newRow.html() !== null) {
							selectRow(newRow);
							if (cartTable.outerHeight()+parseInt(cartTable.css('margin-top')) >= $('.cartContents').outerHeight()) {
								cartTable.animate({marginTop: '+='+(selectedRow.outerHeight()*-1) }, 250);
							}
						}
					}
				});

				$('.scrollUp', node).click(function(e){
					e.preventDefault();
					selectedRow = $('.cartContents table tr.select');
					if (!cartTable.is(':animated')) {
						if (!cartTableRow.first().hasClass('select')) {
							if (parseInt(cartTable.css('margin-top')) < ($('.cartContents table tr:eq(0)').outerHeight()*-1)) {
								cartTable.animate({marginTop: '+='+selectedRow.outerHeight() }, 250);
							} else {
								cartTable.animate({marginTop: '0' }, 250);
							}
							newRow = selectedRow.prev();
							selectRow(newRow);
						}
					}
				});

				$('table tr .delete', node).click(function(e){
					e.preventDefault();
					itemId = $(this).parents('tr').attr( 'cartItemId' );
					$( document.body ).trigger(
						_events.CART.CART_DELETE_ITEM
					,	{ cartItemId: itemId, quantity: 0 }
					);
				});


				$('.edit-cntrl .delete', node).click(function(e){
					e.preventDefault();
					itemId = $('table tr.select').attr( 'cartItemId' );
					$( document.body ).trigger(
						_events.CART.CART_DELETE_ITEM
					,	{ cartItemId: itemId, quantity: 0 }
					);
				});

				/*
				 * Update item quantity in cart based on user interaction with cart table or ADA controls
				 */
				$('table tr .quantity .add', node).click(function(e){
					itemId = $(this).parents('tr').attr( 'cartItemId' );
					qntyBlock = $(this).parent().find('.count');
					if (qntyBlock.html() < 100) {
						newQuantity = parseInt(qntyBlock.html())+1;
						qntyBlock.html( newQuantity );
						adaQnty.html( newQuantity );
						var newPrice = $(this).parents('tr').attr('baseprice')*parseInt(newQuantity);
						$(this).parent().parent().parent().find('.priceInfo').html(newPrice).currency({ region: root.model.globalAppData.getISOCurrencyCode()});
						$('.subhead span').html(parseInt($('.subhead span').html())+1);
						$( document.body ).trigger(
							_events.CART.CART_ITEM_QUANTITY_UPDATE
						,	{ cartItemId: itemId, quantity: newQuantity }
						);
					} else {
						$('table tr.select .limitError', node).show();
					}
				});

				$('table tr .quantity .minus', node).click(function(e){
					itemId = $(this).parents('tr').attr( 'cartItemId' );
					qntyBlock = $(this).parent().find('.count');
					if (qntyBlock.html() > 1) {
						newQuantity = parseInt(qntyBlock.html()) - 1;
						qntyBlock.html( newQuantity );
						adaQnty.html( newQuantity );
						var newPrice = $(this).parents('tr').attr('baseprice')*parseInt(newQuantity);
						$(this).parent().parent().parent().find('.priceInfo').html(newPrice).currency({ region: root.model.globalAppData.getISOCurrencyCode()});
						$('.subhead span', node).html(parseInt($('.subhead span', node).html())-1);
						$( document.body ).trigger(
							_events.CART.CART_ITEM_QUANTITY_UPDATE
						,	{ cartItemId: itemId, quantity: newQuantity }
						);
					}
				});

				$('.quantity-cntrl .add', node).click(function(e){
					e.preventDefault();
					qntyBlock = $('table tr.select .count');
					itemId = $('table tr.select').attr( 'cartItemId' );
					if (qntyBlock.html() < 100) {
						newQuantity = parseInt(qntyBlock.html()) + 1;
						qntyBlock.html( newQuantity );
						adaQnty.html( newQuantity );
						var newPrice = $('table tr.select', node).attr('baseprice')*parseInt(newQuantity);
						$('table tr.select .priceInfo', node).html(newPrice).currency({ region: root.model.globalAppData.getISOCurrencyCode()});
						$('.subhead span', node).html(parseInt($('.subhead span', node).html())+1);
						$body.trigger(
							_events.CART.CART_ITEM_QUANTITY_UPDATE
						,	{ cartItemId: itemId, quantity: newQuantity }
						);
					} else {
						$('table tr.select .limitError', node).show();
					}
				});

				$('.quantity-cntrl .minus', node).click(function(e){
					e.preventDefault();
					qntyBlock = $('table tr.select .count');
					itemId = $('table tr.select').attr( 'cartItemId' );

					if (qntyBlock.html() > 1) {
						newQuantity = parseInt(qntyBlock.html()) - 1;
						qntyBlock.html( newQuantity );
						adaQnty.html( newQuantity );
						var newPrice = $('table tr.select', node).attr('baseprice')*parseInt(newQuantity);
						$('table tr.select .priceInfo', node).html(newPrice).currency({ region: root.model.globalAppData.getISOCurrencyCode()});
						$('.subhead span', node).html(parseInt($('.subhead span', node).html())-1);	
						$body.trigger(
							_events.CART.CART_ITEM_QUANTITY_UPDATE
						,	{ cartItemId: itemId, quantity: newQuantity }
						);
					}
				});

				$('table tr  .edit', node).click(function(e){
					var
						_itemNumber
					;
					_itemNumber = $(this).parents('tr').attr( 'itemNumber' );
					e.preventDefault();
					com_art.model.currentGallery.set({});
					$.bbq.pushState( {
						page: _const.PAGE.ITEM
					,	itemNumber: _itemNumber
					,	categoryTitle: ""
					,	artistName: ""
					} );
				});

				$('.ada-controls .edit', node).click(function(e){
					var
						_itemNumber
					;
					e.preventDefault();
					_itemNumber = $('table tr.select').attr( 'itemNumber' );
					com_art.model.currentGallery.set({});
					$.bbq.pushState( {
						page: _const.PAGE.ITEM
					,	itemNumber: _itemNumber
					,	categoryTitle: ""
					,	artistName: ""
					} );
				});

				$('.continue', node).click(function(e){
					e.preventDefault();
					$.bbq.pushState( {
						page:_const.PAGE.COLLECTION
					,	collection: _model.globalAppData.getLandingContentBlockName()
					,	collectionTitle: _model.globalAppData.getLandingContentBlockName()
					,	pageIndex: 1 } );
				});

				$('.checkout', node).click(function(e){
					e.preventDefault();
					if (!$(this).hasClass('disabled')) {
						$body.trigger(_events.CART.SHOW_SHIPPING);
						root.model.page.set(root.CONST.PAGE.SHIPPINGINFO);
						//$body.trigger(_events.CART.SHOW_BILLING);
						//root.model.page.set(root.CONST.PAGE.BILLINGINFO);
					}
				});

				
				$('#submit', node).click(function(e){					
					e.preventDefault();
					if (!$(this).hasClass('disabled')) {
						$body.trigger(_events.CART.SHOW_CONFIRM);
						root.model.page.set(root.CONST.PAGE.CONFIRMORDER);
					}
				});

				$('#continueBtn', node).click(function(e){					
					e.preventDefault();
					if (!$(this).hasClass('disabled')) {
						$body.trigger(_events.CART.SHOW_BILLING);
						root.model.page.set(root.CONST.PAGE.BILLINGINFO);
					}
				});
				
				$('.back', this.node()).click(function(e){
					e.preventDefault();
					if ($('.error span').html() == root.CONST.ERROR.INVALID_SESSION) { 
						window.location.reload();
					} else {
						history.back();
					}
				});
			}
		}
	} );
}( this, at.ns, at.root ) );
