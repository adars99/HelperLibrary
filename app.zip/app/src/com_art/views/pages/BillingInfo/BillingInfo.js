at.ns.BillingInfo = ( function ( global, ns, root ){
	var
		_ME = "BillingInfo"
	,	_NAME = ns._name_ + "." + _ME
	,	_events = root.EVENTS
	,	_formEvents = _events.FORM
	,	_const = root.CONST
	,	_data = root.data
	,	$body = $( document.body )
	,	isoCountryCode = _data.ARTAPI.COUNTRYCODE
	,	creditcardType = _data.ARTAPI.CREDITCARDTYPE
	,	creditcardMonth = ""
	,	creditcardYear = ""
	,	administrativeEntityList = []	
	,	listVal
	,	ccStr=""
	,   cardParsed = false;
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}

	return ns.AbstractPage.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var 
					_that = this
				,	tempArray = []
				,	remvdArray = []
				,	lastVal = ""	
				,	cardreader
				,	swipe		
				,	value			
				
				;
				
				this._super();
				this.addProps( [				
				,	[ "countryList", [] ]
				] );

				$( document.body ).bind( root.model.page.CHANGE_EVENT, function() {
					if (root.model.page.get() == root.CONST.PAGE.BILLINGINFO) {	
						
					}	
				} );

				$(document.body).keydown(function(d){
					if (root.model.page.get() == root.CONST.PAGE.BILLINGINFO) {	
						
						if(d.which==16)
						{
							$("#ccNumber").focus();
						}
					}	

				});
				

					/*console.log('code '+e.keyCode+'   char '+String.fromCharCode(e.keyCode));
					if(e.keyCode==37) {
						document.body.addEventListener('keydown',handleCCKey);
						window.setTimeout(function() {
							document.body.removeEventListener('keydown',handleCCKey);
							processSwipe(ccStr);
						},150);
					}*/
					//console.log('code '+e.keyCode+'   char '+String.fromCharCode(e.keyCode));					
			/*		var	preventDefault = false;
				
					_that.handleCCKey(e);
					
					window.clearInterval(window['keyInterval']);
					window['keyInterval'] = window.setTimeout(function() {
							if (ccStr&&ccStr.length>0) console.log(ccStr);
							window['ccStr'] = ccStr;								
							
							if (ccStr.charCodeAt(0)==37) {
								_that.processSwipe(ccStr);
							}							
							
							ccStr = '';
							preventDefault = false;
					},500);
					
					if (e.charCode==37) {
						preventDefault = true;
					}
					
					if (preventDefault) e.preventDefault();
				});
				*/
				
				
				
				// Country list
				this.addNeed( {
					dao: _data.countryList
				,	success: this.countryList
				,	fail: function( resp ){
						_that.setServiceError( resp );
						_that.state( _that.STATES.FAIL );
					}
				,	args: function () {
						return {};
					}
				} );
				
				$body.bind( _formEvents.VALUE_CHANGE, function (event, params) {
					var 
						_text = params.text
						_list = ($('.formList:visible').hasClass('countryList')) ? $('.countryList div') : $('.stateList div')
					;
					if ($('.selected').hasClass('list')) {
						if ($('.formList').is(':visible') ) {
							_that.narrowList(_text, _list);
							$('input.selected').val(_text);
						}
					} else {
						$('.selected').val(_text);
					}
					$body.trigger( _formEvents.ISVALID, {valid:_that.isValid($('input.required')) } );
				});
				
				$body.bind( _formEvents.FOCUS_CHANGE, function (event, params) {
					var _btn = params.btn;
					_that.setFocus(_btn);
					$body.trigger( _formEvents.ISVALID, {valid:_that.isValid($('input.required')) } );
					$('.formList:visible div').show();
				});
				
				$body.bind( _formEvents.LIST_NAV, function (event, params) {
					var 
						_btn = params.btn
					,	_up = true
					,	_selectedItem
					, 	_newSelect
					;
					_up = (_btn == "upArrow") ? true : false;
					_selectedItem = ($('.formList:visible div:visible').hasClass('selected')) ? $('.formList:visible div:visible').index($('.formList:visible div.selected')) : -1;
					$('.formList:visible div').removeClass('selected');
					if (_up) {
						_newSelect = _selectedItem-1;
					} else {
						_newSelect = _selectedItem+1;
					}
					$('.formList:visible div:visible:eq('+(_newSelect)+')').addClass('selected');
					$('.formList:visible div:eq(0)').animate({'margin-top':"-"+(($('.formList:visible div:eq(0)').outerHeight())*_newSelect)+"px"}, 250);
				});
				
				$body.bind( _formEvents.LIST_SELECT, function (event, params) {
					var
						_formList = $('.formList:visible')
					,	_newVal = $('.formList:visible div.selected').html()
					,	_listInput = (_formList.hasClass('countryList')) ? $('#country') : $('#state')
					;
					if (_newVal) {
						if (_formList.hasClass('countryList')) {
							isoCountryCode = $('.formList:visible div.selected').attr("id");
							_that.getStateList();
						} else if (_formList.hasClass('stateList')) {
							$("#state").attr('stateId', $('.stateList div.selected').attr("id"));
						}
						_listInput.val(_newVal);
					} else {
						if (_formList.hasClass('countryList')) {
							_listInput.val($('.countryList div[id='+isoCountryCode+']').html());
						} else if (_formList.hasClass('stateList')) {
							if (_listInput.hasClass('required')) {
								_listInput.val($('.stateList div[id='+$("#state").attr('stateId')+']').html());
							}
						}
					}
					if (params.focusUpdate) {
						_that.setFocus("next");
					}
					$('.formList:visible').hide();
				});
										
			}

		
		/*, handleCCKey: function(e) {
					ccStr += String.fromCharCode(e.charCode);					
				}

		, processSwipe: function(value) {
				var	_that = this;
	            var parsedSwipe = _that.parseSwipe(value);
	            if (parsedSwipe.CreditCardNumber) {
	                $("#ccNumber").val(parsedSwipe.CreditCardNumber);
	                $("#ccExpirationDate").val("");
	                $("#fName").val("");
	            }
	            if (parsedSwipe.ExpirationDate) {
	                $("#ccExpirationDate").val(parsedSwipe.ExpirationDate);
	            }
	            if (parsedSwipe.NameOnCard) {
	                $("#fName").val(parsedSwipe.NameOnCard);
	            }            
	            $("body").unbind("click");
    	}
*/

    , checkForReaderInput : function(string) {

    	
    		var	_that = this;
			if (string.substring(0,2) == "%B") 
			{
				string = string.replace('%B', '');
				var arr = string.split('^');
				var ccExpireDate;
				if (arr[0].length == 16 || arr[0].length == 15) 
				{
					$('#ccNumber').val(arr[0]);

					ccExpireDate=arr[2].substring(2, 4) + '/' + arr[2].substring(0, 2);
					$('#ccExpirationDate').val(ccExpireDate);

					var nameArr = arr[1].split('/');
					$('#fName').val(nameArr[1]);
					$('#lName').val(nameArr[0]);
					_that.setMOP(arr[0].substring(0,1));
				}
					cardParsed = true;
					//$('#sdkinputid_ccNumber span.errortext').hide();
					$('#cvvNumber').focus();
					return false;
				
			}
				_that.setMOP(string.substring(0,1));	// for manual CC# entry
	}

	/*, checkPaySubmit :function() {

			if (cardParsed) 
			{ 
				cardParsed = false;
				$('#cvvNumber').focus();
				return false;
			}
			return true;
	 }*/

	,setMOP : function(ccnum) {
		// set #CC_MOP based on first number of ccNumber..
		switch (ccnum)
		 {
				case "3": $('#ccType').val('americanexpress'); break;
				case "4": $('#ccType').val('visa'); break;
				case "5": $('#ccType').val('mastercard'); break;
				case "6": $('#ccType').val('discover'); break;
		}
	 }
  /*   ,  parseSwipe: function(swipe) {
            var swipeData = {};
            if (swipe.indexOf('^') > -1) {
                var cardData = swipe.split('^');
                swipeData.CreditCardNumber = $.trim(cardData[0].replace(/[^0-9]/g, ''));
                if (swipe.length > 1)
                    swipeData.NameOnCard = $.trim(cardData[1].replace(/\//, ' '));
                if (swipe.length > 2)
                    swipeData.ExpirationDate = $.trim(cardData[2].substring(2, 4) + cardData[2].substring(0, 2));
            }
            else if (swipe.indexOf('=') > -1) {
                var cardData = swipe.split('=');
                swipeData.CreditCardNumber = $.trim(cardData[0].replace(/[^0-9]/g, ''));
                if (swipe.length > 1)
                    swipeData.ExpirationDate = $.trim(cardData[1].substring(2, 4) + cardData[1].substring(0, 2));
            }
            return swipeData;
        }

		, setCreditCardAttributes: function(cardreader)
		{
	        try {
	            cardreader = cardreader.replace('%B', '');
	            cardreader = cardreader.replace('%b', '');
	            
	            var arr = cardreader.split('^');
	            var nameArr = arr[1].split(' ');
	            var len = nameArr.length;
	            
	            this.creditcardnumber = arr[0];
	            this.month = arr[2].substring(2, 4);
	            this.year = arr[2].substring(0, 2);
	            this.first_name = '';
	            this.last_name = '';
				
				nameArr = arr[1].split('/');
	            this.first_name = nameArr[1];
	            this.last_name = nameArr[0];
				this.payment_method_id=1;
				this.type='credit';
	        } 
	        catch (err) {
	            pushToErrorLog('class Payment::setCreditCardAttributes() ' + err);
	            displayMessageWindow('Error With Card', 'There was an error reading the data from this card', 'error');
	        }
    	 }
    	 */
		,	getAdministrativeEntityListArgs: function() {
				var
					_hash = {}
				,	_isoCountryCodeKey = _data.countryAdminEntityList.ARGS.ISO_COUNTRY_CODE
				;
				_hash[ _isoCountryCodeKey ] = isoCountryCode;
				return _hash;
			}
		
		,	getStateList: function () {
				var
					_dao = _data.countryAdminEntityList
				,	_that = this
				,	_newStateContent = ""
				;
				_dao.get(
					{
						success: function(data) { 
							administrativeEntityList = data;
							$('.stateList div').remove();
							if (administrativeEntityList.length > 0) {
								$.each(administrativeEntityList, function() {
									_newStateContent ='<div id="'+this.code+'">'+this.name+'</div>'; 
									$('.billingForm .stateList').append(_newStateContent);
								});
								if (!$('#state').hasClass('required')) { 
									$('#state').addClass('required').addClass('list'); 
									$('.billingForm .stateList').height(180);
								}
							} else {
								$('.billingForm .stateList').height(0);
								$('#state').removeClass('required').removeClass('list');
							}
						}
					,	fail: function ( rawData ) {
							//_that.setServiceError( rawData );
							$('.billingForm .stateList').height(0);
							$('#state').removeClass('required').removeClass('list');
						}
					}
				,	_that.getAdministrativeEntityListArgs()
				);
			}
		
		,	isValid: function(inputArray) {
				var isFormValid = true;				
				inputArray.each(function(index, obj){
					if($(obj).val().length === 0) {
						isFormValid = false;
						return false;
					} 
				});
				return isFormValid;
			}
		
		,	placeUpdateBillingCalls: function(
					billingAddressArgs				
			) {
				var
					_that = this
				;
				// update billing address call, then chain				
				_that.placeUpdateBillingAddressCall(
						billingAddressArgs
					,	// address success callback
						function ( rawData ) {							
								com_art.model.page.set(_const.PAGE.CONFIRMORDER);
								return false;
						}
					,	// address error callback
						function ( errorParam ) {
							if ( _exists( errorParam ) ) {
								_that.error( errorParam );
							}
							_that.state( _that.STATES.FAIL );
							return false;
						}
				);
			}		
		,	placeUpdateBillingAddressCall: function (
					billingAddressArgs
				,	successCallback
				,	failCallback
			) {
				// TODO: validation?
				var
					_dao = _data.cartUpdateBillingAddress
				,	_that = this
				;
				_dao.get(
					{
						success: function ( rawData) {							
							successCallback.call( _that, rawData );
							com_art.model.page.set(_const.PAGE.CONFIRMORDER);
							return false;
						}
					,	fail: function ( rawData ) {
							/*_that.setServiceError.call( _that, rawData );
							if ( _data.artComAPIUtils.isInvalidAddressResponse( rawData ) ) {
								// Don't call failCallback or successCallback if a validation error.
								$(".error").show();
								$(".error").html(_const.ERROR.CITYSTATE);
							} else {
								failCallback.call( _that );
							}
							*/
							com_art.model.page.set(_const.PAGE.CONFIRMORDER);
							return false;
						}
					}
				,	billingAddressArgs
				);
			}	

		,	isValidCreditCard: function(type, ccnum)
			{
				if (type == "visa") {
				      // Visa: length 16, prefix 4, dashes optional.
				      var re = /^4\d{3}-?\d{4}-?\d{4}-?\d{4}$/;
				   } else if (type == "mastercard") {
				      // Mastercard: length 16, prefix 51-55, dashes optional.
				      var re = /^5[1-5]\d{2}-?\d{4}-?\d{4}-?\d{4}$/;
				   } else if (type == "discover") {
				      // Discover: length 16, prefix 6011, dashes optional.
				      var re = /^6011-?\d{4}-?\d{4}-?\d{4}$/;
				   } else if (type == "americanexpress") {
				      // American Express: length 15, prefix 34 or 37.
				      var re = /^3[4,7]\d{13}$/;
				   } else if (type == "diners") {
				      // Diners: length 14, prefix 30, 36, or 38.
				      var re = /^3[0,6,8]\d{12}$/;
				   }
				   if (!re.test(ccnum)) return false;
				   // Remove all dashes for the checksum checks to eliminate negative numbers
				   ccnum = ccnum.split("-").join("");
				   // Checksum ("Mod 10")
				   // Add even digits in even length strings or odd digits in odd length strings.
				   var checksum = 0;
				   for (var i=(2-(ccnum.length % 2)); i<=ccnum.length; i+=2) {
				      checksum += parseInt(ccnum.charAt(i-1));
				   }
				   // Analyze odd digits in even length strings or even digits in odd length strings.
				   for (var i=(ccnum.length % 2) + 1; i<ccnum.length; i+=2) {
				      var digit = parseInt(ccnum.charAt(i-1)) * 2;
				      if (digit < 10) { checksum += digit; } else { checksum += (digit-9); }
				   }
				   if ((checksum % 10) == 0) return true; else return false;
			}
		,  isValidCCExpDate: function(ccMonth,ccYear)
		{		
			var expDate=new Date();
			expDate.setFullYear(ccYear, ccMonth, 1);
			var today = new Date();
			if (expDate<today)
			{
				// Credit Card is expire
				return false;
			}
			else
			{
				// Credit is valid
				return true;
			}
		}

		,  isValidCVV: function(creditcardCVV)
		{		
			      var regCvv = /^[0-9]{3,4}$/;
		         var cvvArray = regCvv.exec(creditcardCVV);
		         if(creditcardCVV!=cvvArray)
		          {
		             //invalid cvv number
		            return false;
		          }
		         else
		            {
		             return true;  //valid cvv number
		            }
		}
		,	placeCartGetCall: function () {
				var
					_dao = _data.cart
				,	_that = this
				;
				_dao.get(
					{
						success: function ( cart ) {						
							_that.cart( cart );
							_that.state( _that.STATES.SUCCESS );
						}
					,	fail: function ( rawData ) {
							_that.setServiceError( rawData );
							_that.state( _that.STATES.FAIL );
						}
					}
				);
				this.state( this.STATES.LOADING );
			}
		,	setServiceError: function ( rawResponse ) {
				if ( _def( rawResponse ) ) {
					if ( _data.artComAPIUtils.isValidResponse( rawResponse ) ) {
							this.error( _data.artComAPIUtils.getResponseMessage( rawResponse ) );
					} else {
						this.error( "Invalid response from Art.com service." ); // TODO
					}
				}
				this.error( "Unknown error from Art.com service" );	// TODO
			}
		,	error: function ( errorMessage ) {
				if ( _def( errorMessage ) ) {
					this._error = (errorMessage.length < 200) ? errorMessage : root.CONST.ERROR.DATA;
					this._error = errorMessage;
				}
				return this._error || root.CONST.ERROR.DATA;
			}
		,	cart: function ( cart ) {
				if	( _def( cart ) ) {
					this._cart = cart;
				}
				return this._cart;
			}
		
		,	data: function() {

			}

		,	dataFail: function(){
				if (this.error() == com_art.CONST.ERROR.INVALID_SESSION) {
					$('.mainError').css({'position':'absolute', 'bottom':"300px"});
				}
				return {
					error: this.error()
				};
			}
		
		,	dataSuccess: function() {
				if (!this.cart().billingAddress) {
					isoCountryCode = _data.ARTAPI.COUNTRYCODE;
				}
				return {
					cartTotal: this.cart().cartTotal
				,	countryCode: isoCountryCode
				,	billingAdd: this.cart().billingAddress
				,	shippingAdd: this.cart().shippingAddress
				,	email: this.cart().email
				,	adminEntityList: administrativeEntityList				
				,	countryList: this.countryList()
				};
			}

		,	setFocus: function(direction) {
				var
					_that = this
				,	_inputs = $('.billingForm input.text')
				,	_ind = 0
				,	_newSelect = (direction == "next") ? 1 : -1
				,	_select = "selected"
				;

				_inputs.each(function(index){
					if ($(this).hasClass(_select)) {
						_ind = index;
						if (_ind  == _inputs.length-1) {
							_ind = -1;
						}
					}
				});
				
				_inputs.eq(_ind).removeClass(_select);
				_inputs.eq(_ind).blur();
				_inputs.eq(_ind+_newSelect).addClass(_select);
				
				if (!_inputs.eq(_ind+_newSelect).hasClass('list')) {
					$body.trigger( _formEvents.INPUT_SELECT, {text: _inputs.eq(_ind+_newSelect).val()} );		
				} else {
					$body.trigger( _formEvents.INPUT_SELECT, {text: "", id: $(this).attr('id')} );
				}				
				
				//Show/Hide Country dropdown list and keyboard select controls
				if (_inputs.eq(_ind+_newSelect).attr('id') == "country") {
					listVal = _inputs.eq(_ind+_newSelect).val();
					_that.displayList($('.countryList'));
					$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
				} else {					
					$('.countryList').hide();
					if ((_inputs.eq(_ind).attr('id') == "country") && ($('countryList div').hasClass('selected'))) {
						isoCountryCode = $('countryList div.selected').attr("id");
						_that.getStateList();
					} else {
						
					}
				}
				
				//Show/Hide State dropdown list and keyboard select controls
				//If the list has available options
				if ((_inputs.eq(_ind+_newSelect).attr('id') == "state") && ($('.stateList div').length > 0)) {
					listVal = _inputs.eq(_ind+_newSelect).val();
					_that.displayList($('.stateList'));
					$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
				} else {
					$('.stateList').hide();
				}
				

				//Show/Hide CCType dropdown list and keyboard select controls
				//If the list has available options
				if ((_inputs.eq(_ind+_newSelect).attr('id') == "ccType")) {
					listVal = _inputs.eq(_ind+_newSelect).val();
					_that.displayList($('.ccTypeList'));
					$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
				} else {
					$('.ccTypeList').hide();
				}

				//Show/Hide CCMonth dropdown list and keyboard select controls
				//If the list has available options
			/*	if ((_inputs.eq(_ind+_newSelect).attr('id') == "ccMonth")) {
					listVal = _inputs.eq(_ind+_newSelect).val();
					_that.displayList($('.ccMonthList'));
					$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
				} else {
					$('.ccMonthList').hide();
				}
				
				//Show/Hide CCYear dropdown list and keyboard select controls
				//If the list has available options
				if ((_inputs.eq(_ind+_newSelect).attr('id') == "ccYear")) {
					listVal = _inputs.eq(_ind+_newSelect).val();
					_that.displayList($('.ccYearList'));
					$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
				} else {
					$('.ccYearList').hide();
				}
				*/
				//Hide class on select of non-list input 
				if (!_inputs.eq(_ind+_newSelect).hasClass('list')) {
					$body.trigger( _formEvents.LIST_SHOW, {showList: false} );
				}
			}
		
		,	displayList: function( list ) {
				var 
					_list = list
				,	_firstItem = _list.find('div:eq(0)')
				,	_selectedPos = _list.find('div.selected').index()-2
				;
				_list.show();
				_list.find('div').show();
				_firstItem.css({'margin-top':"-"+((_firstItem.outerHeight())*_selectedPos)+"px"});
			}
		
		,	narrowList: function(str, listContent) {
				var
					_that = this
				,	$selList = listContent
				, 	listInput = ($selList.parent().hasClass('countryList')) ? $('#country') : $('#state');
				;
				$selList.first().css("marginTop", "0px");
				$selList.each(function(){
					var countryName = $(this).html().toUpperCase();
					if (countryName.indexOf(str.toUpperCase()) == 0) {
						$(this).show();
					} else {
						$(this).hide();
					}
				});
				$('.formList:visible div').removeClass('selected');
				$selList.parent().find('div:visible:eq(0)').addClass('selected');
				listInput.val($selList.parent().find('div:visible:eq(0)').html());
				if (listInput == $('#country')) {
					isoCountryCode = $selList.parent().find('div:visible:eq(0)').attr("id");
					_that.getStateList();
				} else if (listInput == $('#state')) {
					$("#state").attr('stateId', $selList.parent().find('div:visible:eq(0)').attr("id"));
				}
			}
			
		}
	,	controller: {
			init: function () {
				var 
					_this = this
				;
				this._super();
				this.live( true );
				this.keyboard = new root.views.Keyboard();
				
				$(document).bind( _formEvents.SUBMIT , function ( event, params ) {
					
					var
						_billingAddressArgs = {}
					,	_billingAddressArgKeys = com_art.data.cartUpdateBillingAddress.ARGS
					,	_valid = true
					,	_errMsg =""
					,   creditcardType
					,   creditcardNum
					,	creditcardExpDate	
					,   expDate
					,	type
					,   ccnum
					,   ccMonth
					,   ccYear
					,	creditcardCVV
					,   cvvNum					
					;
					
					creditcardType = $("#ccType").val().toLowerCase();
					creditcardNum = $("#ccNumber").val().toLowerCase();					
					creditCardExpDate=$("#ccExpirationDate").val();						
					cvvNum =$("#cvvNumber").val();

					var expdate = new Array();
					expdate=creditCardExpDate.split('/');
					ccMonth = expdate[0];
					ccYear = 20 + expdate[1];
					
					
					if (($("#ccNumber").val() != "") && _this.model().isValidCreditCard(creditcardType,creditcardNum)==false) {
						_errMsg =  _const.ERROR.CCNUM+"<br />";
						_valid = false;
					}	
					$("p.error").html("");	
										
					if (($("#ccExpirationDate").val() != "" && ($("#ccExpirationDate").val().indexOf('/') != 2)) || _this.model().isValidCCExpDate(ccMonth,ccYear)==false){
						_errMsg +=  _const.ERROR.CCEXPDATE+"<br />";
						_valid = false;
					}
					$("p.error").html("");	

				    if ($("#cvvNumber").val() != "" && _this.model().isValidCVV(cvvNum)==false)
					{
						_errMsg += _const.ERROR.CCCVV+"<br />";
						_valid = false;
					} 
										
					_billingAddressArgs[ _billingAddressArgKeys.FIRST_NAME ] = $("#fName").val();
					_billingAddressArgs[ _billingAddressArgKeys.LAST_NAME ] = $("#lName").val();
					_billingAddressArgs[ _billingAddressArgKeys.COMPANY_NAME ] = "";
					_billingAddressArgs[ _billingAddressArgKeys.ADDRESS_LINE_1 ] = $("#add1").val();
					_billingAddressArgs[ _billingAddressArgKeys.ADDRESS_LINE_2 ] = $("#add2").val();
					_billingAddressArgs[ _billingAddressArgKeys.CITY ] = $("#city").val();
					_billingAddressArgs[ _billingAddressArgKeys.STATE ] = ($("#state").hasClass('required')) ? $("#state").attr('stateId') : $("#state").val();
					_billingAddressArgs[ _billingAddressArgKeys.ZIP_CODE ] = $("#zip").val();
					_billingAddressArgs[ _billingAddressArgKeys.ISO_COUNTRY_CODE ] = isoCountryCode;					
					_billingAddressArgs[ _billingAddressArgKeys.CC_TYPE ] = $("#ccType").val().toLowerCase();					
					_billingAddressArgs[ _billingAddressArgKeys.CC_NUMBER ] = $("#ccNumber").val();
					_billingAddressArgs[ _billingAddressArgKeys.CVV_NUMBER ] = $("#cvvNumber").val();
					_billingAddressArgs[ _billingAddressArgKeys.CC_MONTH ] = ccMonth;//$('.billingForm .ccMonthList .selected').attr('id');
					_billingAddressArgs[ _billingAddressArgKeys.CC_YEAR ] = ccYear;
					

					if (_valid) {
						_this.model().placeUpdateBillingCalls(
							_billingAddressArgs
						);
					} else {
						$(".error").show();
						$(".error").html(_errMsg);
					}
					
					return false;
				});
			}
		,	prepare: function(){
				this._super();
				this.addChild({
					view: this.keyboard
				,	container: ".keyboardContainer"
				} );
			}
		,	show: function(){
				this._super();
				this.model().placeCartGetCall();
			}
		,	load: function (){
				var 
					_select = "selected"
				,	_node = this.node()
				,	_this = this
				;
				this.model().getStateList();	

				$body.trigger( _formEvents.ISVALID, {valid:_this.model().isValid($('input.required')) } );
				
				$('.cost span').currency({ region: root.model.globalAppData.getISOCurrencyCode()});

				
				/*$('#ccNumber').keyup(function () { 
						this.value = this.value.replace(/[^0-9\.]/g,'');
				});*/
				
				$('#cvvNumber').keyup(function () { 
						this.value = this.value.replace(/[^0-9\.]/g,'');
				});

				$('#zip').keyup(function () { 
						this.value = this.value.replace(/[^0-9\.]/g,'');
				});
				
				$("#ccNumber").change(function (){
					 _this.model().checkForReaderInput($(this).val()); 
					// $('#BillingForm').submit(function () { return checkPaySubmit(); });					 
				});
				
				$('.billingForm input.text').click(function(){
					//Move cursor to the end of the input value
					var _val = $(this).val();
					$(this).val("");
					$(this).val(_val);
					
					//When closing a "drop down" list move to the next field
					if ($(this).hasClass('list')) {
						if ($(this).hasClass(_select)) {
							$('#country').val($('.countryList div[id='+isoCountryCode+']').html());
							if ($('#state').hasClass('required')) {
								$('#state').val($('.stateList div[id='+$("#state").attr('stateId')+']').html());
							}
							_this.model().setFocus("next");
							return
						}
					}
					
					//Show/Hide CC type dropdown list and keyboard select controls 
					if ($(this).attr('id') == "ccType") {
						if (!$('.ccTypeList').is(":visible")) {
							_this.model().displayList($('.ccTypeList'));
							$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
						} 
					} else {
						$('.ccTypeList').hide();
						//$('#ccType').val($('.ccTypeList div[id='+$(this).attr("id")+']').html());
					}
					
					//Show/Hide CC Month dropdown list and keyboard select controls 
					/*if ($(this).attr('id') == "ccMonth") {
						if (!$('.ccMonthList').is(":visible")) {
							_this.model().displayList($('.ccMonthList'));
							$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
						} 
					} else {
						$('.ccMonthList').hide();
						//$('#ccMonth').val($('.ccMonthList div[id='01']').html());
					}
					
					//Show/Hide CC Year dropdown list and keyboard select controls 
					if ($(this).attr('id') == "ccYear") {
						if (!$('.ccYearList').is(":visible")) {
							_this.model().displayList($('.ccYearList'));
							$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
						} 
					} else {
						$('.ccYearList').hide();
						//$('#ccYear').val($('.ccYearList div[id='+ccType+']').html());
					}
					*/
					
					//Show/Hide Country dropdown list and keyboard select controls 
					if ($(this).attr('id') == "country") {
						if (!$('.countryList').is(":visible")) {
							_this.model().displayList($('.countryList'));
							$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
						} 
					} else {
						$('.countryList').hide();
						$('#country').val($('.countryList div[id='+isoCountryCode+']').html());
					}
									
					//Show/Hide State dropdown list and keyboard select controls 
					//If the list has available options
					if (($(this).attr('id') == "state") && ($('.stateList div').length > 0)) {
						if (!$('.stateList').is(":visible")) {
							_this.model().displayList($('.stateList'));
							$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
						} 
					} else {
						$('.stateList').hide();
						if ($('#state').hasClass('required')) {
							$('#state').val($('.stateList div[id='+$("#state").attr('stateId')+']').html());
						}
					}
					
					if (!$(this).hasClass(_select)) {
						$('.billingForm input.text').removeClass(_select);
						$(this).addClass(_select);
						
						$body.trigger( _formEvents.ISVALID, {valid:_this.model().isValid($('input.required')) } );
						//Hide class on select of non-list input
						//Clear out the keyboard input if it a list item
						if (!$(this).hasClass('list')) {
							$body.trigger( _formEvents.LIST_SHOW, {showList: false} );
							$body.trigger( _formEvents.INPUT_SELECT, {text: $(this).val(), id: $(this).attr('id')} );
						} else {
							$body.trigger( _formEvents.INPUT_SELECT, {text: "", id: $(this).attr('id')} );
						}
					}
				});

			$('.billingForm :checkbox').click(function() {
			    var $this = $(this);
			    // $this will contain a reference to the checkbox   
			    if ($this.is(':checked')) {

					var shippingAddressArgsVals=com_art.data.cartUpdateShippingAddress.args;
					var shippingAddVals = [];
			        for (var key in shippingAddressArgsVals) {
			            shippingAddVals.push(shippingAddressArgsVals[key]);
			        }
				
					   $("#fName").val(shippingAddVals[0]);
					   $("#lName").val(shippingAddVals[1]);					   
					   $("#add1").val(shippingAddVals[3]);						
					   $("#add2").val(shippingAddVals[4]);
					   $("#city").val(shippingAddVals[5]);								  
					   $("#state").val($('.stateList div[id='+shippingAddVals[6]+']').html());
					   $("#zip").val(shippingAddVals[7]);					   
					   $('#country').val($('.countryList div[id='+shippingAddVals[8]+']').html());					
					}
					else
					{
						$("#fName").val('');
						$("#lName").val('');						
						$("#add1").val('');			
						$("#add2").val('');			
						$("#city").val('');
						$("#state").val('');
						$("#zip").val('');
						$("#country").val('');
					}							
									    	
				    
				});
				
				$('.billingForm .countryList div').click(function() {
					$('.billingForm .countryList div').removeClass(_select);
					$(this).addClass(_select);
					$('#country').val($(this).html());
					_this.model().setFocus("next");
					isoCountryCode = $(this).attr("id");
					_this.model().getStateList();
				});

				$('.billingForm .ccTypeList div').click(function() {
					$('.billingForm .ccTypeList div').removeClass(_select);
					$(this).addClass(_select);
					$('#ccType').val($(this).html());
					_this.model().setFocus("next");
					creditcardType = $(this).attr("id");
					
				});

				/*$('.billingForm .ccMonthList div').click(function() {
					$('.billingForm .ccMonthList div').removeClass(_select);
					$(this).addClass(_select);
					$('#ccMonth').val($(this).html());
					creditcardMonth = $(this).attr("id");
					_this.model().setFocus("next");
						
					
				});

				$('.billingForm .ccYearList div').click(function() {
					$('.billingForm .ccYearList div').removeClass(_select);
					$(this).addClass(_select);
					$('#ccYear').val($(this).html());
					creditcardYear = $(this).attr("id");
					_this.model().setFocus("next");
					
				});*/

				// Delegate allows events to be attached to future elements.
				$('.stateList').delegate('div', 'click', function(){
					$('.billingForm .stateList div').removeClass(_select);
					$(this).addClass(_select);
					$('#state').val($(this).html());
					$("#state").attr('stateId', $(this).attr('id'));
					_this.model().setFocus("next");
				});
				
				// List Scroll buttons
				$('.formList span').click(function() {
					$body.trigger(_events.FORM.LIST_NAV, {btn: this.id});
				});
				
				$('.back', this.node()).click(function(e){
					e.preventDefault();
					root.model.page.set(root.CONST.PAGE.CART);
				});
			}
		}
	} );	
}( this, at.ns, at.root ) );