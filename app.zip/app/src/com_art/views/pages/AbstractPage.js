/**
 * @fileoverview
 *
 * @requires viewSystem.views.Abstract
 *
 */

at.ns.AbstractPage = ( function ( global, ns, root ){
	var _NAME = ns._name_ + ".AbstractPage";

	return ns._parent_.Abstract.extend( {
		namespace: _NAME
	,	model: {
			init:function () {
				this._super();
				
				this.addProps( [
					"state"
				] );
			}
		
		,	needsMet: function(){ return this._state; }
	}
	,	controller: { }
	} );

}( this, at.ns, at.root ) );