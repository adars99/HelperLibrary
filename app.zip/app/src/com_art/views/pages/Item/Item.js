at.ns.Item = ( function ( global, ns, root ){
	var
		_ME = "Item"
	,	_NAME = ns._name_ + "." + _ME
	,	_model = root.model
	,	_data = root.data
	,	_const = root.CONST
	,	_events = root.EVENTS
	,	_itemEvents = _events.ITEM
	,	$body = $( document.body )
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}
	function _hashSize( h ) {
		var key = null
		,	count = 0;
		;
		for ( key in h ) {
			if ( h.hasOwnProperty( key ) ) {
				count++;
			}
		}
		return count;
	}
	function _getActiveItemVariation( currentItemVariations, itemNumber ) {
		var
			_itemNumberItemMap = currentItemVariations.getItemNumberItemMap()
		,	_activeItem
		;
		if ( _def( _itemNumberItemMap )
				&& _hashSize( _itemNumberItemMap ) > 0 ) {
			_activeItem = _itemNumberItemMap[ itemNumber ];
			if ( _exists( _activeItem ) ) {
				return _activeItem;
			}
		}
		return null;
	}
	function _getViewEntryDefaultItemVariation( currentItemVariations ) {
		var
			_nonCanvasItems = currentItemVariations.getNonCanvasItems()
		,	_canvasItems = currentItemVariations.getCanvasItems()
		,	_activeItem
		;
		if ( _exists( _nonCanvasItems )
				&& _nonCanvasItems.length > 0 ) {
			_activeItem = _nonCanvasItems[0];
			if ( _exists( _activeItem ) ) {
				return _activeItem;
			}
		} else if ( _exists( _canvasItems )
				&& _canvasItems.length > 0 ) {
			_activeItem = _canvasItems[0];
			if ( _exists( _activeItem ) ) {
				return _activeItem;
			}
		}
		return null;
	}

	return ns.AbstractPage.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var
					_that = this
				;
				this._super();

				$body.bind(
					_model.currentItemNumber.CHANGE_EVENT
				,	this.scope( function( e, val ){
						if ( val && val.trim() != '' ) {
							// Always get new item data if there is currentItemNumber data
						//	(CurrentItemNumber indicates item view entry item number)
							_that.placeItemVariationsCall( val );
						}
					} )
				);
			}
		,	placeItemVariationsCall: function ( itemNumber ) {
				if ( !_def( itemNumber ) ) {
					return;
				}
				var
					_dao = _data.itemVariations
				,	_that = this
				;
				_dao.get(
					{
						success: function ( itemVariations ) {
							var _activeItem;
							if ( _def( itemVariations )
									&& itemVariations.length > 0 ) {
								_model.currentItemVariations.setItems( itemVariations );
								_activeItem = _getViewEntryDefaultItemVariation(
										_model.currentItemVariations
									);
								if ( _exists( _activeItem ) ) {
									// On entry to Item view, on't use default item number set by the api
									// Set active item to the first item
									_that.activeItem( _activeItem );
									_that.state( _that.STATES.SUCCESS );
								} else {
									// #ifdef debug
									debug.error( "Item: variations data success: default item found:"
									,	_model.currentItemVariations.get() );
									// #endif
									_that.setNoItemError();
									_that.state( _that.STATES.FAIL );
								}
							} else {
								_that.setNoVariationsError();
								_that.state( _that.STATES.FAIL );
								// #ifdef debug
								debug.warn("ERROR STATE: successful response, but no item variations " +_that.state() );
								// #endif
							}
						}
					,	fail: function ( rawData ) {
							_that.error( rawData );
							_that.state( _that.STATES.FAIL );
						}
					}
				,	itemNumber
				);
				this.state( this.STATES.LOADING );
			}

		,	activeItem: function ( activeItem ) {
				if	( _def( activeItem ) ) {
					this._activeItem = activeItem;
					_model.activeItem.set(activeItem);
				}
				return this._activeItem;
			}
		,	setNoItemError: function(){
				this._error = _const.ERROR.NO_ITEMS;
				return this._error;
			}
		,	setNoVariationsError: function(){
				this._error = _const.ERROR.NO_VARIATATIONS;
				return this._error;
			}
		,	error: function( rawData ){
				if ( _def( rawData ) ) {
					if ( _data.artComAPIUtils.isValidResponse( rawData ) ) {
						this._error = (_data.artComAPIUtils.getResponseMessage( rawData ).length < 200) ? _data.artComAPIUtils.getResponseMessage( rawData ) : root.CONST.ERROR.DATA;
					} else {
						this._error = _const.ERROR.DATA;
					}
				}
				return this._error || _const.ERROR.DATA;
			}
			// Sort the item array by size from smallest to largest
		,	sortBySize: function(arr) {
				var
					sortedItems = arr.slice(0)
				,	sizeInc = 0
				,	sizeIncTotal = 0
				;
				sortedItems.sort(function(a,b){return a.dimensions.height-b.dimensions.height});
				$.each(sortedItems, function(i, val) {
					var
						prev = null
					;
					if ( i > 0 ) {
						prev = sortedItems[i-1];
					}
					if ( !prev
							|| prev.dimensions.width != this.dimensions.width ) {
						sizeInc++;
					}
					this.sizeIndex = sizeInc;
					sizeIncTotal = sizeInc;
			    });
				$.each(sortedItems, function( i, val ) {
					this.sizeIncTotal = sizeIncTotal;
				});
				return arr;
			}
		,	data: function() {
				return {
					namespace: _NAME
				,	item: this.activeItem()
				,	nonCanvasItemVariations: _model.currentItemVariations.getNonCanvasItems()
				,	canvasItemVariations: _model.currentItemVariations.getCanvasItems()
				,	itemFramedVariations: [] //_model.currentItemFramedVariations.getFramedItems()
				};
			}
		,	dataFail: function(){
				if (this.error() == com_art.CONST.ERROR.INVALID_SESSION) {
					$('.mainError').css({'position':'absolute', 'bottom':"400px"});
				}
				return {
					error: this.error()
				};
			}
		,	dataSuccess: function(){
				return {
					namespace: _NAME
				,	item: this.activeItem()
				,	nonCanvasItemVariations: this.sortBySize(_model.currentItemVariations.getNonCanvasItems())
				,	printCnt: (_model.currentItemVariations.getNonCanvasItems() != null) ? _model.currentItemVariations.getNonCanvasItems().length : 0
 				,	canvasItemVariations: this.sortBySize(_model.currentItemVariations.getCanvasItems())
				,	canvasCnt: (_model.currentItemVariations.getCanvasItems()) ? _model.currentItemVariations.getCanvasItems().length : 0
				};
			}

		}
	,	controller: {
			init: function () {
				var
					_that = this
				;
				this._super();
				this.live( true );

				this.frameOptions = new root.views.ItemOptions();
				this.addChild({
					view: this.frameOptions
				,	container: ".frameList"
				} );
				
				/* 
				 * 	Click frame options updates current item image
				*/
				$(document).bind( _itemEvents.SET_FRAME_ITEM, function (event, params) {
					var
						_detailSrc = params.img
					;
					if (_detailSrc) {
						$('.img-loader').show();
						_that.setMainViewItemData(
							params.itemType, params.itemNum
						,	params.price, params.framed
						);
						_that.zoomOut.call( _that, _detailSrc );
					}
				});

				/*
				 * 	Zoom in on item
				 * 	Listens for click from the footer button
				 */
				$(document).bind( _itemEvents.ZOOM, function (event) {
					if ( _that.isZoomedIn.call( _that ) === false) {
						_that.zoomIn.call( _that );
					} else {
						_that.zoomOut.call( _that );
					}
					return
				});

			}
	
		,	getMainViewDetailImage: function () {
				var
					imgURL = $('.imgMed').attr('srcAttr')
				;
				return imgURL;
			}
		
			// Does NOT set the item detail image
		,	setMainViewItemData: function (
					itemType, itemNum, price, framedHtml
			) {	
				var
					_that = this
				;
				$('.addCart')
				.attr('itemNumber', itemNum)
				.attr('itemType', itemType);
				$('.cost span').html(price).currency({ region: root.model.globalAppData.getISOCurrencyCode()});;
				$('.framed').html(framedHtml);
			}
		
			// Sets the item detail image 
		,	setMainViewDetailImage: function ( imgURL, successCallback ) {
				var
					_that = this
				,	detailImg = $('.imgMed')
				;
				imgURL=imgURL+"&appId="+apiSettings.APPID;
				$('.img-loader').show();
				detailImg.attr( 'src', imgURL ).attr( 'srcAttr', imgURL ).load( imgURL, function() {
					$('.img-loader').hide();
					if ( typeof successCallback === "function" ) {
						successCallback.call( _that );
					}
				});
			}

		,	isFramedItem: function ( itemType ) {
				if ( !_def( itemType ) ) {
					itemType = $('.addCart').attr('itemType');
				}
				if ( _data.ARTAPI.ITEM_TYPE.CUSTOM_FRAMED_ITEM == itemType
						|| _data.ARTAPI.ITEM_TYPE.FRAMED_ITEM_RECOMMENDATION == itemType ) {
					return true;
				}
				return false;
			}
		
		,	isZoomedIn: function ( arg ) {
				if ( _def( arg ) ) {
					if ( arg === true ) {
						$('.zoom').addClass('zoomOut');
					} else {
						$('.zoom').removeClass('zoomOut');
						$body.trigger( _itemEvents.ZOOMOUT );
					}
				}
				if ( $('.zoom').hasClass('zoomOut') ) {
					return true;
				}
				return false;
			}
		
		,	zoomOut: function ( imageURL ) {
				var
					_that = this
				, 	$node = _that.node()
				,	framed = _that.isFramedItem()
				,	detailSrc
				,	newImgURL
				,	loadWidth,	loadHeight
				,	maxNonZoomH = 740
				,	maxNonZoomW = 950
				,	minNonZoomH = 540
				,	minNonZoomW = 750
				,	_inc = $('.optionList li.selected', $node).attr('increment')
				,	_incTotal = $('.optionList li.selected', $node).attr('sizeIncTotal')
				;
				if ( _def( imageURL ) ) {
					detailSrc = imageURL;
				} else {
				detailSrc = _that.getMainViewDetailImage();
				}
				if ( framed ) {
					loadWidth = maxNonZoomW;
					loadHeight = maxNonZoomH;
					newImgURL = _data.artComAPIUtils.getResizedFramedImageURL( detailSrc, loadWidth, loadHeight );
				} else {
					loadWidth = Math.round(((maxNonZoomW - minNonZoomW)/_incTotal)*_inc + minNonZoomW);
					loadHeight = Math.round(((maxNonZoomH - minNonZoomH)/_incTotal)*_inc + minNonZoomH);
					newImgURL = _data.artComAPIUtils.getResizedGenericImageURL( detailSrc, loadWidth, loadHeight );
				}
				_that.setMainViewDetailImage( newImgURL );
				$('.imgMed').addClass('zoomOut');
				$('.imgMed').css('display', 'block');
				$('.directions span', $node).html('In');
				$('.itemDetail').fadeIn();
				$('.itemCalc').fadeIn();
				_that.isZoomedIn( false );
			}
		
		,	zoomIn: function () {
				var
					_that = this
				, 	$node = this.node()
				,	framed = _that.isFramedItem()
				,	detailSrc
				,	newWidth, newHeight
				,	newImgURL
				;
				detailSrc = _that.getMainViewDetailImage();
				newWidth = $('.itemContent').width();
				newHeight = $('.itemContent').height();
				if (framed === false) {
					newImgURL = _data.artComAPIUtils.getResizedGenericImageURL( detailSrc, newWidth, newHeight );
				} else {
					newImgURL = _data.artComAPIUtils.getResizedFramedImageURL( detailSrc, newWidth, newHeight );
				}
				_that.setMainViewDetailImage( newImgURL );
				$('.imgMed').removeClass('zoomOut');
				$('.imgMed').css('display', 'block');
				$('.directions span', $node).html('Out');
				$('.itemDetail').fadeOut();
				$('.itemCalc').fadeOut();
				_that.isZoomedIn( true );
			}

		,	prepare: function(){
				this._super();
			}

		,	show: function(){
				this._super();
				this.model().isNotSoFresh();
				// Do not display item options until page is loaded.
				// When placed in load the item options are displayed before the dom is fully rendered
				setTimeout("$('.com_art_views_ItemOptions').show()", 1250);
			}
		
		,	load: function (){
				var
					_that = this
				, 	$node = this.node()
				,	$printItem = $('.paperList .optionList li', $node).add('.canvasList .optionList li', $node)
				,	detailImg = $('.imgMed')
				,	isLoaded = false
				;
								
				$('.jList').jcarousel();	
				$('.cost span').currency({ region: root.model.globalAppData.getISOCurrencyCode()});
								
				/*
				 * Set the default dimensions on load of the image
				 */
				detailImg.load(function() {
					if (isLoaded === false) {
						_that.zoomOut();
						isLoaded = true;
					}
				});
								
				detailImg.click(function() {
					$body.trigger( _itemEvents.ZOOM );
				});

				/*
				 * Click print options to update current item size
				 */
				$printItem.click(function(e){
					if (!$(this).hasClass('selected')) {
						var
							_itemNum = $(this).attr('itemNum')
						,	_itemType
						,	_detailSrc
						,	_itemPrice
						,	_activeItem
						;
						// Set as active item
						_activeItem = _getActiveItemVariation( _model.currentItemVariations, _itemNum );
						_itemType = _activeItem.itemType;
						_detailSrc = _activeItem.genericImageURL;
						_itemPrice = _activeItem.price;
						_that._model.activeItem( _activeItem );
						$printItem.removeClass('selected');
						$(this).addClass('selected');
						$printItem.find('.measurements').removeClass('secondaryColor');
						$(this).find('.measurements').addClass('secondaryColor');
						$('.printSize').html($(this).find('.measurements').html());
						_that.setMainViewItemData(
							_itemType, _itemNum
						,	_itemPrice
						,	"No"	// framedHtml
						);
						_that.zoomOut.call( _that, _detailSrc );
						framed = false;
					}
				});

				/*
				 * 	Add item to cart
				 */
				$('.addCart').click(function(e){
					var
						_itemNumber
					,	_itemType
					;
					e.preventDefault();
					_itemNumber = $(this).attr('itemNumber');
					_itemType = $(this).attr('itemType');
					$.bbq.pushState( {
						page: _const.PAGE.CART
					} );
					$( document.body ).trigger(
						_events.CART.ITEM_ADD
					,	{ itemNumber: _itemNumber, itemType: _itemType }
					);
				});

				/*
				 * 	Click Events for options tabs
				 * 	Print/Frame Paper/Canvas
				 */
				$('.frameTab').click(function(e){
					e.preventDefault();
					$(this).addClass('selected');
					$('.printTab').removeClass('selected');
					$('.frameSubTab').show();
					$('.paperTab').hide();
					$('.canvasTab').hide();
					$('.frameList').show();
					$('.canvasList').hide();
					$('.paperList').hide();
				});
				$('.printTab').click(function(e){
					e.preventDefault();
					$(this).addClass('selected');
					$('.paperTab').addClass('selected');
					$('.canvasTab').removeClass('selected');
					$('.frameTab').removeClass('selected');
					$('.frameSubTab').hide();
					$('.paperTab').show();
					$('.canvasTab').show();
					$('.frameList').hide();
					$('.paperList').show();
					$('.canvasList').hide();
				});
				$('.paperTab').click(function(e){
					e.preventDefault();
					$('.tabs div').removeClass('selected');
					$(this).addClass('selected');
					$('.canvasList').hide();
					$('.paperList').show();
				});
				$('.canvasTab').click(function(e){
					e.preventDefault();
					$('.tabs div').removeClass('selected');
					$(this).addClass('selected');
					$('.paperList').hide();
					$('.canvasList').show();
				});

				$('.back', this.node()).click(function(){
					history.back();
				});
			}
		}
	} );
}( this, at.ns, at.root ) );