at.ns.ConfirmOrder = ( function ( global, ns, root ){
	var
		_ME = "ConfirmOrder"
	,	_NAME = ns._name_ + "." + _ME
	,	_events = root.EVENTS	
	,	$body = $( document.body )
	;
	
	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	
	return ns.AbstractPage.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var _that = this;
				this._super();
				
				/*$body.bind(	_events.CART.SHOW_CONFIRM
				,	function ( event ) {
						_that.placeCartGetCall();
					}
				);*/		
				

				$( document.body ).bind( root.model.page.CHANGE_EVENT, function() {
					if (root.model.page.get() == root.CONST.PAGE.CONFIRMORDER) {
						_that.getCartData();
					
				}
				} );
				
			}			
		,	getCartData: function () {
				var
					_dao = root.data.cart
				,	_that = this
				;
				_dao.get(
					{
						success: function ( cart ) {
							_that.cart( cart );
							_that.state( _that.STATES.SUCCESS );
						}
					,	fail: function ( rawData ) {
							_that.error( rawData );
							_that.state( _that.STATES.FAIL );
						}
					}
				);
				this.state( this.STATES.LOADING );
			}
		,	cart: function ( cart ) {
				if	( _def( cart ) ) {
					this._cart = cart;
				} 
				return this._cart;
			}
		,	error: function( rawData ){
				if ( _def( rawData ) ) {
					if ( root.data.artComAPIUtils.isValidResponse( rawData ) ) {
						this._error = (_data.artComAPIUtils.getResponseMessage( rawData ).length < 200) ? _data.artComAPIUtils.getResponseMessage( rawData ) : root.CONST.ERROR.DATA;
					} else {
						this._error = root.CONST.ERROR.DATA;
					}
				}
				return this._error || root.CONST.ERROR.DATA;
			}
		,	data: function() {
				
			}
		,	dataFail: function(){
				return {
					error: this.error()
				};
			}
		,	dataSuccess: function() {
				return {
					cartTotal: this.cart().cartTotal
				,	shippingAdd: this.cart().shippingAddress
				,	billingAdd: this.cart().billingAddress
				,	email: this.cart().email
				};
			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	load: function (){
				var 
					_this = this
				;
				$('.cost span').currency({ region: root.model.globalAppData.getISOCurrencyCode()});

				var billingAddressArgsVals=com_art.data.cartUpdateBillingAddress.args;
					var billingAddVals = [];
			        for (var key in billingAddressArgsVals) {
			            billingAddVals.push(billingAddressArgsVals[key]);
			        }				

				$("#paymentName").html(billingAddVals[0] + " " + billingAddVals[1] +"<br />");
				$("#paymentAddLine1").html(billingAddVals[3]+"<br />");
				if(billingAddVals[4]!="")
				{
					$("#paymentAddLine2").html(billingAddVals[4]+"<br />");
				}
				$("#paymentCityState").html(billingAddVals[5] + " , " + billingAddVals[6]+"<br />");				
				$("#paymentZip").html(billingAddVals[7]+"<br />");
				$("#paymentCountry").html(billingAddVals[8]);

				$('.editOrder').click(function(e){
					e.preventDefault();
//					root.model.page.set(root.CONST.PAGE.SHIPPINGINFO);
					root.model.page.set(root.CONST.PAGE.BILLINGINFO);
				});

				$('.submitOrder').click(function(e){
					e.preventDefault();
					_this.placeCartSubmitCall.call( _this );
				});

				$('.back', this.node()).click(function(e){
					e.preventDefault();
					if ($('.error span').html() == root.CONST.ERROR.INVALID_SESSION) { 
						window.location.reload();
					} else {
						root.model.page.set(root.CONST.PAGE.CART);
					}
				});
			}
		,	placeCartSubmitCall: function () {
				var
					_dao = root.data.cartSubmitForOrder
				,	_that = this
				;
				_dao.get(
					{
						success: function ( orderNumber ) {
							// Next page: order completion page
							root.model.page.set(root.CONST.PAGE.ORDERCOMPLETE);							
							$( document.body ).trigger( _events.PRINTRECEIPT, {url: apiSettings.PRINTURL+"?format=thermal&ordernumber="+orderNumber} );
						}
					,	fail: function ( rawData ) {
							_that._model.error( rawData );
							_that._model.state( _that._model.STATES.FAIL );
						}
					}
				);
				_that._model.state( this.STATES.LOADING );
			}
		}
	} );
}( this, at.ns, at.root ) );