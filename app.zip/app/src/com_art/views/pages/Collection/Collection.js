at.ns.Collection = ( function ( global, ns, root ){
	var
		_ME = "Collection"
	,	_NAME = ns._name_ + "." + _ME
	,	_model = root.model
	,	_data = root.data
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}

	return ns.AbstractPage.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var _that = this;
				this._super();

				$( document.body ).bind(
						_model.currentCollection.CHANGE_EVENT
					,	this.scope( function( e, val ){
							if ( _model.currentCollection.get().id
								=== _model.collectionList.getId()
							) {
								// If the only thing that changed is the pageNumber
								//	only refresh the view
								_that.isNotSoFresh.call( _that );
							} else {
								// Otherwise, get data call
							_that.placeBannersCall( val.id );
							}
						} )
				);
			}

		,	placeBannersCall: function ( val ) {
				if ( !_def( val ) ) {
					return;
				}
				var
					_dao = _data.contentBlock
				,	_that = this
				,	_id = val
				;
				_dao.get(
					{
						success: function ( data ) {
							_model.collectionStore.add(
									_id
								,	_data.ARTAPI.LINK_TYPES.CONTENT_BLOCK
								,	data.banners );
							_model.collectionList.setHash( _id, data.banners );
							_that.state( _that.STATES.SUCCESS );
							if (_model.currentCollection.get().id !== _model.globalAppData.getLandingContentBlockName()) {
								if ( data.title !== _model.currentCollection.get().title ) {
									_model.currentCollection.setHash(
										_model.currentCollection.get().id
									,	data.title
									,	_model.currentCollection.get().pageNumber
									);
								}
							} else {
								_model.homeCollection.set( data.banners );
							}
						}
					,	fail: function ( rawData ) {
							$('.com_art_views_BottomNav').hide();
							_that.error( rawData );
							_that.state( _that.STATES.FAIL );
						}
					}
				,	_id
				);
				this.state( this.STATES.LOADING );
			}
		,	error: function( rawData ){
				if ( _def( rawData ) ) {
					if ( _data.artComAPIUtils.isValidResponse( rawData ) ) {
							this._error = (_data.artComAPIUtils.getResponseMessage( rawData ).length < 200) ? _data.artComAPIUtils.getResponseMessage( rawData ) : root.CONST.ERROR.DATA;
					} else {
						this._error = root.CONST.ERROR.DATA;
					}
				}
				return this._error || root.CONST.ERROR.DATA;
			}
		,	data: function() {
				return {
					namespace: _NAME
				,	banners: _model.collectionList.getCurrentItems()
				};
			}
		,	dataFail: function(){
				return {
					error: this.error()
				};
			}
		,	dataSuccess: function(){
				var
					_pageNumber = (_model.currentCollection.get().pageNumber)
				;
				return {
					namespace: _NAME
				,	banners: _model.collectionList.getCurrentItems(_pageNumber)
				};
			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	load: function (){
				var
					_linkType
				,	_linkParam
				;

				$('.collections').fadeIn("slow");

				$('.collection').click(function(e){
					e.preventDefault();
					_linkType = $(this).attr('linkType');
					_linkParam = $(this).attr('linkParameter');
					_linkTitle = $(this).attr('linkTitle');
					if (_linkType == _data.ARTAPI.LINK_TYPES.CONTENT_BLOCK) {
						$.bbq.removeState('loadingHome');
						$.bbq.pushState( {
							collection: _linkParam
						,	collectionTitle: _linkTitle
						,	pageIndex: 1
						} );
					} else if ( _linkType == _data.ARTAPI.LINK_TYPES.CATEGORY ) {
						$.bbq.removeState('loadingHome');
						$.bbq.pushState( {
							page: root.CONST.PAGE.GALLERY
						,	categoryId: _linkParam
						,	categoryTitle: _linkTitle
						,	artistCategoryId: ""
						,	artistName: ""
						,	pageIndex: 1
						} );
					}
				});
				
				$('.back', this.node()).click(function(){
					window.location.reload();
				});
			}
		}
	} );
}( this, at.ns, at.root ) );