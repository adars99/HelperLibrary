at.ns.OrderComplete = ( function ( global, ns, root ){
	var
		_ME = "OrderComplete"
	,	_NAME = ns._name_ + "." + _ME
	,	_events = root.EVENTS
	;

	return ns.AbstractPage.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var _that = this;
				this._super();
				this.state( this.STATES.SUCCESS );
			}
		,	data: function() {
			
			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
				
				$( document.body ).bind( com_art.EVENTS.RECEIPTLOADED, function() {
					$('.submitBtn .button').removeClass('inactive');
					$('.submitBtn .print-loader').hide();
				});
			}
		,	load: function (){
				
				$('.button').click(function(e){
					e.preventDefault();
					if (!$(this).hasClass('inactive')) {
						newSession();
					}
				});
				
				$("#orderNumber").text(window.name);				
				var endSession = setTimeout("window.location.reload()", 25000);
				
				function newSession() {
					clearTimeout(endSession);
					$('.receipt-wrapper').css({'display':'none'});
					$(document.body).trigger( root.EVENTS.FOOTER.DISABLE_CART );
					window.location.reload()
				}

			}
		}
	} );
}( this, at.ns, at.root ) );