at.ns.ShippingInfo = ( function ( global, ns, root ){
	var
		_ME = "ShippingInfo"
	,	_NAME = ns._name_ + "." + _ME
	,	_events = root.EVENTS
	,	_formEvents = _events.FORM
	,	_const = root.CONST
	,	_data = root.data
	,	$body = $( document.body )
	,	isoCountryCode = _data.ARTAPI.COUNTRYCODE
	,	administrativeEntityList = []
	,	listVal
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}

	return ns.AbstractPage.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var 
					_that = this
				,	tempArray = []
				,	remvdArray = []
				,	lastVal = ""
				;
				
				this._super();
				this.addProps( [
				,	[ "shippingPriority", _data.ARTAPI.SHIPPING_PRIORITY.STANDARD ]
				,	[ "countryList", [] ]
				] );

				// Country list
				this.addNeed( {
					dao: _data.countryList
				,	success: this.countryList
				,	fail: function( resp ){
						_that.setServiceError( resp );
						_that.state( _that.STATES.FAIL );
					}
				,	args: function () {
						return {};
					}
				} );
				
				$body.bind( _formEvents.VALUE_CHANGE, function (event, params) {
					var 
						_text = params.text
						_list = ($('.formList:visible').hasClass('countryList')) ? $('.countryList div') : $('.stateList div')
					;
					if ($('.selected').hasClass('list')) {
						if ($('.formList').is(':visible') ) {
							_that.narrowList(_text, _list);
							$('input.selected').val(_text);
						}
					} else {
						$('.selected').val(_text);
					}
					$body.trigger( _formEvents.ISVALID, {valid:_that.isValid($('input.required')) } );
				});
				
				$body.bind( _formEvents.FOCUS_CHANGE, function (event, params) {
					var _btn = params.btn;
					_that.setFocus(_btn);
					$body.trigger( _formEvents.ISVALID, {valid:_that.isValid($('input.required')) } );
					$('.formList:visible div').show();
				});
				
				$body.bind( _formEvents.LIST_NAV, function (event, params) {
					var 
						_btn = params.btn
					,	_up = true
					,	_selectedItem
					, 	_newSelect
					;
					_up = (_btn == "upArrow") ? true : false;
					_selectedItem = ($('.formList:visible div:visible').hasClass('selected')) ? $('.formList:visible div:visible').index($('.formList:visible div.selected')) : -1;
					$('.formList:visible div').removeClass('selected');
					if (_up) {
						_newSelect = _selectedItem-1;
					} else {
						_newSelect = _selectedItem+1;
					}
					$('.formList:visible div:visible:eq('+(_newSelect)+')').addClass('selected');
					$('.formList:visible div:eq(0)').animate({'margin-top':"-"+(($('.formList:visible div:eq(0)').outerHeight())*_newSelect)+"px"}, 250);
				});
				
				$body.bind( _formEvents.LIST_SELECT, function (event, params) {
					var
						_formList = $('.formList:visible')
					,	_newVal = $('.formList:visible div.selected').html()
					,	_listInput = (_formList.hasClass('countryList')) ? $('#country') : $('#state')
					;
					if (_newVal) {
						if (_formList.hasClass('countryList')) {
							isoCountryCode = $('.formList:visible div.selected').attr("id");
							_that.getStateList();
						} else if (_formList.hasClass('stateList')) {
							$("#state").attr('stateId', $('.stateList div.selected').attr("id"));
						}
						_listInput.val(_newVal);
					} else {
						if (_formList.hasClass('countryList')) {
							_listInput.val($('.countryList div[id='+isoCountryCode+']').html());
						} else if (_formList.hasClass('stateList')) {
							if (_listInput.hasClass('required')) {
								_listInput.val($('.stateList div[id='+$("#state").attr('stateId')+']').html());
							}
						}
					}
					if (params.focusUpdate) {
						_that.setFocus("next");
					}
					$('.formList:visible').hide();
				});
										
			}
	
		,	getAdministrativeEntityListArgs: function() {
				var
					_hash = {}
				,	_isoCountryCodeKey = _data.countryAdminEntityList.ARGS.ISO_COUNTRY_CODE
				;
				_hash[ _isoCountryCodeKey ] = isoCountryCode;
				return _hash;
			}
		
		,	getStateList: function () {
				var
					_dao = _data.countryAdminEntityList
				,	_that = this
				,	_newStateContent = ""
				;
				_dao.get(
					{
						success: function(data) { 
							administrativeEntityList = data;
							$('.stateList div').remove();
							if (administrativeEntityList.length > 0) {
								$.each(administrativeEntityList, function() {
									_newStateContent ='<div id="'+this.code+'">'+this.name+'</div>'; 
									$('.shippingForm .stateList').append(_newStateContent);
								});
								if (!$('#state').hasClass('required')) { 
									$('#state').addClass('required').addClass('list'); 
									$('.shippingForm .stateList').height(180);
								}
							} else {
								$('.shippingForm .stateList').height(0);
								$('#state').removeClass('required').removeClass('list');
							}
						}
					,	fail: function ( rawData ) {
							//_that.setServiceError( rawData );
							$('.shippingForm .stateList').height(0);
							$('#state').removeClass('required').removeClass('list');
						}
					}
				,	_that.getAdministrativeEntityListArgs()
				);
			}
		
		,	isValid: function(inputArray) {
				var isFormValid = true;				
				inputArray.each(function(index, obj){
					if($(obj).val().length === 0) {
						isFormValid = false;
						return false;
					} 
				});
				return isFormValid;
			}
		
		,	placeUpdateShippingInfoCalls: function(
					shippingAddressArgs
				,	shippingPriority
			) {
				var
					_that = this
				;
				// update shipping address call, then chain
				//	update shipping priority call
				_that.placeUpdateShippingAddressCall(
						shippingAddressArgs
					,	// address success callback
						function ( cart ) {
							_that.placeUpdateShippingPriorityCall(
								shippingPriority
								, // priority success callback
								function ( cart ) {

									//com_art.model.page.set(_const.PAGE.CONFIRMORDER);
									com_art.model.page.set(_const.PAGE.BILLINGINFO);
									return false;
								}
								, // error callback
								function ( errorParam ) {
									if ( _exists( errorParam ) ) {
										_that.error( errorParam );
									}
									_that.state( _that.STATES.FAIL );
									return false;
								}
							);
							return false;
						}
					,	// address error callback
						function ( errorParam ) {
							if ( _exists( errorParam ) ) {
								_that.error( errorParam );
							}
							_that.state( _that.STATES.FAIL );
							return false;
						}
				);
			}
		,	placeUpdateShippingAddressCall: function (
					shippingAddressArgs
				,	successCallback
				,	failCallback
			) {
				// TODO: validation?
				var
					_dao = _data.cartUpdateShippingAddress
				,	_that = this
				;
				_dao.get(
					{
						success: function ( cart ) {
							successCallback.call( _that, cart );
							return false;
						}
					,	fail: function ( rawData ) {
							_that.setServiceError.call( _that, rawData );
							if ( _data.artComAPIUtils.isInvalidAddressResponse( rawData ) ) {
								// Don't call failCallback or successCallback if a validation error.
								$(".error").show();
								$(".error").html(_const.ERROR.CITYSTATE);
							} else {
								failCallback.call( _that );
							}
							return false;
						}
					}
				,	shippingAddressArgs
				);
			}
		,	placeUpdateShippingPriorityCall: function (
				shippingPriority
			,	successCallback
			,	errorCallback
			) {
				var
					_dao = _data.cartUpdateShippingPriority
				,	_that = this
				;
				if ( !_exists( shippingPriority ) ) {
					return;
				}
				_dao.get(
					{
						success: function ( cart ) {
							successCallback.call( _that, cart );
							return false;
						}
					,	fail: function ( rawData ) {						
							_that.setServiceError.call( _that, rawData );
							errorCallback.call( _that );
							return false;
						}
					}
				,	shippingPriority
				);
				this.state( this.STATES.LOADING );
				return false;
			}

		,	placeCartGetCall: function () {
				var
					_dao = _data.cart
				,	_that = this
				;
				_dao.get(
					{
						success: function ( cart ) {							
							_that.cart( cart );
							_that.state( _that.STATES.SUCCESS );
						}
					,	fail: function ( rawData ) {
							_that.setServiceError( rawData );
							_that.state( _that.STATES.FAIL );
						}
					}
				);
				this.state( this.STATES.LOADING );
			}
		,	setServiceError: function ( rawResponse ) {
				if ( _def( rawResponse ) ) {
					if ( _data.artComAPIUtils.isValidResponse( rawResponse ) ) {
							this.error( _data.artComAPIUtils.getResponseMessage( rawResponse ) );
					} else {
						this.error( "Invalid response from Art.com service." ); // TODO
					}
				}
				this.error( "Unknown error from Art.com service" );	// TODO
			}
		,	error: function ( errorMessage ) {
				if ( _def( errorMessage ) ) {
					this._error = (errorMessage.length < 200) ? errorMessage : root.CONST.ERROR.DATA;
					this._error = errorMessage;
				}
				return this._error || root.CONST.ERROR.DATA;
			}
		,	cart: function ( cart ) {
				if	( _def( cart ) ) {
					this._cart = cart;
				}
				return this._cart;
			}
		
		,	data: function() {

			}

		,	dataFail: function(){
				if (this.error() == com_art.CONST.ERROR.INVALID_SESSION) {
					$('.mainError').css({'position':'absolute', 'bottom':"300px"});
				}
				return {
					error: this.error()
				};
			}
		
		,	dataSuccess: function() {
				if (!this.cart().shippingAddress) {
					isoCountryCode = _data.ARTAPI.COUNTRYCODE;
				}
				return {
					cartTotal: this.cart().cartTotal
				,	countryCode: isoCountryCode
				,	shippingAdd: this.cart().shippingAddress
				,	email: this.cart().email
				,	adminEntityList: administrativeEntityList
				,	countryList: this.countryList()
				};
			}

		,	setFocus: function(direction) {
				var
					_that = this
				,	_inputs = $('.shippingForm input.text')
				,	_ind = 0
				,	_newSelect = (direction == "next") ? 1 : -1
				,	_select = "selected"
				;

				_inputs.each(function(index){
					if ($(this).hasClass(_select)) {
						_ind = index;
						if (_ind  == _inputs.length-1) {
							_ind = -1;
						}
					}
				});
				
				_inputs.eq(_ind).removeClass(_select);
				_inputs.eq(_ind).blur();
				_inputs.eq(_ind+_newSelect).addClass(_select);
				
				if (!_inputs.eq(_ind+_newSelect).hasClass('list')) {
					$body.trigger( _formEvents.INPUT_SELECT, {text: _inputs.eq(_ind+_newSelect).val()} );		
				} else {
					$body.trigger( _formEvents.INPUT_SELECT, {text: "", id: $(this).attr('id')} );
				}				
				
				//Show/Hide Country dropdown list and keyboard select controls
				if (_inputs.eq(_ind+_newSelect).attr('id') == "country") {
					listVal = _inputs.eq(_ind+_newSelect).val();
					_that.displayList($('.countryList'));
					$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
				} else {					
					$('.countryList').hide();
					if ((_inputs.eq(_ind).attr('id') == "country") && ($('countryList div').hasClass('selected'))) {
						isoCountryCode = $('countryList div.selected').attr("id");
						_that.getStateList();
					} else {
						
					}
				}
				
				//Show/Hide State dropdown list and keyboard select controls
				//If the list has available options
				if ((_inputs.eq(_ind+_newSelect).attr('id') == "state") && ($('.stateList div').length > 0)) {
					listVal = _inputs.eq(_ind+_newSelect).val();
					_that.displayList($('.stateList'));
					$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
				} else {
					$('.stateList').hide();
				}
				
				//Hide class on select of non-list input 
				if (!_inputs.eq(_ind+_newSelect).hasClass('list')) {
					$body.trigger( _formEvents.LIST_SHOW, {showList: false} );
				}
			}
		
		,	displayList: function( list ) {
				var 
					_list = list
				,	_firstItem = _list.find('div:eq(0)')
				,	_selectedPos = _list.find('div.selected').index()-2
				;
				_list.show();
				_list.find('div').show();
				_firstItem.css({'margin-top':"-"+((_firstItem.outerHeight())*_selectedPos)+"px"});
			}
		
		,	narrowList: function(str, listContent) {
				var
					_that = this
				,	$selList = listContent
				, 	listInput = ($selList.parent().hasClass('countryList')) ? $('#country') : $('#state');
				;
				$selList.first().css("marginTop", "0px");
				$selList.each(function(){
					var countryName = $(this).html().toUpperCase();
					if (countryName.indexOf(str.toUpperCase()) == 0) {
						$(this).show();
					} else {
						$(this).hide();
					}
				});
				$('.formList:visible div').removeClass('selected');
				$selList.parent().find('div:visible:eq(0)').addClass('selected');
				listInput.val($selList.parent().find('div:visible:eq(0)').html());
				if (listInput == $('#country')) {
					isoCountryCode = $selList.parent().find('div:visible:eq(0)').attr("id");
					_that.getStateList();
				} else if (listInput == $('#state')) {
					$("#state").attr('stateId', $selList.parent().find('div:visible:eq(0)').attr("id"));
				}
			}
			
		}
	,	controller: {
			init: function () {
				var 
					_this = this
				;
				this._super();
				this.live( true );
				this.keyboard = new root.views.Keyboard();
				
				$(document).bind( _formEvents.CONTINUE , function ( event, params ) {
					
					var
						_shippingAddressArgs = {}
					,	_shippingAddressArgKeys = com_art.data.cartUpdateShippingAddress.ARGS
					,	_valid = true
					,	_errMsg =""
					;
					
					if (($("#phone").val() != "") && (!/^[0-9\s,.-]{7,24}$/.test($("#phone").val()))) {
						_errMsg =  _const.ERROR.PHONE+"<br />";
						_valid = false;
					}		
					$("p.error").html("");
					if (!/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test($("#email").val())) {
						_errMsg +=  _const.ERROR.EMAIL;
						_valid = false;
					}	
					_shippingAddressArgs[ _shippingAddressArgKeys.FIRST_NAME ] = $("#fName").val();
					_shippingAddressArgs[ _shippingAddressArgKeys.LAST_NAME ] = $("#lName").val();
					_shippingAddressArgs[ _shippingAddressArgKeys.COMPANY_NAME ] = "";
					_shippingAddressArgs[ _shippingAddressArgKeys.ADDRESS_LINE_1 ] = $("#add1").val();
					_shippingAddressArgs[ _shippingAddressArgKeys.ADDRESS_LINE_2 ] = $("#add2").val();
					_shippingAddressArgs[ _shippingAddressArgKeys.CITY ] = $("#city").val();
					_shippingAddressArgs[ _shippingAddressArgKeys.STATE ] = ($("#state").hasClass('required')) ? $("#state").attr('stateId') : $("#state").val();
					_shippingAddressArgs[ _shippingAddressArgKeys.ZIP_CODE ] = $("#zip").val();
					_shippingAddressArgs[ _shippingAddressArgKeys.ISO_COUNTRY_CODE ] = isoCountryCode;
					_shippingAddressArgs[ _shippingAddressArgKeys.PRIMARY_PHONE ] = $("#phone").val();
					_shippingAddressArgs[ _shippingAddressArgKeys.SECONDARY_PHONE ] = "";
					_shippingAddressArgs[ _shippingAddressArgKeys.EMAIL_ADDRESS ] = $("#email").val().toLowerCase();
					
					if (_valid) {
						_this.model().placeUpdateShippingInfoCalls(
							_shippingAddressArgs
						,	_data.ARTAPI.SHIPPING_PRIORITY.STANDARD
						);
					} else {
						$(".error").show();
						$(".error").html(_errMsg);
					}
					
					return false;
				});
			}
		,	prepare: function(){
				this._super();
				this.addChild({
					view: this.keyboard
				,	container: ".keyboardContainer"
				} );
			}
		,	show: function(){
				this._super();
				this.model().placeCartGetCall();
			}
		,	load: function (){
				var 
					_select = "selected"
				,	_node = this.node()
				,	_this = this
				;
				this.model().getStateList();	

				$body.trigger( _formEvents.ISVALID, {valid:_this.model().isValid($('input.required')) } );
				
				$('.cost span').currency({ region: root.model.globalAppData.getISOCurrencyCode()});
				
							
				$('.shippingForm input.text').click(function(){
					//Move cursor to the end of the input value
					var _val = $(this).val();
					$(this).val("");
					$(this).val(_val);
					
					//When closing a "drop down" list move to the next field
					if ($(this).hasClass('list')) {
						if ($(this).hasClass(_select)) {
							$('#country').val($('.countryList div[id='+isoCountryCode+']').html());
							if ($('#state').hasClass('required')) {
								$('#state').val($('.stateList div[id='+$("#state").attr('stateId')+']').html());
							}
							_this.model().setFocus("next");
							return
						}
					}
					
					//Show/Hide Country dropdown list and keyboard select controls 
					if ($(this).attr('id') == "country") {
						if (!$('.countryList').is(":visible")) {
							_this.model().displayList($('.countryList'));
							$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
						} 
					} else {
						$('.countryList').hide();
						$('#country').val($('.countryList div[id='+isoCountryCode+']').html());
					}
									
					//Show/Hide State dropdown list and keyboard select controls 
					//If the list has available options
					if (($(this).attr('id') == "state") && ($('.stateList div').length > 0)) {
						if (!$('.stateList').is(":visible")) {
							_this.model().displayList($('.stateList'));
							$body.trigger( _formEvents.LIST_SHOW, {showList: true} );
						} 
					} else {
						$('.stateList').hide();
						if ($('#state').hasClass('required')) {
							$('#state').val($('.stateList div[id='+$("#state").attr('stateId')+']').html());
						}
					}
					
					if (!$(this).hasClass(_select)) {
						$('.shippingForm input.text').removeClass(_select);
						$(this).addClass(_select);
						
						$body.trigger( _formEvents.ISVALID, {valid:_this.model().isValid($('input.required')) } );
						//Hide class on select of non-list input
						//Clear out the keyboard input if it a list item
						if (!$(this).hasClass('list')) {
							$body.trigger( _formEvents.LIST_SHOW, {showList: false} );
							$body.trigger( _formEvents.INPUT_SELECT, {text: $(this).val(), id: $(this).attr('id')} );
						} else {
							$body.trigger( _formEvents.INPUT_SELECT, {text: "", id: $(this).attr('id')} );
						}
					}
				});
				
				$('.shippingForm .countryList div').click(function() {
					$('.shippingForm .countryList div').removeClass(_select);
					$(this).addClass(_select);
					$('#country').val($(this).html());
					_this.model().setFocus("next");
					isoCountryCode = $(this).attr("id");
					_this.model().getStateList();
				});

				// Delegate allows events to be attached to future elements.
				$('.stateList').delegate('div', 'click', function(){
					$('.shippingForm .stateList div').removeClass(_select);
					$(this).addClass(_select);
					$('#state').val($(this).html());
					$("#state").attr('stateId', $(this).attr('id'));
					_this.model().setFocus("next");
				});
				
				// List Scroll buttons
				$('.formList span').click(function() {
					$body.trigger(_events.FORM.LIST_NAV, {btn: this.id});
				});
				
				$('.back', this.node()).click(function(e){
					e.preventDefault();
					root.model.page.set(root.CONST.PAGE.CART);
				});
			}
		}
	} );
}( this, at.ns, at.root ) );