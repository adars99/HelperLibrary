at.ns.Breadcrumbs = ( function ( global, ns, root ){
	var
		_ME = "Breadcrumbs"
	,	_NAME = ns._name_ + "." + _ME
	,	_const = root.CONST
	;

	return ns.Abstract.extend( {
		namespace: _NAME
	,	model: {
			init: function(){
				var
					_that = this
				,	$body = $( document.body )
				;
				this._super();

				$body.bind( root.model.page.CHANGE_EVENT, this.scope( this.isNotSoFresh ) );
				$body.bind( root.model.currentCollection.CHANGE_EVENT, this.scope( this.isNotSoFresh ) );
				$body.bind( root.model.currentGallery.CHANGE_EVENT, this.scope( this.isNotSoFresh ) );
				$body.bind( root.model.activeItem.CHANGE_EVENT, this.scope( this.isNotSoFresh ) );
			}
		,	data: function() {
				var
					_colTitle = ""
				,	_colDrillDown
				,	i
				,	_currentCollection = root.model.currentCollection
				, 	_activeItem = root.model.activeItem
				,	_currentGallery = root.model.currentGallery
				,	_galleryTitle = ""
				,	_separator = "&nbsp;&nbsp;>&nbsp;&nbsp;"
				;
				if ( _currentCollection.get()
						&& (_currentCollection.get().id !== root.model.globalAppData.getLandingContentBlockName()) ) {
					_colDrillDown = root.model.collectionStore.drillDownTitlesForCollection(
							_currentCollection.get().id );
					if ( _colDrillDown && _colDrillDown.length > 0 ) {
						// drill down list is depth first
						for ( i=_colDrillDown.length-1; i>=0; i-- ) {
							_colTitle = _colDrillDown[i] ? _colTitle + _separator + _colDrillDown[i] : _colTitle ;
						}
					} else {
						// #ifdef debug
						debug.warn( "Breadcrumbs:data:collection: no drill-down list found in collection store for collection id "
								+ _currentCollection.get().id );
						// #endif
						// very default behavior
					_colTitle = (_currentCollection.get().title) ? _separator+_currentCollection.get().title : "";
					}
				}

				if (	root.model.page.get()
					&&	( _const.PAGE.GALLERY == root.model.page.get()
							|| _const.PAGE.ITEM == root.model.page.get()
						)
					&&	_currentGallery.get()
				) {
					if (_currentGallery.get().title) {
						_galleryTitle = _separator + _currentGallery.get().title;
					} else {
						_galleryTitle = "";
						_colTitle = "";
					}
					switch ( _currentGallery.get().type ) {
						case _currentGallery.TYPE.ARTIST_CATEGORY:
							_colTitle = "";
							break;
					}
				}

				return {
					collectionTitle: _colTitle
				,	galleryTitle: _galleryTitle
				,	itemTitle: (_activeItem.get()) ? _separator + _activeItem.get().artist.firstName + " "+ _activeItem.get().artist.lastName : ""
				}
			}

		}
	,	controller: {
			init: function () {
				this._super();
				this.live( true );
			}
		,	load: function (){
				var
					_this = this
				,	_page = root.model.page
				;
				$( document.body ).bind( _page.CHANGE_EVENT, function ( e ) {
					var shoppingPages = _const.PAGE.ITEM || _const.PAGE.COLLECTION || _const.PAGE.GALLERY;
					if (_page.get() == shoppingPages) {
						$('.shopping', _this.node()).css("display", "block");
						$('.checkout', _this.node()).css("display", "none");
					} else {
						$('.checkout img').removeClass('active');
						switch(_page.get()) {
							case _const.PAGE.CART:
								$('.checkout img.step1').addClass('active');
							break;
							case _const.PAGE.SHIPPINGINFO:
								$('.checkout img.step2').addClass('active');
							break;
							case _const.PAGE.BILLINGINFO:
								$('.checkout img.step3').addClass('active');
							break;
							case _const.PAGE.CONFIRMORDER:
								$('.checkout img.step4').addClass('active');
							break;
							case _const.PAGE.ORDERCOMPLETE:
								$('.checkout img.step5').addClass('active');
							break;
						}
						$('.shopping', _this.node()).css("display", "none");
						$('.checkout', _this.node()).css("display", "block");
					}
				});
			}
		}
	} );
}( this, at.ns, at.root ) );