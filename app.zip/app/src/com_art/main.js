at.ns.main = ( function ( global, ns, root ) {
	//#ifdef debug
	$( document ).ready( function(){
		var _nothing = function(){};
		baker = _nothing; //Override Omniture console code.
		Log = {
			add: _nothing
		,	history: []
		,	info: _nothing
		,	warn: _nothing
		,	log: _nothing
		,	debug: _nothing
		};
	} );
	//#endif

	function _def( v ){
		return typeof( v ) !== "undefined";
	}

	var
		_mgr = new viewSystem.Manager()
	,	_events = root.EVENTS
	,	_const = root.CONST
	;

	return {
		/**
		 * Called after page-ready
		 */
		setup: function( dontShowMain ){

			//Overwrite apiSettings.APPID based on url hash parameter
			if ($.bbq.getState( "appId" )) {
				apiSettings.APPID = $.bbq.getState( "appId" );
			}

			//Overwrite ourselves with the main view
			ns.main = new ( function(){
				return root.views.Abstract.extend( {
					namespace: ns._name_ + ".Main"
				,	model: {}
				,	controller: {
						init: function(){
							this._super();
							this._useContainer = true; //Using whole document.body
							this._staticContent = true; //Not generating content - using existing html
						}
					,	prepare: function(){
							this._super();

							var
								_this = this
							,	_page = root.model.page
							;

							this.addChildren( [
								{
									view: new root.views.Header()
								,	container: "#header"
								}
							,	{
									view: new root.views.Breadcrumbs()
								,	container: "#breadcrumbs"
								}
							] );

							this.addChildrenTo(
								[
									{
										view: new root.views.BottomNav()
									,	value: _const.ADA
									}
								]
							,	{
									container: "#bottomNav"
								,	model: "ada"
								}
							);

							this.addChildrenTo(
								[
									{
										view: new root.views.Footer()
									,	value: _const.FOOTER
									}
								]
							,	{
									container: "#footer"
								,	model: "footer"
								}
							);

							this.addChildrenTo(
									[
										{
											view: new root.views.panels.Artist()
										,	value: _const.PANEL.ARTIST
										}
									,	{
											view: new root.views.panels.Collection()
										,	value: _const.PANEL.COLLECTION
										}
									,	{
											view: new root.views.panels.Help()
										,	value: _const.PANEL.HELP
										}
									,	{
											view: new root.views.panels.PrivacyPolicy()
										,	value: _const.PANEL.PRIVACYPOLICY
										}
									]
								,	{
										container: "#panels"
									,	model: "panels"
									}
								);

							this.addChildrenTo(
								[
								 	{
								 		view: new root.views.pages.Collection()
								 	,	value: _const.PAGE.COLLECTION
								 	}
								 ,	{
								 		view: new root.views.pages.Gallery()
								 	,	value: _const.PAGE.GALLERY
								 	}
								 ,	{
								 		view: new root.views.pages.Item()
								 	,	value: _const.PAGE.ITEM
								 	}
								 ,	{
								 		view: new root.views.pages.Cart()
								 	,	value: _const.PAGE.CART
								 	}
								 ,	{
								 		view: new root.views.pages.ShippingInfo()
								 	,	value: _const.PAGE.SHIPPINGINFO
								 	}
								 ,	{
								 		view: new root.views.pages.BillingInfo()
								 	,	value: _const.PAGE.BILLINGINFO
								 	}
								 ,	{
								 		view: new root.views.pages.ConfirmOrder()
								 	,	value: _const.PAGE.CONFIRMORDER
								 	}
								 ,	{
								 		view: new root.views.pages.OrderComplete()
								 	,	value: _const.PAGE.ORDERCOMPLETE
								 	}
								]
							,	{
									container: "#pages"
								,	model: "page"
								}
							);

							$( window ).bind( "hashchange", this.changeViewHash );

							$( document.body ).bind( _page.CHANGE_EVENT, function ( e ) {
								_this.hidePanel();
								switch(_page.get()) {
									case _const.PAGE.COLLECTION:
										_this.showCollection();
									break;
									case _const.PAGE.GALLERY:
										_this.showGallery();
									break;
									case _const.PAGE.ITEM:
										_this.showItem();
									break;
									case _const.PAGE.CART:
										_this.showCart();
									break;
									case _const.PAGE.SHIPPINGINFO:
										_this.showShippingInfo();
									break;
									case _const.PAGE.BILLINGINFO:
										_this.showBillingInfo();
									break;
									case _const.PAGE.CONFIRMORDER:
										_this.showConfirmOrder();
									break;
									case _const.PAGE.ORDERCOMPLETE:
										_this.showOrderComplete();
									break;
								}
							});

							this.showCollection();
						}

					,	changeViewHash: function( e ){
							if( root.model.page.get() !== $.bbq.getState( "page" ) ){
								root.model.page.set( $.bbq.getState( "page" ) );
							}
							// Clear out currentItemNumber so that
							//	when the Item view is called,
							//	that re-sets the currentItemNumber with a real value
							//	and the listeners for the Item view controller
							//	restart with a fresh slate
							root.model.currentItemNumber.set( null );
							switch (root.model.page.get()) {
								case _const.PAGE.COLLECTION:
									root.main.hidePanel();
									root.model.activeItem.set('');
									root.model.currentCollection.setHash(
										$.bbq.getState( "collection" )
									,	$.bbq.getState( "collectionTitle" )
									,	$.bbq.getState( "pageIndex" )
									);
								break;
								case _const.PAGE.GALLERY:
									root.model.activeItem.set('');
									if ( $.bbq.getState( "artistCategoryId" )
											&& $.bbq.getState( "artistCategoryId" ) !== ""
									) {
										root.model.currentGallery.setHash(
											$.bbq.getState( "artistCategoryId" )
										,	$.bbq.getState( "artistName" )
										,	root.model.currentGallery.TYPE.ARTIST_CATEGORY
										,	$.bbq.getState( "pageIndex" )
										);
									} else {
										root.model.currentGallery.setHash(
											$.bbq.getState( "categoryId" )
										,	$.bbq.getState( "categoryTitle" )
										,	root.model.currentGallery.TYPE.CATEGORY
										,	$.bbq.getState( "pageIndex" )
										);
									}
									// Set supergroup data for breadcrumbs
									if ( $.bbq.getState( "collection" ) !== root.model.currentCollection.get().id ) {
										root.model.currentCollection.setHash(
												$.bbq.getState( "collection" )
											,	$.bbq.getState( "collectionTitle" )
											,	1
											);
									}
									break;

								case _const.PAGE.ITEM:
									root.model.currentItemNumber.set( $.bbq.getState( "itemNumber" ) );
									// Set supergroup data for breadcrumbs
									if ( $.bbq.getState( "collection" ) !== root.model.currentCollection.get().id ) {
										root.model.currentCollection.setHash(
												$.bbq.getState( "collection" )
											,	$.bbq.getState( "collectionTitle" )
											,	1
											);
									}
									if ( $.bbq.getState( "artistCategoryId" )
											&& $.bbq.getState( "artistCategoryId" ) != ""
											&& !( $.bbq.getState( "artistCategoryId" ) == root.model.currentGallery.get().id
													&& root.model.currentGallery.TYPE.ARTIST_CATEGORY === root.model.currentGallery.get().type
												)
									) {
										root.model.currentGallery.setHash(
											$.bbq.getState( "artistCategoryId" )
										,	$.bbq.getState( "artistName" )
										,	root.model.currentGallery.TYPE.ARTIST_CATEGORY
										,	$.bbq.getState( "pageIndex" )
										);
									} else if ( $.bbq.getState( "categoryId" )
											&& $.bbq.getState( "categoryId" ) !== ""
											&& !( $.bbq.getState( "categoryId" ) !== root.model.currentGallery.get().id
													&& root.model.currentGallery.TYPE.CATEGORY === root.model.currentGallery.get().type
												)
									) {
										root.model.currentGallery.setHash(
												$.bbq.getState( "categoryId" )
											,	$.bbq.getState( "categoryTitle" )
											,	root.model.currentGallery.TYPE.CATEGORY
											,	1
											);
									}
									break;
								default:
									break;
							}

						}

					,	showCollection: function() {
							this.setChildValue( "page", _const.PAGE.COLLECTION );
							this.setChildValue( "ada", _const.ADA );
							this.setChildValue( "footer", _const.FOOTER );
						}

					,	showGallery: function() {
							this.setChildValue( "page", _const.PAGE.GALLERY );
							this.setChildValue( "ada", _const.ADA );
							this.setChildValue( "footer", _const.FOOTER );
						}

					,	showItem: function() {
							this.setChildValue( "page", _const.PAGE.ITEM );
							this.setChildValue( "ada", _const.OFF );
							this.setChildValue( "footer", _const.FOOTER );
						}

					,	showCart: function() {
							this.setChildValue( "page", _const.PAGE.CART );
							this.setChildValue( "ada", _const.OFF );
							this.setChildValue( "footer", _const.FOOTER );
						}

					,	showShippingInfo: function() {
							this.setChildValue( "page", _const.PAGE.SHIPPINGINFO );
							this.setChildValue( "ada", _const.OFF );
							this.setChildValue( "footer", _const.FOOTER );
						}

					,	showBillingInfo: function() {
							this.setChildValue( "page", _const.PAGE.BILLINGINFO );
							this.setChildValue( "ada", _const.OFF );
							this.setChildValue( "footer", _const.FOOTER );
						}

					,	showConfirmOrder: function() {
							this.setChildValue( "page", _const.PAGE.CONFIRMORDER );
							this.setChildValue( "ada", _const.OFF );
							this.setChildValue( "footer", _const.FOOTER );
						}

					,	showOrderComplete: function() {
							this.setChildValue( "page", _const.PAGE.ORDERCOMPLETE );
							this.setChildValue( "ada", _const.OFF );
							this.setChildValue( "footer", _const.OFF );
						}

					,	showArtistPanel: function() {
							this.setChildValue( "panels", _const.PANEL.ARTIST );
						}

					,	showCollectionPanel: function() {
							this.setChildValue( "panels", _const.PANEL.COLLECTION );
						}

					,	showHelpPanel: function() {
							this.setChildValue( "panels", _const.PANEL.HELP );
						}

					,	showPrivacyPanel: function() {
							this.setChildValue( "panels", _const.PANEL.PRIVACYPOLICY );
						}

					,	hidePanel: function() {
							this.setChildValue( "panels", _const.OFF );
							$( document.body ).trigger(root.EVENTS.FOOTER.SET_INACTIVE);
						}
					
					,	showGlobalError: function() {
							$('.main-loader').hide();
							$('.mainError span').html(_const.ERROR.KIOSK_UNAVAILABLE);
							$('.mainError').show();
							$('#breadcrumbs').hide();
							$('#bottomNav').hide();
							$('#footer').hide();
						}

					,	startNewSession: function ( successCallback, failCallback ) {
							var _that = this;
							//#ifdef debug
							debug.debug( "Discarding old session id; getting new one." );
							//#endif
							root.model.sessionId.set("");
							root.data.session.get(
								{
									success: function ( data ) {
										root.model.sessionId.set( data.sessionData.sessionId );
										// do something
										if ( typeof(successCallback) == "function" ) {
											successCallback.call( root, data );
										}
									}
								,	fail: function ( rawData ) {
										//#ifdef debug
										debug.debug( "Failed to initialize new Art.com API session. Call response: "
										,	rawData );
										//#endif
										
										_that.showGlobalError();
										
										if ( typeof(failCallback) == "function" ) {
											failCallback.call( root, rawData );
										}
									}
								}
							);
						}

					,	/*
						 * Warning: Art.com API wraps even non-session specific data retrieval
						 * in a user session. (It conflates internationalization sessions with user sessions.)
						 * Therefore, there is much interlinkage between the site data calls
						 * and the user session calls.
						 */
						setInitialSiteData: function ( forceStartNewSession
								, successCallback
								, prevLevel
						) {
							var _level = ( prevLevel ) ? prevLevel + 1 : 1;
							var _maxlevels = 3;
							var _that = this;
							if ( forceStartNewSession || !ns.main.sessionIdExists() ) {
								ns.main.startNewSession(
									// success callback
									function ( data ) {
										root.model.globalAppData.setInHash(
											"appName"
										,	data.appData.name );
										root.model.globalAppData.setInHash(
											"isoCurrencyCode"
										,	data.appData.isoCurrencyCode );

										_that.setInitialSiteData.call(
											_that
										,	false, successCallback, _level );
									}
								,	// fail callback
									function ( rawData ) {
										// #ifdef debug
										debug.error( "main:startNewSession: Failed to initialize new Art.com API session." );
										// #endif
										_that.showGlobalError();
									}
								);
							} else {
								// call to get landing init data
								root.data.landing.get( {
									success: function ( data ) {
										root.model.headerBlockName
											.set( data.headerCBName );
										root.model.globalAppData.setInHash(
											"kioskCategoryBlockName"
										,	data.kioskCategoryCBName );
										root.model.globalAppData.setInHash(
											"landingContentBlockName"
										,	data.landingCBName );
										root.model.globalAppData.setInHash(
												"recieptContentBlockName"
										, _const.PRINT_RECEIPTS);
										$('.main-loader').hide();
																	
										if ( typeof(successCallback) == "function" ) {
											successCallback.call( this );
										}
									}
								,	fail: function ( rawData ) {
										if ( root.data.artComAPIUtils.isSessionExpiredResponse( rawData ) ) {
											//#ifdef debug
											debug.error( "Art.com API session expired when retrieving landing data. Attempting to reset sessionId (at _level)", _level );
											//#endif
											root.model.sessionId.set("");
											if ( _level <= _maxlevels ) {
												// Note: recursive call settings would force a startNewSession
												_that.setInitialSiteData.call(
													_that
												,	true
												,	successCallback
												, _level );
											} else {
												// #ifdef debug
												debug.error( "Tried and failed " + _maxlevels
														+ " times to re-initialize Art.com API user session and data." );
												// #endif
												_that.showGlobalError();
											}
										} else {
											// #ifdef debug
											debug.error( "Unknown failure getting landing data with response: "
											,	rawData );
											// #endif
											_that.showGlobalError();
										}
									}
								} );
								// complete call to get landing init data
							}
						}
					,	setKioskCategoryId: function (
								successCallback
							,	failCallback
						) {
							// Get kiosk categoryId information needed
							//	for artists calls
							var
								kioskCategoryBlockName
								= root.model.globalAppData.getKioskCategoryBlockName()
							;

							if ( !kioskCategoryBlockName ) {
								// #ifdef debug
								debug.error( "main:setKioskCategoryId: no kiosk category contentBlockName in global data."
								,	root.model.globalAppData.get() );
								// #endif
								failCallback.call();							
								return;
							}
							root.data.contentBlock.get(
								{
									success: function ( data ) {
										
										if ( data.banners.length > 0
												&& data.banners[0].linkType == root.data.ARTAPI.LINK_TYPES.CATEGORY
										) {
											if ( data.banners[0].linkParameter
													&& data.banners[0].linkParameter.trim() !== ""
											) {
												root.model.globalAppData.setInHash(
													"kioskCategoryId"
												,	data.banners[0].linkParameter );
											} else {
												// #ifdef debug
												debug.warn( "main:setKioskCategoryId: call to get kiosk categoryId returned blank linkParameter."
													+ " Continuing with empty kiosk categoryId", data );
												// #endif
												root.model.globalAppData.setInHash(
													"kioskCategoryId"
												,	"" );
											}
											successCallback.call();
										} else {
											// #ifdef debug
											debug.error( "main:setKioskCategoryId: call to get kiosk categoryId returned no usable data (invalid linktype, etc)."
											,	data );
											// #endif
											failCallback.call();
										}
									}
								,	fail: function ( rawData ) {
										// #ifdef debug
										debug.error( "main:setKioskCategoryId: call to get kiosk categoryId failed."
										,	rawData );
										// #endif
										failCallback.call()
									}
								}
							,	kioskCategoryBlockName
							);
						}

					,	sessionIdExists: function () {
							if ( root.model.sessionId.get() == undefined
									|| !(typeof root.model.sessionId.get() == "string")
									|| root.model.sessionId.get() === ""
							) {
								//#ifdef debug
								debug.debug( "sessionId does not exist" );
								//#endif
								return false;
							}
							return true;
						}

					,	load: function(){
							var
								_that = this
							;

							$.bbq.removeState();
							// TODO: errorCallback
							this.setInitialSiteData(
								true
							,	// successCallback
								function () {
									var
										landingContentBlockName
										= root.model.globalAppData.getLandingContentBlockName()
									;
									//history.replaceState({}, null, '');
									$.bbq.pushState( {
										page: _const.PAGE.COLLECTION
									,	collection: landingContentBlockName
									,	collectionTitle: landingContentBlockName
									,	pageIndex: 1
									,	loadingHome: true} );
									

									// Trigger other global data loading
									_that.setKioskCategoryId(
										// success callback
										function () {
											if ( _that.sessionIdExists.call( _that ) ) {
												$( document.body ).trigger(
													_events.GLOBAL_DATA.ARTISTS_CHANGE
												,	{}
												);
											} else {
												// can't load artist list
												// #ifdef debug
												debug.error( "main:successCallback to setKioskCategoryId: no session id - cannot continue retrieving artist list, etc."
												,	data );
												// #endif
												root.model.artistList.setInfo(
													root.model.artistList.STATE.UNMET_DEPENDENCIES
												,	null
												);
											}
										}
									,	// fail callback
										function () {
											// can't load artist list
											if (window.data === undefined ) {
												_that.showGlobalError();
											}
											// #ifdef debug
											debug.error( "main:failCallback to setKioskCategoryId: failed retrieving kiosk categoryId- cannot continue retrieving artist list, etc."
											,	data );
											// #endif
											root.model.artistList.setInfo(
												root.model.artistList.STATE.UNMET_DEPENDENCIES
											,	null
											);
										}
									);

								}
							);

							$('.retry').click(function(){
								window.location.reload();
							});
						}

					,	show: function(){
							this._super();
						}
					}
				} );
			}() );

			if( !dontShowMain ){
				ns.main.show();
			}
		}
	};
}( this, at.ns, at.root ) );