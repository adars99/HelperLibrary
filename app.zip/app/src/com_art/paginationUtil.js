at.ns.paginationUtil = ( function ( global, ns, root ) {
	var
		_this = {}
	,	_root = root
	,	_NAME = ns._name_ + ".paginationUtil"
	;

	_this.itemsStartIndexByPageNumber = function ( pageNumber, itemsPerPage ) {
		var _pageNumber = (pageNumber > 0) ? pageNumber : 1;
		return ( _pageNumber-1 )*itemsPerPage;
	};

	/**
	 * End bound, not index of end element.
	 * @param pageNumber
	 * @param itemsPerPage
	 * @returns {Number}
	 */
	_this.itemsEndByPageNumber = function ( pageNumber, itemsPerPage ) {
		var _pageNumber = (pageNumber > 0) ? pageNumber : 1;
		return (_pageNumber*itemsPerPage);
	};

	_this.itemsRangeByPageNumber = function ( pageNumber, itemsPerPage ) {
		return {
			start: this.itemsStartIndexByPageNumber( pageNumber, itemsPerPage )
		,	end: this.itemsEndByPageNumber( pageNumber, itemsPerPage )
		};
	};

	_this.pageNumberByItemIndex = function ( index, itemsPerPage ) {
		var _index = (index >= 0) ? index : 0;
		return Math.floor( _index/itemsPerPage ) + 1;
	};

	return _this;

} ( this, at.ns, at.root ) );