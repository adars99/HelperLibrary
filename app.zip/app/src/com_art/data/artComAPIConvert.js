at.ns.artComAPIConvert = ( function ( global, ns, root ) {
	var
		_NAME = ns._name_ + "." + "artComAPIConvert"
		_util = {}
	;

	function _def( val ) {
		return ( typeof ( val ) !== "undefined" );
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}

	_util.getImageModel = function ( rawImage ) {
		var
			_retImage = null
		,	_url
		;
		if ( rawImage ) {
			_retImage = {};

			_url = rawImage.HttpImageURL;
			if ( !_url || _url === "" ) {
				_url = rawImage.HttpsImageURL;
			}
			_retImage[ "url" ] = _url;

		}
		return _retImage;
	};

	_util.getDimensionsModel = function ( rawDimensions ) {
		var
			retDimensions = null
		;
		if ( rawDimensions ) {
			retDimensions = {
				unitOfMeasure: rawDimensions.UnitOfMeasure
			,	height: rawDimensions.Height
			,	width: rawDimensions.Width
			,	depth: rawDimensions.Depth
			};
		}
		return retDimensions;
	};

	_util.getArtistModel = function ( rawArtist ) {
		var
			retArtist = null
		;
		if ( rawArtist ) {
			retArtist = {
				artistId: rawArtist.ArtistId
			,	firstName: rawArtist.FirstName
			,	lastName: rawArtist.LastName
			};
		}
		return retArtist;
	};

	_util.getItemsModel = function ( rawItems, includeDiscontinued ) {
		var
			retItems = null
		,	i = null
		,	rawItem
		,	item
		;
		if ( _exists( rawItems ) ) {
			retItems = [];
			for ( i in rawItems ) {
				rawItem = rawItems[i];
				if ( rawItem.ItemStatus === root.data.ARTAPI.ITEM_STATUS.DISCONTINUED
						&& !includeDiscontinued ) {
					continue;
				}
				item = {
					itemType : rawItem.ItemType
				,	itemNumber : rawItem.ItemNumber
				,	sku : rawItem.Sku
				,	title : rawItem.ItemAttributes.Title
				,	artist : this.getArtistModel( rawItem.ItemAttributes.Artist )
				,	substrateType: rawItem.ItemAttributes.Type
				,	isCanvas : root.data.artComAPIUtils.isCanvasSubstrate( rawItem.ItemAttributes.Type )
				,	dimensions : this.getDimensionsModel( rawItem.ItemAttributes.PhysicalDimensions )
				,	canFrame : rawItem.ItemAttributes.CanFrame
				,	desc : rawItem.ItemAttributes.Description
				,	price : rawItem.ItemPrice.Price
				,	genericImageURL : rawItem.ImageInformation.GenericImageUrl
				};

				retItems.push( item );
			}
		}
		return retItems;
	};

	_util.getFramedItemsModel = function ( rawItems, includeDiscontinued ) {
		var
			retItems = null
		,	i = null
		,	rawItem
		,	framedItem
		;
		if ( _exists( rawItems ) ) {
			retItems = [];
			for ( i in rawItems ) {
				rawItem = rawItems[i];
				if ( rawItem.ItemStatus === root.data.ARTAPI.ITEM_STATUS.DISCONTINUED
						&& !includeDiscontinued ) {
					continue;
				}
				framedItem = {
					itemType : rawItem.ItemType
				,	itemNumber : rawItem.ItemNumber
				,	sku : rawItem.Sku
				,	title : rawItem.ItemAttributes.Title
				,	artist : this.getArtistModel( rawItem.ItemAttributes.Artist )
				,	substrateType: rawItem.ItemAttributes.Type
				,	isCanvas : root.data.artComAPIUtils.isCanvasSubstrate( rawItem.ItemAttributes.Type )
				,	dimensions : this.getDimensionsModel( rawItem.ItemAttributes.PhysicalDimensions )
				,	canFrame : rawItem.ItemAttributes.CanFrame
				,	desc : rawItem.ItemAttributes.Description
				,	price : rawItem.ItemPrice.Price
				,	images : {
						thumbnail: this.getImageModel( rawItem.Service.Frame.Moulding.ThumbnailImage )
					,	resizable: this.getImageModel( rawItem.ImageInformation.LargeImage )
					}
				,	mouldingName : rawItem.Service.Frame.Moulding.Name
				};

				retItems.push( framedItem );
			}
		}
		return retItems;
	};

	// Used for Cart where rawItem.ItemAttributes.CanFrame is deceptive
	_util.isFramed = function ( rawItem ) {
		if ( rawItem && rawItem.Service && rawItem.Service.Frame ) {
			return true;
		}
		return false;
	};

	_util.getCartItemCoreModel = function ( rawItem, includeDiscontinued ) {
		var
			_retItem = null
		,	_isFramed = this.isFramed( rawItem )
		;
		if ( rawItem.ItemStatus === root.data.ARTAPI.ITEM_STATUS.DISCONTINUED
				&& !includeDiscontinued ) {
			return null;
		}
		_retItem = {
			itemType : rawItem.ItemType
		,	itemNumber : rawItem.ItemNumber
		,	sku : rawItem.Sku
		,	title : rawItem.ItemAttributes.Title
		,	artist : this.getArtistModel( rawItem.ItemAttributes.Artist )
		,	substrateType: rawItem.ItemAttributes.Type
		,	isCanvas : root.data.artComAPIUtils.isCanvasSubstrate( rawItem.ItemAttributes.Type )
		,	canFrame : rawItem.ItemAttributes.CanFrame && !_isFramed
		,	desc : rawItem.ItemAttributes.Description
		,	price : rawItem.ItemPrice.Price
		,	images : {
				icon: this.getImageModel( rawItem.ImageInformation.SmallImage )
			}
		,	isFramed : _isFramed
		};
		if ( _isFramed ) {
			_retItem[ "dimensions" ] = this.getDimensionsModel( rawItem.Service.Frame.FrameSummary.PhysicalDimensions );
			_retItem[ "printDimensions" ] = this.getDimensionsModel( rawItem.ItemAttributes.PhysicalDimensions );
		} else {
			_retItem[ "dimensions" ] = this.getDimensionsModel( rawItem.ItemAttributes.PhysicalDimensions );
			_retItem[ "printDimensions" ] = this.getDimensionsModel( rawItem.ItemAttributes.PhysicalDimensions );
		}

		if ( !_retItem.images.icon || !_retItem.images.icon.url ) {
			// Alternative image sources
			_retItem.images.icon = this.getImageModel( rawItem.ImageInformation.MediumImage );
			if ( _retItem.images.icon && _retItem.images.icon.url
					&& root.data.artComAPIUtils.isResizeableFramedImageURLType( _retItem.images.icon.url ) ) {
				// Only use alternate medium image url if it is resizeable
				// Resize
				_retItem.images.icon.url = root.data.artComAPIUtils
				.getResizedFramedImageURL( _retItem.images.icon.url, 130, 130 );
			} else {
				// Otherwise, don't use image url
				// #ifdef debug
				debug.error( "artComAPIConvert:getCartItemCoreModel: icon image: No SmallImage data, attempted to use resized MediumImage, but image is not resizeable; continuing with no icon image." );
				// #endif
				_retItem.images.icon = null;
			}
		}

		return _retItem;
	};

	_util.getCartItemsModel = function ( rawCartShipments, includeDiscontinued ) {
		var
			retCartItems = null
		,	cartItem
		,	rawCartShipment
		,	rawCartItem
		,	i
		,	j
		;
		if ( !_exists( rawCartShipments ) ) {
			return null;
		}
		for ( i=0; i<rawCartShipments.length; i++ ) {
			retCartItems = [];
			rawCartShipment = rawCartShipments[i];
			for ( j=0; j<rawCartShipment.CartItems.length; j++ ) {
				rawCartItem = rawCartShipment.CartItems[j];
				cartItem = {
					id: rawCartItem.Id
				,	quantity: rawCartItem.Quantity
				,	subTotal: rawCartItem.SubTotal
				,	item: this.getCartItemCoreModel( rawCartItem.Item, includeDiscontinued )
				};
				if ( _exists( cartItem.item ) ) {
					retCartItems.push( cartItem );
				}
			}
		}
		return retCartItems;
	};

	_util.getShippingAddress = function ( rawShipments ) {
		var
			_address = null
		,	rawAddress
		,	i
		;
		if ( _exists( rawShipments ) ) {
			for ( i=0; i<rawShipments.length; i++ ) {
				rawAddress = rawShipments[i].Address;
				if ( _exists( rawAddress ) ) {
					_address = {
						companyName: rawAddress.CompanyName
					,	addressLine1: rawAddress.Address1
					,	addressLine2: rawAddress.Address2
					,	city: rawAddress.City
					,	state: rawAddress.State
					,	zipCode: rawAddress.ZipCode
					,	county: rawAddress.County
					,	country: rawAddress.Country
					};

					if ( _exists( rawAddress.Name ) ) {
						_address.name = {
							first: _exists(rawAddress.Name.FirstName) ? rawAddress.Name.FirstName : ""
						,	last: _exists(rawAddress.Name.LastName) ? rawAddress.Name.LastName : ""
						};
					} else {
						_address.name = {
							first: ""
						,	last: ""
						};
					}
					if ( _exists( rawAddress.Phone ) ) {
						_address.phone = {
							primary: _exists(rawAddress.Phone.Primary) ? rawAddress.Phone.Primary : ""
						,	secondary: _exists(rawAddress.Phone.Secondary) ? rawAddress.Phone.Secondary : ""
						};
					} else {
						_address.phone = {
							primary: ""
						,	secondary: ""
						};
					}
					break;
				}
			}
		}

		return _address;
	};

_util.getBillingAddress = function ( rawBilling ) {
		var
			_billAddress = null
		,	rawBillAddress
		,	i
		;
		if ( _exists( rawBilling ) ) {
			for ( i=0; i<rawBilling.length; i++ ) {
				rawBillAddress = rawBilling[i].Address;
				if ( _exists( rawBillAddress ) ) {
					_billAddress = {
						companyName: rawBillAddress.CompanyName
					,	addressLine1: rawBillAddress.Address1
					,	addressLine2: rawBillAddress.Address2
					,	city: rawBillAddress.City
					,	state: rawBillAddress.State
					,	zipCode: rawBillAddress.ZipCode
					,	county: rawBillAddress.County
					,	country: rawBillAddress.Country
					,	ccType: rawBillAddress.CCType
					,	ccNumber: rawBillAddress.CCNumber
					,	cvvNumber: rawBillAddress.CVVNumber
					,	ccMonth: rawBillAddress.CCMonth
					,	ccYear: rawBillAddress.CCYear
					
					};

					if ( _exists( rawBillAddress.Name ) ) {
						_billAddress.name = {
							first: _exists(rawBillAddress.Name.FirstName) ? rawBillAddress.Name.FirstName : ""
						,	last: _exists(rawBillAddress.Name.LastName) ? rawBillAddress.Name.LastName : ""
						};
					} else {
						_billAddress.name = {
							first: ""
						,	last: ""
						};
					}
					if ( _exists( rawBillAddress.Phone ) ) {
						_billAddress.phone = {
							primary: _exists(rawBillAddress.Phone.Primary) ? rawBillAddress.Phone.Primary : ""
						,	secondary: _exists(rawBillAddress.Phone.Secondary) ? rawBillAddress.Phone.Secondary : ""
						};
					} else {
						_billAddress.phone = {
							primary: ""
						,	secondary: ""
						};
					}
					break;
				}
			}
		}

		return _billAddress;
	};
	_util.getEmail = function ( rawEmail ) {
		var
			_email
		;

		if ( _exists( rawEmail ) ) {
			_email = rawEmail;
		} else {
			_email= "";
		}
		return _email;
	};

	_util.getCartModel = function ( rawCart ) {
		var retCart
		,	retCartTotal
		;
		if ( !_exists( rawCart ) ) {
			return null;
		}

		if ( !_exists( rawCart.CartTotal ) ) {
			retCartTotal = {
				productSubTotal: 0.00
			,	taxTotal: 0.00
			,	shippingTotal: 0.00
			,	total: 0.00
			};
		} else {
			retCartTotal = {
				productSubTotal: rawCart.CartTotal.ProductSubTotal
			,	taxTotal: rawCart.CartTotal.TaxTotal
			,	shippingTotal: rawCart.CartTotal.ShippingTotal
			,	total: rawCart.CartTotal.Total
			};
		}
		retCart = {
			cartId: rawCart.CartId
		,	cartTotal: retCartTotal
		,	cartItems: this.getCartItemsModel( rawCart.Shipments )
		,	shippingAddress: this.getShippingAddress( rawCart.Shipments )
		,	billingAddress: this.getBillingAddress( rawCart.Billing )
		,	email: this.getEmail( rawCart.CustomerEmailAddress )
		};
		if ( !_exists( retCart.cartItems ) ) {
			retCart.cartItems = [];
		}
		return retCart;
	};

	_util.getAdministrativeEntityListModel = function ( rawEntityList ) {
		var
			_entityList = []
		,	i = 0
		;
		if ( _exists( rawEntityList ) ) {
			_entityList = [];
			for ( i=0; i<rawEntityList.length; i++ ) {
				_entityList.push( {
					code: rawEntityList[i].StateCode
				,	name: rawEntityList[i].Name
				} );
			}
		}

		return _entityList;
	};

	_util.getCountryListModel = function ( rawCountryList ) {
		var
			_countryList = []
		,	i = 0
		;
		if ( _exists( rawCountryList ) ) {
			for ( i=0; i<rawCountryList.length; i++ ) {
				_countryList.push( {
					isoA2: rawCountryList[i].IsoA2
				,	isoA3: rawCountryList[i].IsoA3
				,	name: rawCountryList[i].Name
				} );
			}
		}
		return _countryList;
	};


	_util.getMonthListModel = function () {
		var
			_monthList = [{key:'01',val:'January'},
			{key:'02',val:'February'},
			{key:'03',val:'March'},
			{key:'04',val:'April'},
			{key:'05',val:'May'},
			{key:'06',val:'June'},
			{key:'07',val:'July'},
			{key:'08',val:'August'},
			{key:'09',val:'September'},
			{key:'10',val:'October'},
			{key:'11',val:'November'},
			{key:'12',val:'December'}
			]
			, i = 0
		;
		if ( _exists( rawMonthList ) ) {
			for ( i=0; i<=12; i++ ) {
				_monthList.push( {
					value: _monthList[i].key				
				,	name: rawMonthList[i].Name
				} );
			}
		}
		return _monthList;
	};


	_util.getArtistsModel = function ( rawArtists ) {
		var
			retArtists = []
		,	i = 0
		;
		if ( _exists( rawArtists ) ) {
			for ( i=0; i<rawArtists.length; i++ ) {
				retArtists.push( {
					artistCategoryId: rawArtists[i].CategoryId
				,	name: rawArtists[i].Name
				} );
			}
		}
		return retArtists;
	};

	return _util;
})( this, at.ns, at.root );
