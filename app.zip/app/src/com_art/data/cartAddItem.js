/*
 * requires ns.ArtComAPIDao
 */

at.ns.cartAddItem = ( function ( global, ns, root ) {
	var
		_root = root
	,	_NAME = ns._name_ + ".cartAddItem"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.CART_ADD_ITEM_PATH
	,	_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		,	ITEM_ID: "itemId"
		,	LOOKUP_TYPE: "lookupType"
		}
	,	_dao
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}

	/**
	 * returns Object
	 */
	function _prepData( rawData ) {
		var
			retCart = null
		;
		// Preliminary data validation already done by superclass ArtComAPIDao
			retCart = root.data.artComAPIConvert.getCartModel( rawData.d.Cart );

		return retCart;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function () {
				this._super();
				this.url = _URL;
				this.setAPIKeyInHash( this.args );
			}
		,	get: function ( daoArgs, itemNumber, itemType ) {
				if ( !_exists( daoArgs )
				) {
					//#ifdef debug
					debug.error( "CartAddItem DAO: missing daoArgs." );
					//#endif
					daoArgs = {};
				}
				if ( !_exists( itemNumber )
						|| !_exists( itemType )
				) {
					//#ifdef debug
					debug.error( "CartAddItem DAO: missing itemNumber or itemType."
							, itemNumber, itemType );
					//#endif
				}
//				daoArgs.scope = this;	// TODO
				daoArgs.prepData = _prepData;

				this.args[ _ARGS.LOOKUP_TYPE ] = ns.ARTAPI
					.ITEM_TYPE_CART_ADD_LOOKUP_TYPE[ itemType ];
				if ( !_exists( this.args[ _ARGS.LOOKUP_TYPE ] ) ) {
					//#ifdef debug
					debug.error( "CartAddItem DAO: No cart add lookup type for itemType " + itemType );
					//#endif
				}
				this.args[ _ARGS.ITEM_ID ] = itemNumber;
				// Set Session ID parameter from global value
				this.args[ _ARGS.SESSION_ID ] = _root.model.sessionId.get();

				// don't cache

				this._super( daoArgs, itemNumber, itemType );
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();
})( this, at.ns, at.root );
