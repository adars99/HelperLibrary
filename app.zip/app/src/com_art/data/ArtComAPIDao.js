/*
 * requires viewSystem.Dao
 * Wraps subclass get method's daoArgs.prepData in some global analysis.
 */

at.ns.ArtComAPIDao = ( function ( global, ns, root ) {
	var
		_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		}
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}

	return viewSystem.Dao.extend( {
		init: function () {
			this._super();

			/*
			 * Use the prepDataGlobalError method
			 * to handle errors
			 * before executing sub-class' daoArgs.prepData.
			 */
			this.useGlobalErrorHandling = true;

			this.type = "GET";
			switch ( apiSettings.API_SERVICE ) {
				case apiSettings.API_SERVICES.JSON:
					this.dataType = "json";
					break;
				case apiSettings.API_SERVICES.JSONP:
					this.dataType = "jsonp";
					break;
				default:
					// #ifdef debug
					debug.error( "ArtComAPIDao: unknown service type " + apiSettings.SERVICE );
					// #endif
					break;
			}

			// for jsonp
			if ( this.dataType == "jsonp" ) {
				this.timeout = 60000;
			}
		}
	,	setAPIKeyInHash: function ( hash ) {
			hash[ _ARGS.API_KEY ] = apiSettings.KEY;
		}
	,	_finish: function( daoArgs, data ){
			var
				_data = data
			;

			this._failed = ( !_def( data ) ) || daoArgs.failed;
			if ( this._failed && this.dataType === "jsonp" ) {
				// Wrap fail response in "d" hash if using JSONP service
				//	Success response not in raw format
				//		or already wrapped by prepData logic.
				if ( _exists( data ) ) {
					_data = { d : data };
				}
			}
			this._super( daoArgs, _data );
		}
	,
		get: function ( daoArgs ) {
			var
				_arguments = arguments
			,	_barePrepData = daoArgs.prepData
			,	_scope
			,	_that = this
			;
			daoArgs.scope = daoArgs.scope || global;
			_scope = daoArgs.scope;

			daoArgs.prepData = function ( rawData ) {
				var
					_rawData = rawData
				;
				if ( _rawData && _that.dataType == "jsonp" ) {
					// Art.com JSONP service returns data
					//	that is missing a wrapping "d" object
					//	when compared with the Art.com JSON service
					_rawData = { d : _rawData };
				}
				if ( _that.useGlobalErrorHandling ) {
					_rawData = _that.prepDataGlobalError.call( _that, _rawData );
				}
				if ( _rawData ) {
					if ( _barePrepData ) {
						return _barePrepData.call( _scope, _rawData );
					} else {
						return _rawData;
					}
				}
				return null;
			};

			this._super.apply( this, _arguments );
		}
	,	prepDataGlobalError: function ( rawData ) {
			var
				_utils = ns.artComAPIUtils
			,	_landingContentBlockName
			;
			if ( _utils.isValidResponse.call( this, rawData ) ) {
				if ( _utils.isSuccessfulOperationResponse.call( this, rawData ) ) {
					return rawData;
				} else if ( _utils.isSessionExpiredResponse.call( this, rawData ) ) {
					// #ifdef debug
					debug.error( "ArtComAPIDao: Art.com API session expired. Attempting to reset sessionId.", this );
					// #endif
					//Display timeout error message
					$('.mainError').height($('#bottomNav').height());
					$('.mainError span').html(root.CONST.ERROR.TIMEOUT);
					$('.mainError').show();
					//Hide ADA components if they are displayed
					$('#bottomNav').hide();
					$('.keyboardContainer').hide();
					setTimeout("window.location.reload()", 3000);
				}
			}
			return null;
		}
		/**
		 * Warning: key method uses current object's args as well.
		 */
	,	key: function ( args ) {
			var
				_tempArgs = {}
			;
			this.setAPIKeyInHash( _tempArgs );

			$.extend( _tempArgs, args );
			// cache based on args other than user session id
			return this._super(
				ns.artComAPIUtils.createHashMinus(
						_tempArgs, _ARGS.SESSION_ID
				)
			);
		}
	,	ARGS: _ARGS
	} );

})( this, at.ns, at.root );
