/*
 * requires ns.ArtComAPIDao
 */

at.ns.artistCategoryPage = ( function ( global, ns, root ) {
	var
		_root = root
	,	_NAME = ns._name_ + ".artistCategoryPage"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.ITEM_SEARCH_PATH
	,	_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		,	ARTIST_CATEGORY_ID: "artistCategoryId"
		,	CATEGORY_ID_LIST: "categoryIdList"
		,	PAGE_NUMBER: "pageNumber"
		,	NUMBER_OF_RECORDS: "numberOfRecords"
		}
	,	_dao
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( v ){
		return _def( v ) && v !== null;
	}

	/**
	 * returns Object
	 */
	function _prepData( rawData ) {
		var
			retArtistCategory = null
		;
		// Preliminary data validation already done by superclass ArtComAPIDao
			retArtistCategory = {
				items: root.data.artComAPIConvert.getItemsModel( rawData.d.Items )
			,	totalRecordCount: rawData.d.ResultSummary.TotalRecordCount
			,	pageNumber: rawData.d.ResultSummary.PageNumber
			,	resultsPerPage: rawData.d.ResultSummary.ResultsPerPage
			};
			retArtistCategory[ "itemsStartIndex" ]
				= root.paginationUtil.itemsStartIndexByPageNumber(
					retArtistCategory.pageNumber
				,	retArtistCategory.resultsPerPage
				);

		return retArtistCategory;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function () {
				this._super();
				this.url = _URL;
				this.setAPIKeyInHash( this.args );
				this.args[ _ARGS.NUMBER_OF_RECORDS ] = ns.ARTAPI.PAGINATION_PER_PAGE_MAX;
			}
		,	get: function ( daoArgs, args ) {
				if ( !_exists( daoArgs ) ) {
					//#ifdef debug
					debug.error( "Artist Category DAO: missing daoArgs." );
					//#endif
					daoArgs = {};
				}
				if ( !this.validateArgs( args ) ) {
					//#ifdef debug
					debug.error( "Artist Category DAO: invalid args.", args );
					//#endif
				}

//				daoArgs.scope = this;	// TODO
				daoArgs.prepData = _prepData;

				args[ _ARGS.PAGE_NUMBER ] = _exists( args[ _ARGS.PAGE_NUMBER ] )
					? args[ _ARGS.PAGE_NUMBER ] : 1;
				$.extend( this.args, args );
				// Set Session ID parameter from global value
				this.args[ _ARGS.SESSION_ID ] = _root.model.sessionId.get();
				// Set Kiosk Category ID parameter from global value
				this.args[ _ARGS.CATEGORY_ID_LIST ] = _root.model.globalAppData.getKioskCategoryId();

				daoArgs.key = this.key( this.args );

				this._super( daoArgs, args );
			}
		,	validateArgs: function ( args ) {
				return _exists( args )
						&& _exists( args[ _ARGS.ARTIST_CATEGORY_ID ] );
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();
})( this, at.ns, at.root );
