/*
 * requires ns.ArtComAPIDao
 */

at.ns.cartUpdateShippingPriority = ( function ( global, ns, root ) {
	var
		_root = root
	,	_NAME = ns._name_ + ".cartUpdateShippingPriority"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.CART_UPDATE_SHIPPING_PRIORITY_PATH
	,	_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		,	SHIPPING_PRIORITY: "shipmentPriority"
		}
	,	_dao
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}

	/**
	 * returns Object
	 */
	function _prepData( rawData ) {
		var
			retCart = null
		;
		// Preliminary data validation already done by superclass ArtComAPIDao
			retCart = root.data.artComAPIConvert.getCartModel( rawData.d.Cart );

		return retCart;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function () {
				this._super();
				this.url = _URL;
				this.setAPIKeyInHash( this.args );
			}
		,	get: function ( daoArgs, shippingPriority ) {
				if ( !_exists( daoArgs ) ) {
					//#ifdef debug
					debug.error( "CartUpdateShippingPriority DAO: missing daoArgs." );
					//#endif
					daoArgs = {};
				}
				if ( !_exists( shippingPriority ) ) {
					//#ifdef debug
					debug.error( "CartUpdateShippingPriority DAO: missing shippingPriority." );
					//#endif
				}

//				daoArgs.scope = this;	// TODO
				daoArgs.prepData = _prepData;

				this.args[ _ARGS.SHIPPING_PRIORITY ] = shippingPriority;
				// Set Session ID parameter from global value
				this.args[ _ARGS.SESSION_ID ] = _root.model.sessionId.get();

				// don't cache

				this._super( daoArgs, shippingPriority );
				return false;
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();
})( this, at.ns, at.root );
