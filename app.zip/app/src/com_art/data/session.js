/*
 * requires ns.ArtComAPIDao
 */
at.ns.session = (function ( global, ns, root ) {
	var
		_NAME = ns._name_ + ".session"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.INITPATH
	, 	_ARGS = {
			API_KEY: "apiKey"
		,	APPLICATION_ID: "applicationId"
		,	LANGUAGE_CODE: "twoDigitISOLanguageCode"
		,	COUNTRY_CODE: "twoDigitISOCountryCode"
		}
	,	_dao
	;

	/**
	 * @returns Object
	 */
	function _prepData( rawData ) {
		var
			retData = null
		;
		// Preliminary data validation already done by superclass ArtComAPIDao
				retData = {
					"appData" : {
							"name" : rawData.d.Application.Name
						,	"isoCurrencyCode" : rawData.d.IsoCurrencyCode
					}
				,	"sessionData" : {
							"sessionId" : rawData.d.SessionId
						,	"expirationDate" : rawData.d.DateExpires	// doesn't seem to actually mean anything
					}
				};
				return retData;

		return retData;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function(){
				this._super();
				this.url = _URL;
				this.setAPIKeyInHash( this.args );
				this.args[_ARGS.APPLICATION_ID] = apiSettings.APPID;
				this.args[_ARGS.LANGUAGE_CODE] = ns.ARTAPI.LANGCODE;
				this.args[_ARGS.COUNTRY_CODE] = utils.getQueryParam('twoDigitISOCountryCode','US');//ns.ARTAPI.COUNTRYCODE;
			}
		,	get: function( daoArgs ){
//				daoArgs.scope = this;	// TODO
				daoArgs.prepData = _prepData;

				this._super( daoArgs );
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();

})( this, at.ns, at.root );