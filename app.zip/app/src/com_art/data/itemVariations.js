/*
 * requires ns.ArtComAPIDao
 */

at.ns.itemVariations = ( function ( global, ns, root ) {
	var
		_root = root
	,	_NAME = ns._name_ + ".itemVariations"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.ITEM_GET_VARIATIONS_PATH
	,	_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		,	ITEM_ID: "itemId"
		,	LOOKUP_TYPE: "lookupType"
		}
	,	_dao
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}

	/**
	 * returns Object
	 */
	function _prepData( rawData ) {
		var
			items
		;
		// Preliminary data validation already done by superclass ArtComAPIDao
			// getItemsModel filters out discontinued items
			items = root.data.artComAPIConvert.getItemsModel( rawData.d.Items );

		return items;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function () {
				this._super();
				this.url = _URL;
				this.setAPIKeyInHash( this.args );
				this.args[ _ARGS.LOOKUP_TYPE ] = ns.ARTAPI.ITEM_LOOKUP_TYPE.ITEM_NUMBER;
			}
		,	get: function ( daoArgs, itemNumber ) {
				if ( !_def( daoArgs ) ) {
					//#ifdef debug
					debug.error( "Item Variations DAO: missing daoArgs." );
					//#endif
					daoArgs = {};
				}
				if ( !_def( itemNumber ) ) {
					//#ifdef debug
					debug.error( "Item Variations DAO: missing itemNumber." );
					//#endif
				}

//				daoArgs.scope = this;	// TODO
				daoArgs.prepData = _prepData;

				this.args[ _ARGS.ITEM_ID ] = itemNumber;
				// Set Session ID parameter from global value
				this.args[ _ARGS.SESSION_ID ] = _root.model.sessionId.get();

				// cache based on args other than user session id
				daoArgs.key = this.key(
					this.args
				);

				this._super( daoArgs, itemNumber );
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();
})( this, at.ns, at.root );
