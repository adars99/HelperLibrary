/*
 * requires ns.ArtComAPIDao
 */

at.ns.contentBlock = ( function ( global, ns, root ) {
	var
		_root = root
	,	_NAME = ns._name_ + ".contentBlock"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.CONTENT_BLOCK_PATH
	,	_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		,	CONTENT_BLOCK_NAME: "contentBlockName"
		}
	,	_dao
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}

	/**
	 * returns Object
	 */
	function _prepData( rawData ) {
		var retData = null;
		var _rawTitle
		,	_rawBanners
		,	_banners
		,	i = null
		,	_rawBanner
		,	_banner
		;
		// Preliminary data validation already done by superclass ArtComAPIDao
			retData = {};
			_rawTitle = rawData.d.ContentBlock.Title;
			retData[ "title" ] = _rawTitle;

			_rawBanners = rawData.d.ContentBlock.Banners;
			_banners = [];
			for ( i in _rawBanners ) {
				_rawBanner = _rawBanners[i];
				_banner = {};
				_banner[ "image" ] = ns.artComAPIConvert.getImageModel( _rawBanner.Image );
				_banner[ "linkType" ] = _rawBanner.LinkType;
				_banner[ "linkParameter" ] = _rawBanner.LinkParameter;
				_banner[ "title" ] = _rawBanner.Title;
				_banner[ "desc" ] = _rawBanner.SmallTextBlock;
				_banners.push( _banner );
			}
			retData[ "banners" ] = _banners;

		return retData;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function () {
				this._super();
				this.url = _URL;
				this.setAPIKeyInHash( this.args );
			}
		,	get: function ( daoArgs, contentBlockName ) {
				if ( !_def( daoArgs ) ) {
					//#ifdef debug
					debug.error( "ContentBlock DAO: missing daoArgs." );
					//#endif
					daoArgs = {};
				}
				if ( !_def( contentBlockName ) ) {
					//#ifdef debug
					debug.error( "ContentBlock DAO: missing contentBlockName." );
					//#endif
				}
//				daoArgs.scope = this;	// TODO
				daoArgs.prepData = _prepData;

				this.args[ _ARGS.CONTENT_BLOCK_NAME ] = contentBlockName;
				// Set Session ID parameter from global value
				this.args[ _ARGS.SESSION_ID ] = _root.model.sessionId.get();

				// cache based on args other than user session id
				daoArgs.key = this.key( this.args );

				this._super( daoArgs, contentBlockName );
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();
})( this, at.ns, at.root );
