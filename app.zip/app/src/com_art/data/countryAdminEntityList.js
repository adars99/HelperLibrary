/*
 * requires ns.ArtComAPIDao
 * a.k.a. states
 */

at.ns.countryAdminEntityList = ( function ( global, ns, root ) {
	var
		_root = root
	,	_NAME = ns._name_ + ".countryAdminEntityList"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.GET_COUNTRY_ADMINISTRATIVE_ENTITY_LIST_PATH
	,	_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		,	ISO_COUNTRY_CODE: "twoDigitISOCountryCode"
		}
	,	_dao
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}

	/**
	 * returns Object
	 */
	function _prepData( rawData ) {
		var
			retCart = null
		;
		// Preliminary data validation already done by superclass ArtComAPIDao
			retCart = root.data.artComAPIConvert.getAdministrativeEntityListModel( rawData.d.States );

		return retCart;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function () {
				this._super();
				this.url = _URL;
				this.setAPIKeyInHash( this.args );
			}
		,	get: function ( daoArgs, args ) {
				if ( !_exists( daoArgs )
				) {
					//#ifdef debug
					debug.error( "countryAdminEntityList DAO: missing daoArgs." );
					//#endif
					daoArgs = {};
				}
				if ( !this.validateArgs( args )
				) {
					//#ifdef debug
					debug.error( "countryAdminEntityList DAO: invalid arguments.", args );
					//#endif
				}

//				daoArgs.scope = this;	// TODO
				daoArgs.prepData = _prepData;

				this.setArgs( args );
				// Set Session ID parameter from global value
				this.args[ _ARGS.SESSION_ID ] = _root.model.sessionId.get();

				// cache based on args other than user session id
				daoArgs.key = this.key( this.args );

				this._super( daoArgs, args );
			}
		,	setArgs: function ( args ) {
				var
					_isoCountryCode = args[ _ARGS.ISO_COUNTRY_CODE ];
				;

				this.args[ _ARGS.ISO_COUNTRY_CODE ] = _isoCountryCode;
			}
		,	validateArgs: function ( _args ) {
				if ( !_exists( _args ) ) {
					return false;
				}
				var
					_isoCountryCode = _args[ _ARGS.ISO_COUNTRY_CODE ];
				;
				if ( !_exists( _isoCountryCode ) || typeof ( _isoCountryCode ) !== "string" ) {
					return false;
				}
				return true;
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();
})( this, at.ns, at.root );
