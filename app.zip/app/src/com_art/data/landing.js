/*
 * requires ns.ArtComAPIDao
 * Warning: configured to *not* use ArtComAPIDao's prepDataGlobalError
 * to pre-handling for errors
 */

at.ns.landing = ( function ( global, ns, root ) {
	var
		_NAME = ns._name_ + ".landing"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.LANDING_PATH
	,	_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		}
	,	_dao
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}

	/**
	 * returns Object
	 */
	function _prepData( rawData ) {
		var
			retData = null
		,	contentBlockNames
		,	headerCBName = null
		,	kioskCategoryCBName = null
		,	landingCBName = null
		,	i = 0
		,	name
		,	_rawData = rawData
		,	_that = this
		;
		// Preliminary data validation configured to NOT be done
		//	by superclass ArtComAPIDao
		if ( ns.artComAPIUtils.isValidResponse.call( this, _rawData )
				&& ns.artComAPIUtils.isSuccessfulOperationResponse.call( this, _rawData )
		) {
			contentBlockNames = _rawData.d.ContentBlockNames;
			for ( i in contentBlockNames ) {
				name = contentBlockNames[i];
				if ( name.toLowerCase() == ns.ARTAPI.HEADER_NAME ) {
					// expect one name to be "header" (case insensitive)
					headerCBName = name;
				} else if ( name.toLowerCase() == ns.ARTAPI.KIOSK_CATEGORY_NAME.toLowerCase() ) {
					kioskCategoryCBName = name;
				} else if ( !landingCBName ) {
					// expect one other name for the landing ContentBlock
					//	use first
					landingCBName = name;
				}
				if ( headerCBName && kioskCategoryCBName && landingCBName ) {
					break;
				}
			}
			retData = {
					"headerCBName" : headerCBName
				,	"kioskCategoryCBName" : kioskCategoryCBName
				,	"landingCBName" : landingCBName
			};
		}
		return retData;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function () {
				this._super();
				this.url = _URL;

				/*
				 * DON'T use the superclass ArtComAPIDao's
				 * prepDataGlobalError method to handle errors
				 * before executing daoArgs.prepData.
				 */
				this.useGlobalErrorHandling = false;

				this.setAPIKeyInHash( this.args );
			}
		,	get: function ( daoArgs ) {
				if ( !_def( daoArgs ) ) {
					daoArgs = {};
				}
				daoArgs.scope = this;	// Needed for _prepData (jsonp vs json behavior)
				daoArgs.prepData = _prepData;

				// Set Session ID parameter
				this.args[ _ARGS.SESSION_ID ] = root.model.sessionId.get();

				daoArgs.key = this.key( this.args );

				this._super( daoArgs );
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();
})( this, at.ns, at.root );
