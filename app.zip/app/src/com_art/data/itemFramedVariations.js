/*
 * requires ns.ArtComAPIDao
 */

at.ns.itemFramedVariations = ( function ( global, ns, root ) {
	var
		_root = root
	,	_NAME = ns._name_ + ".itemFramedVariations"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.ITEM_GET_FRAME_RECOMMENDATIONS_PATH
	,	_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		,	ITEM_ID: "itemId"
		,	LOOKUP_TYPE: "lookupType"
		,	MAX_NUMBER: "maxNumberOfRecommendations"
		,	MAX_WIDTH: "maxJpegImageWidth"
		,	MAX_HEIGHT: "maxJpegImageHeight"
		}
	,	_dao
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}

	/**
	 * returns Object
	 */
	function _prepData( rawData ) {
		var
			framedItems = null
		;
		// Preliminary data validation already done by superclass ArtComAPIDao
			// getFramedItemsModel filters out discontinued items
			framedItems = root.data.artComAPIConvert.getFramedItemsModel( rawData.d.Items );

		return framedItems;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function () {
				this._super();
				this.url = _URL;
				this.setAPIKeyInHash( this.args );
				this.args[ _ARGS.LOOKUP_TYPE ] = ns.ARTAPI.ITEM_LOOKUP_TYPE.ITEM_NUMBER;
				this.args[ _ARGS.MAX_NUMBER ] = ns.ARTAPI.MAX_NUMBER_FRAMED_VARIATIONS;
				this.args[ _ARGS.MAX_WIDTH ] = ns.ARTAPI.ITEM_VIEW_DETAIL_MAX_WIDTH;
				this.args[ _ARGS.MAX_HEIGHT ] = ns.ARTAPI.ITEM_VIEW_DETAIL_MAX_HEIGHT;
			}
		,	get: function ( daoArgs, itemNumber ) {
				if ( !_def( daoArgs ) ) {
					//#ifdef debug
					debug.error( "Item Frame Variations DAO: missing daoArgs." );
					//#endif
					daoArgs = {};
				}
				if ( !_def( itemNumber ) ) {
					//#ifdef debug
					debug.error( "Item Frame Variations DAO: missing itemNumber." );
					//#endif
				}

//				daoArgs.scope = this;	// TODO
				daoArgs.prepData = _prepData;

				this.args[ _ARGS.ITEM_ID ] = itemNumber;
				// Set Session ID parameter from global value
				this.args[ _ARGS.SESSION_ID ] = _root.model.sessionId.get();

				// cache based on args other than user session id
				daoArgs.key = this.key(
					this.args
				);

				this._super( daoArgs, itemNumber );
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();
})( this, at.ns, at.root );
