/*
 * requires ns.ArtComAPIDao
 */

at.ns.artists = ( function ( global, ns, root ) {
	var
		_root = root
	,	_NAME = ns._name_ + ".artists"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.ITEM_SEARCH_PATH
	,	_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		,	CATEGORY_ID_LIST: "categoryIdList"
		,	PAGE_NUMBER: "pageNumber"
		,	NUMBER_OF_RECORDS: "numberOfRecords"
		}
	,	_dao
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}

	/**
	 * returns Object
	 */
	function _prepData( rawData ) {
		var
			retArtists = null
		;
		// Preliminary data validation already done by superclass ArtComAPIDao
			retArtists = root.data.artComAPIConvert.getArtistsModel( rawData.d.Refinements.Artists );

		return retArtists;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function () {
				this._super();
				this.url = _URL;
				this.setAPIKeyInHash( this.args );
				this.args[ _ARGS.NUMBER_OF_RECORDS ] = 1; // logically irrelevant to artists list
				this.args[ _ARGS.PAGE_NUMBER ] = 1; // logically irrelevant to artists list
			}
		,	get: function ( daoArgs ) {
				if ( !_def( daoArgs ) ) {
					//#ifdef debug
					debug.error( "Artists DAO: missing daoArgs." );
					//#endif
					daoArgs = {};
				}
//				daoArgs.scope = this;	// TODO
				daoArgs.prepData = _prepData;

				// Set Session ID parameter from global (API session) value
				this.args[ _ARGS.SESSION_ID ] = _root.model.sessionId.get();
				// Set Kiosk Category ID parameter from global value
				this.args[ _ARGS.CATEGORY_ID_LIST ] = _root.model.globalAppData.getKioskCategoryId();

				daoArgs.key = this.key( this.args );

				this._super( daoArgs );
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();
})( this, at.ns, at.root );
