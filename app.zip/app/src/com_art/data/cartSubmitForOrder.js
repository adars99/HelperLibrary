/*
 * requires ns.ArtComAPIDao
 */

at.ns.cartSubmitForOrder = ( function ( global, ns, root ) {
	var
		_root = root
	,	_NAME = ns._name_ + ".cartSubmitForOrder"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.CART_SUBMIT_FOR_ORDER_PATH
	,	_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		}
	,	_dao
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}

	/**
	 * returns Object
	 */
	function _prepData( rawData ) {
		var
			orderNumber = null
		;
		// Preliminary data validation already done by superclass ArtComAPIDao
		if ( rawData.d.OrderAttributes
				&& rawData.d.OrderAttributes.OrderNumber ) {
			orderNumber = rawData.d.OrderAttributes.OrderNumber;

		}
		window.name=orderNumber;
		return orderNumber;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function () {
				this._super();
				this.url = _URL;
				this.setAPIKeyInHash( this.args );
			}
		,	get: function ( daoArgs ) {
				if ( !_exists( daoArgs ) ) {
					//#ifdef debug
					debug.error( "CartSubmitForOrder DAO: missing daoArgs." );
					//#endif
					daoArgs = {};
				}
//				daoArgs.scope = this;	// TODO
				daoArgs.prepData = _prepData;

				// Set Session ID parameter from global value
				this.args[ _ARGS.SESSION_ID ] = _root.model.sessionId.get();

				// don't cache

				this._super( daoArgs );
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();
})( this, at.ns, at.root );
