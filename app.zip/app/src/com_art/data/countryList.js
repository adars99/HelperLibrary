/*
 * requires ns.ArtComAPIDao
 * a.k.a. states
 */

at.ns.countryList = ( function ( global, ns, root ) {
	var
		_root = root
	,	_NAME = ns._name_ + ".countryList"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.GET_COUNTRY_LIST_PATH
	,	_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		}
	,	_dao
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}

	/**
	 * returns Object
	 */
	function _prepData( rawData ) {
		var
			retVal = null
		;
		// Preliminary data validation already done by superclass ArtComAPIDao
		retVal = root.data.artComAPIConvert.getCountryListModel( rawData.d.Countries );

		return retVal;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function () {
				this._super();
				this.url = _URL;
				this.setAPIKeyInHash( this.args );
			}
		,	get: function ( daoArgs ) {
				if ( !_exists( daoArgs )
				) {
					//#ifdef debug
					debug.error( "countryList DAO: missing daoArgs." );
					//#endif
					daoArgs = {};
				}

//				daoArgs.scope = this;	// TODO
				daoArgs.prepData = _prepData;

				// Set Session ID parameter from global value
				this.args[ _ARGS.SESSION_ID ] = _root.model.sessionId.get();

				// cache based on args other than user session id
				daoArgs.key = this.key( this.args );

				this._super( daoArgs );
			}
		,	validateArgs: function ( _args ) {
				return true;
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();
})( this, at.ns, at.root );
