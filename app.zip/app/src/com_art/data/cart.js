/*
 * requires ns.ArtComAPIDao
 */

at.ns.cart = ( function ( global, ns, root ) {
	var
		_root = root
	,	_NAME = ns._name_ + ".cart"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.CART_GET_PATH
	,	_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		}
	,	_dao
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}

	/**
	 * returns Object
	 */
	function _prepData( rawData ) {
		var
			retCart = null
		;
		// Preliminary data validation already done by superclass ArtComAPIDao
			retCart = root.data.artComAPIConvert.getCartModel( rawData.d.Cart );

		return retCart;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function () {
				this._super();
				this.url = _URL;
				this.setAPIKeyInHash( this.args );
			}
		,	get: function ( daoArgs ) {
				if ( !_exists( daoArgs ) ) {
					//#ifdef debug
					debug.error( "Cart DAO: missing daoArgs." );
					//#endif
					daoArgs = {};
				}
//				daoArgs.scope = this;	// TODO
				daoArgs.prepData = _prepData;

				// Set Session ID parameter from global value
				this.args[ _ARGS.SESSION_ID ] = _root.model.sessionId.get();

				// don't cache

				this._super( daoArgs );
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();
})( this, at.ns, at.root );
