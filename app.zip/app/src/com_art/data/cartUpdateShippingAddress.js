/*
 * requires ns.ArtComAPIDao
 */

at.ns.cartUpdateShippingAddress = ( function ( global, ns, root ) {
	var
		_root = root
	,	_NAME = ns._name_ + ".cartUpdateShippingAddress"
	,	_URL = apiSettings.APIROOT + ns.ARTAPI.CART_UPDATE_SHIPPING_ADDRESS_PATH
	,	_ARGS = {
			API_KEY: "apiKey"
		,	SESSION_ID: "sessionId"
		,	FIRST_NAME: "firstName"
		,	LAST_NAME: "lastName"
		,	COMPANY_NAME: "companyName"
		,	ADDRESS_LINE_1: "addressLine1"
		,	ADDRESS_LINE_2: "addressLine2"
		,	CITY: "city"
		,	STATE: "state"
		,	ZIP_CODE: "zipCode"
		,	ISO_COUNTRY_CODE: "twoDigitIsoCountryCode"
		,	PRIMARY_PHONE: "primaryPhone"
		,	SECONDARY_PHONE: "secondaryPhone"
		,	EMAIL_ADDRESS: "emailAddress"
		}
	,	_dao
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}

	/**
	 * returns Object
	 */
	function _prepData( rawData ) {
		var
			retCart = null
		;
		// Preliminary data validation already done by superclass ArtComAPIDao
			retCart = root.data.artComAPIConvert.getCartModel( rawData.d.Cart );

		return retCart;
	}

	_dao = ( function(){
		return ns.ArtComAPIDao.extend( {
			init: function () {
				this._super();
				this.url = _URL;
				this.setAPIKeyInHash( this.args );
			}
		,	get: function ( daoArgs
				,	args
			) {
				if ( !_exists( daoArgs ) ) {
					//#ifdef debug
					debug.error( "CartUpdateShippingAddress DAO: missing daoArgs." );
					//#endif
					daoArgs = {};
				}
				if ( !this.validateArgs( args ) ) {
					//#ifdef debug
					debug.error( "CartUpdateShippingAddress DAO: invalid args.", args );
					//#endif
				}

//				daoArgs.scope = this;	// TODO
				daoArgs.prepData = _prepData;

				this.args = args;
				this.setAPIKeyInHash( this.args );
				// Set Session ID parameter from global value
				this.args[ _ARGS.SESSION_ID ] = _root.model.sessionId.get();

				// don't cache

				this._super( daoArgs, args );
			}
		,	validateArgs: function ( args ) {
				if ( !_exists( args ) ) {
					return false;
				}
				// Art.com API service has strange behavior when there is insufficient
				//	information to locate a county - it defaults to the first alphabetical county,
				//	but treats the parameters as valid. However, it does validate
				//	if there is sufficient information to locate a county.
				//	This validation halts the dao before having to deal with the odd edge case behavior.
				if ( !_exists( args[ _ARGS.CITY ] )
						|| !_exists( args[ _ARGS.ZIP_CODE ] ) ) {
					return false;
				}
				return true;
			}
		,	ARGS: _ARGS
		} );
	}() );

	_dao.URL = _URL;

	return new _dao();
})( this, at.ns, at.root );
