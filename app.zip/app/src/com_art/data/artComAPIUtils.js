at.ns.artComAPIUtils = {
		isValidResponse: function ( rawData ) {
			if ( rawData && rawData.d && rawData.d.OperationResponse
					&& rawData.d.OperationResponse.ResponseCode ) {
				return true;
			}
			return false;
		}
	,	isSuccessfulOperationResponse: function ( rawData ) {
			var responseCode = rawData.d.OperationResponse.ResponseCode;
			if ( responseCode == 200 ) {
				return true;
			}
			return false;
		}
	,	isSessionExpiredResponse: function ( rawData ) {
			if ( rawData && rawData.d && rawData.d.OperationResponse ) {
				var responseCode = rawData.d.OperationResponse.ResponseCode;
				var responseMessage = rawData.d.OperationResponse.ResponseMessage;
				if ( responseCode == 500
					&& responseMessage == "Invalid session identifier." ) {
					return true;
				}
			}
			return false;
		}
	,	isNoResultsFoundResponse: function ( rawData ) {
			if ( rawData && rawData.d && rawData.d.OperationResponse ) {
				var responseCode = rawData.d.OperationResponse.ResponseCode;
				var responseMessage = rawData.d.OperationResponse.ResponseMessage;
				if ( responseCode == 500
					&& responseMessage == "No results found." ) {
					return true;
				}
			}
			return false;
		}
	,	isInvalidAddressResponse: function ( rawData ) {
			var
				responseCode
			,	responseMessage
			,	matches
			;
			if ( rawData && rawData.d && rawData.d.OperationResponse ) {
				responseCode = rawData.d.OperationResponse.ResponseCode;
				responseMessage = rawData.d.OperationResponse.ResponseMessage;
				if ( responseCode == 500 ) {
					matches = responseMessage.match( /\bInvalid\b.*\baddress\b/gi );
					if ( matches != null ) {
						return true;
					}
				}
			}
			return false;
		}
	,	getResponseMessage: function ( rawData ) {
			var message = null;
			if ( rawData && rawData.d && rawData.d.OperationResponse ) {
				var responseMessage = rawData.d.OperationResponse.ResponseMessage;
				return responseMessage;
			}
			return message;
		}
	,	isCanvasSubstrate: function ( substrateType ) {
			var
				matches
			;
			if ( typeof substrateType !== "undefined" && substrateType != null ) {
				matches = substrateType.match( /canvas/i );
				if ( typeof matches != "undefined" && matches != null ) {
					return true;
				}
			}
			return false;
		}
	,	createHashMinus: function ( hash, keyToRemove ) {
			var
				_key = null
			, _retHash = {}
			;
			for ( _key in hash ) {
				if ( _key !== keyToRemove ) {
					_retHash[ _key ] = hash[ _key ];
				}
			}
			return _retHash;
		}
	,	getResizedGenericImageURL: function ( genericURL, width, height ) {
			// Example URL:
			//	"http://qa-imgsrc.art.com/images/giclee-print/grant-wood-dinner-with-threshers_i-G-51/5136/C5NEG00Z.jpg"
			var
				retURL
			,	queryStringIndex
			;
			queryStringIndex = genericURL.indexOf("?");
			if ( queryStringIndex === -1 ) {
				retURL = genericURL;
			} else {
				retURL = genericURL.substring( 0, queryStringIndex );
			}
			retURL = retURL + "?w=" + width + "&h=" + height;
			return retURL;
		}
	,	getResizedFramedImageURL: function ( baseURL, width, height ) {
			// Example URL:
			//	"http://qa-frameimage.art.com/frameimagehandler/universal/frameimage.jpg?"
			//	+ "frame=[FAP:0+PRT:[PAP=7391521|PRW=40|PRH=14|PIP=%5c51%5c5136%5cC5NEG00Z.jpg"
			//	+ "|LFN=FAMPOD\PD-SFM00362-GE.jpg|PWL=400|PHL=140|PWO=723|PHO=253]"
			//	+ "+MLD:[MID=5092332|MDW=2.25|MDH=1.25]+NMM:1+MT1:"
			//	+ "[MTD=4325054|MTP=|MTC=f7e8bf|MTL=2.25|MTT=2.25|MTR=2.25|MTB=2.25|MDP=0.2|MBV=0.08]"
			//	+ "+CRP:[CID=1|CRX=24|CRY=24|CRW=353|CRH=84]+MXD:1000+MXW:900+MXH:740+QLT:90"
			//	+ "+OVH:[TOH=0.125|ROH=0.125|BOH=0.125|LOH=0.125]]"
			var
				retURL
			;
			retURL = baseURL.replace( /\+MXW\:\d+\+/g, "+MXW:" + width + "+" );
			retURL = retURL.replace( /\+MXH\:\d+\+/g, "+MXH:" + height  + "+" );
			// #ifdef debug
			debug.log( "resizedFramedImageURL: width, height, url", width, height, retURL );
			// #endif
			return retURL;
		}
	,	isResizeableFramedImageURLType: function ( baseURL ) {
			// Example URL:
			//	"http://qa-frameimage.art.com/frameimagehandler/universal/frameimage.jpg?"
			//	+ "frame=[FAP:0+PRT:[PAP=7391521|PRW=40|PRH=14|PIP=%5c51%5c5136%5cC5NEG00Z.jpg"
			//	+ "|LFN=FAMPOD\PD-SFM00362-GE.jpg|PWL=400|PHL=140|PWO=723|PHO=253]"
			//	+ "+MLD:[MID=5092332|MDW=2.25|MDH=1.25]+NMM:1+MT1:"
			//	+ "[MTD=4325054|MTP=|MTC=f7e8bf|MTL=2.25|MTT=2.25|MTR=2.25|MTB=2.25|MDP=0.2|MBV=0.08]"
			//	+ "+CRP:[CID=1|CRX=24|CRY=24|CRW=353|CRH=84]+MXD:1000+MXW:900+MXH:740+QLT:90"
			//	+ "+OVH:[TOH=0.125|ROH=0.125|BOH=0.125|LOH=0.125]]"
			var
				matches
			,	doesMatchFrameQueryParam = false
			,	doesMatchWidthParam = false
			,	doesMatchHeightParam = false
			;
			matches = baseURL.match( /\?frame=\[/ig );
			if ( matches ) {
				doesMatchFrameQueryParam = true;
			}
			matches = baseURL.match( /\+MXW\:\d+\+/ig );
			if ( matches ) {
				doesMatchWidthParam = true;
			}
			matches = baseURL.match( /\+MXH\:\d+\+/ig );
			if ( matches ) {
				doesMatchHeightParam = true;
			}
			// #ifdef debug
			debug.log( "isResizeableFramedImageURLType: baseURL, doesMatchFrameQueryParam, doesMatchWidthParam, doesMatchHeightParam"
					, baseURL, doesMatchFrameQueryParam, doesMatchWidthParam, doesMatchHeightParam );
			// #endif
			return doesMatchFrameQueryParam && doesMatchWidthParam && doesMatchHeightParam;
		}
};
