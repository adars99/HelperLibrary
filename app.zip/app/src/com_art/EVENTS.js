at.ns.EVENTS = ( function ( global, ns, root ) {
	return {
		FORM: {
			VALUE_CHANGE: "Form:Input:Value:Change"
		,	FOCUS_CHANGE: "Form:Input:Focus:Change"
		,	INPUT_SELECT: "Form:Input:Selection"
		,	LIST_SHOW: "Form:Input:List:Show"
		,	LIST_NAV: "Form:Input:List:Navigate"
		,	LIST_SELECT: "Form:Input:List:Selection"
		,	ISVALID: "Form:IsValid"
		,	SUBMIT: "Form:Submit"
		,	CONTINUE: "Form:Continue"
		}
	,	ITEM: {
			ZOOM: "ItemDetail:Zoom:View"
		,	ZOOMOUT: "ItemDetail:ZoomOut:View"
		,	SET_FRAME_ITEM: "ItemDetail:Image:Set"
		}
	,	CART: {
			ITEM_ADD: "Cart:Item:Add:Change"
		,	CART_ITEM_QUANTITY_UPDATE: "Cart:CartItem:Quantity:Change"
		,	CART_DELETE_ITEM: "Cart:Item:Delete"
		,	SHOW: "Cart:Show:Change"
		,	SHOW_SHIPPING: "Cart:Show:ShippingInfo"
		,	SHOW_BILLING: "Cart:Show:BillingInfo"
		,	SHOW_CONFIRM: "Cart:Show:Confirmation"
		,	SHOW_COMPLETE: "Cart:Show:Completion"
		,	SHIPPING_INFO_UPDATE: "Cart:ShippingAddress:Change"
		,	BILLING_INFO_UPDATE: "Cart:BillingAddress:Change"
		}
	,	PRINTRECEIPT : "Receipt:Print"
	, 	RECEIPTLOADED: "Receipt:Loaded"
	,	PRINT_NUM_COPIES: "Num_Receipt_Copies"
	,	 GLOBAL_DATA: {
			ARTISTS_CHANGE: "GlobalData:Artists:Change"
		}
	,	FOOTER: {
			SET_INACTIVE: "Footer:Btn:SetInactive" 
		,	DISABLE_CART: "Footer:Disable:Cart"
		}
	};

} ( this, at.ns, at.root ) );