at.ns.CONST = ( function ( global, ns, root ) {
	return {
		FOOTER: "Footer"
	,	BREADCRUMBS: "Breadcrumbs"
	,	ADA: "BottomNav"
	,	PANEL: {
			ARTIST: "Artist"
		,	COLLECTION: "Collection"
		,	HELP: "Help"
		,	PRIVACYPOLICY: "PrivacyPolicy"
		}
	,	PAGE: { 
			COLLECTION: "Collection"
		,	GALLERY: "Gallery"
		,	ITEM: "Item"
		,	CART: "Cart"
		,	ORDERCOMPLETE: "OrderComplete"
		,	SHIPPINGINFO: "ShippingInfo"
		,	BILLINGINFO: "BillingInfo"
		,	CONFIRMORDER: "ConfirmOrder"
		,	NOSET: "NoSet"
		}
	,	OFF: "off"
	,	PRINT_RECEIPTS: "receipts"	
	,	ERROR: {
			DATA: "Invalid response from data server."
		,	DATA_RETRIEVAL: "Unable to retrieve data from the server."
		,	KIOSK_UNAVAILABLE: "Kiosk unavailable. Please contact a museum employee."
		,	NO_ITEMS: "No items found."
		,	NO_VARIATATIONS: "No item variations found."
		,	CITYSTATE: "Please enter valid shipping information. Country, City, State, and Postal Code"
		,	EMAIL: "Your email address is not valid. "
		,	CCNUM: "Please enter a valid card number."
		,	CCCVV: "Please enter a valid CVV number."
		,	CCEXPDATE: "Please enter a valid expiration date."
		,	PHONE: "Please enter a valid phone number. "
		,	ARTISTLIST: "Cannot retrieve artist list. Please refresh or contact a museum employee."
		,	TIMEOUT: "Your session has timed out. Starting over..."
		,	INVALID_SESSION: "Invalid session identifier."
		}
	};

} ( this, at.ns, at.root ) );