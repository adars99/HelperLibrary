at.ns.currentItemFramedVariations = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "currentItemFramedVariations"
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	;

	_model.setFramedItems = function ( framedItemsArray ) {
		var
			framedItems = []
		,	itemNumberFramedItemMap = {}
		,	i
		,	framedItem
		,	framedItemNumber
		,	existingFramedItem
		;
		if ( framedItemsArray ) {
			for ( i=0; i<framedItemsArray.length; i++ ) {
				framedItem = framedItemsArray[i];
				framedItemNumber = framedItem.itemNumber;
				existingFramedItem = itemNumberFramedItemMap[ framedItemNumber ];
				if ( existingFramedItem ) {
					//#ifdef debug
					debug.log( "currentItemFramedVariations: duplicate framedItem.", framedItem );
					//#endif
				} else {
					itemNumberFramedItemMap[ framedItemNumber ] = framedItem;
					framedItems.push( framedItem );
				}
			}
		}
		this.set( {
			"framedItems": framedItems
		,	"itemNumberFramedItemMap": itemNumberFramedItemMap
		} );
	}

	_model.getFramedItems = function () {
		if ( this._value ) {
			return this._value.framedItems;
		}
		return null;
	}
	_model.getItemNumberFramedItemMap = function () {
		if ( this._value ) {
			return this._value.itemNumberFramedItemMap;
		}
		return null;
	}

	return _model;

}( this, at.ns, at.root ) );