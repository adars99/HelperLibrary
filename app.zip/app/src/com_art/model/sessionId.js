at.ns.sessionId = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "sessionId"
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	;

	return _model;

}( this, at.ns, at.root ) );