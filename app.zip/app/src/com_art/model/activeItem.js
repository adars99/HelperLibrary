/*
 * Actually active item, may not match the item number used to get into the Item view.
 */
at.ns.activeItem = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "activeItem"
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	;

	return _model;

}( this, at.ns, at.root ) );