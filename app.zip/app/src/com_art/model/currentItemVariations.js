at.ns.currentItemVariations = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "currentItemVariations"
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	;

	_model.setItems = function ( itemsArray ) {
		var
			nonCanvasItems = []
		,	canvasItems = []
		,	itemNumberItemMap = {}
		,	i
		,	item
		,	itemNumber
		,	existingItem
		;
		if ( itemsArray ) {
			for ( i=0; i<itemsArray.length; i++ ) {
				item = itemsArray[i];
				itemNumber = item.itemNumber;
				existingItem = itemNumberItemMap[ itemNumber ];
				if ( existingItem ) {
					//#ifdef debug
					debug.log( "currentItemVariations: duplicate item.", item );
					//#endif
				} else {
					itemNumberItemMap[ itemNumber ] = item;
					if ( item.isCanvas ) {
						canvasItems.push( item );
					} else {
						nonCanvasItems.push( item );
					}
				}
			}
		}
		this.set( {
			"nonCanvasItems": nonCanvasItems
		,	"canvasItems": canvasItems
		,	"itemNumberItemMap": itemNumberItemMap
		} );
	}

	_model.getNonCanvasItems = function () {
		if ( this._value ) {
			return this._value.nonCanvasItems;
		}
		return null;
	}
	_model.getCanvasItems = function () {
		if ( this._value ) {
			return this._value.canvasItems;
		}
		return null;
	}
	_model.getItemNumberItemMap = function () {
		if ( this._value ) {
			return this._value.itemNumberItemMap;
		}
		return null;
	}

	return _model;

}( this, at.ns, at.root ) );