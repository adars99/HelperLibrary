at.ns.globalAppData = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "globalAppData"
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}

	_model.setInHash = function ( key, value ) {
		var obj = this.get();
		if ( !_def( obj ) ) {
			obj = {};
		}
		obj[ key ] = value;
		this.set( obj );
	};

	_model.getAppName = function () {
		if ( this._value ) {
			return this._value.appName;
		}
	};

	_model.getISOCurrencyCode = function () {
		if ( this._value ) {
			return this._value.isoCurrencyCode;
		}
	};

	_model.getKioskCategoryBlockName = function () {
		if ( this._value ) {
			return this._value.kioskCategoryBlockName;
		}
	};

	_model.getKioskCategoryId = function () {
		if ( this._value ) {
			return this._value.kioskCategoryId;
		}
	};

	_model.getLandingContentBlockName = function () {
		if ( this._value ) {
			return this._value.landingContentBlockName;
		}
	};

	return _model;

}( this, at.ns, at.root ) );