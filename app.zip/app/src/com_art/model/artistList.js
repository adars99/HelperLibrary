at.ns.artistList = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "artistList"
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	,	_STATE = {
			LOADING: "loading"
		,	SUCCESS: "success"
		,	ERROR: "error"
		,	UNMET_DEPENDENCIES: "unmetDependencies"
		}
	,	_events = root.EVENTS
	;

	_model.STATE = _STATE;

	_model.setInfo = function ( state, artists ) {
		this.set( {
			"state": state
		,	"artists": artists
		} );
	};

	_model.getState = function () {
		if ( this._value ) {
			return this._value.state;
		}
	};
	_model.getArtists = function () {
		if ( this._value ) {
			return this._value.artists;
		}
	};

	// Data binding and triggers
	$( document.body ).bind(
		_events.GLOBAL_DATA.ARTISTS_CHANGE
	,	function ( event, params ) {
			placeArtistsCall();
		}
	);

	function placeArtistsCall() {
		var
			_dao = root.data.artists
		;
		_model.setInfo(
				_model.STATE.LOADING
			,	null
		);

		_dao.get(
			{
				success: function ( artists ) {
					_model.setInfo(
						_model.STATE.SUCCESS
					,	artists
					);
					if ( !_def( artists )
							|| artists.length == 0 ) {
						// #ifdef debug
						debug.log("Artists call warning: successful response, but no artists." );
						// #endif
					}
				}
			,	fail: function ( rawData ) {
					if ( root.data.artComAPIUtils.isValidResponse( rawData ) ) {
							// #ifdef debug
							debug.error( "Artists call: " + root.data.artComAPIUtils.getResponseMessage( rawData ) );
							// #endif
					} else {
						// #ifdef debug
						debug.error( "Artists call: Invalid response from Art.com server." );
						// #endif
					}
					_model.setInfo(
						_model.STATE.ERROR
					,	null
					);
				}
			}
		);
	}

	function _def( v ){
		return typeof( v ) !== "undefined";
	}

	return _model;

}( this, at.ns, at.root ) );