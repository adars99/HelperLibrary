at.ns.collectionList = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "collectionList"
	, 	_MAXCNT = 4
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	;

	_model.setHash = function ( id, items ) {
		this.set( {
			"id" : id
		,	"items" : items
		} );
	};
	_model.setBlank = function () {
		this.set( {
			"id" : ""
		,	"items" : []
		} );
	};

	_model.getId = function () {
		if ( this._value ) {
			return this._value.id;
		}
	};

	_model.getAllItems = function( filterOutUnactionableItems ) {
		if ( this._value ) {
			if ( filterOutUnactionableItems ) {
				return this.filterOutUnactionableItems( this._value.items );
			} else {
			return this._value.items;
			}
		}
	};

	_model.getCurrentItems = function( pgIndex, filterOutUnactionableItems ){
		var
			_items = ( this._value && this._value.items ) ? this._value.items : []
		,	_index = pgIndex - 1
		,	_start = (_index == 0) ? _index : _index*_MAXCNT
		,	_end = (_index == 0) ? _MAXCNT : _MAXCNT*pgIndex
		,	_currItemList
		;

		_currItemList = _items.slice( _start, _end );
		if ( filterOutUnactionableItems ) {
			_currItemList = this.filterOutUnactionableItems( _currItemList );
		}
		return _currItemList;
	};

	_model.filterOutUnactionableItems = function ( items ) {
		var
			filteredItems = []
		,	_item
		,	i
		;
		if ( items ) {
			for ( i=0; i<items.length; i++ ) {
				_item = items[i];
				if ( _item.linkType
						&& _item.linkParameter && _item.linkParameter.trim() !== ""
				) {
							filteredItems.push( _item );
				} else {
					// #ifdef debug
					debug.warn( "model.collectionList:filterOutUnactionableItems: Unactionable item!", _item );
					// #endif
				}
			}
		}

		return filteredItems;
	};

	_model.getPageCount = function(){
		var
			_items = this._value ? this._value.items : []
		,	_pageCnt = Math.ceil(_items.length/_MAXCNT)
		;
		return _pageCnt;
	}

	return _model;

}( this, at.ns, at.root ) );