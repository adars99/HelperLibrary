/**
 * Current item number used to enter item view.
 * Not a Framed Item Number.
 * May not match that of the "activeItem".
 */
at.ns.currentItemNumber = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "currentItemNumber"
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	;

	return _model;

}( this, at.ns, at.root ) );