at.ns.collectionStore = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "collectionStore"
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	;

	function _def( val ) {
		return ( typeof ( val ) !== "undefined" );
	}
	function _exists( val ) {
		return ( _def( val ) && val != null );
	}

	function matchesParameter( obj, key, value ) {
		if ( obj.hasOwnProperty( key ) && obj[ key ] === value ) {
			return true;
		}
		return false;
	};

	function findInListRecursive( list
		,	isTarget	// function to check if object is final target object
		,	getRecursionData	// function to get the data for the next recursion
		,	depth ) {
		var
			i = 0
		,	_obj
		,	_maxDepth = 100
		,	_depth = depth ? depth : 0
		;
		if ( _exists( list ) ) {
			for ( i=0; i<list.length; i++ ) {
				_obj = list[i];
				if ( isTarget( _obj ) ) {
					return _obj;
				} else if ( _depth < _maxDepth ) {
					_obj = findInListRecursive( getRecursionData( _obj )
							,	isTarget
							,	getRecursionData
							,	_depth + 1 );
					if ( _exists( _obj ) ) {
						return _obj;
					}
				} else {
					debug.warn( "collectionStore:find: reached recursion max depth " + _maxDepth );
				}
			}
		}
		return null;
	};

	_model.getDrillDownList = function (
			drillDown
		,	list
		,	isTarget	// function to check if object is final target object
		,	getDisplayValue	// function to get the value representing an object in the drill-down
		,	getRecursionData	// function to get the data for the next recursion
		,	depth ) {
		var
			_drillDown = drillDown ? drillDown : []
		,	_obj
		,	_maxDepth = 100
		,	_depth = depth ? depth : 0
		,	i
		;
		if ( _exists( list ) ) {
			for ( i=0; i<list.length; i++ ) {
				_obj = list[i];
				if ( isTarget( _obj ) ) {
					_drillDown.push( getDisplayValue( _obj ) );
					return _drillDown;
				} else if ( _depth < _maxDepth ) {
					_drillDown = this.getDrillDownList( _drillDown
							,	getRecursionData( _obj )
							,	isTarget, getDisplayValue, getRecursionData
							,	_depth + 1 );
					if ( _exists( _drillDown )
							&& _drillDown.length > 0 ) {
						_drillDown.push( getDisplayValue( _obj ) );
						return _drillDown;
					}
				} else {
					debug.warn( "collectionStore:getDrillDownList: reached recursion max depth " + _maxDepth );
				}
			}
		}
		return _drillDown;
	};

	_model.drillDownTitlesForCollection = function ( linkParameterValue ) {
		var
			_titles = []
		,	_val = this._value ? this._value : []
		;
		_titles = this.getDrillDownList( _titles
		,	_val
		,	// isTarget
			function ( obj ) {
				if ( matchesParameter( obj, "linkParameter", linkParameterValue )
						&& matchesParameter( obj, "linkType", root.data.ARTAPI.LINK_TYPES.CONTENT_BLOCK )
				) {
					return true;
				}
				return false;
			}
		,	// getDisplayValue
			function ( obj ) {	return obj[ "title" ];	}
		,	// getRecursionData
			function ( obj ) {	return obj[ "collectionList" ];	}
		,	0
		);
		return _titles;
	};
	_model.drillDownTitlesForCategory = function ( linkParameterValue ) {
		var
			_titles = []
		,	_val = this._value ? this._value : []
		;
		_titles = this.getDrillDownList( _titles
		,	_val
		,	// isTarget
			function ( obj ) {
				if ( matchesParameter( obj, "linkParameter", linkParameterValue )
						&& matchesParameter( obj, "linkType", root.data.ARTAPI.LINK_TYPES.CATEGORY )
				) {
					return true;
				}
				return false;
			}
		,	// getDisplayValue
			function ( obj ) {	return obj[ "title" ];	}
		,	// getRecursionData
			function ( obj ) {	return obj[ "collectionList" ];	}
		,	0
		);
		return _titles;
	};

	_model.add = function ( id, linkType, collectionList ) {
		var
			_val = this._value ? this._value : []
		,	_obj
		;
		_obj = findInListRecursive( _val
		,	// isTarget
			function ( obj ) {
				if ( matchesParameter( obj, "linkParameter", id )
						&& matchesParameter( obj, "linkType", linkType )
				) {
					return true;
				}
				return false;
			}
		,	// getRecursionData
			function ( obj ) {	return obj[ "collectionList" ];	}
		);
		if ( _exists( _obj ) ) {
			if ( !_exists( _obj[ "collectionList" ] ) ) {	// for when daos don't cache or using deep copies, not the original objects
				_obj[ "collectionList" ] = collectionList;
			}
		} else {
			_obj = {
				"linkParameter" : id
			,	"linkType" : root.data.ARTAPI.LINK_TYPES.CONTENT_BLOCK
			,	"collectionList" : collectionList
			};
			_val.push( _obj );
		}
		this.set( _val );
	};

	return _model;

}( this, at.ns, at.root ) );