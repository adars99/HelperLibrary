at.ns.galleryList = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "galleryList"
	, 	_MAXCNT = 4
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}
	function _exists( v ) {
		return _def( v ) && v !== null;
	}

	/*
	 * Model change methods
	 */
	_model.clear = function () {
		var
			_newVal = this.createBlankObject();
		;
		// #ifdef debug
		debug.log( "galleryList:clear()" );
		// #endif
		this.set( _newVal );
	};
	/**
	 * Keep the same data structure, but reset the model
	 * (to trigger a change for any listeners).
	 */
	_model.indicateChange = function () {
		var
			_newVal
		;
		if ( this._value ) {
			_newVal = {
				"total": this._value.total
			,	"loadedItemsStartOffset": this._value.loadedItemsStartOffset
			,	"items": this._value.items
			,	"type" : this._value.type
			,	"id" : this._value.id
			};
		} else {
			_newVal = this.createBlankObject();
		}
		this.set( _newVal );
	};
	_model.createBlankObject = function () {
		return {
					"total": 0
				,	"loadedItemsStartOffset": 0
				,	"items": []
				,	"type" : root.model.currentGallery.TYPE.NONE
				,	"id" : null
				}
		;
	};

	/**
	 * Add to existing model, if any. Create new model object if none existing.
	 */
	_model.addData = function (
			total
		,	loadedItemsStartOffset
		,	items, startIndex
		,	type, id
	) {
		var _newVal
		,	_loadedItems
		,	_spliceArgs
		;

		if ( startIndex > ( loadedItemsStartOffset + this.getLoadedItemsCount() ) ) {
			//#ifdef debug
			debug.error( "galleryList: addData: adding items at startIndex greater than loadedItemsCount+loadedItemsStartOffset; (startIndex, new items,new loadedItemsStartOffset,curr gallery data). Returning..."
					, startIndex, items, loadedItemsStartOffset, this.get() );
			//#endif
			return;
		}
		if ( startIndex < loadedItemsStartOffset ) {
			//#ifdef debug
			debug.error( "galleryList: addData: adding items at startIndex less than loadedItemsStartOffset; (startIndex, new items,new loadedItemsStartOffset,curr gallery data). Returning..."
					, startIndex, items, loadedItemsStartOffset, this.get() );
			//#endif
			return;
		}
		if ( startIndex + items.length > total ) {
			//#ifdef debug
			debug.error( "galleryList: addData: adding items would exceed total; (startIndex,new items,new loadedItemsStartOffset,total,curr gallery data), Returning..."
				,	startIndex
				,	items
				,	loadedItemsStartOffset
				,	total
				,	this.get() );
			//#endif
			returning;
		}

		// add new items to any existing items list
		_loadedItems = [];
		if ( this._value ) {
			_loadedItems = this._value[ "items" ];
		}
		_spliceArgs = items.slice();
		// [ startIndex - loadedItemsStartOffset, items.length, items[0], items[1], ... ]
		_spliceArgs.splice( 0, 0, startIndex - loadedItemsStartOffset, items.length );
		Array.prototype.splice.apply( _loadedItems, _spliceArgs );

		// Create new value so that listeners are notified of all new data
		_newVal = this._value ? this._value : {};
		_newVal[ "total" ] = total;
		_newVal[ "loadedItemsStartOffset" ] = loadedItemsStartOffset;
		_newVal[ "items" ] = _loadedItems;
		_newVal[ "type" ] = type;
		_newVal[ "id" ] = id;

		this.set( _newVal );
	};

	/*
	 * Model retrieval methods
	 */
	/**
	 * Total possible items. Contrast with getLoadedItemsCount().
	 */
	_model.getTotal = function () {
		if ( this._value ) {
			return this._value.total;
		}
	};
	_model.getType = function () {
		if ( this._value ) {
			return this._value.type;
		}
	};
	_model.getId = function () {
		if ( this._value ) {
			return this._value.id;
		}
	};

	_model.getLoadedRange = function ( pageNumber ) {
		var
			_loadedItems = ( this._value ) ? this._value.items : []
		,	_loadedItemsStartOffset = ( this._value ) ? this._value.loadedItemsStartOffset : 0
		,	_total = ( this._value ) ? this._value.total : 0
		,	_start = root.paginationUtil.itemsStartIndexByPageNumber( pageNumber, _MAXCNT )
		,	_end = root.paginationUtil.itemsEndByPageNumber( pageNumber, _MAXCNT )
		,	_loadedStart = _start - _loadedItemsStartOffset
		,	_loadedEnd = _end - _loadedItemsStartOffset
		;
		// total doesn't reach pagination end
		if ( _end > _total ) {
			_end = _total;
			_loadedEnd = _end - _loadedItemsStartOffset;
		}

		if ( _loadedStart >= 0
				&& _loadedEnd <= _loadedItems.length ) {
			return {
				start: _loadedStart
			,	end: _loadedEnd
			};
		}

		// #ifdef debug
		debug.log( "galleryList:getLoadedRange: loaded items not sufficient for page (pageNumber,_loadedStart,_loadedEnd,gallery data)"
				, pageNumber, _loadedStart, _loadedEnd, this.get() );
		// #endif
		return null;
	};
	_model.isLoaded = function ( pageNumber, type, id ) {
		var
			_loadedRange = this.getLoadedRange( pageNumber )
		;
		if ( _loadedRange
				&& this.getType() == type
				&& this.getId() == id
			) {
			return true;
		}

		return false;
	};

	_model.getCurrentItems = function ( pageNumber ) {
		var
			_loadedItems = (this._value) ? this._value.items : []
		,	_loadedRange = this.getLoadedRange( pageNumber )
		,	_loadedStart
		,	_loadedEnd
		,	_itemList = null
		;

		if ( _loadedRange ) {
			_loadedStart = _loadedRange.start;
			_loadedEnd = _loadedRange.end;
			_itemList = _loadedItems.slice( _loadedStart, _loadedEnd );
		} else {
			// #ifdef debug
			debug.error( "galleryList:getCurrentItems: loaded items not sufficient for page (pageNumber,gallery data)"
					, pageNumber, this.get() );
			// #endif
		}
		return _itemList;
	};

	_model.getLoadedItemsCount = function () {
		var
			_allItems = (this._value) ? this._value.items : []
		;
		return _allItems.length;
	};

	_model.getPageCount = function(){
		var
			_total = (this._value) ? this._value.total : 0
		,	_pageCnt = Math.ceil(_total/_MAXCNT)
		;
		return _pageCnt;
	};

	/*
	 * Data retrieval methods
	 */
	_model.loadToCover = function (
			galleryType
		,	id
		,	pageNumber
		,	callbackScope
		,	successCallback
		,	failCallback
		,	errorCallback
	) {
		var
			_daoCallFunction = null
		,	_initialDaoPageNumber = 1
		,	_finalDaoPageNumberByRequestedRange = 1
		,	_finalDaoPageNumberByTotal = 0
		,	_range = root.paginationUtil.itemsRangeByPageNumber( pageNumber, _MAXCNT )
		,	_startIndex, _endIndex
		,	_loadedItemsStartOffset = 0
		,	_recursiveSuccessCallback
		,	_recursiveFailCallback
		,	_errorMessage
		,	_callbackScope = callbackScope ? callbackScope : global
		,	_that = this;
		;
		_startIndex = _range.start;
		_endIndex = _range.end;
		_initialDaoPageNumber = root.paginationUtil
			.pageNumberByItemIndex( _startIndex, root.data.ARTAPI.PAGINATION_PER_PAGE_MAX );
		_finalDaoPageNumberByRequestedRange = root.paginationUtil
			.pageNumberByItemIndex( _endIndex, root.data.ARTAPI.PAGINATION_PER_PAGE_MAX );
		_loadedItemsStartOffset = root.paginationUtil
			.itemsStartIndexByPageNumber( _initialDaoPageNumber, root.data.ARTAPI.PAGINATION_PER_PAGE_MAX );
		// #ifdef debug
		debug.debug( "galleryList:load initialization: "
			+ "(_startIndex,_endIndex,_loadedItemsStartOffset,_initialDaoPageNumber"
			+ "\n,_finalDaoPageNumberByRequestedRange,_finalDaoPageNumberByTotal,gallery data)"
		,	_startIndex, _endIndex, _loadedItemsStartOffset
		,	_initialDaoPageNumber, _finalDaoPageNumberByRequestedRange, _finalDaoPageNumberByTotal
		,	_that.get() );
		// #endif

		switch ( galleryType ) {
			case root.model.currentGallery.TYPE.CATEGORY:
				_daoCallFunction = _that.placeCategoryCall;
				break;
			case root.model.currentGallery.TYPE.ARTIST_CATEGORY:
				_daoCallFunction = _that.placeArtistCategoryCall;
				break;
		}

		// callbacks
		_recursiveFailCallback = function ( rawData, daoPageNumber ) {
			failCallback.call( _callbackScope, rawData );
		};
		_recursiveSuccessCallback = function ( category, daoPageNumber ){
			var
				_daoPageNumber = daoPageNumber ? daoPageNumber : 1
			,	_isDone
			,	_isMismatchedCount
			;
			_that.addData(
					category.totalRecordCount
				,	_loadedItemsStartOffset
				,	category.items
				,	category.itemsStartIndex
				,	galleryType
				,	id
			);
			_finalDaoPageNumberByTotal = root.paginationUtil
				.pageNumberByItemIndex( category.totalRecordCount, root.data.ARTAPI.PAGINATION_PER_PAGE_MAX );
			_isDone = daoPageNumber >= _finalDaoPageNumberByRequestedRange
				|| daoPageNumber >= _finalDaoPageNumberByTotal;
			_isMismatchedCount = ( category.items.length == 0 )
				|| ( category.items.length < root.data.ARTAPI.PAGINATION_PER_PAGE_MAX
						&& _that.getTotal() > (_that.getLoadedItemsCount()+_loadedItemsStartOffset)
					)
				|| ( _that.getLoadedItemsCount()+_loadedItemsStartOffset > _that.getTotal() )
				;
			if ( _isDone ) {
				_that.indicateChange();
				successCallback.call( _callbackScope, _that.get()  );
			} else if ( _isMismatchedCount ) {
				_errorMessage = "Unexpected number of items from server.";
				// If no items even if they are expected or fewer than expected
				// #ifdef debug
				debug.error( "galleryList:load recursion: " + _errorMessage
					+ "(_startIndex,_endIndex,daoPageNumber,_loadedItemsStartOffset,_initialDaoPageNumber,_finalDaoPageNumberByRequestedRange,_finalDaoPageNumberByTotal,gallery data)"
				,	_startIndex, _endIndex, _loadedItemsStartOffset
				,	daoPageNumber, _initialDaoPageNumber, _finalDaoPageNumberByRequestedRange, _finalDaoPageNumberByTotal
				,	_that.get() );
				// #endif
				errorCallback.call( _callbackScope, _errorMessage );
			} else {
				// recursion
				_daoCallFunction.call(
						this, id
					,	_daoPageNumber+1	// recursion variable
					,	_recursiveSuccessCallback	// why does this work? pointers?
					,	_recursiveFailCallback
				);
			}
		};

		// execute
		_that.clear();
		_daoCallFunction.call(
				this
			,	id
			,	_initialDaoPageNumber
			,	// recursive successCallback
				_recursiveSuccessCallback
			,	// recursive errorCallback
				_recursiveFailCallback
		);
	};

	_model.placeCategoryCall = function (
			id
		,	daoPageNumber
		,	successCallback
		,	failCallback
	) {
		if ( !_exists( id ) ) {
			// #ifdef debug
			debug.error( "galleryList: placeCategoryCall: invalid id." );
			// #endif
			return;
		}
		var
			_dao = root.data.categoryPage
		,	_daoPageNumber = daoPageNumber ? daoPageNumber : 1
		,	_args = {}
		;
		_args[ _dao.ARGS.CATEGORY_ID_LIST ] = id;
		_args[ _dao.ARGS.PAGE_NUMBER ] = _daoPageNumber;
		_dao.get(
			{
				success: function ( category ) {
					successCallback( category, _daoPageNumber );
				}
			,	fail: function ( rawData ) {
					failCallback( rawData, _daoPageNumber );
				}
			}
		,	_args
		);
	};
	_model.placeArtistCategoryCall = function (
			artistCategoryId
		,	daoPageNumber
		,	successCallback
		,	failCallback
	) {
		if ( !_exists( artistCategoryId ) ) {
			// #ifdef debug
			debug.error( "galleryList: placeCategoryCall: invalid artistCategoryId." );
			// #endif
			return;
		}
		var
			_dao = root.data.artistCategoryPage
		,	_daoPageNumber = daoPageNumber ? daoPageNumber : 1
		,	_args = {}
		,	_that = this
		;
		_args[ _dao.ARGS.ARTIST_CATEGORY_ID ] = artistCategoryId;
		_args[ _dao.ARGS.PAGE_NUMBER ] = _daoPageNumber;
		_dao.get(
			{
				success: function ( artistCategory ) {
					successCallback( artistCategory, _daoPageNumber );
				}
			,	fail: function ( rawData ) {
					failCallback( rawData, _daoPageNumber );
				}
			}
		,	_args
		);
	};

	return _model;

}( this, at.ns, at.root ) );