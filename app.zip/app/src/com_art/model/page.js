at.ns.page = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "page"
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	;

	return _model;

}( this, at.ns, at.root ) );