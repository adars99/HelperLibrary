at.ns.currentGallery = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "currentGallery"
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	,	_TYPE = {
			CATEGORY : "category"
		,	ARTIST_CATEGORY : "artistCategory"
		,	NONE : "none"
		}
	;

	_model.TYPE = _TYPE;

	_model.setHash = function ( id, title, type, pageNumber ) {
		this.set(
			{
				"id" : id
			,	"title" : title
			,	"type" : type
			,	"pageNumber" : pageNumber
			}
		);
	};

	return _model;

}( this, at.ns, at.root ) );