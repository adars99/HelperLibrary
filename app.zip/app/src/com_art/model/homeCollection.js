at.ns.homeCollection = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "homeCollection"
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	;

	return _model;

}( this, at.ns, at.root ) );