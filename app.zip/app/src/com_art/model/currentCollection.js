at.ns.currentCollection = ( function ( global, ns, root ){
	var
		_NAME = ns._name_ + "." + "currentCollection"
	, 	_model = new viewSystem.Model( {
			namespace: _NAME
		} )
	;

	_model.setHash = function ( id, title, pageNumber ) {
		this.set(
			{
				"id" : id
			,	"title" : title
			,	"pageNumber" : pageNumber
			}
		);
	};

	return _model;

}( this, at.ns, at.root ) );