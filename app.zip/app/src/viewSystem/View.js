/**
 * @fileoverview
 * viewSystem views Abstract view implements core viewSystem view methods.
 *
 * @author Ernesto Johnson ernesto@dhapdigital.com
 *
 * @requires jquery 1.6.2 http://jquery.com/
 * @requires Class http://ejohn.org/blog/simple-javascript-inheritance/
 *
 */

//Ensure namespace exists
var viewSystem = viewSystem || {};

/**
 * @class Abstract view (comprised of a View Controller, View Model, and View Template/CSS ) implements core viewSystem view methods.
 *
 * @requires jQuery 1.6.2
 */

viewSystem.View = ( function ( global ) {
	var
		_View
	,	_Controller
	,	_Model
	,	_instances = 0

	,	_STATES = {
			DEFAULT: "DEFAULT"
		,	LOADING: "LOADING"
		,	FAIL:    "FAIL"
		,	SUCCESS: "SUCCESS"

		}
	,	_VIEW_CLASS = "view"
	,	_NODE_TYPE_DEFAULT = "div"

	,	_extends
	;

	function _def( i ){
		return ( typeof( i ) !== "undefined" );
	}
	function _isHash( obj ) {
		if ( typeof(obj) === "object"
				&& obj !== null
				&& !_def( obj.length )
		) {
			return true;
		}
		return false;
	}

	function _getChildViewId( modelKey, value ){
		return [ "view", "_", modelKey, "_", value ].join("");
	}

	_Model = viewSystem.Model.extend({
		init: function(){
			this._super( {
				namespace: this.VIEWTYPE
			} );
			this._needsRefresh = true;
			this._liveUpdate = false;
			this._needs = []; // Array of Needs Objects

			this.child = {};

			this.scope = function( method ){
				return viewSystem.utils.scope( method, this );
			};
		}
	,	dataHasChanged: function(){ return this._needsRefresh; }
	,	feelsRefreshed: function(){ this._needsRefresh = false; }
	,	isNotSoFresh  : function(){
			this._needsRefresh = true;
			if( this._liveUpdate ){
				this._updater.action.apply( this._updater.scope );
			}
		}
	,	liveUpdate: function( bool ){
			this._liveUpdate = bool;
			return this;
		}
	,	addProps: function( arry ){
			var
				l = arry.length
			,	i
			,	str = ""
			,	priv
			,	def
			;
			for ( i = 0; i < l; i++ ){
				str = arry[ i ];
				if( $.isArray( str ) ){
					if( ( str.length > 1 ) ){
						def = str[ 1 ];
						str = str[ 0 ];
					}// TODO: else error?  Also, what to do if greater than 2?
				} else {
					def = "batunatech"; // setting to a nonsense string - allows for any other value (even null or undefined) to be a default value.
				}
				priv = "_" + str;
//				this[ str ] = new viewSystem.Model( {
//					namespace: this.VIEWTYPE + ":model:" + str
//				} );
				this[ str ] = viewSystem.utils.getSet.call( this, priv ); //TODO: should we check for the presence of this[ str ] before overwriting it?
				if( def !== "batunatech" ){ //default value was passed
					this[ priv ] = def;
				}
			}

			return this;
		}
	,	setEnMasse: function( obj, announce ){
			var
				_prop
			,	_priv
			;
			for( _prop in obj ){
				_priv = "_" + _prop;
				this[ _priv ] = obj[ _prop ];
			}
			if( announce ){
				this.isNotSoFresh();
			}
		}
	,	dataBase: function() {
			return {}; //For now we're returning an empty object.  May be extended by subclasses or enhanced in future versions of the viewSystem
		}
	,	gatherData: function() {
			var
				_data = this.dataBase()
			;
			switch( this.needsMet() ){
				case _STATES.DEFAULT:
					if( typeof( this.data ) === "function" ){
						return $.extend( _data, this.data() );
					}
				break;
				case _STATES.LOADING:
					if( typeof( this.dataLoading ) === "function" ){
						return $.extend( _data, this.dataLoading() );
					}
				break;
				case _STATES.FAIL:
					if( typeof( this.dataFail ) === "function" ){
						return $.extend( _data, this.dataFail() );
					}
				break;
				case _STATES.SUCCESS:
					if( typeof( this.dataSuccess ) === "function" ){
						return $.extend( _data, this.dataSuccess() );
					}
				break;
				default:
					//Error - shouldn't happen (would imply a problem with "needsMet")
				break;
			}
			return _data;
		}
	,	needs: function (){
			return this._needs;
		}
		/**
		 *
		 * @requires _root.data.Dao (framework TBD) - API needs:
		 *		get( [ argsObject ], callbackFunction, scopeForCallback )
		 *		key ( argsObject )
		 *		attempted ( key )
		 *
		 * needObj = {
		 *	 dao: _root.dao.foo // Object: DAO instance
		 * , success: this.foo  // Function: Local Model getter/setter
		 * , args: this.fooArgs // Function: ( Optional ) Local Model builder for dao args object. Must return arguments in a hash.
		 * , trigger: _root.model.fooDO.CHANGE_EVENT // String: ( Optional ) - event to trigger a not-so-fresh state.
		 * }
		 */
	,	addNeed: function( needObj ){
			var _that = this;
			needObj.lastKey = needObj.lastKey || "";
			needObj.fail = needObj.fail || needObj.success;
			function _isNotSoFresh(){
				_that.isNotSoFresh();
			}
			if( needObj.trigger ){
				$( document.body ).bind( needObj.trigger, _isNotSoFresh );
			}
			this._needs.push( needObj );
			return this;
		}
		/**
		 * Used during the View refresh request.
		 *
		 * @returns boolean
		 */
	,	attemptNeeds: function (){
			var
				_needs = this._needs
			,	_need // requirement object
			,	_needArgs // args object
			,	_argsValid = true
			,	_dArgs = [] //Array for args applied to dao.get
			,	_key = ""
			,	l = _needs.length
			,	i
			,	_attemptedAny = false
			;

			for( i = 0; i < l; i++ ){
				_need = _needs[ i ];
				if( _need.args ){
					_needArgs = _need.args.apply( this );
					if ( !_isHash( _needArgs ) ) {
						//#ifdef debug
						debug.error( "View: attemptNeeds: need args did not return a hash object.", _need );
						//#endif
						continue;
					}
					_argsValid = _need.dao.validateArgs.call( _need.dao, _needArgs );
					_key = _need.dao.key.call( _need.dao, _needArgs );
				} else {
					_key = "";
					_needArgs = false;
					_argsValid = true; //No args should be considered valid
				}
				if(	//TODO: If key == "" then there will be serious problems with this system (infinite looping)
					( _key === "" ) // There's no key, so we're going to kick off a data request (since no key implies "no cache")
				||
					(
						( typeof( _need.success() ) === "undefined" ) //TODO / NOTE: Means that unrequested data storage function *must* return undefined and failed should return something defined?
					&&	( !_need.dao.attempted ( _key ) ) // The curent arg set has never been attempted.  Kick off the request
					)
				|| ( !_need.dao.attempted ( _key ) )
				|| ( _need.lastKey !== _key )
				){
					if( _argsValid ){

						_dArgs = [];
						_dArgs.push( {
							success: _need.success
						,	fail: _need.fail
						,	scope: this
						} );
						_dArgs.push( _needArgs );

						_need.lastKey = _key;
						_need.dao.get.apply( _need.dao, _dArgs ); //Initiate getter
						_attemptedAny = true;
					} else {
						//what to do?  Can't attempt for real
					}

				}
			}

			return _attemptedAny; //return indicates whether any requests have been set off
		}
		/**
		 * Used during the View refresh request.
		 *
		 * @returns boolean
		 */
	,	needsMet: function (){
			var
				_needs = this._needs
			,	_need // requirement object
			,	_needArgs // args object
			,	_key = ""
			,	l = _needs.length
			,	i
			,	_gotItAll = ( _needs.length === 0 ) ? _STATES.DEFAULT : _STATES.SUCCESS
			;
			for( i = 0; i < l; i++ ){
				_need = _needs[ i ];
				if( _need.args ){
					_needArgs = _need.args.call( this );
					_key = _need.dao.key( _needArgs );
				} else {
					_key = "";
					_needArgs = false;
				}
				if(
					(
						( typeof( _need.success.call( this ) ) === "undefined" ) //TODO / NOTE: Means that unrequested data storage function *must* return undefined
					&&	( typeof( _need.fail.call( this ) ) === "undefined" )
					)
				||	( !_need.dao.attempted ( _key ) ) // Current arg configs haven't been attempted yet
				){
					if( this._attempting ){ // The dao's are currently being attempted.
						_gotItAll = _STATES.LOADING;
					} else { // Can't request data yet because the needs to submit data requests are not yet met.
						_gotItAll = _STATES.DEFAULT;
					}
				}
				if(
					( _need.dao.failed( _key ) ) // Current args have been attempted and failed.
				){
					_gotItAll = _STATES.FAIL;
				}
			}

			return _gotItAll;
		}
	,	STATES: _STATES
	} );

	_Controller = Class.extend( {
		init: function() {

			this._instance = _instances++;
			this._children = [];
			this._managers = {};
			this._model = new this.Model();
			this._model._updater = {
				action: this.refresh
			,	scope: this
			};

			this._hasNewContainer = true;
			this._containerSelector = ""; //Used to hold selector string when view is an child of another view

			this._useContainer = false;//( params && params.useContainer ) ? params.useContainer : false;
			this._containerExists = false; // :DOMobject - used with static content when there's a "parent" container to the node
			this._staticContent = false; //( params && params.staticContent ) ? params.staticContent : false;
			this._tag = _NODE_TYPE_DEFAULT;

			this._prepped = false;
			this._enabled = true; // to easily disable the rendering of a view (primarily for a child)
			this._isVisible = false;
			this._visibleUpdate = false;
			this._templateDefault = null;
			this._templateLoading = null;
			this._templateFail = null;
			this._templateSuccess = null;

			this.scope = function( method ){
				return viewSystem.utils.scope( method, this );
			};
		}

		/**
		 * Sets template based on id ( must return document.getElementById -> node who's innerHTML is formatted for templatizing );
		 */
	,	_initializeTemplate: function(){
			var
				_viewtype = this.constructor.VIEWTYPE
			,	_tpl = new viewSystem.utils.tpl( this._tagOverrides )
			;
			this._templateDefault = _tpl( _viewtype ); // _STATES.DEFAULT
			this._templateLoading = _tpl( _viewtype + "_" + _STATES.LOADING );
			this._templateFail    = _tpl( _viewtype + "_" + _STATES.FAIL );
			this._templateSuccess = _tpl( _viewtype + "_" + _STATES.SUCCESS );
		}

		/**
		 * Getter for _model
		 *
		 * @function
		 * @returns {Object}
		 */
	,	model: function(){ return this._model; }

		/**
		 * Getter for _prepped
		 *
		 * @function
		 * @returns {Boolean}
		 */
	,	isPrepped: function(){ return this._prepped; }

		/**
		 * Setter for _prepped
		 *
		 * @function
		 * @returns {Null}
		 */
	,	setPrepped: function(state){ this._prepped = state; }

		/**
		 * Getter for _isVisible
		 *
		 * @function
		 * @returns {Boolean}
		 */
	,	isThisVisible: function(){ return this._isVisible; }

		/**
		 * @function Sets _isVisible to true
		 * @returns {Null}
		 */
	,	isVisible: function() { this._isVisible = true; }

		/**
		 * @function Sets _isVisible to false
		 * @returns {Null}
		 */
	,	isNotVisible: function() { this._isVisible = false; }

	,	template: function( data ){
			switch( this.model().needsMet() ){
				case _STATES.DEFAULT:
					return this._templateDefault( data );
				//break;
				case _STATES.LOADING:
					return this._templateLoading( data );
				//break;
				case _STATES.FAIL:
					return this._templateFail( data );
				//break;
				case _STATES.SUCCESS:
					return this._templateSuccess( data );
				//break;
			}
		}

	,	prepare: function() {
			var
				i
			,	l
			;
			if( this.isPrepped() ){ return true; }

			this.setPrepped( true );

			this.node(); //call node to initialize it.

			this._initializeTemplate();

			for( i = 0, l = this._children.length; i < l; i++ ){
				this._children[i].prepare();
			}

			$( this.node() ).trigger( viewSystem.EVENTS.VIEWPREPPED, {view:this} );
		}


	,	node: function () {
			var
				_className = this.constructor.VIEWTYPE
			,	_paddedNodeClass
			;
			if( !this.isPrepped() ){
				this.prepare();
			}
			if( typeof( this._node ) !== "undefined" ){
				return this._node;
			} // else get/create node
			if ( this._useNode ) {
				this._node = this._useNode();
			} else if ( this._useContainer ){
				this._node = this.container();
			} else {
				this._node = document.createElement( this._tag );
			}

			_paddedNodeClass = " " + this._node.className + " "; //ensures there is a space on either end to make for easy matching

			if( _paddedNodeClass.indexOf( " " + _className + " " ) === -1 ){
				if( this._node.className !== "" ){
					_className = " " + _className;
				}
				this._node.className += _className;
			}
			if( _paddedNodeClass.indexOf( " " + _VIEW_CLASS + " " ) === -1 ){
				this._node.className += " " + _VIEW_CLASS;
			}
			this._node.style.display = "none";
//			if ( !this._useContainer ) {
//				this.container().appendChild( this._node );
//			}
			return this._node;
		}

		/**
		 * Shows the view.
		 *
		 * @returns {Null}
		 */
	,	show: function(){
			var
				_man
			,	_mgr
			,	_modelChild = this.model().child
			,	_modelKey
			,	_childModel
			,	_value
			,	_viewMap
			,	_viewClass
			,	_viewId
			,	i
			,	l
			;
			if( !this.isPrepped() ){                this.prepare(); }
			if( this.model().dataHasChanged() ){	this.refresh(); }
			this.node().style.display = '';
			this.isVisible();
			if( this._visibleUpdate ){
				this.modelLive( true );
			}

			for( i = 0, l = this._children.length; i < l; i++ ){
				this._children[i].show();
			}

			for( _man in this._managers ){
				_mgr = this._managers[ _man ];
				_modelKey = _mgr.model;
				_childModel = _modelChild[ _modelKey ];
				_value = _childModel.get();
				if( !_value ){
					//#ifdef debug
					debug.log( "exiting with no value for ", _man, " of ", this.VIEWTYPE );
					//#endif
					continue; // no state set
				}
				_viewMap = _childModel._viewMap[ _value ];
				if( !_viewMap ){
					//#ifdef debug
					debug.log( "exiting with no viewMap for ", _man, " of ", this.VIEWTYPE );
					//#endif
					continue; // value is not mapped to a child
				}
				_viewClass = _viewMap[ 0 ];
				_viewId = _viewMap[ 1 ];
				_mgr.showOnly( _viewClass, _viewId );
			}

			this.updateLayout();

			$( this.node() ).trigger( viewSystem.EVENTS.VIEWSHOWN, {view:this} );
		}

	,	updateLayout: function() {
			//Method to override for layout calculations only possible after all children rendered (or that need to be updated when children change state
		}

		/**
		 * Hides the view.
		 *
		 * @returns {Null}
		 */
	,	hide: function(){
			var
				i
			,	l
			;
			if( !this.isThisVisible() ){ return; }// already hidden!
			this.node().style.display = 'none';
			this.isNotVisible();
			this.modelLive( false );

			for( i = 0, l = this._children.length; i < l; i++ ){
				this._children[ i ].hide();
			}

			$( this.node() ).trigger( viewSystem.EVENTS.VIEWHIDDEN, { view:this } );
		}

	,	toggle: function( bool ){
			this._enabled = bool;
		}

		/**
		 * Processes view data with view template and attaches html to this.node()
		 * TODO: Stop observers for all items in node(if previously populated) and destroy
		 * innerHTML before population.
		 *
		 * @see viewSystem.views.Abstract.node
		 * @returns {Null}
		 */
	,	refresh: function(){
			if( this._enabled === false ){ return false; }
			if( !this.isPrepped() ){ this.prepare(); }

			this.model()._attempting = this.model().attemptNeeds();

			var
				_model = this.model()
			,	_templateData// = _model.gatherData()
			//,	_innerHTML// = this.template( _templateData )
			,	_node = this.node()
			,	i
			,	l
			,	_child
			,	_loadCalled = false
			;

			if ( !this._staticContent ) {
				// stop any observers
					// TODO: figure out a better way to do this.  This will execute quite slowly on a large block of HTML.
					//  - possible solution - wrap all event observer assignment(s) inside of load (and any other areas where
					//    this view's node elements may be observed) with a method that will register the element and events observed

				$.each( $( _node ).find("*"), function(i, element){
					$( element ).unbind();
				} );
				if(
					( typeof( _model ) !== "undefined" )
				) {
					_templateData = this.model().gatherData();
				}
				$( _node ).html( this.template( _templateData ) );

				$( _node ).find( "img.imageLoader" ).each( function( image ){
					new viewSystem.utils.imageLoader( image.source, image );
				} );

			}
//			$( _node ).html( _innerHTML );
//			$( _node ).find( "img.imageLoader" ).each( function( image ){
//				new viewSystem.utils.imageLoader( image.source, image );
//			} );

			_model.feelsRefreshed();

			if( this._hasNewContainer && (! this._useContainer ) ){
				if( typeof( this.container() ) === "undefined" ){
					_model.isNotSoFresh();
					return false;
				}
				if( this._addToTopOfContainer ){
					$( this.container() ).prepend( _node );
				} else {
					$( this.container() ).append( _node );
				}
				this._hasNewContainer = false;
			}

			switch( _model.needsMet() ){
				case _STATES.LOADING:
					if( typeof( this.loadLoading ) === "function" ){
						this.loadLoading();
						_loadCalled = true;
					}
				break;
				case _STATES.FAIL:
					if( typeof( this.loadFail ) === "function" ){
						this.loadFail();
						_loadCalled = true;
					}
				break;
				case _STATES.SUCCESS:
					if( typeof( this.loadSuccess ) === "function" ){
						this.loadSuccess();
						_loadCalled = true;
					}
				break;
			}

			if( ! _loadCalled ){ //Default to calling "load" - required for every concrete view to implement, regardless of any other viewstate
				//#ifdef debug
				if( ! this.load ){
					debug.error( "no load method implemented in view.", this.VIEWTYPE);
				}
				//#endif
				this.load();
			}

			for( i = 0, l = this._children.length; i < l; i++ ){
				_child = this._children[i];
				if( _child._containerSelector ){
					_child.setContainer( $( _node ).find( _child._containerSelector )[0] );
				}
				_child.refresh();
			}

			if( this.isThisVisible() ){
				// Already visible, may need to update layout
				this.updateLayout();
			}

			$( _node ).trigger( viewSystem.EVENTS.VIEWREFRESHED, {view:this} );
		}

		/**
		 * Container which this.node() will be attached to during this.prepare();
		 * Defaults to document.body.  Can be overridden by subclass when/if a view should be attached
		 * to a specific container.
		 *
		 * @see viewSystem.views.Abstract.node
		 * @see viewSystem.views.Abstract.prepare
		 */
	,	container: function(){
			//return document.body;
			return this.document().body;
		}

	,	setContainer: function ( item ){
			switch( typeof( item ) ){
				case "undefined":
					return;
				//break;
				case "string":
					this.container = function() {
						return $( item )[ 0 ];
					};
					this._hasNewContainer = true;
				break;
				case "function":
					this.container = item;
					this._hasNewContainer = true;
				break;
				default:
					this.container = function() {
						return item;
					};
					this._hasNewContainer = true;
				break;
			}
		}

	,	addChild: function ( child ) {
			//#ifdef debug
			if(
				( !child.view )
			||	( !child.container )
			){
				debug.error( "can't add child without a view and container selector", child );
			}
			//#endif
			var
				_that = this // :Object - Pointer for use in descoped method calls
			,	_child = child.view // :View - instance of child class
			,	_mgr // : Manager
			,	_container = child.container
			,	_viewId
			,	_modelChild
			,	_modelKey = child.model
			,	_value = child.value
			;
			if( !_modelKey ){
				_child._containerSelector = _container;
				this._children.push( _child );
			} else {
				if( !this._managers[ _container ] ){
					this._managers[ _container ] = new viewSystem.Manager();
				}
				_mgr = this._managers[ _container ];
				_mgr.model = _modelKey;
				_modelChild = this.model().child;
				//_viewId = [ "view", "_", _modelKey, "_", _value ].join(""); // ( ( _value ) ? _value : viewSystem.utils.rand() );
				_viewId = _getChildViewId( _modelKey, _value );

				_mgr.registerView( _child.constructor, _child, _viewId );

				_child.setContainer( function(){
					return $( _that.node() ).find( _container )[ 0 ];
				} );


				if( !_modelChild[ _modelKey ] ){
					_modelChild[ _modelKey ] = new viewSystem.Model( {
						namespace: this.constructor.VIEWTYPE + ":childKey:" + _modelKey
					,	node: this.node()
					} );
					var _change_event = _modelChild[ _modelKey ].CHANGE_EVENT;

					$( this.node() ).bind( _change_event, function( e, v ){
						var
							_mod
						,	_viewMap
						,	_view
						,	_viewId
						;

						_mod = _modelChild[ _modelKey ];
						_viewMap = _mod._viewMap[ _mod.get() ];
						if( !_viewMap ){
							_mgr.hideAll(); //There's no child registered with this key value.  We'll just hide all children.
							return false; //this value isn't registered.
						}
						_view = _viewMap[ 0 ];
						_viewId = _viewMap [ 1 ];

						if( !_that.isPrepped() ){
							//#ifdef debug
							debug.warn( "parent isn't prepped when a child control value is being updated");
							//#endif
							return false;
						}
						_mgr.showOnly( _view, _viewId );
						if( _that.isThisVisible() ){
							_that.updateLayout();
						}
					} );
				}
				if( !_modelChild[ _modelKey ]._viewMap ){
					_modelChild[ _modelKey ]._viewMap = {};
				}
				_modelChild[ _modelKey ]._viewMap[ _value ] = [ _child.constructor, _viewId ];
				if( _child.isDefault ){
					this._children.push( _child );
				}
			}
			return _child;
		}

	,	addChildren: function ( children ) {
			var i, l = children.length;
			for( i = 0; i < l; i++ ){
				this.addChild( children[ i ] );
			}
			//this._children = this._children.concat( children );
			return this._children; //IDEA: is this right?  should it be "this" instead?  Or something else? the original array?
		}
	,	addChildrenTo: function( viewsAndValue, containerAndModel ){
			var
				i
			,	l = viewsAndValue.length
			,	_child
			,	_cAndM = containerAndModel
			;
			for( i = 0; i < l; i++ ){
				_child = viewsAndValue[ i ];
				this.addChild( {
					view: _child.view
				,	container: _cAndM.container
				,	model: _cAndM.model
				,	value: _child.value
				} );
			}
			return this._children;
		}

	//TODO: finish this - useful for determining if a specific container/model/value combo has already been registered

	,	hasChild: function( child ) {
			var
				_child = child.view // :View - instance of child class
			,	_mgr // : Manager
			,	_container = child.container
			,	_viewId
			,	_modelChild
			,	_modelKey = child.model
			,	_value = child.value
			;
			if( !_modelKey ){
				//TODO: Is there a good way to determine? Until determined, just returning false - better to think there isn't one and add one, than to think there is one when there isn't.
				return false;
			} else {
				if( !this._managers[ _container ] ){
					// there's no manager's for this container, there are no children:
					return false;
				}
				_mgr = this._managers[ _container ];
				_mgr.model = _modelKey;
				_modelChild = this.model().child;

				if( !_modelChild[ _modelKey ]._viewMap ){
					return false;
				}

				if( _modelChild[ _modelKey ]._viewMap[ _value ] ){
					return true;
				}
			}
			return false;

		}


	,	getChild: function( obj ) {
			var
				_mgr // : Manager
			,	_container = obj.container
			,	_viewId
			,	_modelChild
			,	_modelKey = obj.model
			,	_value = obj.value
			;
			if( !_modelKey ){
				//TODO: Is there a good way to determine? Until determined, just returning false - better to think there isn't one and add one, than to think there is one when there isn't.
				return false;
			} else {
				if( !this._managers[ _container ] ){
					// there's no manager's for this container, there are no children:
					return false;
				}
				_mgr = this._managers[ _container ];
				_mgr.model = _modelKey;
				_modelChild = this.model().child;

				if( !_modelChild[ _modelKey ]._viewMap ){
					return false;
				}

				if( _modelChild[ _modelKey ]._viewMap[ _value ] ){
					return _mgr.getView( _modelChild[ _modelKey ]._viewMap[ _value ][ 0 ], _modelChild[ _modelKey ]._viewMap[ _value ][ 1 ] );
				}
			}
			return false;

		}

	,	children: function () {
			return this._children;
		}

	,	setChildValue: function( modelKey, value ) {
			var _childModel = this.model().child[ modelKey ];
			if( _childModel ){
				_childModel.set( value );
				return true; // TODO: should this return "this" for chaining?
			} else {
				//#ifdef debug
				debug.error( "No child model with key", modelKey );
				//#endif
				return false;
			}
		}

	,	getChildValue: function( modelKey ) {
			var _childModel = this.model().child[ modelKey ];
			if( _childModel ){
				return _childModel.get();
			} else {
				//#ifdef debug
				debug.error( "No child model with key", modelKey );
				//#endif
				return false;
			}
		}
	,	getChildModel: function( modelKey ) {
			var _childModel = this.model().child[ modelKey ];
			if( _childModel ){
				return _childModel;
			} else {
				//#ifdef debug
				debug.error( "No child model with key", modelKey );
				//#endif
				return {};
			}
		}

	,	live: function ( bool ) { //live update when visible
			this._visibleUpdate = bool;
		}

	,	modelLive: function ( bool ) {
			this.model().liveUpdate( bool );
		}

	,	document: function(){ return global.document; }

	,	instance: function(){ return this._instance; }

	,	instances: function(){ return _instances; }

	,	Model: _Model

	,	STATES: _STATES

	} );

	_Controller._extend = _Controller.extend;

	$.extend( _Controller, {

		VIEWTYPE: "Abstract"

	,	STATES: _STATES

	,	Model: _Model

	,	instances: function(){
			return _instances;
		}

	,	extend: function( args ){
			var
				_ParentController = args.parent || this //_Controller
			,	_ParentModel = _ParentController.Model || _Model
			,	_namespace = args.namespace || "viewSystem.View"
			,	_controller = args.controller || {}
			,	_model = args.model || {}
			,	_VIEWTYPE = _namespace.replace( /\./g, "_" )

			,	Controller
			,	Model

			,	_extendedModel
			,	_shared
			;


			_extendedModel = $.extend( {}, _model, {
				VIEWTYPE: _VIEWTYPE
			} );

			Model = _ParentModel.extend( _extendedModel );

			_shared = $.extend( {}, _ParentController, {
				Model: Model
			,	VIEWTYPE: _VIEWTYPE
			} );

			$.extend( _controller, _shared );

			Controller = _ParentController._extend( _controller );

			/*
			 * 9/28/2011 - for some reason FF 3.6 (and an older "dot" release of Safari)
			 * do not correctly perform this jquery extend: $.extend( Controller, _shared )
			 * Suspect that it is due to some sort of internal protection against potential
			 * circular references.  Regardless of cause, bypassing issue for now by manually
			 * copying all necessary props.
			 */
			//$.extend( Controller, _shared );
			Controller.Model = _shared.Model;
			Controller.STATES = _shared.STATES;
			Controller.VIEWTYPE = _shared.VIEWTYPE;
			Controller._extend = _shared._extend;
			Controller.extend = _shared.extend;
			Controller.instances = _shared.instances;

			return Controller;

		}
	} );

	return _Controller;
}( this ) );