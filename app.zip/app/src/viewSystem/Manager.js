/**
 * @fileoverview
 * viewSystem Manager
 * Manages dynamic page states (views).
 *
 * @author ernesto
 * @date 11/18/2009
 */
// #ifdef debug
	debug.info("loading file | viewManager.js");
// #endif

/**
 * @namespace Holds all classes and methods related to viewSystem
 */
var viewSystem = viewSystem || {};

/**
 * viewSystem.manager Singleton handles registering new views,
 * returning requested views, and passing through view commands.
 *
 * @namespace For global viewSystem methods and functions.
 */
viewSystem.Manager = ( function(){
	/**#@+
	 * @private
	 * @memberOf viewSystem.manager
	*/ //START PRIVATE
	var
		_UNIQUE_VIEW = "UNIQUE_VIEW"
	,	_ALWAYS_NEW_VIEW = "ALWAYS_NEW_VIEW"
	;

	/*
	 * @constructor
	 */
	function _Manager() {
		/**
		 * Stored reference for all viewTypes (classes) registered.  Used to quickly ensure that calls to a view are valid.
		 * ViewTypes are stored as string.
		 *
		 * @type Array
		 */
		this._registeredViewTypes = [];

		/**
		 * Array of arrays of view instance storage objects, by view type. used for reference/lookup of view instances.
		 * View instances are use for cached alternate versions of a particular view, or to have multiple versions of the
		 * same view type visible simultaneously.
		 *
		 * @see viewSystem.manager._createViewInstanceStorageObject
		 * @type Object
		 */
		this._registeredViewInstances = {};
	}

	/**
	 * Checks for presence in this._registeredViewTypes.
	 * Fastest method to ensure that a viewClass has been registered with the ViewManager.
	 *
	 * @param {Class} viewClass Prototype.js Class definition that implements viewSystem.ifaces.view
	 * @returns {Boolean}
	 */
	_Manager.prototype._hasViewClass = function (viewClass){
		var
			_types = this._registeredViewTypes
		,	i
		,	l
		;

		for( i = 0, l = _types.length; i < l; i++ ){
			if( _types[i] == viewClass ){
				return true;
			}
		}
		return false;
	};

	_Manager.prototype._registerViewClass = function ( viewClass ){
		this._registeredViewTypes.push(viewClass);
		this._registeredViewInstances[viewClass.VIEWTYPE] = [];
	};

	/**
	 * Gets a stored instance of viewClass or creates one if not found.  Also stores a global reference to the viewClass for quick lookup later.
	 * Optional uniqueID used to store multiple
	 * instances of single viewClass.  This allows for caching or simultaneous display of multiple items created by same
	 * viewClass.
	 *
	 * @see viewSystem.manager._hasViewClass
	 * @see viewSystem.manager._createViewInstanceStorageObject
	 * @param {Class} viewClass viewClass Prototype.js Class definition that implements viewSystem.ifaces.view
	 * @param {String} uniqueID Optional Reference ID used for instance lookup (only required if multiple instances created)
	 * @returns {Object}
	 */
	_Manager.prototype._getViewInstance = function ( viewClass, uniqueID ){
		var
			_foundView = false
		,	_viewType = viewClass.VIEWTYPE
		,	_viewStorageObject = false
		,	_instances = []
		,	i
		,	l
		;

		if( !this._hasViewClass( viewClass ) ){ //TODO: see TODO on line 131
//			this._registeredViewTypes.push(viewClass);
//			this._registeredViewInstances[viewClass.VIEWTYPE] = [];
			this._registerViewClass( viewClass );
		}

		_instances = this._registeredViewInstances[ _viewType ];

		if( ( uniqueID == _UNIQUE_VIEW ) && this._registeredViewInstances[ _viewType ].length > 0 ) { 		// ensure we always use the first (should be *only*) stored view for UNIQUE_VIEW
			_viewStorageObject = this._registeredViewInstances[ _viewType ][ 0 ]; 								// use previously stored item.
		} else {
			for( i = 0, l = _instances.length; i < l; i ++ ){
				if( _instances[ i ].id == uniqueID ){
					_viewStorageObject = _instances[ i ];
					break;
				}
			}

			if( _viewStorageObject && ( uniqueID == _ALWAYS_NEW_VIEW ) ) {
				this._destroyView( viewClass, uniqueID );
				_viewStorageObject = null;
			}
		}
		if( _viewStorageObject ){
			_foundView = _viewStorageObject.view;
		}
		if( !_foundView ){
			_foundView = this._createViewInstanceStorageObject( viewClass, uniqueID ).view;
		}
		return _foundView;
	};

	/**
	 * Creates a new instance of viewClass and returns a view instance storage object in the format:
	 * 	{ id: "unique.to.this.viewtype.id", view: _referenceToViewObject }
	 *
	 * @param {Class} viewClass viewClass Prototype.js Class definition that implements viewSystem.ifaces.view
	 * @param {String} uniqueID Optional Reference ID used for instance lookup (only required if multiple instances created)
	 * @returns {Object}
	 */
	_Manager.prototype._createViewInstanceStorageObject = function ( viewClass, uniqueID ){
		var
			_viewInstance = new viewClass(uniqueID)
		;

		return this._registerViewInstance( viewClass, _viewInstance, uniqueID );
	};

	_Manager.prototype._registerViewInstance = function( viewClass, viewInstance, uniqueID ){
		var
			_viewType = viewClass.VIEWTYPE
		,	_viewInstance = viewInstance
		,	_viewInstanceStorageObject = {}
		;

		_viewInstanceStorageObject.id = uniqueID || "";
		_viewInstanceStorageObject.view = _viewInstance;

		if( !this._hasViewClass( viewClass ) ){
			this._registerViewClass( viewClass );
		}

		this._registeredViewInstances[ _viewType ].push( _viewInstanceStorageObject );
		return _viewInstanceStorageObject;
	};


	_Manager.prototype._destroyView = function( viewClass, uniqueID ){
		var
			_viewType = viewClass.VIEWTYPE
		,	_inst = {}
		,	_instances = this._registeredViewInstances[ _viewType ]
		,	i
		,	l
		;

		if ( _instances ) {
			if ( uniqueID && ( uniqueID != "" ) ) {
				for( i = 0, l = _instances.length; i < l; i++ ){
					_inst = _instances[ i ];
					if( _inst.id == uniqueID ){
						this._registeredViewInstances[ _viewType ].splice( i, 1 );
						break;
					}
				}
			} else { // destroy instances of viewClass
				_instances.length = 0;
			}
		}
	};

	/**#@-*/ //END PRIVATE

	_Manager.prototype.UNIQUE_VIEW = _UNIQUE_VIEW;
	_Manager.prototype.ALWAYS_NEW_VIEW = _ALWAYS_NEW_VIEW;

	_Manager.prototype.getView = function( viewClass, uniqueID ){
		var _uniqueID = uniqueID || _UNIQUE_VIEW;
		var _view = this._getViewInstance( viewClass, _uniqueID );
		return _view;
	};

	//NOTE: only useful if viewClass has already been stored.
	_Manager.prototype.getViewByType = function( viewType, uniqueID ){
		var
			_types = this._registeredViewTypes
		,	_type
		,	i
		,	l
		;

		for( i = 0, l = _types.length; i < l; i++ ){
			_type = _types[ i ];
			if( _type.VIEWTYPE == viewType ){
				return this.getView( _type, uniqueID);
			}
		}
		return false;
	};

	_Manager.prototype.getAllVisible = function(){
		var
			_returnArray = []
		,	_types = this._registeredViewTypes
		,	_instances = this._registeredViewInstances
		,	_storageObjs = []
		,	_view
		,	i	//iterator
		,	l	//iterator limit
		,	ii	//iterator
		,	ll	//iterator limit
		;

		for( i = 0, l = _types.length; i < l; i++ ){
			_storageObjs = _instances[ _types[ i ].VIEWTYPE ];
			for( ii = 0, ll = _storageObjs.length; ii < ll; ii++ ){
				_view = _storageObjs[ ii ].view;
				if( _view.isThisVisible() ){
					_returnArray.push( _view);
				}
			}
		}
		return _returnArray;
	};

	_Manager.prototype.registerView = function( viewClass, viewInstance, uniqueID ){
		this._registerViewInstance( viewClass, viewInstance, uniqueID );
		return this; // ??? what else should we return
	};

	/**
	 * Creates a new instance of viewClass and stores a refrence with uniqueID.  Will ensure view is on DOM and ready before a show() call is made.
	 * A reference to the view is returned for potential direct use.  NOTE: this returned reference is no longer used by
	 * viewSystem.manager lookups:  the uniqueID (if passed) is required for accessing the specific view instance.
	 *
	 * @param {Class} viewClass viewClass Prototype.js Class definition that implements viewSystem.ifaces.view
	 * @param {String} uniqueID Optional Reference ID used for instance lookup (only required if multiple instances created)
	 * @returns {Object}
	 */
	_Manager.prototype.createView = function( viewClass, uniqueID ){
		var
			_uniqueID = uniqueID || _UNIQUE_VIEW
		,	_newView = this._getViewInstance( viewClass, _uniqueID )
		;

		return _newView;
	};

	/**
	 * Passthrough for show() method on an instance of viewClass with uniqueID.  viewClass will be created if does not already
	 * exist.
	 *
	 * @param {Class} viewClass viewClass Prototype.js Class definition that implements viewSystem.ifaces.view
	 * @param {String} uniqueID Optional Reference ID used for instance lookup (only required if multiple instances created)
	 * @returns {Null}
	 */
	_Manager.prototype.showView = function( viewClass, uniqueID ){
		var
			_uniqueID = uniqueID || _UNIQUE_VIEW
		,	_viewInstance = this._getViewInstance( viewClass, _uniqueID )
		;

		_viewInstance.show();

	};

	_Manager.prototype.showOnly = function( viewClass, uniqueID ){
		var
			_uniqueID = uniqueID || _UNIQUE_VIEW
		,	_viewInstance = this._getViewInstance( viewClass, _uniqueID )
		;

		if( !_viewInstance.isThisVisible() ){
			this.hideAll();
		}

		_viewInstance.show();

	};


	/**
	 * Passthrough for hide() method on an instance of viewClass with uniqueID.  Exits if viewClass not stored.
	 * NOTE: as of 11/25/09 - will *create* an instance of viewClass with uniqueId, if viewClass has already been stored,
	 * but instance with uniqueId not previously created.
	 *
	 * @param {Class} viewClass viewClass Prototype.js Class definition that implements viewSystem.ifaces.view
	 * @param {String} uniqueID Optional Reference ID used for instance lookup (only required if multiple instances created)
	 * @returns {Null}
	 */
	_Manager.prototype.hideView = function( viewClass, uniqueID ){
		var
			_uniqueID = uniqueID || _UNIQUE_VIEW
		,	_viewInstance
		;

		if( !this._hasViewClass( viewClass ) ){ return; } // viewsClass does not exist!
		_viewInstance = this._getViewInstance(viewClass, _uniqueID);
		_viewInstance.hide();

	};

	/**
	 * Iterates all stored viewClasses and their instances, calling member's hide() method.
	 */
	_Manager.prototype.hideAll = function(){
		var
			_types = this._registeredViewTypes || []
		,	_instances = this._registeredViewInstances || []
		,	_storageObjs = []
		,	_view
		,	i	// iterator
		,	l	// iterator limit
		,	ii	// iterator
		,	ll	// iterator limit
		;
		for( i = 0, l = _types.length; i < l; i++ ){
			_storageObjs = _instances[ _types[ i ].VIEWTYPE ];
			for( ii = 0, ll = _storageObjs.length; ii < ll; ii++){
				_view = _storageObjs[ ii ].view;
				if( _view ){
					_view.hide();
				}
			}
		}
	};

	/**
	 * Iterates all stored instances of viewClass instances, calling member's hide() method.
	 *
	 * @param {Class} viewClass viewClass Prototype.js Class definition that implements viewSystem.ifaces.view
	 */
	_Manager.prototype.hideAllofViewClass = function( viewClass ){
		var
			_instances = this._registeredViewInstances
		,	i
		,	l
		;

		if ( this._hasViewClass( viewClass ) ) {
			for( i = 0, l = _instances.length; i < l; i++ ){
				_instances[ i ].view.hide();
			}
		} // else - none exist, no need to hide.
	};

	/**
	 * Iterates all stored instances of viewClasses except those passed in, calling each member's hide() method
	 */
	_Manager.prototype.hideAllExceptForViewClasses = function ( viewClasses ){
		var
			_filter = false
		,	_types = this._registeredViewTypes
		,	_type	// ViewClass
		,	i	// iterator
		,	l	// iterator limit
		,	ii	// iterator
		,	ll = viewClasses.length	// iterator limit
		;
		iTypes:
		for( i = 0, l = _types.length; i < l; i++ ){
			_type = _types[ i ];
			_filter = false;
			iViewClasses:
			for( ii = 0; ii < ll; ii++ ){
				if( viewClasses[ ii ].VIEWTYPE == _type.VIEWTYPE ){
					_filter = true;
					break iViewClasses;
				}
			}
			if( !_filter ){
				this.hideAllofViewClass( _type );
			}
		}
	};

	_Manager.prototype.destroyView = function( viewClass, uniqueID ){
		this._destroyView( viewClass, undefinedID );
	};

	return _Manager;
} )();
viewSystem.manager = new viewSystem.Manager();