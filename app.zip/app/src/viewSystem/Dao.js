
var viewSystem = viewSystem || {};

viewSystem.Dao = ( function ( global ) {

	function _def( val ){
		return ( typeof( val ) !== "undefined" );
	}

	function _index( arry, val ){ //handles IE's lack of .indexOf support
		var i, l = arry.length;
		for( i = 0; i < l; i++ ){
			if( arry[ i ] == val ){
				return i;
			}
		}
		return -1;
	}

	return Class.extend( {
		init: function () {
			var
				_this = this
			;

			this._cache = {};
			this._failedKeys = [];
			this._transacting = false;
			this._failed = false;
			this._attempted = false;
			this._queue = [];

			this._actives = [];

			this.url = ""; //Should be overwritten by the real action/url for data gather
			this.args = {}; //Could be overritten by a string for direct adding to query if necessary


			return this;
		}

	,	_doQueue: function(key){
			while(!this.active(key) && this._queue.length > 0 ){
				this._queue.shift()();
			}
		}

	,	_finish: function( daoArgs, data ){
			var
				_that = this
			,	_key = daoArgs.key
			, 	_success = daoArgs.success
			,	_fail = daoArgs.fail
			, 	_scope = daoArgs.scope
			, 	_i
			;

			this._failed = ( !_def( data ) ) || daoArgs.failed;
			this._setActive( false, _key );

			_i = _index( this._failedKeys, _key );
			if( !this._failed ){
				if( _key ){
					this._cache[ _key ] = data;
					if( _i != -1 ){
						this._failedKeys = this._failedKeys.splice( _i, 1 );
					}
				}
				_success.call( _scope, data );
			} else {
				if( _key ){
					if( _i == -1 ){
						this._failedKeys.push( _key );
					}
				}
				_fail.call( _scope, data );
			}

			this._doQueue.call( this, _key );
		}

		/**
		 * daoArgs = {
				key: "key"			// String
			, 	prepData: prepData	// Function
			, 	success: success 	// Function
			,	fail: fail			// Function Optional (defaults to success)
			, 	scope: scope		// Object
			}
		 */
	,	get: function ( daoArgs ) {
			var
				_that = this
			,	_key = daoArgs.key
			, 	_prepData = daoArgs.prepData
			, 	_success = daoArgs.success
			,	_fail
			,	_ajaxObj = {}
			,	_scope

			// Overriding classes calling this super method should append all
			//	arguments in _super() call;
			//	Functionality-by-convention requires daoArgs to be first argument.
			,	_arguments = arguments
			;

			if( ! daoArgs
					|| typeof( _success ) != "function"
					|| typeof( _prepData ) != "function"
			){
				//#ifdef debug
				debug.error( "Dao.get: first argument is not in expected daoArgs form." );
				//#endif
				return; // TODO: thow error?  more detailed validation?  etc.
			}

			if(
				( _def( _key ) )
			&& 	( ( _key + "" ) !== "")
			){
				daoArgs.key = _key + "";
			} else {
				daoArgs.key = false;
			}

			daoArgs.fail = daoArgs.fail || _success;
			daoArgs.scope = daoArgs.scope || global;

			_key = daoArgs.key;
			_fail = daoArgs.fail;
			_scope = daoArgs.scope;


			this._attempted = true;

			//#ifdef debug
			if( ! this.active ){
				debug.error("Error: Dao has no 'active' method.  Probably scoping issue (try using call/apply instead)" );
				debug.trace();
			}
			//#endif

			if( _key && this.active( _key ) ){
				//#ifdef debug
				debug.log( "already trying to get that data, we'll make your call after this one finishes.", _arguments );
				//#endif
				this.enqueue( function(){
					_that.get.apply( _that, _arguments ); //Should return cached data.
				} );
			} else if( _key  && ( this._cache.hasOwnProperty( _key ) ) ){
				//#ifdef debug
				debug.log("returning cached data");
				//#endif
				setTimeout( function(){ // finishing on timeout to ensure asynchronous
					_that._finish.call( _that, daoArgs, _that._cache[ _key ] );
				}, 75 );
			} else {
				if( typeof( _success ) != "function" ) {
					// #ifdef debug
					debug.error("Dao get 'success' is not a function.", _success, daoArgs );
					// #endif
					return;
				}
// Analyze following for deletion.
// (Cases where data calls made using different parameters and same parameters without caching).
//				if( this.active() ) { //Already transacting - let's enqueue the callBack for when it's all done.
//					// #ifdef debug
//					debug.log("already transacting, we'll make your call after this one finishes");
//					// #endif
//					this.enqueue( function( data ) {
//						_success.call( _scope, data );
//					} );
//				}
				this._setActive( true, _key );
				_ajaxObj =  {
					url: _that.url
				,	data: _that.args
				, 	success: function( response ){
					// #ifdef debug
					debug.log( "successful response:", response );
					// #endif
						var payload;
						try {
							var _preppedData = _prepData.call( _scope, response );
							if( _preppedData ){
								// #ifdef debug
								debug.log( "data prepped successfully, finishing transaction: ", _preppedData );
								// #endif
								payload = _preppedData;
							} else {
								// #ifdef debug
								debug.log( "data prep returned falsey, finishing transaction: ", daoArgs );
								// #endif
								daoArgs.failed = true;
								payload = response;
							}

						} catch ( err ) {
							// #ifdef debug
							debug.log( "data prep fatally errored", daoArgs, err );
							// #endif
							daoArgs.failed = true;
							payload = response;
						}

						// call finish using payload
						_that._finish.call( _that, daoArgs, payload );
					}
				,	error: function( response ){
						var _data = ( response.responseXML ) ? response.responseXML : response.responseText;

						daoArgs.failed = true;

						_that._finish.call( _that, daoArgs, _data );
						// #ifdef debug
						debug.error("failed response:", _that.url, _that.args, daoArgs, _data);
						// #endif
					}
				};
				//Check for overrides
				if( this.accepts ){ _ajaxObj.accepts = this.accepts; }
				if( this.type ){ _ajaxObj.type = this.type; }
				if( this.dataType ){ _ajaxObj.dataType = this.dataType; }
				if( this.contentType ){ _ajaxObj.contentType = this.contentType; }
				if( this.jsonpCallback ){ _ajaxObj.jsonpCallback = this.jsonpCallback; }
				if( this.crossDomain ){ _ajaxObj.crossDomain = this.crossDomain; }
				if( this.timeout ){ _ajaxObj.timeout = this.timeout; }
				// #ifdef debug
				if ( _ajaxObj.dataType == "jsonp" && !_ajaxObj.timeout ) {
					debug.warn( "Dao: jsonp request without timeout being set!" );
				}
				if ( _ajaxObj.dataType === "jsonp" ) {
					// JSONP requests are not obvious: log explicitly
					debug.log( "Attempting JSONP request", _ajaxObj );
				}
				// #endif

				$.ajax( _ajaxObj );
			}
		}
	,	_setActive: function( state, key ){
			//#ifdef debug
			debug.log( "Dao._setActive(", state, key, ")" );
			//#endif
			if( _def( state ) ) {
				this._transacting = state;
				if(
					( !_def( key ) )
				|| 	( key == "UNIQUE" )
				|| 	( key == "" )
				){
					return;
				}
				if( state ){
					if( _def( key ) && ( _index( this._actives, key ) ) === -1 ){
						this._actives.push( key );
					}
				} else {
					if( _def( key ) ){
						if( this._actives.length == 1 ){
							this._actives = [];
						} else {
							var _i = _index( this._actives, key );
							if( _i != -1 ){
								this._actives.splice( _index( key ), 1 );
							}
						}
					}
				}
			}
		}
	,	failedLast: function() {
			return this._failed;
		}
	,	failed: function( key ) {
			if( ! this._attempted ){
				return false; //can't have failed if not even attempted
			}
			if( _def( key ) ){
				if( _index( this._failedKeys, key ) == -1 ){
					return false;
				} else {
					return true;
				}
			}
			return this._failed; //If there's no key, then use the last _failed (as it is the right data)
		}
	,	everAttempted: function() {
			return this._attempted;
		}

	,	attempted: function( key ) {
			if( ! this._attempted ){
				return false;
			}
			if( _def( key ) ){

				if( this._cache.hasOwnProperty( key ) || ( _index( this._failedKeys, key ) !== -1 ) ){
					return true;
				} else {
					return false;
				}
			}
			return true;
		}
	,	active: function( key ){
			if( !_def( key ) ){
				return this._transacting;
			} else {
				if(
					( this._transacting )
				&&	( _index( this._actives, key ) !== -1 )
				){
					return true;
				}
				return false;
			}
		}
	,	enqueue: function( func ){
			if( typeof( func ) !== "function" ){
				return; //Can't queue anything but methods... should we throw an error here?
			}
			this._queue.push(func);
		}

	,	validateArgs: function () {
			return true;  //If this method has not been overriden by an instance/subClass, we'll just assume any args are valid.
		}
	,	genericValidator: function ( args ){
			var _ARGS = this.ARGS;
			if(
				( !args )
			){
				//#ifdef debug
				debug.warn( "viewSystem.Dao.genericValidator(): No args provided" );
				//#endif
				return false;
			} else {
				for( arg in _ARGS){
					if( !_def( args[ _ARGS[ arg ] ] ) ){
						//#ifdef debug
						debug.warn( "viewSystem.Dao.genericValidator(): " + arg + " not provided" );
						//#endif
						return false;
					}
				}

			}
			return true;
		}
	,	key: function( obj, level ) {
			var
				_ret = [] // Ensure first character is valid
			,	_val
			,	_prop
			,	_level = ( level ) ? level + 1 : 1 //Used to limit depth
			;

			for( _prop in obj ){
				_val = obj[ _prop ];
				_ret.push( "$", _prop, "__" );
				if( $.isArray( _val ) ){
					_ret.push( _val.join("___") );
				} else {
					if( typeof( _val ) == "function" ){
						// TODO: what to do?  Execute and evaluate result type?  Or ignore? Ignoring for now.
						_ret.push( "function" );
						continue;
					}
					if(
						( _val instanceof Object )
					&&	( _level < 5 ) //TODO: determine if this is the appropriate depth
					){
						_ret.push( this.key( _val, _level ) );
					} else {
						_ret.push( _val );
					}
				}
			}

			return this.cleanKey( _ret.join( "" ) );
		}
	,	cleanKey: function( dirtyKey ) {
			return dirtyKey.replace(/[\s]/g,"_").replace(/[^a-z0-9_$]/ig,"");
		}
	} );

}( this ) );