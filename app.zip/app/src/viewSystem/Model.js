var viewSystem = viewSystem || {};

viewSystem.Model =  ( function (){
	var
		_Model
	,	_EVENTS = viewSystem.EVENTS
	;

	function _def( v ){
		return typeof( v ) !== "undefined";
	}

	function _trigger(
		/* args will be passed with event */
	){
		for( var i = 0, l = this._subscribers.length; i < l; i ++ ){
			var _sub = this._subscribers[ i ];
			_sub.fn.call( _sub.scope, this._value );
		}
		
		var _args = [].slice.call( arguments );
		_args.unshift( this._value );
		
		$( this._node ).trigger( this.CHANGE_EVENT, _args );
	}

	_Model = Class.extend( {
		init: function( inits ) {
			this._value;
			this._EVENT = "";
			this._doChangeId = false;
			this._changeId = "";
			this._node = document.body;
			this._subscribers = []; //simple observation queue

			this.CHANGE_EVENT = "";

			this.setEnMasse( inits );
		}

	,	_def: _def

	,	_trigger: _trigger

	,	setEnMasse: function( inits ){
			var
				_ns
			,	_rn
			,	_node
			,	_val
			;
			if( _def( inits ) ){
				_ns = inits.namespace;
				_rn = inits.doChangeId;
				_node = inits.node;
				_val = inits.value;
			}
			if( _def( _ns ) ){
				this._EVENT = ( _ns.replace( /[^0-9a-zA-Z_]/g, ":" ) );
				this.CHANGE_EVENT = this._EVENT + ":" + _EVENTS.CHANGED;
			} else {
				this.CHANGE_EVENT = "viewSystem:Model:" + _EVENTS.CHANGED;
			}
			if( _def( _rn ) ){
				this._doChangeId = ( _rn !== false );
			}
			if( _def( _node ) ){
				this._node = _node;
			}
			if( _def( _val ) ){
				this._value = _val;
			}
		}

	,	set: function ( value ) {
			var _rn;
			if(
				( _def( value ) )
			&& 	( ( value !== this._value ) || ( this._doChangeId ) )
			){
				this._value = value;
				if( this._doChangeId ){
					_rn = viewSystem.utils.rand();
					this._changeId = _rn;
				}
				this._trigger();
			}
			return this;
		}

	,	get: function () {
			return this._value;
		}

	,	changeId: function (){
			return this._changeId;
		}

	,	subscribe: function( fn, scope ){
			this._subscribers.push( {
				fn: fn
			,	scope: scope
			} ); // Note: extremely simple observer - no ability to stop observation and/or protect against duplicate
		}

	} );

	return _Model;
}() );