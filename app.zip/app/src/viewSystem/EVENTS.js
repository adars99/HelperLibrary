var viewSystem = viewSystem || {};

viewSystem.EVENTS =( function () {
	var
		AT = "viewSystem"

	,	CHANGED = "changed"
	,	SHOWN = "shown"
	,	PREPPED = "prepped"
	,	HIDDEN = "hidden"
	,	REFRESHED = "refreshed"

	,	VIEW = "view"
	,	DATA = "data"

	;

	function _( arry ){
		return arry.join( ":" );
	}

	return {

		CHANGED: CHANGED
	,	SHOWN: SHOWN
	,	PREPPED: PREPPED
	,	HIDDEN: HIDDEN
	,	REFRESHED: REFRESHED


	,	VIEWSHOWN: _( [ AT, VIEW, SHOWN ] ) //"viewSystem:view:shown"
	,	VIEWPREPPED: _( [ AT, VIEW, PREPPED ] ) // "viewSystem:view:prepped"
	,	VIEWHIDDEN: _( [ AT, VIEW, HIDDEN ] ) // "viewSystem:view:hidden"
	,	VIEWREFRESHED: _( [ AT, VIEW, REFRESHED ] ) // "viewSystem:view:refreshed"
//	,	DATACHANGED: _( [ AT, DATA, SHOWN ] ) // "viewSystem:data:changed"
	};

}() );