var viewSystem = viewSystem || {};
viewSystem.utils = viewSystem.utils || {};

viewSystem.utils.getSet = ( function( global ){
	return function ( property ){
		//#ifdef debug
		if( this == global ){
			throw new Error( "utils.getSet called in the scope of global");
		}
		//#endif

		if( this.hasOwnProperty( property ) ){ // this already has that property
			return this[ property ]; //Should we throw an error instead for trying to over-write the existing?  Or do nothing?
		}
		return function( val ) {
			if( typeof( val ) !== "undefined" ){
				this[property] = val;
				this.isNotSoFresh();
			}
			return this[property];
		};
	};
}( this ) );