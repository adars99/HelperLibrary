var viewSystem = viewSystem || {};
viewSystem.utils = viewSystem.utils || {};

viewSystem.utils.rand = function( len ){
	var
		_ret = ""
	,	_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
	,	_opts = _CHARS.length
	,	_num
	,	i
	,	l = len || 16
	;
	for( i = 0; i < l; i ++ ){
		_num = Math.floor( Math.random() * _opts );
		_ret += _CHARS.substring( _num, _num + 1 );
	}
	return _ret;
};