var viewSystem = viewSystem || {};
viewSystem.utils = viewSystem.utils || {};

viewSystem.utils.createElement = function( oblit, documentScope ){
	if( !oblit.tag ){ return false; } //No tagname provided, returning.
	var
		_document = documentScope || document
		// Create a new dom element of provided tagname.
	,	_newNode = _document.createElement(oblit.tag)
	,	attrib
	,	_newAttrNode
	;

	// Check to see if any attributes have been provided
	if( oblit.attributes ){
		// Iterate attributes
		for( attrib in oblit.attributes ){
			// Ensure each attribute is not inherited by prototype chaining
			if( oblit.attributes.hasOwnProperty( attrib ) ){
				// Create a new attribute
				_newAttrNode = document.createAttribute( attrib );
				// Set attribute value
				_newAttrNode.nodeValue = oblit.attributes[ attrib ];
				// Add attribute to dom element
				_newNode.setAttributeNode( _newAttrNode );
			}
		}
	}

	// Check to see if an innerHTML string has been provided
	if(oblit.innerHTML){
		// Set innerHTML value of dom element
		_newNode.innerHTML = oblit.innerHTML;
	}

	// Return dom element
	return _newNode;
};