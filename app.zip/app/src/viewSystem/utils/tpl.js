/**
 * Implementation of John Resig's micro templating: http://ejohn.org/blog/javascript-micro-templating/
 */
var viewSystem = viewSystem || {};
viewSystem.utils = viewSystem.utils || {};

viewSystem.utils.tpl = function( overrides ){
	var
		_cache = {}
	,	_defs = {
			begin: "<%"
		,	end: "%>"
		,	control: "%"
		}
	,	_opts = {}
	,	_beginEsc
	,	_endEsc
	;

	if( overrides ){
		$.extend( _opts, _defs, overrides );
	} else {
		$.extend( _opts, _defs );
	}

	_beginEsc = _opts.begin.replace( /\\\\/g,"batunatech" ).replace( /\\/g, "" ).replace( "batunatech", "\\" );
	_endEsc = _opts.end.replace( /\\\\/g,"batunatech" ).replace( /\\/g, "" ).replace( "batunatech", "\\" );

	function _bld_fn ( str ){
		var
			_endPat = new RegExp( "'(?=[^" + _opts.control + "]*" + _opts.end + ")", "g" )
		,	_equalPat = new RegExp( _opts.begin + "=(.+?)" + _opts.end, "g" )
		,	_ret =
				"var __p__=[]"
			+	",print=function(){__p__.push.apply(__p__,arguments);}"	//Allows for manual insertion to output array string
			+	",deefault=''"
			+	";"
//			+ 	"debug.debug( obj );"
//			+	"if(typeof(obj)=='undefined'){obj={};}"
			+	"with(obj){__p__.push('"  // Introduce the data as local variables using with(){}
			+	str.replace( /[\r\t\n]/g, " " ) // Convert the template into pure JavaScript
				.replace( _endPat, "\t" )
				.split( "'" )
				.join( "\\'" )
				.split( "\t" )
				.join( "'" )
				.replace( _equalPat, "',$1,'" )
				.split( _opts.begin )
				.join( "');" )
				.split( _opts.end )
				.join( "__p__.push('" )
			+ 	"');}"
//			+	"debug.debug(__p__.join(''));"
			+	"return __p__.join('');"
		;
//		debug.debug( _ret );
		return _ret;
	}

	function _tmpl( str, data){
		// Figure out if we're getting a template, or if we need to
		// load the template - and be sure to cache the result.
		var
			fn =
				!/\W/.test(str) //TODO: won't this fail if you have a template with only one word an/or no spaces?
			?
					_cache[str] = _cache[str]
				||	( ( document.getElementById(str) ) ? _tmpl( document.getElementById(str).innerHTML ) : _tmpl( _beginEsc + "=deefault" + _endEsc) )
			:
				// Generate a reusable function that will serve as a template
				// generator (and which will be cached).
				new Function( "obj", _bld_fn( str ) )
			;

		// Provide some basic currying to the user
		return data ? fn( data ) : fn;
	}

	return _tmpl;
};