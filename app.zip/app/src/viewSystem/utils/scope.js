var viewSystem = viewSystem || {};
viewSystem.utils = viewSystem.utils || {};

viewSystem.utils.scope = function( method, obj ){
	return function(){
		method.apply( obj, arguments );
	};
};