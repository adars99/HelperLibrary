var viewSystem = viewSystem || {};
viewSystem.utils = viewSystem.utils || {};

viewSystem.utils.imageLoader = function( imagepath, targetimage ){
	var
		_targetimage = targetimage
	,	_tmpImage = new Image()
	;
	$( _tmpImage ).bind( "load", function(){
		_targetimage.src = _tmpImage.src;
	} );
	_tmpImage.src = imagepath;
};