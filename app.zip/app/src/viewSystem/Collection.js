var viewSystem = viewSystem || {};

viewSystem.Collection = ( function ( global ) {
	var
		_Collection
	;

	_Collection = Class.extend( {
		init: function( arry ){
			this._members = arry;
			this._current = 0;
		}
	,	members: function(){
			// return members
			return this._members;
		}
	,	setCurrent: function( index ){
			// set current index and return member
			this._current = index;
			return this.getMember();
		}
	,	current: function(){
			return this._current;
		}
	,	next: function(){
			var
				_curr = this._current
			,	_next = _curr + 1
			,	_len = this._members.length
			;
			// return next member and index
			if( _curr == _len - 1 ){
				// current is last
				_next = 0;
			}
			return _next;
		}
	,	previous: function(){
			// return previous member and index
			var
				_curr = this._current
			,	_prev = _curr - 1
			,	_len = this._members.length
			;
			// return next member and index
			if( _curr == 0 ){
				// current is first
				_prev = _len - 1;
			}
			return _prev;
		}
		/*
		 * @return Array [ item, index ]
		 */
	,	getMember: function( index ){
			if( typeof index == "undefined" ){
				index = this._current;
			}
			return {
				item: this._members[ index ]
			, 	index: index
			};
		}
	,	getCurrent: function(){
			// getter active member and index
			return this.getMember();
		}
	,	getFirst: function(){
			return this.getMember( 0 );
		}
	,	getLast: function(){
			return this.getMember( this._members.length - 1 );
		}
	,	getNext: function(){
			return this.getMember( this.next() );
		}
	,	getPrevious: function(){
			return this.getMember( this.previous() );
		}
	,	goNext: function(){
			// increment current and return (new) current item and index
			return this.setCurrent( this.next() );
		}
	,	goPrevious: function(){
			// decrement current and return (new) current item and index
			return this.setCurrent( this.previous() );
		}
	,	goFirst: function(){
			// set current to 0 and return 0 member and 0;
			return this.setCurrent( 0 );
		}
	,	goLast: function(){
			// set current to last and return last member and last index
			return this.setCurrent( this._members.length - 1 );
		}
	} );

	return _Collection;

}( this ) );