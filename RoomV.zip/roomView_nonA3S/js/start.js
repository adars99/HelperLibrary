var baseUrl = prd_roomView_baseUrl;// '$baseUrl$';

var mod = art.view('roomViewModule');

app.model.roomView.baseUrl = mod.args.baseUrl;
app.model.roomView.version = mod.args.v;
app.view.roomView.containerHeight = mod.args.height;

app.commands.roomView.start();

if (prd_roomView_touch) {
	window.setTimeout( function() {
		$('#roomViewContainer').addClass('touch');
	}, 500 );
	
	if( typeof(FileReader) == 'undefined' ) {
		$('#roomViewContainer').addClass('noUpload');
		
		setTimeout( function() {  document.getElementById('roomView_uploadButton').style.display = 'none'; } , 1000 );
	}
}

com.art.core.controller.Controller.notify('RoomViewModuleLoaded',{});
info('RoomView.html > RoomViewModuleLoaded notification sent.');
/*
window['y'] = function(val) {
	if(!val) {
		warn('y value for '+app.model.roomView.bareWall.Name+' is '+app.model.roomView.bareWall.ProductTargetAreaPosY);
		return;
	}
	app.model.roomView.bareWall.ProductTargetAreaPosY = val;
	warn('setting PTAPY to '+val+' for '+app.model.roomView.bareWall.Name);
	app.commands.roomView.updateDLE()
}
*/

var loggingServiceUrl = MyGalleriesEnvironmentVariables.ApiEcommerceServiceUrl;
if (isNullOrEmpty(loggingServiceUrl)) {
	error('roomView.html > ERROR: MyGalleriesEnvironmentVariables.ApiEcommerceServiceUrl is null or empty!');
}
loggingServiceUrl = loggingServiceUrl.replace( 'EcommerceAPI.svc' , 'Log.svc' ); // different endpoints, plus I'm lazy

var env = {
        serviceUrlLoggingApi : loggingServiceUrl
        , apiKey : 'AAB349013DDE43D29585BAD7C272CA36'
        , sessionId : MyGalleriesEnvironmentVariables.sessionId
}

window.onerror = function(err)
{
    loggingManager.logError(err);
    return true;
}
window['loggingManager'] = new com.art.core.utils.LoggingManager(env);

/*
window['error'] = function(str){
	if(traceLevel<1) {return} 
	try {
		var err = {
			name: 'Core-reported Error',
			message: str,
			fileName: 'fileName unknown',
			lineNumber: 'lineNumber unknown',
			stack: str+' at (stack not available)'
		}
			
		loggingManager.logError( err, undefined, MyGalleriesEnvironmentVariables.sessionId );
	} catch(e) {}
	if(!console){return} 
	if(console.error){console.error(a)}
}
*/