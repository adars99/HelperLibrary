if (!app) var app = {};
if (!app.model) app.model = {};
if (!app.model.roomView) app.model.roomView = {};

app.model.roomView.room = {};

app.model.roomView.populateModel = function(onComplete) {
	info('roomViewModel.js > populateModel > begin.');
	/*
	app.model.roomView.roomSets = systemBareWalls.Library.BareWallGalleries;
	app.model.roomView.currentRoomSet = systemBareWalls.Library.BareWallGalleries[1].BareWalls;
	app.model.roomView.bareWall = systemBareWalls.Library.BareWallGalleries[1].BareWalls[0]; //galleryDetails.Library.Galleries[0].Walls[0].WallDetails;
	*/
	
	app.model.roomView.populateRoomSets(function() {
		app.model.roomView.foregroundItems = app.commands.roomView.getForegroundItems();
		app.model.roomView.currentForegroundItem = app.model.roomView.foregroundItems[0];
		
		if (art.view('dle_foreground')) {
			art.view('dle_foreground').factory.source = app.model.roomView.currentForegroundItem.ItemDetails.ImageInformation.LargeImage.HttpImageURL;
			art.view('dle_foreground').update();			
		} else {
			Controller.register('moduleLoaded',function(payload) {
				error('roomViewModule.js > populateModel > payload to follow.');
				error(payload);
				art.view('dle_foreground').factory.source = app.model.roomView.currentForegroundItem.ItemDetails.ImageInformation.LargeImage.HttpImageURL;
				art.view('dle_foreground').update();	
				
			});
		}
		
		app.model.roomView.populateCustomRooms(true);
		
		onComplete();
	});
	
}	

app.model.roomView.getForegroundComponents = function() {
	// returns a collection of jvml Components that are rendering the foreground
	return $art.jvml.getComponentById('dle_foreground').components;
}

app.model.roomView.populateRoomSets = function(onComplete) {
	info('roomViewModel.js > populateRoomSets > begin.');
	var url = app.model.roomView.baseUrl+'data/DFLERoomImages.xml?v='+app.model.roomView.version;
	info('roomViewModel.js > populateRoomSets > url='+url);
	
	var xhr = new XMLHttpRequest();
	xhr.open('GET',url,true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState!=4) return;
		if (xhr.status!=200) {
			error('roomViewModel.js > ERROR: could not load static rooms!');
			return;
		}
		var text = xhr.responseText;
		info('roomViewModel.js > populateRoomSets > XHR is returning. text='+text.left(50));
		try {
			var xml = $art.XMLUtil.getXMLFromString(text);
			var json = $art.XMLUtil.xmlToJson(xml);
			
			app.model.roomView.roomSets = json.RoomImages.RoomType;
			
			var arr = [];
			for (var i = 0; i < json.RoomImages.RoomType.length; i++) {
				var roomSet = json.RoomImages.RoomType[i];
				for (var j = 0; j < roomSet.RoomImage.length; j++) {
					var img = roomSet.RoomImage[j];
					img.URL = 'http://cache1.artprintimages.com/'+img.URL;
					img.ThumbnailURL = 'http://cache1.artprintimages.com/'+img.ThumbnailURL;
					arr.push( img );
				}
			}
			
			//app.model.roomView.currentRoomSet = json.RoomImages.RoomType[0];
			app.model.roomView.currentRoomSet = arr;
			app.model.roomView.allRooms = arr;
			app.model.roomView.staticRooms = arr;
			app.model.roomView.bareWall = json.RoomImages.RoomType[0].RoomImage[0];
		} catch(e) {
			error('roomViewModel.js > populateRoomSets > ERROR: '+e);
		}
		
		onComplete.call(this);		
	}
	xhr.send();
	
	
};

app.model.roomView.populateCustomRooms = function(initialLoad) {
	if (MyGalleriesCore.getModel().user.isAccountTypeAnonymous()) {
		info('roomViewModel > populateCustomRooms > not running, because user is anonymous.');
		return;
	}
	
	var rvp = MyGalleriesCore.getRoomViewProxy()
	//var rvp = new com.art.myGalleries.proxies.RoomViewProxy();
	rvp.getBareWalls_userUploaded(function(rooms) { 
		
		var deletedRooms = localStorage.getItem('roomView_deletedRooms');
		if (!deletedRooms) deletedRooms = [];
		
		var arr = [];
		for (var i = 0; i < rooms.length; i++) {
			var room = rooms[i];
			var obj = {};
			obj.ThumbnailURL = room.ImageInformation.ThumbnailImage.HttpImageURL;
			obj.URL = room.ImageInformation.LargeImage.HttpImageURL;
			obj.WallAreaWidthInches = room.WallAreaWidthInches;
			obj.WallAreaHeightInches = room.WallAreaHeightInches;
			obj.WallAreaWidth = room.WallAreaWidth;
			obj.WallAreaHeight = room.WallAreaHeight;
			obj.UsableAreaWidth = room.UsableAreaWidth;
			obj.UsableAreaHeight = room.UsableAreaHeight;
			obj.DateCreated = room.DateCreated;
			obj.DateUpdated = room.DateUpdated;
			obj.isUserWall = true;
			if (typeof(obj.DateCreated)=='string') obj.DateCreated = obj.DateCreated.replace( /[^\d-]/g , '');
			if (typeof(obj.DateUpdated)=='string') obj.DateUpdated = obj.DateUpdated.replace( /[^\d-]/g , '');
			obj._original = room;
			
			if (deletedRooms.indexOf&&deletedRooms.indexOf(obj.URL)>-1) continue;
			
			arr.push(obj);
		}
		
		arr = arr.sort( function(a,b) {
			if (!a.DateUpdated || !b.DateUpdated) return 0;
			else if (a.DateUpdated > b.DateUpdated) return -1;
			else return 1;
		});
		
		app.model.roomView.allRooms = arr.concat(app.model.roomView.staticRooms);
		app.model.roomView.currentRoomSet = $art.ObjectUtil.copyArray(app.model.roomView.allRooms);
		app.model.roomView.bareWall = app.model.roomView.currentRoomSet[0];
		
		if (rooms.length>0&&app.view.roomView.measuring!=true) document.getElementById('roomView_measureRoomContainer').style.display='block';
		
		rvUpdate();
		
		//app.model.roomView.currentRoomSet.unshift( { ThumbnailURL: 'http://cache1.artprintimages.com/images/modules/roomView/UMR-txt.jpg', isUploadButton:true } );
		
		if (initialLoad) app.commands.roomView.restoreLastViewedRoom(); // restore last viewed on completion, but only on initial load; this function is also called whenever an upload completes
		
	});
};

app.model.roomView.getBarewallSize = function() {
	var bw = this.bareWall;
	var width = new app.model.measurement( app.model.roomView.bareWall.WallAreaWidthInches );
	var height = new app.model.measurement( app.model.roomView.bareWall.WallAreaHeightInches );
	return width.formatForDisplay() + ' x ' + height.formatForDisplay();
}


app.model.measurement = function(value, uom) {
	this.uom = uom;
	if (!this.uom) this.uom = app.model.unitOfMeasure.detectUOM();
	this.value = value;
	
	this.formatForDisplay = function() {
		var val = this.value * this.uom.inchConversion;
		switch (this.uom.name) {
			case 'inch':
				var ft = Math.floor( val/12 );
				var inc = Math.round(val % 12);
				var ft_str = ft > 0 ? ft+'\'' : '';
				var inc_str = inc+'"';
				return ft_str+inc_str;
			case 'cm':
				var m = Math.floor( val/100 );
				var cm = Math.round(val % 100);
				var m_str = m+'m ';
				var cm_str = cm+'cm ';
				return m_str+cm_str;
		}
	}
}
app.model.unitOfMeasure = function(args) {
	if (args) {
		this.name = args.name;
		this.inchConversion = args.inchConversion;
	}
};
app.model.unitOfMeasure.INCH = new app.model.unitOfMeasure({ name:'inch', inchConversion:1 });
app.model.unitOfMeasure.CM = new app.model.unitOfMeasure({ name:'cm', inchConversion:2.54 });
app.model.unitOfMeasure.detectUOM = function() {
	warn('app.model.roomView.getUOM > using ART-specific method of detecting unit of measure!');
	switch (window.location.href.indexOf('eu.')>-1 || window.location.href.indexOf('.co.uk')>-1) {
		case true: return app.model.unitOfMeasure.CM; 
		case false: return app.model.unitOfMeasure.INCH; 
	}
}

