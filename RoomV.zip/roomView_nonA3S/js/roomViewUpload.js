
app.view.roomView.getUploader = function() {
	// creates an uploader interface, abstracting either an HTML5/4 form field or a Flash uploader
	
	// step 1 - detect supported features
	var fileReader = typeof(FileReader) != 'undefined';
	var flash;
	if ( typeof(swfobject)=='undefined' ) { 
		warn('roomViewUpload > getUploader > WARNING: swfobject is undefined. Flash will detect as not supported, even though it may be! Ensure swfobject.js is included!'); 
		flash = false;
	} else
		flash = swfobject.hasFlashPlayerVersion('9.0.0');
	var touch = 'ontouchstart' in document.documentElement;
	
	// order of preference: native HTML5 > flash
	var uploader = null;
	switch (true) {
		case fileReader: 
			uploader = this.getUploader_fileReader();
			break;
		case !fileReader&&flash: 
			uploader = this.getUploader_flash();
			break;
		case !fileReader&&touch: 
			this.getUploader_showError('Error: touch device, no fileReader support. Insert iOS error message here.');
			return;
		case !touch&&!fileReader&!flash: 
			this.getUploader_showError('Error: no flash, no fileReader, no touch.');
			return;
		default: method='unknown';
	}
	
	// bind events
	uploader.done = this.handleDone;
	uploader.progress = this.handleProgress;
	uploader.error = this.handleError;
	uploader.callbacks.uploadStart = function() {
		$('#roomView_loadingIndicator').css('display','inline-block');
	}
	
	return uploader;	
}

app.view.roomView.handleProgress = function(e) {
	info('roomViewUpload.js > handleProgress > PROGRESS');
	info(e);
}
app.view.roomView.handleDone = function(responseText) {
	// success criteria:
	//  - response is valid XML
	//  - ResponseText field value = "Success"
	info('roomViewUpload.js > handleDone > begin.');

	var img;
	
	/* OLDER SERVICE USED XML RETURN SET 
	try {
		var xml = $art.XMLUtil.getXMLFromString( responseText );
		var json = $art.XMLUtil.xmlToJson( xml );
		iur = json.ImageUploadResponse;
	} catch(e) {
		error('app.view.roomView.handleDone > ERROR in parsing upload response. e to follow, then responseText');
		error(e);
		error(responseText);
		this.getUploader_showError('Sorry, there was a problem uploading your image. Please try again.');
	}
	*/
	try {
		var json = JSON.parse( responseText );
		img = json.Image;
	} catch(e) {
		error('app.view.roomView.handleDone > ERROR in parsing upload response. e to follow, then responseText');
		error(e);
		error(responseText);
		this.getUploader_showError('Sorry, there was a problem uploading your image. Please try again.');
	}
	
	info('roomViewUpload > handleDone > image upload response object to follow.');
	info(img);
	
	localStorage.setItem('roomView_lastRoom',null);
	
	app.view.roomView.createBarewall(img,function(result) {
		$('#roomView_loadingIndicator').css('display','none');	
		
		// check for errors
		if (typeof(result)=='object'&&result.OperationResponse&&result.OperationResponse.OperationStatus==-1) {
			error('app.view.roomView.handleDone > ERROR in creating bareWall. result to follow');
			error(result);
			app.view.roomView.getUploader_showError('Sorry, there was a problem uploading your image. Please try again.');			
		} else {
			app.model.roomView.populateCustomRooms();
			app.commands.roomView.openRoomBrowser('close');
			app.commands.roomView.measure();
		}
	});
	
}
var rvxml,rvjson;
app.view.roomView.handleError = function(responseText) {
	error('app.view.roomView.handleError > ERROR: '+responseText);
	this.getUploader_showError('Sorry, there was a problem uploading your image. Please try again.');
}

app.view.roomView.Uploader = function() {
	// must override
	this.open = function() {}; // should open the file browsing prompt
	this.check = function() {}; // should check file requirements and return an error message or true if no errors
	this.upload = function() {}; // should invoke upload
	this.done = function() {}; // should fire when done uploading
	this.progress = function() {}; // should fire on progress. arg1: object, format { lengthComputable: boolean, loaded: number, total: number }
	this.error = function() {}; // should fire when error occurs during upload
	this.callbacks = {
		uploadStart: function() {}
	}
	
	// optional override
	var apiUrl = MyGalleriesEnvironmentVariables.ApiEcommerceServiceUrl;
	if (isNullOrEmpty(apiUrl)) {
		error('roomViewUpload.js > ERROR: MyGalleriesEnvironmentVariables.ApiEcommerceServiceUrl is null or empty!');
		return;
	}
	apiUrl = apiUrl.replace( 'EcommerceAPI.svc' , 'ImageUpload/default.aspx?format=JSON' ); // different endpoints, plus I'm lazy
	this.destination = apiUrl;
	this.fileTypes = /^(?:image\/bmp|image\/cis\-cod|image\/gif|image\/ief|image\/jpeg|image\/jpeg|image\/jpeg|image\/pipeg|image\/png|image\/svg\+xml|image\/tiff|image\/x\-cmu\-raster|image\/x\-cmx|image\/x\-icon|image\/x\-portable\-anymap|image\/x\-portable\-bitmap|image\/x\-portable\-graymap|image\/x\-portable\-pixmap|image\/x\-rgb|image\/x\-xbitmap|image\/x\-xpixmap|image\/x\-xwindowdump)$/i;
	this.minFileSize = 0;
	this.maxFileSize = 20*1024*1024;
	this.checkFileType = function(type) {
		return this.fileTypes.test(type);
	}
	this.checkFileSize = function(size) {
		return !(size<this.minFileSize || size>this.maxFileSize);
	}

}

app.view.roomView.getUploader_fileReader = function() {
	// instantiate the input, if not already done
	if (!document.getElementById('roomView_uploader_fileReader')) {
		var node = document.createElement('input');
		node.setAttribute('type','file');
		node.setAttribute('id','roomView_uploader_fileReader');
		//node.style.display = 'none';
		//node.style.display = 'position: absolute; top: 50px; left: 50px; background: red; padding: 20px; z-index: 29500;';
		document.body.appendChild(node);		
	}
	
	var input = document.getElementById('roomView_uploader_fileReader');
	var uploader = new app.view.roomView.Uploader();
	
	uploader.open = function() { input.click(); };
	uploader.check = function() {
		var file = input.files[0];
		if ( !this.checkFileType(file.type) ) {
			this.getUploader_showError('Invalid file type.');
			return false;
		}
		return true;
	}
	uploader.upload = function() {
		var file = input.files[0];
		var fr = new FileReader();
		fr.onload = function(e) { 
			if ( !e || !e.target || !e.target.result ) { 
				error('roomViewUpload.js > getUploader_fileReader > weird error using FileReader. Aborting...');
				this.getUploader_showError();
				return;
			}
			
			var base64 = e.target.result;
			base64 = base64.substr( base64.indexOf('base64,') +7  );
			var xml = "<image><imagedata>"+base64+"</imagedata></image>";
			
			//var params = { imageXml: xml };
			
			var params = 'imageXml='+encodeURIComponent(xml);
			params = params.replace(/%20/g, '+');
			
			/*
			if (true) {//!$apiSessionId) {
				var serviceUrl = 'http://qa-api.art.com/ECommerceAPI.svc';
				var sp = new com.art.core.services.ServiceProvider(
					 {
						serviceUrlEcommerceApi: serviceUrl
					}
				);
				var api = sp.ecommerceAPIService;
				var apiKey = 'AAB349013DDE43D29585BAD7C272CA36';
				var appId = '86627B368CCE4AB5AEF60B710BE521C1';
				var authToken = MyGalleriesEnvironmentVariables.authToken;
					
				var callbacks = {
					successHandler: function(response) {
						info('INIT API RESPONSE:');
						info(response);
						var sessionId = response.SessionId;
						
						var op = 'ImageUpload';
						var p = [
							['apiKey',apiKey],
							['authToken',authToken],
							['imageXml',xml]
						]

						var url = sp.getUrl(serviceUrl, op, p);
						sp.doRequest(url,{
							errorHandler: function(){},
							beforeSendHandler: function(){},
							successHandler:function(response){
								info('IMAGE UPLOAD RESPONSE:');
								info(response);
							}
						});
						
					},
					beforeSendHandler: function() {},
					errorHandler: function() {}
				};	
				api.initializeApi( callbacks, apiKey, appId, 'US', 'en', '' );
					
			}
			
			
			
			return;
			*/
			
			var apiKey = 'AAB349013DDE43D29585BAD7C272CA36';
			var appId = '86627B368CCE4AB5AEF60B710BE521C1';
			
			//var params = 'imageXml='+xml;
			//params = params.replace(/%20/g, '+');
			
			var formData = new FormData();
			//formData.append("imagexml", xml);
			formData.append('thefile',file);
			
			formData.append('apiKey',apiKey);
			formData.append('persistentId','unknown-persistentId-askAOCHTINSKY');
			
			var xhr, upload;
			
			function done(e) {
				info(e);
				uploader.done();
			}
	
			// where's the IE support, you might ask? XDomain and all that?
			// well, since File API isn't supported, there isn't much reason to support XDomain; we'll just use Flash

			xhr = new XMLHttpRequest();
			upload = xhr.upload;
			upload.xhr = xhr;
			upload.addEventListener( 'progress' , uploader.progress );
			//upload.addEventListener( 'load' , done );
			xhr.onreadystatechange = function() {
				//info('readyState:'+xhr.readyState);
				//info('status:'+xhr.status);
				if (xhr.readyState==4) {
					if (xhr.status==200) {
						uploader.done(xhr.responseText);
					} else {
						uploader.error(xhr.responseText);
					}
				}
			};
			xhr.open('POST',uploader.destination+'&rnd='+Math.random());
			//xhr.setRequestHeader('Content-Type','text/plain');
			//xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			error('roomViewUpload.js > uploader.upload > sending image to: '+uploader.destination);
			xhr.send(formData);
			
			uploader.callbacks.uploadStart();			
		}
		fr.readAsDataURL(file);		
	}
	input.onchange = function(e) {
			/*
			info('e='+e);
			info('e.target='+e.target);
			info('e.target.files='+e.target.files);
			info('e.target.files.length='+e.target.files.length);
			for (var i = 0; i < e.target.files.length; i++) {
				info('File #'+i+': '+e.target.files[i]);
			}
		*/
		if ( !uploader.check() ) return;
		uploader.upload();
	}
	
	return uploader;
}

app.view.roomView.getUploader_showError = function(str) {
	//$art.jvml.getComponentById('roomView_uploadMessage').text = str;
	$('#roomView_uploadMessage').html(str);
	//$art.jvml.getComponentById('roomView_uploadMessage').update();
	art.view('roomView_uploadMessageModal').open();
}
	



	
app.view.roomView.showUploadModal = function() {
	// shows a modal, allowing upload of user images
	var _this = this;
	
	var popupTemplate = 
		'<div id="mg_roomview_uploadmodal_closebutton" class="mg_roomview_uploadmodal_cancel"></div>'+
		'<h1>Upload a Room</h1>'+
		'<div id="mg_roomview_uploadmodal_content">'+
			'<div class="mg_roomview_uploadmodal_error">{~error~}</div>'+
			'<div id="mg_roomview_uploadmodal_flashtarget"></div>'+
		'</div>'+
		'<div id="mg_roomview_uploadmodal_buttons">'+
			'<span id="mg_roomview_uploadmodal_cancel" class="silver_button medium mg_roomview_uploadmodal_cancel">Cancel</span>'+
			'<span id="mg_roomview_uploadmodal_continue" class="orange_button medium">Continue</span>'+
		'</div>';
	
	// detect flash
	var hasFlash = swfobject.hasFlashPlayerVersion('9.0.0');
			
	// create popup
	//  -- remove any previous popups
	$('#mg_roomview_uploadmodal').remove();	
	//  -- create the element
	var popup = document.createElement('div');
	popup.id = 'mg_roomview_uploadmodal';
	//  -- render content
	popup.innerHTML = popupTemplate;
	popup.innerHTML = popup.innerHTML.replace( '{~error~}' , hasFlash?'':'Sorry, uploading images requires the Flash Player.' );
	//  -- append to body
	document.body.appendChild(popup);
	

	// send in the Flash!
	var uploadServiceUrl = MyGalleriesEnvironmentVariables.imageAppServiceUrl;
	uploadServiceUrl = uploadServiceUrl.replace( /\/UploadSearchImage/g , '' );
	uploadServiceUrl += '/UploadImage';
	var flashvars = {
		"notify":"app.view.roomView.handleNotification",
		"disable":'disable',
		"enable":'enable',
		"uploadComplete":'uploadComplete',
		"uploadService": uploadServiceUrl,
		"minSize": 0, 
		"type":"file"
	};
	var params = {"wmode":"transparent","AllowScriptAccess":"always"};
	var attributes = {};
	swfobject.embedSWF("/swfs/UploaderMin.swf", "mg_roomview_uploadmodal_flashtarget", "500", "71", "10", "/swfs/expressInstall.swf",flashvars,params,attributes);
	
	// pop up in center, make draggable
	$('#mg_roomview_uploadmodal').centerNoDropShadow(true);
	//try { $('#mg_roomview_uploadmodal').draggable(); } catch(e) {};
	$('.mg_roomview_uploadmodal_cancel').click(function() {
		$('#mg_roomview_uploadmodal').remove();
	});
	$('#mg_roomview_uploadmodal_continue').click(function() {
		getMovie('mg_roomview_uploadmodal_flashtarget').startUpload();
	});
};
app.view.roomView.handleNotification = function(notification) {
	info(notification);
	switch(notification.name) {
		case 'uploadComplete': app.view.roomView.handle_dleImageUploadComplete(notification); break;
	}
};
app.view.roomView.handle_dleImageUploadComplete = function(note) {
	// handles the notification sent by the Flash Uploader
	var roomView = this;
	
	MyGalleriesCore.getRoomViewProxy().createBarewallFromImageUploadService(note.body,function(response) {
		var err = '';
		try { err = response.OperationResponse.ResponseMessage; }
		catch(e) { err = 'unknown error'; };
		if (err!='Success') {
			// error!
			$('.mg_roomview_uploadmodal_error').html(err);
		} else {
			// success!
			$('#mg_roomview_uploadmodal').hide(500,function() {
				$('#mg_roomview_uploadmodal').remove();
			});
			MyGalleriesCore.getRoomViewProxy().getBareWalls_userUploaded(function(userWalls) {
				localStorage.setItem('roomView_lastRoom',null);
				app.model.roomView.populateCustomRooms();
				app.commands.roomView.measure();
				rvUpdate();
			});
		}
		
	});	
};



app.view.roomView.createBarewall = function(imageUploadResponse, onComplete) {
	// imageUploadResponse: JSO format from gallery service
	var barewall = {};
	var iur = imageUploadResponse;
	
		/*
	var imgXml = com.art.core.utils.XMLUtil.getXMLFromString(imageUploadResponse.Image.replace(/\[\[BACKSLASH\]\]/g,'\\'));
	var img = {};
	img.LargeImage = { HttpImageURL:com.art.core.utils.XMLUtil.getTextFromUniqueNodeInXml(imgXml,'LrgImageUrl') };
	img.MediumImage = { HttpImageURL:com.art.core.utils.XMLUtil.getTextFromUniqueNodeInXml(imgXml,'MedImageUrl') };
	img.SmallImage = { HttpImageURL:com.art.core.utils.XMLUtil.getTextFromUniqueNodeInXml(imgXml,'SmlImageUrl') };
		*/
	
	barewall.BareWallId = "0";
	barewall.IsAngledRoom = false;
	barewall.RoomAngle = 0;
	barewall.ImageInformation = null; //img;
	//barewall.UsableAreaWidth = iur.Image.OrigW;
	barewall.UsableAreaWidth = iur.OrigW;
	//barewall.UsableAreaHeight = iur.Image.OrigH;
	barewall.UsableAreaHeight = iur.OrigH;
	barewall.UsableAreaPosY = 0;
	barewall.UsableAreaPosX = 0;
	barewall.ProductTargetAreaPosX = 0;
	barewall.ProductTargetAreaPosY = 0;
	barewall.WallAreaWidth = barewall.UsableAreaWidth;
	barewall.WallAreaHeight = barewall.UsableAreaHeight;
	barewall.WallAreaWidthInches = 10 * 12;
	barewall.WallAreaHeightInches = barewall.WallAreaWidthInches * (barewall.UsableAreaHeight/barewall.UsableAreaWidth);
	barewall.RulerLength = 0;
	barewall.Guide1Y = 0;
	barewall.Guide2Y = 0;
	barewall.RulerX1 = 0;
	barewall.RulerX2 = 0;
	barewall.RulerY1 = 0;
	barewall.RulerY2 = 0;
	barewall.RulerLength = 0;
	barewall.Caption = "caption";
	//barewall.WallImageGUID = iur.Image.ImageGUID;
	barewall.WallImageGUID = iur.ImageGUID;
	
	var icr = -1;
	var icr2 = Number(barewall.UsableAreaWidth) / (10*12);
	if (!isNaN(icr2)) icr = icr2;
	
	barewall.InchesConversionRate =  icr;
	
	var rvp = MyGalleriesCore.getRoomViewProxy();
	rvp.createBarewall(barewall,onComplete);
}