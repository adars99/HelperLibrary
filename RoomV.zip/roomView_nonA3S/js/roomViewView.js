if (!app.view) app.view = {};
if (!app.view.roomView) app.view.roomView = {};

	
app.view.roomView.initialize = function() {
	com.art.core.controller.Controller.register( 'roomView_changeRoomToggle' , app.view.roomView.handleChangeRoomToggle , app.view );
	com.art.core.controller.Controller.register( 'moduleLoaded' , app.view.roomView.handleLoad , app.view );
};
app.view.roomView.handleChangeRoomToggle = function(data) {
	switch (data) {
		case 'open': 
			$('#roomInfo').hide();
			UIUtil.fadeOut( document.getElementById('roomView_measureRoomContainer') , 250 );
			break;
		case 'closed': case 'close': 
			$('#roomInfo').show(); 
			if (app.model.roomView.bareWall.isUserWall) UIUtil.fadeIn( document.getElementById('roomView_measureRoomContainer') , 250 , function(){document.getElementById('roomView_measureRoomContainer').style.opacity=0.66; } );
			break;
	}
};

app.view.roomView.initRoomDrawer = function() {
	//if (app.view.roomView.initRoomDrawer.runOnce) return; else app.view.roomView.initRoomDrawer.runOnce = true;
	var rbHeight = document.getElementById('currentRoomsetBrowser').offsetHeight;//$('#currentRoomsetBrowser').height();//
	var targetY = -rbHeight;
	var height = rbHeight + 22;
	/*
	error('rbHeight='+rbHeight);
	error('targetY='+targetY);
	error('height='+height);
	*/
	app.global.roomView.roomBrowserTargetY = -rbHeight;
	document.getElementById('roomBrowser').style.height = height+'px';
	//document.getElementById('roomBrowser').style.bottom = -height+'px';
}

app.view.roomView.handleLoad = function(payload) {
	// to do: verify in payload that this is the right module
	info(payload);
	
	//app.view.roomView.initRoomDrawer();
}

// also see roomViewUpload and roomViewMeasure...these are still part of the view.roomView namespace	
