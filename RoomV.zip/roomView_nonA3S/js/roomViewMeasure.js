// ********************************* MEASURE WITH RULER *********************
app.view.roomView.startMeasuringWithRuler = function() {
	// enters "measure mode", wherein the user is using a ruler tool to change the measurement of a barewall
	// notes:
	//  -- should not be possible if in view mode, or if current bareWall is not user-uploaded
	
	this.measuring = true;
	
	var roomView = this;
	var startX;
	var startY;
	var containerOffset;
	var hasMeasurement = false;
	
	// create and bind cursor
	//  -- cursor should look like a ruler, but only when inside the RoomView
	//  -- onmousedown (within background area), start drawing a ruler
	//  -- onmouseup, end drawing the ruler; if cursor wasn't inside background area, ignore
	//  -- ruler should only be visible inside background (should be easy with overflow: hidden)
	$('#roomView_rulerSpace').addClass('roomView_hasRulerCursor');
	$('#roomView_rulerSpace').css('display','block');

	// this DIV will block mouse events behind it, and serve as a click target for IE
	if ($('#roomView_rulerSpace').length==0)
		$('#dle').append('<div id="roomView_rulerSpace">&nbsp;</div>');
	
	// show dialog
	var dialogTemplate = '<div id="mg_roomView_rulerDialog">'+
			'<div id="mg_roomView_rulerDialog_beforeMeasure">'+
				'<h2>Calibrate</h2>'+
				'<p>Click and drag between two points to measure a known distance.</p>'+
			'</div>'+
			'<div id="mg_roomView_rulerDialog_afterMeasure">'+
				'<p>Enter length and select unit of measure.</p>'+
				'<input id="mg_roomView_rulerDialog_measurement" type="text" />'+
				'<select id="mg_roomView_rulerDialog_unitOfMeasure">'+
					'<option>inches</option>'+
					'<option>feet</option>'+
					'<option>cm</option>'+
					'<option>meters</option>'+
				'</select>'+
			'</div>'+
			'<div>'+
				'<span class="silver_button medium" id="mg_roomView_rulerDialog_cancel">Cancel</span>'+
				'<span class="orange_button medium" id="mg_roomView_rulerDialog_apply">Apply</span>'+
			'</div>'+
			'<div id="mg_roomView_rulerDialog_success">Calibration successful!</div>'+
		'</div>';
	if ($('#mg_roomView_rulerDialog').length==0) {
		$('#mg_roomView_editmode_foreground').append(dialogTemplate);
		$('#mg_roomView_rulerDialog_apply').click(function() {
			calculateRoomWidth();
			endMeasure();
		});
		$('#mg_roomView_rulerDialog_cancel').click(function() {
			endMeasure();
		});
		dialogBeforeMeasure();
	};	
	function dialogBeforeMeasure() {
		$('#roomView_measureModal_step1').addClass('active');
		$('#roomView_measureModal_step1').removeClass('inactive');
		
		$('#roomView_measureModal_step2').removeClass('active');
		$('#roomView_measureModal_step2').addClass('inactive');
		
		if ($.browser.msie) {
			document.getElementById('roomView_measureModal_input').disabled = true;
			document.getElementById('roomView_measureModal_units').disabled = true;
		} else {
			// IE inexplicably can't handle this
			$('#roomView_measureModal_input').attr('disabled','true');		
			$('#roomView_measureModal_units').attr('disabled','true');
		}
		
		//$('#roomView_measureModal_calibrate').attr('disabled','true');
		art.view('roomView_measureModal_calibrate').disable();
	};
	function dialogAfterMeasure() {		
		// activate part 1, disable part 2	
		$('#roomView_measureModal_step1').removeClass('active');
		$('#roomView_measureModal_step1').addClass('inactive');
		
		$('#roomView_measureModal_step2').removeClass('inactive');
		$('#roomView_measureModal_step2').addClass('active');
		
		if ($.browser.msie) {
			document.getElementById('roomView_measureModal_input').disabled = false;
			document.getElementById('roomView_measureModal_units').disabled = false;
		} else {	
			// IE inexplicably can't handle this		
			$('#roomView_measureModal_input').removeAttr('disabled');
			$('#roomView_measureModal_units').removeAttr('disabled');
		}
		//$('#roomView_measureModal_calibrate').removeAttr('disabled');
		art.view('roomView_measureModal_calibrate').enable();
		$(document.body).removeClass('noSelect');
		
	};
	function endMeasure() {
		$('#roomView_rulerSpace').remove();
		$('#roomView_ruler').hide();
		$('#roomView_dleContainer').removeClass('mg_roomView_hasRulerCursor');
		$('#mg_roomView_rulerDialog').remove();
		$(document.body).removeClass('noSelect');
	};
	
	

	// and here's the actual ruler
	if ($('#roomView_rulerSpace').length==0)
		$('#roomView_rulerSpace').append('<div id="roomView_ruler"></div>');
	
	
	// bind ruler space
	if (prd_roomView_touch) document.getElementById('roomView_rulerSpace').addEventListener( 'touchstart' , function(e) { info('touchstart'); startRuler(e); }); 
	else { error('CONDITION BETA'); 
		document.getElementById('roomView_rulerSpace').onmousedown = startRuler;
		//$('#roomView_rulerSpace').on('mousedown',startRuler); 
	}
	
		
	function startRuler(e) {	
		info('startRuler');
		if (!e&&event) e = event; // IE8 support
		
		if (e.preventDefault) e.preventDefault(); // stop touch devices from treating this as a mousedown; it is a touchmove start
		
		$('#roomView_ruler').show(); // show ruler
		
		hasMeasurement = false;
		
		// set ruler start x, y
		if (e.offsetX) {
			// yay! your browser doesn't suck!
			startX = e.offsetX;
			startY = e.offsetY;
		} else {
			containerOffset = UIUtil.getPageOffset(document.getElementById('roomView_rulerSpace'));
			if (e.touches) {
				try { document.getElementById('iPadDebugHUD').innerHTML = 'touches='+e.touches+', touches[0]='+e.touches[0]+', touches[0].pageX='+touches[0].pageX; } catch(e) { error(e) }					
				startX = e.touches[0].pageX - containerOffset.x;
				startY = e.touches[0].pageY - containerOffset.y;
			} else {
				//try { document.getElementById('iPadDebugHUD').innerHTML = 'no touch'; } catch(e) { error(e) }					
				startX = e.pageX - containerOffset.x;
				startY = e.pageY - containerOffset.y;
			}
		}
		
		info('startX='+startX+', startY='+startY);
		
		$('#roomView_ruler').css( 'left' , startX+'px' );
		$('#roomView_ruler').css( 'top' , startY+'px' );
		// set mousemove
		/////////$(document).on('mousemove',':not(#roomView_ruler)',handleMouseMove);
		if (prd_roomView_touch) document.getElementById('roomView_rulerSpace').addEventListener( 'touchmove' , function(e) { info('touchmove2'); handleMouseMove(e); }); 
		else $(document).on('mousemove','#roomView_rulerSpace',handleMouseMove);
		
		if (prd_roomView_touch) document.getElementById('roomView_rulerSpace').addEventListener( 'touchend' , function(e) { info('touchend'); stopRuler(e); }); 
		else UIUtil.bind( document.getElementById('roomView_rulerSpace') , 'mouseup' , stopRuler, true );
		//$(document).on('mouseup','#roomView_rulerSpace',stopRuler);
		
		
		function stopRuler(e) {
			if (!e&&event) e = event; // IE8 support
			
			try {
			info('stopRuler');
			info(e);
			info(e.srcElement);
			info(e.srcElement.id);
			}catch(e) {}
			// cancel mousemove
			///////$(document).off('mousemove',':not(#roomView_ruler)',handleMouseMove);
			$(document).off('mousemove','#roomView_rulerSpace',handleMouseMove);
			$(document).off('touchmove','#roomView_rulerSpace',handleMouseMove);
			
			// update dialog...only if they actually made a measurement
			//if (hasMeasurement&&$('#roomView_ruler').position().top!='0') 
			dialogAfterMeasure();
			
			// while moving ruler, dialog was behing rulerSpace DIV so it didn't catch mouse events
			//  -- now it must be placed in front, so it can interact
			//$('#mg_roomView_rulerDialog').insertAfter('#mg_roomView_rulerSpace');
			//$('#roomView_rulerSpace').insertBefore('#roomView_rulerDialog');
		}
		
		// show debug
		/*
		if ($('#mg_roomView_rulerDebug').length==0) {
			$('#mg_roomView_editmode_foreground').append(com.art.myGalleries.modules.RoomView.prototype.rulerDebugTemplate);
		};
		*/
		
		// while moving ruler, put dialog behind rulerSpace DIV so it doesn't catch mouse events
		//$('#mg_roomView_rulerDialog').insertBefore('#mg_roomView_rulerSpace');
		//$('#roomView_rulerSpace').insertAfter('#roomView_rulerDialog');
		
		$(document.body).addClass('noSelect'); // prevents text selection
		document.body.onselectstart = function () { return false; } // prevents cursor override in Chrome
	};
	function handleMouseMove(e) {		
		info('mousemove');
		if (!e&&event) e = event;
		e.preventDefault();
			if (e.srcElement && e.srcElement.id=='roomView_ruler') return;
			
			//var x1 = $('#mg_roomView_ruler').position().left;
			//var y1 = $('#mg_roomView_ruler').position().top;
			var x1 = startX;
			var y1 = startY;
			
			/*
			var t = $('#mg_roomView_ruler');
			var yy1 = Math.round(y1);
			var o = Math.round(t.offset().top);
			var p = t.offsetParent();
			var pid = p.attr('id');
			var po = Math.round(p.offset().top);
			var m = t.css('marginTop');
			var pm = p.css('marginTop');
			var pb = p.css('borderTopWidth');
			info('yy1='+yy1+' o='+o+' po='+po+' m='+m+' pm='+pm+' pb='+pb);
			*/
			
			var x2, y2;
			if (e.offsetX) {
				// yay! your browser doesn't suck!
				x2 = e.offsetX;
				y2 = e.offsetY;
			} else {
				//x2 = e.pageX - containerOffset.x;
				//y2 = e.pageY - containerOffset.y;
				if (e.touches) {
					x2 = e.touches[0].pageX - containerOffset.x;
					y2 = e.touches[0].pageY - containerOffset.y;
					info('tx='+e.touches[0].pageX);
				} else {
					x2 = e.pageX - containerOffset.x;
					y2 = e.pageY - containerOffset.y;
				}
			}
			
			info('x2='+x2+', y2='+y2);
			
			
			var dx = x2 - x1;
			var dy = y2 - y1;
			
			//info('dx='+dx+', dy='+dy);
			
			var h = Math.sqrt( Math.pow(dx,2) + Math.pow(dy,2) );
			//h *= 0.75;
			info('h='+h);
			app.view.roomView._currentMeasurement = h;

			// change ruler width, height
			$('#roomView_ruler').width( h );
			
			// rotate!
			var rads = Math.atan2(dy,dx);
			var degs = rads / (2*Math.PI) * 360;
			info('degs='+degs);
			var css = 'rotate('+degs+'deg)';
			
			
			/*
			setRulerStyle('msTransform',css);
			*/
			//document.getElementById('ruler').style.filter = 'progid:DXImageTransform.Microsoft.BasicImage(rotation='+(Math.round(degs/90))+');';
			
			if ($.browser.msie) {
				if (parseFloat($.browser.version)<10) {
					if (dy<0) setRulerStyle('marginTop',(dy)+'px');
					if (dx<0) setRulerStyle('marginLeft',(dx)+'px');
					fnSetRotation( document.getElementById('roomView_ruler') , rads );
				} else {
					
					setRulerStyle('msTransform',css);	
				}
			} else {
				setRulerStyle('webkitTransform',css);
				setRulerStyle('mozTransform',css);	
				setRulerStyle('transform',css);			
			}
			
			hasMeasurement = true;
			
			/*
			document.getElementById('x1').innerHTML = x1;
			document.getElementById('y1').innerHTML = y1;
			document.getElementById('x2').innerHTML = x2;
			document.getElementById('y2').innerHTML = y2;
			document.getElementById('dx').innerHTML = dx;
			document.getElementById('dy').innerHTML = dy;
			document.getElementById('h').innerHTML = h;			
			//document.getElementById('t').innerHTML = e.currentTarget.tagName + '[id=' + e.currentTarget.id +']';
			document.getElementById('t').innerHTML = e.srcElement.id;
			document.getElementById('rads').innerHTML = rads;
			document.getElementById('degs').innerHTML = degs;
			document.getElementById('degs').innerHTML = degs;
			*/
		};
		function fnSetRotation(oObj, rad)
		{
		    costheta = Math.cos(rad);
		    sintheta = Math.sin(rad);

		    a = parseFloat(costheta).toFixed(8);
		    c = parseFloat(-sintheta).toFixed(8);
		    b = parseFloat(sintheta).toFixed(8);
		    d = parseFloat(costheta).toFixed(8);
	/*
		    document.getElementById("fM11").value = a;
		    document.getElementById("fM12").value = c;
		    document.getElementById("fM21").value = b;
		    document.getElementById("fM22").value = d;
		    */

		    if (oObj.filters) {
			oObj.filters.item(0).M11 = costheta;
			oObj.filters.item(0).M12 = -sintheta;
			oObj.filters.item(0).M21 = sintheta;
			oObj.filters.item(0).M22 = costheta;
		    } else {
			   // oObj.setAttribute("style", "position:absolute; -moz-transform:  matrix(" + a + ", " + b + ", " + c + ", " + d + ", 0, 0); -webkit-transform:  matrix(" + a + ", " + b + ", " + c + ", " + d + ", 0, 0); -o-transform:  matrix(" + a + ", " + b + ", " + c + ", " + d + ", 0, 0);");
			   setRulerStyle('webkitTransform','matrix('+a+','+b+','+c+','+d+',0,0)');
			   setRulerStyle('mozTransform','matrix('+a+','+b+','+c+','+d+',0,0)');
			   setRulerStyle('msTransform','matrix('+a+','+b+','+c+','+d+',0,0)');
		    }

		};
		function setRulerStyle(name,css) {
			var e = document.getElementById('roomView_ruler');
			//if (typeof(e.style[name])!='undefined') e.style[name] = css;
			e.style[name] = css;
		};
};
app.view.roomView.calculateRoomWidth = function() {		
	// get current width of the ruler, in px
	//var rulerWidth = $('#roomView_ruler').width();
	var rulerWidth = app.view.roomView._currentMeasurement;
	
	// compare to width of background image
	//var backgroundWidth = $('#dle_background').width();
	var backgroundWidth = $('#bareWallImg').width(); // the actual background image.
	var rulerWidthPercent = rulerWidth/backgroundWidth;
	
	info('roomViewMeasure > calculate RoomWidth > begin unlabeled debug text.');
	info('rulerWidth='+rulerWidth);
	info('backgroundWidth='+backgroundWidth);
	info('rulerWidthPercent='+rulerWidthPercent);
	
	// get user measurement
	var measurement = $('#roomView_measureModal_input').val();
	if (measurement==''||isNaN(measurement)||parseFloat(measurement)<0) {
		$('#roomView_measureModal_error').show();
		$('#roomView_measureModal_error').html('Please enter a valid number.');
		return;
	}
	$('#roomView_measureModal_error').hide();
	$('#roomView_measureModal_error').html('');
	var unit = $('#roomView_measureModal_units').val();
	var finalMeasurement = -1;
	switch(unit) {
		case 'Feet': finalMeasurement = measurement * 12; break;
		case 'Centimeters': finalMeasurement = measurement * 0.393701; break;
		case 'Meters': finalMeasurement = measurement * 39.3701; break;
		default:
		case 'Inches': finalMeasurement = measurement; break;
	};
	
	info('finalMeasurement='+finalMeasurement+' inches');
	
	// determine final wall width
	var wallWidth = finalMeasurement * (1/rulerWidthPercent);
	info('wallWidth='+wallWidth+' inches');
	
	app.model.roomView.bareWall.WallAreaWidthInches = wallWidth;
	var aspect = app.model.roomView.bareWall.WallAreaWidth / app.model.roomView.bareWall.WallAreaHeight;
	app.model.roomView.bareWall.WallAreaHeightInches = app.model.roomView.bareWall.WallAreaWidthInches / aspect;
	app.model.roomView.bareWall.InchesConversionRate = app.model.roomView.bareWall.WallAreaWidth / app.model.roomView.bareWall.WallAreaWidthInches;
	
	app.commands.roomView.updateDLE();
	
	// send updateBarewall
	//error('RoomView > startMeasuringWithRuler > calculateRoomWidth > not sending updateBareWall!');
	var rvp = MyGalleriesCore.getRoomViewProxy();
	bareWall = app.model.roomView.bareWall._original;
	bareWall.WallAreaWidthInches = app.model.roomView.bareWall.WallAreaWidthInches;
	bareWall.WallAreaHeightInches = app.model.roomView.bareWall.WallAreaHeightInches;
	bareWall.InchesConversionRate = app.model.roomView.bareWall.InchesConversionRate;
	
	info('roomViewMeasure > attempting to send updateBarewall with following bareWall object...');
	info(bareWall);
	
	rvp.updateBarewall(bareWall,function(response) {
		var err = '';
		try { err = response.OperationResponse.ResponseMessage; }
		catch(e) { err = 'unknown error'; };
		if (err!='Success') {
			// error!
			error('roomViewMeasure > ERROR sending updateBarewall: '+err);
			error(response);
		} else {
			// success!
			info('roomViewMeasure > updateBarewall successful');
		}
	});
	
	rvUpdate();
	
	// close calibration window
	app.view.roomView.endMeasure();
	
	// close room browser
	app.commands.roomView.closeRoomBrowser();
};
app.view.roomView.endMeasure = function(options) {
	// stops measuring. does not calibrate, just removes measure UI	
	
	$('#roomView_ruler').hide();
	$('#roomView_rulerSpace').removeClass('roomView_hasRulerCursor');
	$('#roomView_rulerSpace').css('display','none');
	if(!options||!options.noModalClose) $art.jvml.getComponentById('roomView_measureModal').close();
	
	$('#roomView_measureRoomContainer').show();
	
	this.measuring = false;
	$('#roomView_measureLightbox').hide();
}
