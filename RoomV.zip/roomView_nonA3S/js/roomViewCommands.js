if (!app) var app = {};
if (!app.commands) app.commands = {};
if (!app.commands.roomView) app.commands.roomView = {};

app.commands.roomView.start = function() {
	
	setTimeout( function() {
		if (MyGalleriesCore.getModel().user.isAccountTypeAnonymous()) $('#roomView_uploadButton').addClass('hidden'); // not ready to hide() just yet
		else $('#roomView_uploadLogin').addClass('hidden');
	}, 250 );
	
	info('roomViewCommands.js > start > calling populateModel.');
	app.model.roomView.populateModel(function() {
		app.view.roomView.initialize();
		$art.databind(app,'model');
		//app.commands.roomView.positionImage();
		
		$roomViewReady = true;
		
		app.commands.roomView.restoreLastViewedRoom();
		
	});
}

	
	
app.commands.roomView.checkOS = function() {
	return;
	
	var userAgent = navigator.userAgent.toLowerCase();	
	var isMac107 = /Mac OS X 10_7/.test(userAgent);
	var isMac108 = /Mac OS X 10_8/.test(userAgent);
		
	if (isMac107||isMac108) {
		app.global.roomView.roomBrowserTargetY = -94;
		$art.g('roomBrowser').style.height = '114px';
		$art.g('roomBrowser').style.top = '-94px';
		app.global.roomView.isMacOSXLion = true;
	}
}
	
app.commands.roomView.setBareWall = function(obj) {
	var i;
	if (typeof(obj)=='number') {
		i = app.model.roomView.bareWall.i;
		i += obj;
		if (i > app.model.roomView.currentRoomSet.length-2) i = app.model.roomView.currentRoomSet.length-1;
		if (i < 0) i = 0;
	} else if (typeof(obj)=='object'&&obj.index!=null) {
		i = obj.index;
	} else {
		i = obj.getAttribute('data-index');
	}
	var newRoom = app.model.roomView.currentRoomSet[i];
	if (newRoom.isUploadButton) {
		error('app.commands.roomView.setBareWall > called on an upload button. this shouldn\'t be possible anymore. aborting...');
		this.upload();
		return;
	}
	app.model.roomView.bareWall = newRoom;
//	app.commands.roomView.positionImage();
	app.commands.roomView.openRoomBrowser('closed');
		
	if (i <= 0) $art.g('prevRoom').style.visibility = 'hidden'; else $art.g('prevRoom').style.visibility = 'visible'; 
	if (i >= app.model.roomView.currentRoomSet.length-1) $art.g('nextRoom').style.visibility = 'hidden'; else $art.g('nextRoom').style.visibility = 'visible'; 
	
	app.view.roomView.endMeasure(); // close the calibration tool if open
	
	if (localStorage) {
		localStorage.setItem('roomView_lastRoom',newRoom.ThumbnailURL);
	}
	
	if (newRoom.isUserWall) $('#roomView_measureRoomContainer').show();
	else $('#roomView_measureRoomContainer').hide();
}
app.commands.roomView.toggleGalleryItem = function(obj) {
	var i = obj.getAttribute('data-index');
	var gi = galleryDetails.Library.Galleries[0].Walls[0].WallItems[i];
	
	// disable if on foreground
	
	app.commands.roomView.enableForegroundItem(app.model.roomView.foregroundItems[i],'toggle');
	
	//com.art.core.jvml.Databinding.requestUpdate({object:room,propertyName:'foregroundItems',value:null});
}

app.commands.roomView.getForegroundItems = function () {
	
	var item = {
		ItemGalleryItemID: 12345,
		enabled: true,
		ItemDetails: { 
			ImageInformation: { LargeImage: { HttpImageURL: $roomViewData.imageUrl } },
			PhysicalDimensions: { Width: $roomViewData.inchWidth, Height: $roomViewData.inchHeight }
		},
		pixelWidth: $roomViewData.pixelWidth,
		horizontalCenter: $roomViewData.horizontalCenter,
		verticalCenter: $roomViewData.verticalCenter
	};
	
	app.commands.roomView.enableForegroundItem(item,true);
	
	return [ item ];
	
	
	/*
	var galleryItems = galleryDetails.Library.Galleries[0].Items;
	var wallItems = galleryDetails.Library.Galleries[0].Walls[0].WallItems;
	var arr = [];
	
	for (var i = 0; i < galleryItems.length; i++) {
		arr.push(galleryItems[i]);
		var isEnabled = false;
		for (var  j = 0; j < wallItems.length; j++) {
			if (wallItems[j].Item.ItemGalleryItemID == galleryItems[i].ItemGalleryItemID) {
				if (galleryItems[i].ItemGalleryItemID!='1585171') continue; // hack
				isEnabled = true;
				break;
			}
		}
		enableForegroundItem(arr[i],isEnabled);		
	}
	
	return arr;
	*/
}

app.commands.roomView.enableForegroundItem = function (item,enabled) {
	if (enabled=='toggle') enabled = !item.enabled;
	
	item.enabled = enabled;
	//if (!item.x) item.horizontalCenter = $art.g('dle').offsetWidth / 2;
	//if (!item.y) item.verticalCenter = $art.g('dle').offsetHeight / 2;
	
	// calculate scale
	// my data is broken, apparently, so...

	if (!app.model.roomView.bareWall) return;
	var bwi = app.model.roomView.bareWall.WallAreaWidthInches;
	var bwp = app.model.roomView.bareWall.WallAreaWidth;
	var icr = bwi/bwp;
	var fwi = item.ItemDetails.PhysicalDimensions.Width;
	var fwp = fwi/icr;
	
	item.pixelWidth = fwp;	
}

app.commands.roomView.selectBareWallGallery = function (element) {
	var name = element.getAttribute('data-name');
	var gals = app.model.roomView.roomSets;//systemBareWalls.Library.BareWallGalleries;
	
	for (var i = 0; i < gals.length; i++) {
		if (gals[i].Name == name) {
			app.model.roomView.currentRoomSet = gals[i];
			return;
		}
	}
	
	error('did not find a bareWall gallery...');
}



app.commands.roomView.resizeBackground = function() {	
	error('app.commands.roomView.resizeBackground is deprecated');
	app.commands.roomView.updateDLE();
	return;
};
app.commands.roomView.updateForeground = function(payload) {
	error('app.commands.roomView.updateForeground is deprecated');
	app.commands.roomView.updateDLE();
	return;

}
app.commands.roomView.fadeInItem = function(item) {
	var htmlNode = $art.g('dle_foreground');
	if (!htmlNode) { error('roomView_fadeOutItem > could not find HTML node for #'+item.ItemGalleryItemID+'. Cannot fade out.'); return; };
	
	info('fading in item #'+item.ItemGalleryItemID);
	UIUtil.fadeIn(htmlNode,333);
}
app.commands.roomView.fadeOutItem = function(item) {
	var htmlNode = $art.g('dle_foreground');
	if (!htmlNode) { error('roomView_fadeOutItem > could not find HTML node for #'+item.ItemGalleryItemID+'. Cannot fade out.'); return; };
	
	UIUtil.fadeOut(htmlNode,333);
}

if (!app.global) app.global = {};
if (!app.global.roomView) app.global.roomView = {};
	
app.global.roomView.roomBrowserStatus = 'closed';
app.global.roomView.roomBrowserTargetY = -110;
app.commands.roomView.openRoomBrowser = function(override) {
	var action;
	if ( app.global.roomView.roomBrowserStatus=='closed' ) action = 'open';
	else action = 'closed';
	
	app.view.roomView.initRoomDrawer();
	
	if (typeof(override)=='string') action = override;
	
	if (action=='open') {
		UIUtil.animate($art.g('roomBrowser'),300,{bottom:0});
		app.global.roomView.roomBrowserStatus = 'open';
	} else {
		//if (app.global.roomView.roomBrowserStatus==action) $art.g('roomBrowser').style.bottom = app.global.roomView.roomBrowserTargetY; 
		//else 
			UIUtil.animate($art.g('roomBrowser'),300,{bottom:app.global.roomView.roomBrowserTargetY});
		app.global.roomView.roomBrowserStatus = 'closed';
	}
	com.art.core.controller.Controller.notify( 'roomView_changeRoomToggle' , action );
}

app.global.roomView_closeRoomBrowser_timer = null;
app.commands.roomView.closeRoomBrowser = function() {
	app.global.roomView_closeRoomBrowser_timer = window.setTimeout(function() {
		UIUtil.animate($art.g('roomBrowser'),500,{bottom:app.global.roomView.roomBrowserTargetY});
		app.commands.roomView.toggleMoreRooms('false');
	},350);		
	//$art.g('roomBrowser').addEventListener('mouseover',function() { window.clearTimeout(roomView_closeRoomBrowser_timer); });
	UIUtil.bind($art.g('roomBrowser'),'mouseover',function() { window.clearTimeout(app.global.roomView_closeRoomBrowser_timer); }, true);
	UIUtil.bind($art.g('moreRooms_panel'),'mouseover',function() { window.clearTimeout(app.global.roomView_closeRoomBrowser_timer); }, true);
	UIUtil.bind($art.g('moreRooms_panel'),'mouseout',app.commands.roomView.closeRoomBrowser);
}

app.commands.roomView.toggleMoreRooms = function(forceStatus) {
	//$art.g('moreRooms_panel').className = $art.g('moreRooms_panel').className=='enabled' ? 'disabled' : 'enabled';
	var target = $art.g('moreRooms_panel');
	
	var status = target.getAttribute('data-enabled');
	if (status=='false') status='true'; else status='false';
	if (forceStatus) status = forceStatus;
	target.setAttribute('data-enabled',status);
	
	var top = status=='true' ? '0%' : '100%';
	var height = status=='true' ? '100%' : '0%';
	
	UIUtil.animate(target,500,{top:top,height:height});
}
app.commands.roomView.changeSize = function(itemGalleryItemID,width,height) {
	/*
	if (!whichItem) {
		for (var i = 0; i < room.foregroundItems.length; i++) {
			if (room.foregroundItems[i].enabled) {
				whichItem = room.foregroundItems[i].ItemGalleryItemID
				break;
			}
		}
	}
	*/
	if (!itemGalleryItemID) itemGalleryItemID = '1585171'; // hack!!!
	var item = app.model.roomView.foregroundItems[0]; // hack!!!!
	var node = $art.g('dle_foreground');
	
	var bwi = app.model.roomView.bareWall.WallAreaWidthInches;
	var bwp = app.model.roomView.bareWall.WallAreaWidth;
	var icr = bwi/bwp;			
	
	item.ItemDetails.PhysicalDimensions.Width = width;
	item.ItemDetails.PhysicalDimensions.Height = height;

	width /= icr;
	height /= icr;
	
	this.filterRooms();
	
	var rby;
	var rbh;
	
	if (app.model.roomView.currentRoomSet.length < 6 || prd_roomView_touch || app.global.roomView.isMacOSXLion) {
		app.global.roomView.roomBrowserTargetY = -94;
		rbh = 114;
	} else {
		app.global.roomView.roomBrowserTargetY = -110;
		rbh = 130;	
	}
	
	if (app.global.roomView.roomBrowserStatus=='open') rby = 0;
	else rby = app.global.roomView.roomBrowserTargetY;
	
	UIUtil.animate($art.g('roomBrowser'),200,{bottom:rby,height:rbh});
	
	this.updateDLE();
	
	//UIUtil.animate(node,300,{width:width,height:height});

	try {
		// update foreground image, if necessary
		var oldUrl = app.model.roomView.currentForegroundItem.ItemDetails.ImageInformation.LargeImage.HttpImageURL;
		var newUrl = $('#MainImage').attr('src');
		if (newUrl != oldUrl) {
			app.model.roomView.currentForegroundItem.ItemDetails.ImageInformation.LargeImage.HttpImageURL = newUrl;
			$('dle_foreground').attr('src',newUrl);
		}
	} catch(e) {
		error('roomViewCommands.js > changeSize > tried to change foreground image src, but failed. error to follow.');
		error(e);
	}
}
app.commands.roomView.filterRooms = function() {
	var item = app.model.roomView.foregroundItems[0];
	var itemWidthInches = item.ItemDetails.PhysicalDimensions.Width;
	var itemHeightInches = item.ItemDetails.PhysicalDimensions.Height;
	
	app.model.roomView.currentRoomSet = app.model.roomView.allRooms.filter( function(bw) {
		//var bw = app.model.roomView.bareWall;
		var ppi = bw.WallAreaWidth / bw.WallAreaWidthInches;
		var usableAreaWidthPixels = parseFloat(bw.UsableAreaWidth);
		var usableAreaHeightPixels = parseFloat(bw.UsableAreaHeight);
		if (!app.model.roomView.bareWall.adjustedDimensions)
			warn('roomViewCommands.js > filterRooms > warning: app.model.roomView.bareWall.adjustedDimensions is null.');
		else
			usableAreaHeightPixels += app.model.roomView.bareWall.adjustedDimensions.y;
		
		var roomWidthInches = usableAreaWidthPixels / ppi;
		var roomHeightInches = usableAreaHeightPixels / ppi;
		if (itemWidthInches > roomWidthInches || itemHeightInches > roomHeightInches) return false;
		else return true;
	});
		
	//app.model.roomView.currentRoomSet.unshift( { ThumbnailURL: 'http://cache1.artprintimages.com/images/modules/roomView/UMR-txt.jpg', isUploadButton:true } );
	
}
app.commands.roomView.deleteWall = function(obj) {
	var i = obj.getAttribute('data-index');
	var node = $art.g('roomView_thumbnail_'+i);
	var room = app.model.roomView.currentRoomSet[i];
	
	var str = localStorage.getItem('roomView_deletedRooms');
	if (!str) str = '';
	
	if (str.length>0) str += ',';
	str += room.URL;
		
	localStorage.setItem( 'roomView_deletedRooms' , str );
	
	function removeWall() {
		node.style.display = 'none';
	}
	
	UIUtil.animate( node, 400, { opacity: 0, done: removeWall } );
}
app.commands.roomView.upload = function() {
	var notLoggedIn = MyGalleriesCore.getModel().user.isAccountTypeAnonymous()
	
	if ( notLoggedIn ) { dle_myGalleriesLogin(); return; }
	
	var whichUploader = 'new';

	if (typeof(FileReader) == 'undefined') whichUploader = 'old';
	
	switch (whichUploader) {
		case 'old':	app.view.roomView.showUploadModal(); break;
		case 'new': 
		//alert('new uploader');
			var uploader = app.view.roomView.getUploader();
			uploader.open();
	}
}
app.commands.roomView.measure = function() {	
	$art.jvml.getComponentById('roomView_measureModal').open();
	app.view.roomView.startMeasuringWithRuler();
	document.getElementById('roomView_measureModal').style.left = '476px';
	UIUtil.animate( document.getElementById('roomView_measureModal'), 250, { left: { start: 476, end: 496 } } );
	
	// clear form fields
	$art.g('roomView_measureModal_input').value = '';
	$art.g('roomView_measureModal_error').innerHTML = '';
	
	$('#roomView_measureRoomContainer').hide();
	$('#roomView_measureLightbox').show();
}
app.commands.roomView.restoreLastViewedRoom = function() {
	if ($art.g('roomBrowser')==null) return;
	if (localStorage && localStorage.getItem('roomView_lastRoom')) {
		for (var i = 0; i < app.model.roomView.currentRoomSet.length; i++) {
			if (app.model.roomView.currentRoomSet[i].ThumbnailURL==localStorage.getItem('roomView_lastRoom')) {
				app.commands.roomView.setBareWall({index:i});
				info('roomViewCommands.js > app.commands.roomView.restoreLastViewedRoom > found it! '+localStorage.getItem('roomView_lastRoom'));
				return;
			}
		}
	}
	info('roomViewCommands.js > app.commands.roomView.restoreLastViewedRoom > could not find room with thumbnail URL: '+localStorage.getItem('roomView_lastRoom'));
}
app.commands.roomView.triggerLogin = function() {
	dle_myGalleriesLogin();
}
app.commands.roomView.triggerSignup = function() {
	dle_myGalleriesRegister();
}












app.global.roomView.fillMethod = 'fill';


var $roomViewTemp = {};

app.commands.roomView.updateDLE = function() {
	// updates background and foreground alike
	info('roomViewCommands > updateDLE begin');
	
	var item = app.model.roomView.currentForegroundItem;
	//var fg = $art.g('dle_foreground_'+item.ItemGalleryItemID);
	var fg = $art.g('dle_foreground');
	var bg = $art.g('bareWallImg');
	
	//if (!bg.complete) {
	if (!art.view('bareWallImg').imageLoaded) {
		warn('app.commands.roomView.updateDLE > unable to update. Background image load is not complete.');
		return;
	}
	if (!fg.complete) {
		warn('app.commands.roomView.updateDLE > unable to update. Foreground image is not ready.');
		return;
	}
	if ( !$(bg).is(':visible') || !$(fg).is(':visible') ) {
		warn('app.commands.roomView.updateDLE > unable to update. Background or foreground is not visible.');
		return;		
	}
	info('roomViewCommands > updateDLE > actually running.');
	
	// enable/disable
	/*
	if (item.enabled && node.style.display=='none') roomView_fadeInItem(item);
	if (!item.enabled && node.style.display!='none') roomView_fadeOutItem(item);
	*/
	
	// step 1: fit background image to container
	var nativeWidth = bg.naturalWidth;
	var nativeHeight = bg.naturalHeight;
	if (!nativeWidth) {
		// in IE8, naturalWidth and height don't exist. so...
		var img = new Image();
		img.src = bg.src;
		nativeWidth = img.width;
		nativeHeight = img.height;
	}
	var nativeAspect = nativeWidth / nativeHeight;
	/*
	info('app.commands.roomView.resizeBackground > nativeWidth = '+nativeWidth);
	info('app.commands.roomView.resizeBackground > nativeHeight = '+nativeHeight);
	*/
	if (nativeWidth==0||nativeHeight==0) {
		error('app.commands.roomView.updateDLE > ERROR. This browser is dumb. The image has definitely loaded, but somehow doesn\'t have a naturalWidth or naturalHeight yet. Aborting. Image node to follow.');
		error(img);
		error(img.naturalWidth);
		error(img.naturalHeight);
		return;
	}
	
	var bgContainer = $art.g('dle_background');
	var containerWidth = bgContainer.offsetWidth;
	var containerHeight = bgContainer.offsetHeight;
	if (roomView_forceRoomViewContainerHeight) {
		if (containerHeight != roomView_forceRoomViewContainerHeight)
			warn('roomViewCommands.js > updateDLE > despite explicitly setting the height of RoomViewContainer, the browser has decided to suck, and got the value wrong. Not to worry, got it covered. containerHeight='+containerHeight+', roomView_forceRoomViewContainerHeight='+roomView_forceRoomViewContainerHeight);
		containerHeight = roomView_forceRoomViewContainerHeight;
	}
	containerHeight = parseInt(app.view.roomView.containerHeight);
	info('roomViewCommands.js > updateDLE > HAHAHA DISREGARD THAT containerHeight='+containerHeight);
	var containerAspect = containerWidth / containerHeight;
	info('roomViewCommands.js > updateDLE > background stats: nativeAspect='+nativeAspect+', containerWidth='+containerWidth+', containerHeight='+containerHeight+', containerAspect='+containerAspect);
	
	var fillMethod = app.global.roomView.fillMethod;//'fill'; // options: fill, letterbox
	info('roomViewCommands.js > updateDLE > fillMethod = '+fillMethod);
	var tx = 0;
	var ty = 0;
	var tw = '';
	var th = '';
	var fgTargetWidth;
	var fgTargetHeight;
	var fgTargetX = 0;
	var fgTargetY = 0;
	switch(fillMethod) {
		case 'fill':
			if (nativeAspect>containerAspect) {				
				// match heights, image will be wider than container
				th = containerHeight;
				tw = th * nativeAspect;
				info('roomViewCommands.js > updateDLE > fill mode, bg is wider than container. Matching heights. tw='+tw+', th='+th);
			} else {
				// match widths, vertically center
				tw = containerWidth;
				th = tw / nativeAspect;
				ty = (containerHeight-th)/2;
				info('roomViewCommands.js > updateDLE > fill mode, bg is taller than container. Matching widths. tw='+tw+', th='+th+', ty='+ty);
			}
			fgTargetWidth = containerWidth;
			fgTargetHeight = containerHeight;
			break;
		case 'letterbox':
			var tw, th, tx, ty;
			if (nativeAspect>containerAspect) {
				info('app.commands.roomView.updateDLE > landscape letterbox mode');
				// bg image is wider than container--match widths, change y value
				tw = containerWidth;
				th = tw / nativeAspect;
				ty = (containerHeight-th)/2;
			} else {
				// container is wider than bg image--match heights, change x value
				info('app.commands.roomView.updateDLE > portrait letterbox mode');
				th = containerHeight;
				tw = th * nativeAspect;
				tx = (containerWidth-tw)/2;
			}
			fgTargetX = tx;
			fgTargetY = ty;
			fgTargetWidth = tw;
			fgTargetHeight = th;
			break;				
	}
	

	// move/size background image
	bg.style.left = tx+'px';
	bg.style.top = ty+'px';
	bg.style.width = tw+'px';
	bg.style.height = th+'px';
	
	info('roomViewCommands > updateDLE > bg coords: tw='+tw+', th='+th);
	
	app.model.roomView.bareWall.adjustedDimensions = { x:tx, y:ty, w:tw, h:th };
	
	// change foreground container position; should mask movement of foreground images
	var fgContainer = $art.g('dle');
	var fgx1 = fgContainer.offsetLeft;
	fgContainer.style.left = fgTargetX+'px';
	fgContainer.style.top = fgTargetY+'px';
	fgContainer.style.width = fgTargetWidth+'px';
	fgContainer.style.height = fgTargetHeight+'px';
	var dx = fgx1-tx;
	
	var fgix = fg.offsetLeft;
	fg.style.left = fgix + dx+'px';
	
	// move hover controls so they are always in the bottom left of the bg image
	$art.g('hoverControls').style.left = tx + 5 + 'px';
	
	
	// calculate foreground image size
	var bwi = app.model.roomView.bareWall.WallAreaWidthInches;
	var bwp = tw;
	var icr = bwi/bwp;
	var fwi = item.ItemDetails.PhysicalDimensions.Width;
	var fwp = fwi/icr;
	var fhi = item.ItemDetails.PhysicalDimensions.Height;
	var fhp = fhi/icr;
	
	var bw = app.model.roomView.bareWall;	
	var bgh = fillMethod=='letterbox' ? th : containerHeight;
	var bgw = fillMethod=='letterbox' ? tw : containerWidth;
	
	if (bgh==0) {
		error('app.commands.roomView.updateDLE > unable to position foreground item. background image has no height.');		
		
		//UIUtil.animate(fg,400,{width:fwp,height:fhp});
	} else {
	
		// target x = center
		// target y = bottom: 40% relative to bg image		
		
		var foregroundTargetX = bgw/2 - fwp/2;
		var foregroundTargetY = ty + th * 0.4 - fhp;
		if (foregroundTargetY<20) foregroundTargetY = 20;
		
		// or...
		var bw = app.model.roomView.bareWall;
		if (bw.ProductTargetAreaPosY&&bw.WallAreaHeight) {
			var altY = ty + (bw.ProductTargetAreaPosY / bw.WallAreaHeight) * th - fhp;
			if (!isNaN(altY) && altY >= 20 && altY < (th-fhp) ) {
				warn('using altY='+altY+' instead of y='+foregroundTargetY);
				foregroundTargetY = altY;
			} else {
				warn('NOT USING altY='+altY+' instead of y='+foregroundTargetY);
			}
		}
		
		//ty *= bgh / parseFloat(bw.WallAreaHeight);
		/*
		var ty2 = parseFloat(bw.UsableAreaPosY)+parseFloat(bw.UsableAreaHeight)-fhp;
		ty2 *= bgh  / parseFloat(bw.WallAreaHeight);
		
		if (ty+fhp>175) ty = ty2;
		if (ty2+fhp>175) ty = 20;
		*/
		
		var l =  foregroundTargetX;
		var t =  foregroundTargetY;
	
		if (l < 0) l = 0;
		if (t < 0) t = 0;
		//node.style.top = t + 'px';
		//node.style.left = l + 'px';
		
		if ( fg.style.top == '-1px' ) t = { start: t-10, end: t };
		
		//node.style.width = fwp+'px';
		UIUtil.animate(fg,400,{width:fwp,height:fhp,top:t,left:l});
		
	}
	
	//update image
	if (item.ItemDetails.ImageInformation.LargeImage.HttpImageURL != fg.src) fg.src = item.ItemDetails.ImageInformation.LargeImage.HttpImageURL;

	info('updateDLE end');	
}


